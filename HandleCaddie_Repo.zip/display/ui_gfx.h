// ui_gfx.h - small anti-aliased 2D layer for the 480x320 landscape UI.
//
// Draws straight into the Arduino_Canvas RGB565 framebuffer (320x480 native).
// Landscape (x,y) maps to native index  x*320 + (319 - y)  (same as Arduino_GFX
// rotation 1, which is what the JC3248W535EN library uses for text).
//
// No Arduino dependencies on purpose, so it can also be compiled on a PC for
// previewing the layout.
#pragma once
#include <stdint.h>
#include <math.h>
#include <string.h>
#include "ui_fonts.h"

namespace ui {

static const int W = 480;
static const int H = 320;
static const int NATIVE_STRIDE = 320;

static uint16_t* fb = nullptr;
inline void begin(uint16_t* framebuffer) { fb = framebuffer; }

// ---- colour helpers (colours are 0xRRGGBB) ---------------------------------
inline uint16_t to565(uint32_t c) {
  return (uint16_t)(((c >> 8) & 0xF800) | ((c >> 5) & 0x07E0) | ((c >> 3) & 0x001F));
}

// Ordered (Bayer 4x4) dither so gradients don't show banding in RGB565.
inline uint16_t to565d(uint32_t c, int x, int y) {
  static const uint8_t B[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};
  int t = B[((y & 3) << 2) | (x & 3)];
  int r = (int)((c >> 16) & 0xFF) + ((t * 8) >> 4);
  int g = (int)((c >> 8) & 0xFF) + ((t * 4) >> 4);
  int b = (int)(c & 0xFF) + ((t * 8) >> 4);
  if (r > 255) r = 255;
  if (g > 255) g = 255;
  if (b > 255) b = 255;
  return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3));
}

inline uint32_t mix(uint32_t a, uint32_t b, float t) {
  if (t < 0) t = 0;
  if (t > 1) t = 1;
  int r = (int)(((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t + 0.5f);
  int g = (int)(((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t + 0.5f);
  int bl = (int)((a & 0xFF) * (1 - t) + (b & 0xFF) * t + 0.5f);
  return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)bl;
}

inline void fillScreen(uint32_t c) {
  uint16_t v = to565(c);
  for (int i = 0; i < NATIVE_STRIDE * 480; i++) fb[i] = v;
}

// ---- pixel / rect ----------------------------------------------------------
inline void blendPx(int x, int y, uint32_t c, uint8_t a) {
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H || a == 0) return;
  uint16_t* p = &fb[x * NATIVE_STRIDE + (NATIVE_STRIDE - 1 - y)];
  if (a == 255) { *p = to565(c); return; }
  uint16_t d = *p;
  int dr = (d >> 11) & 31, dg = (d >> 5) & 63, db = d & 31;
  int sr = (c >> 19) & 31, sg = (c >> 10) & 63, sb = (c >> 3) & 31;
  int a1 = a + (a >> 7);
  dr += ((sr - dr) * a1 + 128) >> 8;
  dg += ((sg - dg) * a1 + 128) >> 8;
  db += ((sb - db) * a1 + 128) >> 8;
  *p = (uint16_t)((dr << 11) | (dg << 5) | db);
}

inline void fillRect(int x, int y, int w, int h, uint32_t c, uint8_t a = 255) {
  int x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
  int x1 = x + w > W ? W : x + w, y1 = y + h > H ? H : y + h;
  if (x1 <= x0 || y1 <= y0) return;
  if (a == 255) {
    uint16_t v = to565(c);
    for (int xx = x0; xx < x1; xx++) {
      uint16_t* p = &fb[xx * NATIVE_STRIDE + (NATIVE_STRIDE - y1)];
      for (int n = y1 - y0; n > 0; n--) *p++ = v;
    }
  } else {
    for (int xx = x0; xx < x1; xx++)
      for (int yy = y0; yy < y1; yy++) blendPx(xx, yy, c, a);
  }
}

// ---- rounded rectangle / circle (signed-distance, sub-pixel accurate) -------
static inline float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

// Fill is a vertical gradient from `top` to `bot` (equal = flat colour).
// strokeW > 0 draws an inside border in `stroke`.  fillA is 0..255.
inline void rrect(float x, float y, float w, float h, float r,
                  uint32_t top, uint32_t bot, uint8_t fillA = 255,
                  float strokeW = 0, uint32_t stroke = 0, uint8_t strokeA = 255) {
  if (r > w * 0.5f) r = w * 0.5f;
  if (r > h * 0.5f) r = h * 0.5f;
  float cx = x + w * 0.5f, cy = y + h * 0.5f, hw = w * 0.5f, hh = h * 0.5f;
  int x0 = (int)floorf(x) - 1, y0 = (int)floorf(y) - 1;
  int x1 = (int)ceilf(x + w) + 1, y1 = (int)ceilf(y + h) + 1;
  if (x0 < 0) x0 = 0;
  if (y0 < 0) y0 = 0;
  if (x1 > W) x1 = W;
  if (y1 > H) y1 = H;
  bool flat = (top == bot);
  uint16_t flat565 = to565(top);
  float inv = h > 0 ? 1.0f / h : 0;

  for (int xx = x0; xx < x1; xx++) {
    float qx0 = fabsf(xx + 0.5f - cx) - (hw - r);
    for (int yy = y0; yy < y1; yy++) {
      float qy = fabsf(yy + 0.5f - cy) - (hh - r);
      float d = (qx0 > 0 && qy > 0) ? sqrtf(qx0 * qx0 + qy * qy) - r
                                    : (qx0 > qy ? qx0 : qy) - r;
      float cov = clamp01(0.5f - d);
      if (cov <= 0) continue;
      uint32_t fc = flat ? top : mix(top, bot, (yy + 0.5f - y) * inv);

      // fast path: fully inside, opaque, not near the border
      if (fillA == 255 && d < -(strokeW + 1.0f)) {
        fb[xx * NATIVE_STRIDE + (NATIVE_STRIDE - 1 - yy)] = flat ? flat565 : to565d(fc, xx, yy);
        continue;
      }
      uint8_t fa = (uint8_t)(cov * fillA + 0.5f);
      if (fa) {
        if (!flat && fa == 255) fb[xx * NATIVE_STRIDE + (NATIVE_STRIDE - 1 - yy)] = to565d(fc, xx, yy);
        else blendPx(xx, yy, fc, fa);
      }
      if (strokeW > 0) {
        float sc = cov * clamp01(d + strokeW + 0.5f);
        uint8_t sa = (uint8_t)(sc * strokeA + 0.5f);
        if (sa) blendPx(xx, yy, stroke, sa);
      }
    }
  }
}

inline void box(float x, float y, float w, float h, float r, uint32_t c, uint8_t a = 255) {
  rrect(x, y, w, h, r, c, c, a, 0, 0, 0);
}

inline void circle(float cx, float cy, float r, uint32_t c, uint8_t a = 255,
                   float strokeW = 0, uint32_t stroke = 0) {
  rrect(cx - r, cy - r, 2 * r, 2 * r, r, c, c, a, strokeW, stroke, 255);
}

// ring only (no fill)
inline void ring(float cx, float cy, float r, float w, uint32_t c, uint8_t a = 255) {
  rrect(cx - r, cy - r, 2 * r, 2 * r, r, c, c, 0, w, c, a);
}

// ---- line with round caps ---------------------------------------------------
inline void line(float ax, float ay, float bx, float by, float w, uint32_t c, uint8_t a = 255) {
  float hw = w * 0.5f;
  int x0 = (int)floorf((ax < bx ? ax : bx) - hw) - 1, x1 = (int)ceilf((ax > bx ? ax : bx) + hw) + 1;
  int y0 = (int)floorf((ay < by ? ay : by) - hw) - 1, y1 = (int)ceilf((ay > by ? ay : by) + hw) + 1;
  if (x0 < 0) x0 = 0;
  if (y0 < 0) y0 = 0;
  if (x1 > W) x1 = W;
  if (y1 > H) y1 = H;
  float dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
  for (int xx = x0; xx < x1; xx++) {
    for (int yy = y0; yy < y1; yy++) {
      float px = xx + 0.5f - ax, py = yy + 0.5f - ay;
      float t = l2 > 0 ? (px * dx + py * dy) / l2 : 0;
      t = clamp01(t);
      float ex = px - t * dx, ey = py - t * dy;
      float d = sqrtf(ex * ex + ey * ey) - hw;
      float cov = clamp01(0.5f - d);
      if (cov > 0) blendPx(xx, yy, c, (uint8_t)(cov * a + 0.5f));
    }
  }
}

inline void dashedLine(float ax, float ay, float bx, float by, float w, float dash, float gap,
                       uint32_t c, uint8_t a = 255) {
  float dx = bx - ax, dy = by - ay, len = sqrtf(dx * dx + dy * dy);
  if (len < 1) return;
  float ux = dx / len, uy = dy / len;
  for (float s = 0; s < len; s += dash + gap) {
    float e = s + dash > len ? len : s + dash;
    line(ax + ux * s, ay + uy * s, ax + ux * e, ay + uy * e, w, c, a);
  }
}

// ---- anti-aliased polygon (even-odd, handles concave) -----------------------
struct PtF { float x, y; };

// clipY0/clipY1 restrict drawing to a band of rows, clipX0/clipX1 to a band of columns (used for mowing stripes).
inline void polyFill(const PtF* p, int n, uint32_t c, uint8_t alpha = 255, int clipY0 = 0, int clipY1 = H, int clipX0 = 0, int clipX1 = W) {
  if (n < 3) return;
  float ymin = p[0].y, ymax = p[0].y;
  for (int i = 1; i < n; i++) {
    if (p[i].y < ymin) ymin = p[i].y;
    if (p[i].y > ymax) ymax = p[i].y;
  }
  int ya = (int)floorf(ymin), yb = (int)ceilf(ymax);
  if (ya < clipY0) ya = clipY0;
  if (yb > clipY1) yb = clipY1;
  if (ya < 0) ya = 0;
  if (yb > H) yb = H;
  static float acc[W + 2];
  float xs[128];

  for (int y = ya; y < yb; y++) {
    int minx = W, maxx = -1;
    for (int i = 0; i < W + 2; i++) acc[i] = 0;
    for (int s = 0; s < 4; s++) {
      float sy = y + (s + 0.5f) * 0.25f;
      int k = 0;
      for (int i = 0, j = n - 1; i < n; j = i++) {
        float ay = p[j].y, by = p[i].y;
        if ((ay <= sy) != (by <= sy) && k < 128) {
          xs[k++] = p[j].x + (sy - ay) * (p[i].x - p[j].x) / (by - ay);
        }
      }
      for (int a = 1; a < k; a++) {          // insertion sort
        float v = xs[a];
        int b = a - 1;
        while (b >= 0 && xs[b] > v) { xs[b + 1] = xs[b]; b--; }
        xs[b + 1] = v;
      }
      for (int a = 0; a + 1 < k; a += 2) {
        float x0 = xs[a], x1 = xs[a + 1];
        if (x1 <= clipX0 || x0 >= clipX1) continue;
        if (x0 < clipX0) x0 = clipX0;
        if (x1 > clipX1) x1 = clipX1;
        int i0 = (int)floorf(x0), i1 = (int)floorf(x1);
        if (i0 < minx) minx = i0;
        if (i1 > maxx) maxx = i1;
        if (i0 == i1) {
          acc[i0] += (x1 - x0) * 0.25f;
        } else {
          acc[i0] += (i0 + 1 - x0) * 0.25f;
          for (int i = i0 + 1; i < i1; i++) acc[i] += 0.25f;
          acc[i1] += (x1 - i1) * 0.25f;
        }
      }
    }
    if (maxx < 0) continue;
    if (maxx > W - 1) maxx = W - 1;
    for (int x = minx; x <= maxx; x++) {
      float cv = acc[x];
      if (cv > 0.002f) blendPx(x, y, c, (uint8_t)(clamp01(cv) * alpha + 0.5f));
    }
  }
}

inline void polyStroke(const PtF* p, int n, float w, uint32_t c, uint8_t a = 255) {
  for (int i = 0, j = n - 1; i < n; j = i++) line(p[j].x, p[j].y, p[i].x, p[i].y, w, c, a);
}

// ---- text -------------------------------------------------------------------
enum { ALIGN_LEFT = 0, ALIGN_CENTER = 1, ALIGN_RIGHT = 2 };

inline int glyphIndex(const AAFont& f, unsigned char ch) {
  if (ch < f.first || ch > f.last) return -1;
  return ch - f.first;
}

inline float textWidthF(const AAFont& f, const char* s, float tracking = 0) {
  float w = 0;
  for (; *s; s++) {
    int gi = glyphIndex(f, (unsigned char)*s);
    if (gi < 0) continue;
    w += f.glyphs[gi].adv16 / 16.0f + tracking;
  }
  return w > 0 ? w - tracking : 0;
}
inline int textWidth(const AAFont& f, const char* s, float tracking = 0) {
  return (int)(textWidthF(f, s, tracking) + 0.5f);
}

// y is the text BASELINE.
inline void text(const AAFont& f, float x, int y, const char* s, uint32_t c,
                 int align = ALIGN_LEFT, float tracking = 0, uint8_t alpha = 255) {
  float cx = x;
  if (align == ALIGN_CENTER) cx -= textWidthF(f, s, tracking) * 0.5f;
  else if (align == ALIGN_RIGHT) cx -= textWidthF(f, s, tracking);
  for (; *s; s++) {
    int gi = glyphIndex(f, (unsigned char)*s);
    if (gi < 0) continue;
    const AAGlyph& g = f.glyphs[gi];
    if (g.w && g.h) {
      int gx = (int)floorf(cx + 0.5f) + g.xo;
      int gy = y + g.yo;
      const uint8_t* bm = f.bitmap + g.off;
      for (int j = 0; j < g.h; j++) {
        int py = gy + j;
        if ((unsigned)py >= (unsigned)H) { bm += g.w; continue; }
        for (int i = 0; i < g.w; i++) {
          uint8_t a = bm[i];
          if (a) blendPx(gx + i, py, c, alpha == 255 ? a : (uint8_t)((a * alpha + 127) / 255));
        }
        bm += g.w;
      }
    }
    cx += g.adv16 / 16.0f + tracking;
  }
}

}  // namespace ui
