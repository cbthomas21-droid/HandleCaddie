// club_detector.h - turns raw "is something in front of the sensor?" samples
// into debounced PULLED / RETURNED events.  No hardware code in here so it can
// be unit-tested on a PC.
//
// Assumed mounting: the VL6180X (range ~0-100 mm) looks at the club grip/shaft
// in its slot.  Club present  => short range reading.
//                  Club pulled => nothing in range.
#pragma once
#include <stdint.h>

class ClubDetector {
 public:
  enum Event { NONE = 0, PULLED, RETURNED };

  // pullConfirmMs  : how long the club must be gone before we call it "pulled"
  // returnConfirmMs: how long it must be back before we call it "returned"
  ClubDetector(uint32_t pullConfirmMs = 500, uint32_t returnConfirmMs = 400)
      : pullMs_(pullConfirmMs), retMs_(returnConfirmMs) {}

  // Call once per sensor sample. `present` = club detected in front of sensor.
  Event update(bool present, uint32_t nowMs) {
    if (!init_) {                       // first sample defines the starting state, no event
      init_ = true;
      inBag_ = present;
      candSince_ = 0;
      return NONE;
    }
    if (present == inBag_) {            // agrees with current state: cancel any pending change
      candSince_ = 0;
      return NONE;
    }
    if (candSince_ == 0) candSince_ = nowMs ? nowMs : 1;
    uint32_t need = inBag_ ? pullMs_ : retMs_;
    if (nowMs - candSince_ < need) return NONE;

    candSince_ = 0;
    inBag_ = present;
    if (!present) {
      pulledAt_ = nowMs;
      return PULLED;
    }
    lastHeldMs_ = nowMs - pulledAt_;
    return RETURNED;
  }

  bool clubOut() const { return init_ && !inBag_; }
  uint32_t lastHeldMs() const { return lastHeldMs_; }
  // Pretend the club state is `out` (used when the user taps the strip manually).
  void force(bool out, uint32_t nowMs) {
    init_ = true;
    inBag_ = !out;
    candSince_ = 0;
    if (out) pulledAt_ = nowMs;
  }

 private:
  uint32_t pullMs_, retMs_;
  bool init_ = false, inBag_ = true;
  uint32_t candSince_ = 0, pulledAt_ = 0, lastHeldMs_ = 0;
};
