// ===========================================================================
//  HandleCaddie  -  push-cart golf dashboard
//  ESP32-S3 + JC3248W535EN 3.5" touch LCD (AXS15231B) + VL6180X club sensor
//
//  Division of labour
//    Phone app  : GPS, zone (tee / fairway / rough / green), stroke counting,
//                 shot distance, club recommendation, course data, scoring.
//    This unit  : shows what the app sends, reads the club sensor and tells the
//                 app when a club is pulled / returned, takes touch input.
//
//  Libraries (Library Manager):  GFX Library for Arduino, ArduinoJson (v7),
//  Adafruit VL6180X (pulls in Adafruit BusIO), JPEGDecoder, and the
//  JC3248W535EN-Touch-LCD library you already have.
//
//  Files in this folder:  ui_fonts.h (generated), ui_gfx.h, ui_screens.h,
//  club_detector.h.  Keep them next to this .ino.
// ===========================================================================
#include <JC3248W535EN-Touch-LCD.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <ArduinoJson.h>
#include <Adafruit_VL6180X.h>
#include <vector>
#include <Preferences.h>

#include "ui_screens.h"
#include "club_detector.h"
#include "display_gate.h"

JC3248W535EN screen;

// ---------------------------------------------------------------------------
// USER SETTINGS
// ---------------------------------------------------------------------------
// Touch calibration: tap the four corners with the Serial Monitor open (115200)
// and adjust until top-left reads ~(0,0) and bottom-right ~(479,319).
#define TOUCH_SWAP_XY   0
#define TOUCH_FLIP_X    0
#define TOUCH_FLIP_Y    0
#define TOUCH_DEBUG     0     // 1 = print touch coords + draw a red dot (calibration only)

// Club sensor (VL6180X / "TOF050C").
#define TOF_SHARED_BUS  1     // 1 = share the touch I2C bus (SDA 4 / SCL 8, no extra Wire.begin)
                              // 0 = use separate pins below on Wire1
#define TOF_SDA         17
#define TOF_SCL         18
#define TOF_PRESENT_MM  80    // closer than this (and valid) = club is in the slot
#define TOF_POLL_MS     50
#define TOF_DEBUG       0     // 1 = print range readings (or send "range" on Serial)

// If the phone is not connected the unit keeps its own rough stroke count.
#define OFFLINE_COUNT_ON_RETURN  1
#define OFFLINE_MIN_HELD_MS      8000   // ignore quick club swaps

// Minimum time the splash screen stays up (the bar fills smoothly over this time).
#define SPLASH_MIN_MS   2000

// Who may talk to the display over Bluetooth (see display_gate.h). 1 = the phone must prove it holds the display's key first
// (the first time, it pairs with a PIN shown on this screen). 0 = anyone can connect, as before. Needs the matching app.
#define DISPLAY_AUTH    1
#define PAIR_CORNER_W   100   // touch and hold this top-left corner for 4 s to pair another phone
#define PAIR_CORNER_H   46

// Show a sample hole at boot so you can see the layout. The first message
// from the app replaces it.
#define DEMO_ON_BOOT    1

// ---------------------------------------------------------------------------
// BLE (Nordic UART service)
// ---------------------------------------------------------------------------
#define SERVICE_UUID           "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define CHARACTERISTIC_UUID_RX "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"   // app -> unit (write)
#define CHARACTERISTIC_UUID_TX "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"   // unit -> app (notify)

BLEServer *pServer = NULL;
BLECharacteristic *pTxCharacteristic;
BLECharacteristic *pRxCharacteristic;
volatile bool deviceConnected = false;

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
enum ScreenState { SCREEN_DASHBOARD, SCREEN_SCORECARD };
ScreenState currentScreen = SCREEN_DASHBOARD;

AppState S;                          // everything the screens draw
SemaphoreHandle_t dataMutex;         // protects S (BLE task writes, loop task draws)
volatile bool needRedraw = true;
bool demoActive = false;
unsigned long lastDraw = 0, lastTouchDebounce = 0, lastTofPoll = 0, lastTofPrint = 0;

Adafruit_VL6180X tof;
bool tofOk = false;
bool tofDebug = TOF_DEBUG;
ClubDetector detector(500, 400);     // club gone 0.5 s = pulled, back 0.4 s = returned

String rxBuf;                        // BLE receive accumulator (BLE task only)

#if DISPLAY_AUTH
static Preferences prefs;
static cart::DisplayGate gate(esp_random);
static SemaphoreHandle_t gateMutex;          // the gate is used by the BLE task (lines in) and the loop task (everything else)
static String pendingReply;                  // lines to send back to the phone; sent from loop(). Guarded by gateMutex.
static volatile bool bleJustConnected = false, bleJustDropped = false;
static uint32_t bleConnMs = 0;
static bool pairShown = false; static char pairPin[8] = {0}; static uint32_t pairLeftS = 0, pairLastDraw = 0;
#endif
static volatile bool phoneAuthed = !DISPLAY_AUTH;

// Is a phone connected AND (when authentication is on) proven? Everything that talks to the phone or falls back to the offline
// behaviour asks this, not just "connected".
static inline bool phoneReady() { return deviceConnected && phoneAuthed; }

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------
static void sendRaw(const char* s, size_t n) {          // loop task only. Long lines are cut into notifications that fit the MTU
  if (!deviceConnected || !pTxCharacteristic || n == 0) return;
#if DISPLAY_AUTH
  size_t chunk = (millis() - bleConnMs > 2000) ? 200 : 20;   // the app asks for a bigger MTU just after connecting; until then assume the small one
#else
  size_t chunk = 200;
#endif
  for (size_t i = 0; i < n; i += chunk) {
    size_t k = (n - i < chunk) ? (n - i) : chunk;
    pTxCharacteristic->setValue((uint8_t*)(s + i), k);
    pTxCharacteristic->notify();
    if (n > chunk) delay(8);
  }
}

static void sendToApp(const char* json) {
  if (!phoneReady() || !pTxCharacteristic) return;     // nothing goes to a phone that has not proven itself
  String m = String(json) + "\n";
  sendRaw(m.c_str(), m.length());
}

static void resetHoleData(int h) {          // caller holds dataMutex
  S.hole = h;
  S.par = S.pars[h - 1];
  S.holeLen = 0;
  S.toPin = 0;
  S.zone = ZONE_UNKNOWN;
  S.strokes = 0;
  S.putts = 0;
  S.manualPutt = false;
  S.front = S.back = 0;
  S.lastShot = 0;
  S.clubOut = false;
  S.pulledClub[0] = 0;
  S.fairways.clear(); S.greens.clear(); S.bunkers.clear(); S.water.clear();
  S.hasPin = S.hasTee = S.hasPlayer = false;
}

static Zone parseZone(const char* z) {
  if (!z || !*z) return ZONE_UNKNOWN;
  switch (z[0] | 0x20) {                    // lower-case first letter
    case 't': return ZONE_TEE;
    case 'f': return ZONE_FAIRWAY;
    case 'r': return ZONE_ROUGH;
    case 'g': return ZONE_GREEN;
  }
  return ZONE_UNKNOWN;
}

static void loadDemo() {                    // caller holds dataMutex (or is in setup)
  AppState d;
  auto shape = [](std::initializer_list<ui::PtF> l) { Shape s; s.pts.assign(l.begin(), l.end()); smoothShape(s); return s; };
  d.hole = 4; d.par = 4; d.holeLen = 385; d.toPin = 142; d.front = 128; d.back = 156; d.zone = ZONE_FAIRWAY;
  d.strokes = 2; d.lastShot = 231;
  strlcpy(d.club, "7 Iron", sizeof(d.club)); d.clubCarry = 150;
  d.fairways.push_back(shape({{40,395},{78,395},{88,300},{110,230},{150,170},{200,120},{196,70},{150,86},{98,140},{50,230},{34,320}}));
  d.greens.push_back(shape({{176,80},{208,70},{232,88},{228,116},{200,128},{176,112}}));
  d.bunkers.push_back(shape({{150,118},{168,112},{172,132},{154,138}}));
  d.bunkers.push_back(shape({{236,120},{250,126},{246,146},{232,142}}));
  d.bunkers.push_back(shape({{96,210},{110,204},{116,224},{100,230}}));
  d.water.push_back(shape({{0,60},{120,40},{150,60},{120,90},{40,110},{0,100}}));
  d.hasTee = true;    d.tee = {58, 388};
  d.hasPin = true;    d.pin = {204, 98};
  d.hasPlayer = true; d.player = {112, 232};
  int sc[18] = {4,5,3,5,0,0,0,0,0, 0,0,0,0,0,0,0,0,0};
  for (int i = 0; i < 18; i++) d.scores[i] = sc[i];
  d.connected = S.connected;
  S = d;
  demoActive = true;
}

// ---------------------------------------------------------------------------
// Incoming messages (app -> unit)
//
// One JSON object per message, every key optional:
//   "hole":4            switching holes clears the per-hole data
//   "par":4  "len":385  "dist":142  "front":130  "back":154  "zone":"fairway"
//   "strokes":2  "putts":0  "last":231
//   "club":"7 Iron"  "carry":150  "pulled":"7 Iron"  "clubOut":false
//   "fairway"/"green"/"bunkers"/"water": polygon [[x,y],...] or list of polygons
//   "tee":[x,y]  "pin":[x,y]  "player":[x,y]       (same units as the polygons)
//   "pars":[18 ints]  "scores":[18 ints, 0 = not played]
//   "tip":"Birdie. Nicely played."         one line shown over the screen for ~4 s, then faded out
// Messages may be split across several BLE writes if each message ends in '\n'.
// ---------------------------------------------------------------------------
static bool readPoly(JsonArrayConst poly, Shape &out) {
  out.pts.clear();
  for (JsonArrayConst pt : poly) {
    if (pt.size() < 2) continue;
    if (out.pts.size() >= 48) break;
    out.pts.push_back({pt[0].as<float>(), pt[1].as<float>()});
  }
  if (out.pts.size() < 3) return false;
  smoothShape(out);
  return true;
}

static void loadShapes(JsonVariantConst v, std::vector<Shape> &out) {
  out.clear();
  JsonArrayConst arr = v.as<JsonArrayConst>();
  if (arr.isNull() || arr.size() == 0) return;
  if (arr[0][0].is<JsonArrayConst>()) {                 // list of polygons
    for (JsonArrayConst poly : arr) { Shape sh; if (readPoly(poly, sh)) out.push_back(sh); }
  } else {                                              // a single polygon
    Shape sh; if (readPoly(arr, sh)) out.push_back(sh);
  }
}

static bool readPoint(JsonVariantConst v, ui::PtF &p) {
  JsonArrayConst a = v.as<JsonArrayConst>();
  if (a.isNull() || a.size() < 2) return false;
  p.x = a[0].as<float>(); p.y = a[1].as<float>();
  return true;
}

static void applyMessage(JsonDocument &doc) {           // caller holds dataMutex
  if (demoActive) {                                      // real data replaces the demo
    bool c = S.connected;
    S = AppState();
    S.connected = c;
    demoActive = false;
  }

  if (doc["hole"].is<int>()) {
    int h = doc["hole"];
    if (h >= 1 && h <= 18 && h != S.hole) resetHoleData(h);
  }
  if (doc["par"].is<int>())     S.par = doc["par"];
  if (doc["len"].is<int>())     S.holeLen = doc["len"];
  if (doc["dist"].is<int>())    S.toPin = doc["dist"];
  if (doc["distance"].is<int>()) S.toPin = doc["distance"];      // legacy key
  if (doc["strokes"].is<int>()) S.strokes = doc["strokes"];
  if (doc["putts"].is<int>())   S.putts = doc["putts"];
  if (doc["front"].is<int>())   S.front = doc["front"];
  if (doc["back"].is<int>())    S.back = doc["back"];
  if (doc["last"].is<int>())    S.lastShot = doc["last"];
  if (doc["carry"].is<int>())   S.clubCarry = doc["carry"];
  if (doc["zone"].is<const char*>()) {
    S.zone = parseZone(doc["zone"].as<const char*>());
    S.manualPutt = false;                                // the app now decides
  }
  if (doc["club"].is<const char*>())   strlcpy(S.club, doc["club"].as<const char*>(), sizeof(S.club));
  if (doc["tip"].is<const char*>()) {                    // caddie tip: show for a moment, then fade
    strlcpy(S.tip, doc["tip"].as<const char*>(), sizeof(S.tip));
    S.tipStartMs = millis();
    Serial.printf("tip shown: %s\n", S.tip);
  }
  if (doc["pulled"].is<const char*>()) strlcpy(S.pulledClub, doc["pulled"].as<const char*>(), sizeof(S.pulledClub));
  if (doc["clubOut"].is<bool>()) {
    S.clubOut = doc["clubOut"];
    detector.force(S.clubOut, millis());
  }

  if (!doc["fairway"].isNull()) loadShapes(doc["fairway"], S.fairways);
  if (!doc["green"].isNull())   loadShapes(doc["green"],   S.greens);
  if (!doc["bunkers"].isNull()) loadShapes(doc["bunkers"], S.bunkers);
  if (!doc["water"].isNull())   loadShapes(doc["water"],   S.water);
  if (!doc["tee"].isNull())     S.hasTee    = readPoint(doc["tee"],    S.tee);
  if (!doc["pin"].isNull())     S.hasPin    = readPoint(doc["pin"],    S.pin);
  if (!doc["player"].isNull())  S.hasPlayer = readPoint(doc["player"], S.player);

  JsonArrayConst pars = doc["pars"];
  if (!pars.isNull()) for (int i = 0; i < 18 && i < (int)pars.size(); i++) S.pars[i] = pars[i];
  JsonArrayConst scores = doc["scores"];
  if (!scores.isNull()) for (int i = 0; i < 18 && i < (int)scores.size(); i++) S.scores[i] = scores[i];

  needRedraw = true;
}

// returns true if the line was consumed (valid or empty)
static bool handleLine(String line) {
  line.trim();
  if (line.length() == 0) return true;

  bool digits = line.length() <= 2;                       // legacy: bare hole number "4"
  for (size_t i = 0; i < line.length() && digits; i++) digits = isDigit(line[i]);
  if (digits) {
    int h = line.toInt();
    if (h >= 1 && h <= 18) {
      xSemaphoreTake(dataMutex, portMAX_DELAY);
      if (demoActive) { bool c = S.connected; S = AppState(); S.connected = c; demoActive = false; }
      if (h != S.hole) resetHoleData(h);
      xSemaphoreGive(dataMutex);
      needRedraw = true;
    }
    return true;
  }

  JsonDocument doc;
  if (deserializeJson(doc, line)) { Serial.println("unit: could not read that line as JSON"); return false; }   // incomplete or invalid
  if (!doc.is<JsonObject>()) return true;
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  applyMessage(doc);
  xSemaphoreGive(dataMutex);
  return true;
}

// Every line from the phone comes through here (BLE task). With DISPLAY_AUTH on, only an authenticated phone's non-authentication lines reach handleLine().
static bool rxLine(String line) {
#if DISPLAY_AUTH
  line.trim();
  if (line.length() == 0) return true;
  char reply[300]; bool keyChanged = false;
  xSemaphoreTake(gateMutex, portMAX_DELAY);
  bool toApp = gate.onLine(line.c_str(), millis(), reply, sizeof(reply), &keyChanged);
  if (reply[0]) pendingReply += reply;
  xSemaphoreGive(gateMutex);
  if (!toApp) return true;                                // dropped or handled as authentication
#endif
  return handleLine(line);
}

class MyRxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *c) {
    String v = c->getValue();
    if (v.length() == 0) return;
    // Messages are flat JSON objects, so a write that starts with '{' is always the
    // start of a new message - drop any stale half-message left in the buffer.
    if (v[0] == '{') rxBuf = "";
    rxBuf += v;
    if (rxBuf.length() > 8000) rxBuf = "";

    int nl;
    while ((nl = rxBuf.indexOf('\n')) >= 0) {             // complete, newline-terminated messages
      String line = rxBuf.substring(0, nl);
      rxBuf.remove(0, nl + 1);
      rxLine(line);
    }
    String t = rxBuf; t.trim();                           // message without a trailing newline (older app)
    if (t.length() && t[t.length() - 1] == '}') {
      rxLine(t);                                          // no nested objects, so '}' always ends a message
      rxBuf = "";                                         // ...valid or not: never keep garbage around
    } else if (t.length() && t.length() <= 2 && rxLine(t)) {
      rxBuf = "";                                         // bare hole number
    }
  }
};

// NOTE: the ESP32 BLE library names these onConnect / onDisconnect.
class MyServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *s) {
    deviceConnected = true;
#if DISPLAY_AUTH
    bleConnMs = millis(); bleJustConnected = true;
#endif
    S.connected = phoneReady();
    rxBuf = "";
    needRedraw = true;
  }
  void onDisconnect(BLEServer *s) {
    deviceConnected = false;
#if DISPLAY_AUTH
    bleJustDropped = true; phoneAuthed = false;
#endif
    S.connected = false;
    s->startAdvertising();
    needRedraw = true;
  }
};

void initBLEServer() {
  BLEDevice::init("HandleCaddie_BLE");
  BLEDevice::setMTU(247);                                 // allow bigger payloads if the app asks
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());
  BLEService *pService = pServer->createService(SERVICE_UUID);
  pTxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_TX, BLECharacteristic::PROPERTY_NOTIFY);
  pTxCharacteristic->addDescriptor(new BLE2902());
  pRxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_RX,
                        BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  pRxCharacteristic->setCallbacks(new MyRxCallbacks());
  pService->start();
  pServer->getAdvertising()->addServiceUUID(SERVICE_UUID);
  pServer->getAdvertising()->start();
}

// ---------------------------------------------------------------------------
// Club sensor
//
// Messages to the app (kept short so they fit in a default 20-byte notify):
//   {"e":"pull"}            club taken out of the bag
//   {"e":"ret","ms":23500}  club put back (ms = how long it was out)
//   {"e":"str","n":3}       strokes edited on the unit by tapping the tile
//   {"e":"green"}           user tapped "ON GREEN?" (app may not have detected the green yet)
//   {"e":"putt","n":2}      putt count changed with the - / + buttons
//   {"e":"out","s":5,"p":2} HOLE OUT tapped: s = total strokes incl. putts, p = putts
// ---------------------------------------------------------------------------
static void onClubEvent(ClubDetector::Event ev) {
  if (ev == ClubDetector::NONE) return;

  xSemaphoreTake(dataMutex, portMAX_DELAY);
  if (ev == ClubDetector::PULLED) {
    S.clubOut = true;
    strlcpy(S.pulledClub, S.club, sizeof(S.pulledClub));    // assume the recommended club until told otherwise
  } else {
    S.clubOut = false;
    S.pulledClub[0] = 0;
#if OFFLINE_COUNT_ON_RETURN
    if (!phoneReady() && detector.lastHeldMs() >= OFFLINE_MIN_HELD_MS && S.strokes < 99) S.strokes++;
#endif
  }
  xSemaphoreGive(dataMutex);
  needRedraw = true;

  if (ev == ClubDetector::PULLED) {
    sendToApp("{\"e\":\"pull\"}");
  } else {
    char b[32];
    snprintf(b, sizeof(b), "{\"e\":\"ret\",\"ms\":%lu}", (unsigned long)detector.lastHeldMs());
    sendToApp(b);
  }
  Serial.println(ev == ClubDetector::PULLED ? "Club PULLED" : "Club RETURNED");
}

static void pollSensor() {
  if (!tofOk || millis() - lastTofPoll < TOF_POLL_MS) return;
  lastTofPoll = millis();

  uint8_t range  = tof.readRange();
  uint8_t status = tof.readRangeStatus();
  bool present = (status == VL6180X_ERROR_NONE) && (range <= TOF_PRESENT_MM);

  if (tofDebug && millis() - lastTofPrint > 250) {
    lastTofPrint = millis();
    Serial.printf("TOF range=%u mm status=%u present=%d\n", range, status, present);
  }
  onClubEvent(detector.update(present, millis()));
}

// ---------------------------------------------------------------------------
// Touch
// ---------------------------------------------------------------------------
static void mapTouch(uint16_t rawX, uint16_t rawY, int &x, int &y) {
  x = rawX; y = rawY;
#if TOUCH_SWAP_XY
  int t = x; x = y; y = t;
#endif
#if TOUCH_FLIP_X
  x = (ui::W - 1) - x;
#endif
#if TOUCH_FLIP_Y
  y = (ui::H - 1) - y;
#endif
}

static void switchScreen(ScreenState s) { currentScreen = s; needRedraw = true; }

static void advanceHoleOffline() {                      // fallback when the phone isn't connected
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  if (demoActive) { bool c = S.connected; S = AppState(); S.connected = c; demoActive = false; }
  if (S.strokes + S.putts > 0) S.scores[S.hole - 1] = S.strokes + S.putts;
  resetHoleData((S.hole % 18) + 1);
  xSemaphoreGive(dataMutex);
  needRedraw = true;
}

static void handleTouch(int x, int y) {
  if (ui::hit(ui::NAV_BTN, x, y, 6)) {
    switchScreen(currentScreen == SCREEN_DASHBOARD ? SCREEN_SCORECARD : SCREEN_DASHBOARD);
    return;
  }
  if (currentScreen != SCREEN_DASHBOARD) return;

  const int pad = 4;                                     // a bit of slack for gloved / sunlit taps
  char b[48];

  if (ui::puttMode(S)) {
    // ---- putting: - / + putts and HOLE OUT ----
    if (ui::hit(ui::PUTT_MINUS, x, y, pad) || ui::hit(ui::PUTT_PLUS, x, y, pad)) {
      bool plus = ui::hit(ui::PUTT_PLUS, x, y, pad);
      xSemaphoreTake(dataMutex, portMAX_DELAY);
      if (plus && S.putts < 9) S.putts++;
      else if (!plus && S.putts > 0) S.putts--;
      int n = S.putts;
      xSemaphoreGive(dataMutex);
      snprintf(b, sizeof(b), "{\"e\":\"putt\",\"n\":%d}", n);
      sendToApp(b);
      needRedraw = true;
    } else if (ui::hit(ui::HOLE_OUT, x, y, pad)) {
      snprintf(b, sizeof(b), "{\"e\":\"out\",\"s\":%d,\"p\":%d}", S.strokes + S.putts, S.putts);
      sendToApp(b);
      if (!phoneReady()) advanceHoleOffline();        // with the phone connected, the app moves us on
    }
    return;
  }

  if (ui::nearGreen(S) && ui::hit(ui::GREEN_CHIP, x, y)) {   // "ON GREEN?" -> switch to putting
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    S.manualPutt = true;
    xSemaphoreGive(dataMutex);
    sendToApp("{\"e\":\"green\"}");
    needRedraw = true;
  } else if (ui::hit(ui::STROKES_TILE, x, y, pad)) {     // tap = +1 stroke (wraps at 12) to correct the count
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    S.strokes = (S.strokes + 1) % 13;
    int n = S.strokes;
    xSemaphoreGive(dataMutex);
    snprintf(b, sizeof(b), "{\"e\":\"str\",\"n\":%d}", n);
    sendToApp(b);
    needRedraw = true;
  } else if (ui::hit(ui::CLUB_STRIP, x, y, pad)) {       // manual "club in hand" toggle (sensor override)
    bool out = !S.clubOut;
    detector.force(out, millis());
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    S.clubOut = out;
    if (out) strlcpy(S.pulledClub, S.club, sizeof(S.pulledClub)); else S.pulledClub[0] = 0;
    xSemaphoreGive(dataMutex);
    sendToApp(out ? "{\"e\":\"pull\"}" : "{\"e\":\"ret\",\"ms\":0}");
    needRedraw = true;
  } else if (ui::hit(ui::MAP_CARD, x, y) && !phoneReady()) {
    advanceHoleOffline();
  }
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------
static void render() {
  ui::begin(screen.gfx->getFramebuffer());
  xSemaphoreTake(dataMutex, portMAX_DELAY);
  if (currentScreen == SCREEN_DASHBOARD) ui::drawDashboard(S);
  else                                   ui::drawScorecard(S);
  if (S.tip[0]) {                                        // caddie tip overlay; clears itself once faded out
    uint32_t el = millis() - S.tipStartMs;
    uint8_t a = ui::tipAlpha(el);
    if (a == 0) S.tip[0] = 0; else ui::drawTip(S.tip, a);
  }
  xSemaphoreGive(dataMutex);
#if DISPLAY_AUTH
  if (pairShown) ui::drawPairing(pairPin, pairLeftS);
#endif
  screen.flush();
  lastDraw = millis();
}

static float splashShown = 0;

static void splashStep(float p, const char* msg) {         // draw one splash frame
  ui::begin(screen.gfx->getFramebuffer());
  ui::drawSplash(p, msg);
  screen.flush();
  splashShown = p;
}

// Smoothly fill the bar up to `target` over `ms` milliseconds.
static void splashAnimate(float target, uint32_t ms, const char* msg) {
  float from = splashShown;
  uint32_t t0 = millis();
  while (millis() - t0 < ms) {
    float k = (float)(millis() - t0) / (float)ms;
    splashStep(from + (target - from) * k, msg);
  }
  splashStep(target, msg);
}

// ---------------------------------------------------------------------------
// Authentication housekeeping (loop task): connection events, replies to send, key storage, pairing screen, cutting strangers off.
// ---------------------------------------------------------------------------
static void authService() {
#if DISPLAY_AUTH
  uint32_t now = millis();
  uint8_t key[cart::Auth::KEY_LEN]; bool erase = false;
  xSemaphoreTake(gateMutex, portMAX_DELAY);
  if (bleJustConnected) {
    bleJustConnected = false;
    char c[200]; int n = gate.connected(now, c, sizeof(c));
    if (n > 0) pendingReply += c;                           // the app also asks with "hello" in case this went out before it was listening
  }
  if (bleJustDropped) { bleJustDropped = false; gate.disconnected(); }
  bool cut = gate.shouldCut(now);
  bool haveKey = gate.takeKey(key, &erase);
  bool open = gate.pairingOpen(now);
  bool authed = gate.authed();
  if (open) { strlcpy(pairPin, gate.pin(), sizeof(pairPin)); pairLeftS = gate.pairingLeftS(now); }
  String out = pendingReply; pendingReply = "";
  xSemaphoreGive(gateMutex);

  if (haveKey) { if (erase) prefs.remove("akey"); else prefs.putBytes("akey", key, cart::Auth::KEY_LEN); }
  if (out.length()) sendRaw(out.c_str(), out.length());
  if (cut && pServer) { Serial.println("A phone did not prove itself in time: disconnecting it."); pServer->disconnect(pServer->getConnId()); }
  if (authed != phoneAuthed) {
    phoneAuthed = authed;
    xSemaphoreTake(dataMutex, portMAX_DELAY); S.connected = phoneReady(); xSemaphoreGive(dataMutex);
    needRedraw = true;
    if (authed) Serial.println("Phone accepted.");
  }
  if (open != pairShown) { pairShown = open; needRedraw = true; if (open) Serial.printf("Pairing open. PIN %s\n", pairPin); }
  if (open && now - pairLastDraw >= 1000) { pairLastDraw = now; needRedraw = true; }            // the countdown
#endif
}

// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  Serial.println("HandleCaddie firmware: caddie tips + smoothed shapes");   // seeing this line proves the new version is running
  delay(300);

  dataMutex = xSemaphoreCreateMutex();
#if DISPLAY_AUTH
  gateMutex = xSemaphoreCreateMutex();
  prefs.begin("hcdisp", false);
  {
    uint8_t k[cart::Auth::KEY_LEN]; bool have = prefs.getBytesLength("akey") == cart::Auth::KEY_LEN && prefs.getBytes("akey", k, cart::Auth::KEY_LEN) == cart::Auth::KEY_LEN;
    gate.begin(have ? k : nullptr, millis());
    if (!have) Serial.println("No phone paired yet: the PIN is shown on the screen for 5 minutes.");
  }
#endif

  if (!screen.begin()) {                                 // also starts Wire on the touch pins
    Serial.println("Screen initialization failed!");
    while (1) delay(1000);
  }
  uint32_t splashStart = millis();
  splashStep(0.08f, "STARTING");

  // club sensor
#if TOF_SHARED_BUS
  tofOk = tof.begin(&Wire);
#else
  Wire1.begin(TOF_SDA, TOF_SCL, 400000);
  tofOk = tof.begin(&Wire1);
#endif
  Serial.println(tofOk ? "VL6180X club sensor ready" : "VL6180X NOT found - check wiring (touch still works)");
  splashStep(0.35f, tofOk ? "SENSOR READY" : "NO SENSOR");

#if DEMO_ON_BOOT
  loadDemo();
#else
  resetHoleData(1);
#endif

  splashStep(0.55f, "BLUETOOTH");
  initBLEServer();
  splashStep(0.75f, "READY");

  // finish the bar so the logo is visible for at least SPLASH_MIN_MS
  uint32_t used = millis() - splashStart;
  uint32_t left = used < SPLASH_MIN_MS ? SPLASH_MIN_MS - used : 0;
  splashAnimate(1.0f, left > 150 ? left : 150, "READY");
  delay(150);

  render();
  Serial.println("Handle Caddie ready.");
}

void loop() {
  uint16_t rawX = 0, rawY = 0;

  if (screen.screenWasTouched && screen.getTouchPoint(rawX, rawY)) {
    int x, y;
    mapTouch(rawX, rawY, x, y);
#if TOUCH_DEBUG
    Serial.printf("Touch raw(%u,%u) -> ui(%d,%d)\n", rawX, rawY, x, y);
#endif
#if DISPLAY_AUTH
    xSemaphoreTake(gateMutex, portMAX_DELAY); gate.touch(x < PAIR_CORNER_W && y < PAIR_CORNER_H, millis()); xSemaphoreGive(gateMutex);
#endif
    if (millis() - lastTouchDebounce > 300) {
      lastTouchDebounce = millis();
      handleTouch(x, y);
#if TOUCH_DEBUG
      if (!needRedraw) {                                  // show where it registered
        ui::begin(screen.gfx->getFramebuffer());
        ui::circle(x, y, 6, ui::C_RED, 200);
        screen.flush();
      }
#endif
    }
  }

  pollSensor();
  authService();

  // Serial test commands:  s / d = screens, 1-18 = hole, pull / ret = simulate sensor, range = toggle debug
  if (Serial.available() > 0) {
    String cmd = Serial.readStringUntil('\n');
    cmd.trim();
    if (cmd == "s")           switchScreen(SCREEN_SCORECARD);
    else if (cmd == "d")      switchScreen(SCREEN_DASHBOARD);
    else if (cmd == "pull")   { detector.force(true, millis());  onClubEvent(ClubDetector::PULLED); }
    else if (cmd == "ret")    { detector.force(false, millis()); onClubEvent(ClubDetector::RETURNED); }
    else if (cmd == "range")  { tofDebug = !tofDebug; }
#if DISPLAY_AUTH
    else if (cmd == "pair")   { xSemaphoreTake(gateMutex, portMAX_DELAY); gate.openPairing(millis()); xSemaphoreGive(gateMutex); Serial.println("Pairing open for 2 minutes."); }
    else if (cmd == "unpair") { xSemaphoreTake(gateMutex, portMAX_DELAY); gate.forget(millis()); xSemaphoreGive(gateMutex); Serial.println("Key forgotten: no phone is paired. Pairing open for 5 minutes."); }
#endif
    else if (cmd.length())    handleLine(cmd);            // same path as BLE (hole number or JSON)
  }

  if (S.tip[0]) needRedraw = true;                       // keep redrawing while a tip is on screen so it can fade

  if (needRedraw && millis() - lastDraw >= 60) {
    needRedraw = false;
    render();
  }

  delay(5);
}
