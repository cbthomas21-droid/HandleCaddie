// cart_proto.h - TRIMMED copy for the display. cart_auth.h (shared with the cart firmware) includes this file only for the tiny
// flat-JSON reader below; the cart's own cart_proto.h is a superset of it with the same function names. Do not add cart logic here.
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

namespace cart {
inline const char* findKey(const char* s, const char* key) {
  char pat[16]; int n = snprintf(pat, sizeof(pat), "\"%s\"", key);
  if (n <= 0 || n >= (int)sizeof(pat)) return nullptr;
  const char* p = strstr(s, pat);
  if (!p) return nullptr;
  p += n;
  while (*p == ' ') p++;
  if (*p != ':') return nullptr;
  p++;
  while (*p == ' ') p++;
  return p;
}
inline bool getNum(const char* s, const char* key, float* out) {
  const char* p = findKey(s, key); if (!p) return false;
  char* end; float v = strtof(p, &end);
  if (end == p || !isfinite(v)) return false;
  *out = v; return true;
}
inline bool getStr(const char* s, const char* key, char* out, size_t cap) {
  const char* p = findKey(s, key); if (!p || *p != '"') return false;
  p++; size_t i = 0;
  while (*p && *p != '"' && i + 1 < cap) out[i++] = *p++;
  if (*p != '"') return false;
  out[i] = 0; return true;
}
}  // namespace cart
