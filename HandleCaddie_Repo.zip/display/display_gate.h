// display_gate.h - who may talk to the display over Bluetooth. Pure C++ (no Arduino calls), unit-tested on a PC (tests/test_display_gate.cpp).
//
// THREAT THIS ANSWERS: a stranger's phone (or a stray app) within Bluetooth range connecting to the display, taking its one connection
// slot and pushing made-up holes, scores or messages onto your screen. WHAT IT DOES:
//   * the display sends a fresh random challenge each connection; only a phone holding the shared key can answer it
//     (HMAC-SHA256, the same code and the same messages as the cart link: cart_auth.h)
//   * until that happens every line the phone sends is ignored, and the display sends nothing back
//   * a phone that connects and does not authenticate within CUT_MS is disconnected, so it cannot hog the slot
//   * pairing: with no key stored the display opens a 5 minute pairing window by itself and shows a PIN on its screen;
//     later, touch and hold the top-left corner for 4 seconds to open a 2 minute window for a new phone (it replaces the old one)
// WHAT IT DOES NOT DO: the Bluetooth link is not encrypted, so someone recording the radio during the few seconds of pairing could
// learn the key. Pair in a car park, not in a crowd. (The cart link adds Bluetooth LE Secure Connections on top; see CART_DESIGN.md.)
#pragma once
#include "cart_auth.h"

namespace cart {

class DisplayGate {
 public:
  static const uint32_t CUT_MS = 10000;     // an unauthenticated phone is dropped after this long
  static const uint32_t HOLD_MS = 4000;     // hold the corner this long to open pairing
  static const uint32_t GAP_MS = 700;       // touches closer together than this are one continuous hold

  explicit DisplayGate(Auth::RandFn r) : auth_(r) {}

  /** Once at boot with the stored key (or nullptr). */
  void begin(const uint8_t* key, uint32_t now) { auth_.begin(key, now); live_ = false; cut_ = false; holdStart_ = lastTouch_ = 0; fired_ = false; }

  /** A phone connected. Writes the challenge into [out] (send it; the app also asks with "hello"). Returns its length. */
  int connected(uint32_t now, char* out, size_t cap) {
    live_ = true; cut_ = false; connMs_ = now;
    auth_.requireSecureLink(false); auth_.setLink(false, false);
    return auth_.onConnect(now, out, cap);
  }
  void disconnected() { live_ = false; auth_.onDisconnect(); }

  bool authed() const { return auth_.authed(); }
  bool paired() const { return auth_.hasKey(); }
  bool pairingOpen(uint32_t now) const { return auth_.pairingOpen(now); }
  const char* pin() const { return auth_.pin(); }
  uint32_t pairingLeftS(uint32_t now) const { return auth_.pairingLeftS(now); }
  void openPairing(uint32_t now) { auth_.openPairing(now); }
  void forget(uint32_t now) { auth_.forget(now); }

  /**
   * One whole line from the phone. [reply] gets any lines to send back (may be empty). Returns true only when the line is
   * for the application: the phone is authenticated AND it is not an authentication line. [keyChanged] is set when a key
   * must be stored or erased (call takeKey()).
   */
  bool onLine(const char* line, uint32_t now, char* reply, size_t cap, bool* keyChanged) {
    Auth::Result r = auth_.handle(line, now, reply, cap);
    if (r.ev != Auth::Event::NONE) *keyChanged = true;
    if (r.consumed) return false;
    return auth_.authed();
  }
  bool takeKey(uint8_t key[Auth::KEY_LEN], bool* erase) { return auth_.takeKeyChange(key, erase); }

  /** True once when a phone has been connected too long without proving itself: the caller disconnects it. */
  bool shouldCut(uint32_t now) {
    if (!live_ || cut_ || auth_.authed() || (int32_t)(now - connMs_) <= (int32_t)CUT_MS) return false;
    cut_ = true; return true;
  }

  /** Feed every touch. [inCorner] = it is inside the top-left corner. Holding it HOLD_MS opens pairing (once per hold). */
  void touch(bool inCorner, uint32_t now) {
    if (!inCorner) { holdStart_ = 0; fired_ = false; return; }
    if (holdStart_ == 0 || (int32_t)(now - lastTouch_) > (int32_t)GAP_MS) { holdStart_ = now; fired_ = false; }
    lastTouch_ = now;
    if (!fired_ && (int32_t)(now - holdStart_) >= (int32_t)HOLD_MS) { fired_ = true; auth_.openPairing(now); }
  }

 private:
  Auth auth_;
  bool live_ = false, cut_ = false, fired_ = false;
  uint32_t connMs_ = 0, holdStart_ = 0, lastTouch_ = 0;
};

}  // namespace cart
