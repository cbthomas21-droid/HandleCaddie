// ui_screens.h - dashboard + scorecard rendering for the 480x320 landscape display.
// Pure drawing code: reads an AppState, draws into the ui:: framebuffer.
#pragma once
#include <stdio.h>
#include <string.h>
#include <vector>
#include "ui_gfx.h"

// ---------------------------------------------------------------------------
// Data the screens need
// ---------------------------------------------------------------------------
enum Zone { ZONE_UNKNOWN = 0, ZONE_TEE, ZONE_FAIRWAY, ZONE_ROUGH, ZONE_GREEN };

struct Shape { std::vector<ui::PtF> pts; };

// Round the corners of a closed outline (Chaikin corner cutting). OpenStreetMap outlines are straight segments between a
// few dozen points; this makes greens/bunkers/water look hand-drawn. Runs once when a hole arrives, not per frame.
// Shapes with few points get two passes, bigger ones one, so the result never exceeds SHAPE_MAX_PTS points.
static const int SHAPE_MAX_PTS = 128;
static void smoothShape(Shape &s) {
  for (int pass = 0; pass < 2; pass++) {
    size_t n = s.pts.size();
    if (n < 3 || n * 2 > (size_t)SHAPE_MAX_PTS) return;
    if (pass == 1 && n > 40) return;
    std::vector<ui::PtF> q; q.reserve(n * 2);
    for (size_t i = 0; i < n; i++) {
      const ui::PtF a = s.pts[i], b = s.pts[(i + 1) % n];
      q.push_back({0.75f * a.x + 0.25f * b.x, 0.75f * a.y + 0.25f * b.y});
      q.push_back({0.25f * a.x + 0.75f * b.x, 0.25f * a.y + 0.75f * b.y});
    }
    s.pts.swap(q);
  }
}

struct AppState {
  bool connected = false;

  // hole
  int hole = 1, par = 4, holeLen = 0;      // holeLen in yards (0 = unknown)
  int toPin = 0;                           // yards to pin (0 = unknown)
  Zone zone = ZONE_UNKNOWN;
  int strokes = 0;                         // strokes taken this hole
  int lastShot = 0;                        // yards of last shot (0 = none yet)
  int front = 0, back = 0;                 // yards to front / back of green (0 = unknown)
  int putts = 0;                           // putts this hole (entered on the unit or by the app)
  bool manualPutt = false;                 // user tapped "on green?" before the app said so

  // club
  char club[20] = "";                      // recommended club, e.g. "7 Iron"
  int  clubCarry = 0;                      // expected carry, yards
  bool clubOut = false;                    // sensor says a club is pulled
  char pulledClub[20] = "";                // club that was pulled, if known

  // map (any consistent units; y grows downward; auto-fitted to the card)
  std::vector<Shape> fairways, greens, bunkers, water;
  bool hasPin = false, hasTee = false, hasPlayer = false;
  ui::PtF pin = {0, 0}, tee = {0, 0}, player = {0, 0};

  // caddie tip: one line shown for a moment, then faded out (set by the app: {"tip":"Birdie. Nicely played."})
  char tip[56] = "";
  uint32_t tipStartMs = 0;

  // scorecard
  int pars[18]   = {4, 4, 3, 5, 4, 4, 3, 4, 5, 4, 5, 3, 4, 4, 3, 5, 4, 4};
  int scores[18] = {0};                    // 0 = not played yet
};

// ---------------------------------------------------------------------------
// Layout / hit areas (shared with the sketch for touch handling)
// ---------------------------------------------------------------------------
namespace ui {
struct Rect { int x, y, w, h; };
static const Rect NAV_BTN    = {364, 8, 104, 34};
static const Rect LEFT_CARD  = {12, 52, 232, 256};
static const Rect MAP_CARD   = {252, 52, 216, 256};
static const Rect CLUB_STRIP = {26, 240, 204, 52};
static const Rect STROKES_TILE = {26, 184, 98, 48};
static const Rect GREEN_CHIP  = {128, 58, 112, 34};   // "ON GREEN?" (generous hit area)
static const Rect PUTT_MINUS  = {26, 190, 62, 54};
static const Rect PUTT_PLUS   = {168, 190, 62, 54};
static const Rect HOLE_OUT    = {26, 252, 204, 40};
static const int  PUTT_NEAR_YDS = 60;                 // offer the "ON GREEN?" chip inside this distance
inline bool hit(const Rect& r, int x, int y, int pad = 0) {
  return x >= r.x - pad && x < r.x + r.w + pad && y >= r.y - pad && y < r.y + r.h + pad;
}

// ---------------------------------------------------------------------------
// Palette
// ---------------------------------------------------------------------------
static const uint32_t C_BG        = 0x0A0F1A;
static const uint32_t C_CARD_T    = 0x141D30;
static const uint32_t C_CARD_B    = 0x0F1727;
static const uint32_t C_BORDER    = 0x24324D;
static const uint32_t C_TILE      = 0x1B2740;
static const uint32_t C_TEXT      = 0xF2F5FA;
static const uint32_t C_MUTED     = 0x8A97B1;
static const uint32_t C_DIM       = 0x56637D;
static const uint32_t C_GREEN     = 0x3DDC84;
static const uint32_t C_AMBER     = 0xFFB020;
static const uint32_t C_RED       = 0xFF5C5C;
static const uint32_t C_BLUE      = 0x4DA3FF;

static const uint32_t M_ROUGH     = 0x174D2E;
static const uint32_t M_FAIRWAY   = 0x45AE63;
static const uint32_t M_GREEN     = 0x86E89A;
static const uint32_t M_BUNKER    = 0xF3EBD2;
static const uint32_t M_WATER     = 0x3A8FE0;

// ---------------------------------------------------------------------------
// small helpers
// ---------------------------------------------------------------------------
static inline bool puttMode(const AppState& s) { return s.zone == ZONE_GREEN || s.manualPutt; }
static inline bool nearGreen(const AppState& s) {
  return !puttMode(s) && s.toPin > 0 && s.toPin <= PUTT_NEAR_YDS;
}

static inline void card(const Rect& r) {
  rrect(r.x, r.y, r.w, r.h, 14, C_CARD_T, C_CARD_B, 255, 1.0f, C_BORDER, 255);
}

static inline void label(const char* s, float x, int baseline, uint32_t col = C_MUTED, int align = ALIGN_LEFT) {
  text(FONT_LABEL, x, baseline, s, col, align, 1.1f);
}

static const char* zoneName(Zone z) {
  switch (z) {
    case ZONE_TEE:     return "TEE BOX";
    case ZONE_FAIRWAY: return "FAIRWAY";
    case ZONE_ROUGH:   return "ROUGH";
    case ZONE_GREEN:   return "GREEN";
    default:           return "";
  }
}
static uint32_t zoneColor(Zone z) {
  switch (z) {
    case ZONE_TEE:     return C_BLUE;
    case ZONE_FAIRWAY: return C_GREEN;
    case ZONE_ROUGH:   return C_AMBER;
    case ZONE_GREEN:   return 0x7CF0A8;
    default:           return C_DIM;
  }
}

static void pill(float x, float y, float w, float h, uint32_t fill, uint8_t fa, uint32_t stroke) {
  rrect(x, y, w, h, h * 0.5f, fill, fill, fa, 1.0f, stroke, 255);
}

static const uint32_t C_BRAND = 0x184879;   // logo blue

// Golf-cart mark, traced from the Handle Caddie logo and redrawn as vector so it stays crisp at
// any size. The box is 40 x 32 units * s. Coordinates below are in the tracing grid (zx, zy).
static void cartIcon(float x, float y, float s, uint32_t col, uint32_t bg) {
  const float k = s / 14.5f;
  auto X = [&](float zx) { return x + (zx - 75) * k; };
  auto Y = [&](float zy) { return y + (zy - 135) * k; };

  PtF roof[4] = {{X(135), Y(140)}, {X(555), Y(140)}, {X(545), Y(182)}, {X(145), Y(182)}};   // roof slab
  polyFill(roof, 4, col);
  box(X(180), Y(178), 44 * k, 212 * k, 3 * k, col);                                         // rear post
  PtF ws[4] = {{X(492), Y(180)}, {X(524), Y(180)}, {X(574), Y(388)}, {X(544), Y(388)}};     // windshield post
  polyFill(ws, 4, col);

  line(X(250), Y(292), X(262), Y(372), 20 * k, col, 210);                                   // seat back
  box(X(238), Y(366), 125 * k, 28 * k, 6 * k, col, 230);                                    // seat
  line(X(412), Y(340), X(462), Y(298), 20 * k, col);                                        // steering wheel
  line(X(448), Y(318), X(498), Y(372), 20 * k, col);

  PtF body[12] = {{X(135), Y(380)}, {X(385), Y(380)}, {X(388), Y(476)}, {X(496), Y(476)},   // body with floor well
                  {X(496), Y(408)}, {X(556), Y(386)}, {X(628), Y(428)}, {X(648), Y(478)},
                  {X(604), Y(524)}, {X(92), Y(524)},  {X(76), Y(508)},  {X(100), Y(420)}};
  polyFill(body, 12, col);

  const float wx[2] = {190, 587};                                                           // wheels
  for (int i = 0; i < 2; i++) {
    circle(X(wx[i]), Y(535), 73 * k, bg);        // wheel arch gap
    circle(X(wx[i]), Y(535), 63 * k, col);
    circle(X(wx[i]), Y(535), 19 * k, bg);        // hub
  }
}

// little flag icon
static void flagIcon(float x, float y, uint32_t col) {
  line(x + 3, y + 2, x + 3, y + 22, 2.0f, col);
  PtF f[3] = {{x + 3.5f, y + 2}, {x + 17, y + 7.5f}, {x + 3.5f, y + 13}};
  polyFill(f, 3, M_GREEN);
  circle(x + 3, y + 23, 2.6f, col);
}

// ---------------------------------------------------------------------------
// header (both screens)
// ---------------------------------------------------------------------------
static void header(const AppState& s, bool onScorecard) {
  cartIcon(12, 9, 0.9f, C_TEXT, C_BG);

  char buf[48];
  if (onScorecard) snprintf(buf, sizeof(buf), "Scorecard");
  else             snprintf(buf, sizeof(buf), "Hole %d", s.hole);
  text(FONT_TITLE, 54, 36, buf, C_TEXT);
  int tw = textWidth(FONT_TITLE, buf);

  if (!onScorecard) {
    float x = 54 + tw + 12;
    circle(x, 29, 2.0f, C_DIM);
    x += 10;
    snprintf(buf, sizeof(buf), "Par %d", s.par);
    text(FONT_SMALL, x, 35, buf, C_MUTED);
    x += textWidth(FONT_SMALL, buf);
    if (s.holeLen > 0) {
      x += 10;
      circle(x, 29, 2.0f, C_DIM);
      x += 10;
      snprintf(buf, sizeof(buf), "%d yd", s.holeLen);
      text(FONT_SMALL, x, 35, buf, C_MUTED);
    }
  }

  // phone link status
  const char* st = s.connected ? "Phone" : "Searching";
  uint32_t sc = s.connected ? C_GREEN : C_AMBER;
  int stw = textWidth(FONT_SMALL, st);
  float sx = NAV_BTN.x - 14 - stw;
  text(FONT_SMALL, sx, 35, st, C_MUTED);
  if (s.connected) {
    circle(sx - 12, 30, 3.4f, sc);
  } else {
    circle(sx - 12, 30, 3.4f, sc, 90);
    ring(sx - 12, 30, 3.4f, 1.2f, sc);
  }

  // nav button
  const char* nb = onScorecard ? "Dashboard" : "Scorecard";
  pill(NAV_BTN.x, NAV_BTN.y, NAV_BTN.w, NAV_BTN.h, C_GREEN, 28, C_GREEN);
  text(FONT_SMALL, NAV_BTN.x + NAV_BTN.w / 2.0f, NAV_BTN.y + 22, nb, C_GREEN, ALIGN_CENTER);
}

// ---------------------------------------------------------------------------
// hole map
//   * rotated so the tee->pin line points up, whatever the compass heading
//   * mowing stripes on fairways and greens
//   * while putting, zooms in on the green
// ---------------------------------------------------------------------------
static void drawMap(const AppState& s) {
  const Rect& c = MAP_CARD;
  card(c);
  bool putt = puttMode(s);
  bool zoom = putt && !s.greens.empty();
  label(zoom ? "GREEN" : "HOLE MAP", c.x + 16, c.y + 26);

  Rect m = {c.x + 10, c.y + 40, c.w - 20, c.h - 50};
  box(m.x, m.y, m.w, m.h, 10, M_ROUGH);

  // rotation about the tee (or the player) so the line to the pin points up
  float rc = 1, rs = 0, rx = 0, ry = 0;
  if (s.hasPin && (s.hasTee || s.hasPlayer)) {
    PtF a = s.hasTee ? s.tee : s.player;
    float dx = s.pin.x - a.x, dy = s.pin.y - a.y, L = sqrtf(dx * dx + dy * dy);
    if (L > 1e-3f) { rc = -dy / L; rs = -dx / L; rx = a.x; ry = a.y; }
  }
  auto T = [&](float x, float y) -> PtF {
    float px = x - rx, py = y - ry;
    return {rc * px - rs * py, rs * px + rc * py};
  };

  // bounding box of what we want to show
  bool any = false;
  float x0 = 0, y0 = 0, x1 = 0, y1 = 0;
  auto grow = [&](float x, float y) {
    PtF q = T(x, y);
    if (!any) { x0 = x1 = q.x; y0 = y1 = q.y; any = true; return; }
    if (q.x < x0) x0 = q.x;
    if (q.x > x1) x1 = q.x;
    if (q.y < y0) y0 = q.y;
    if (q.y > y1) y1 = q.y;
  };
  auto scan = [&](const std::vector<Shape>& v) { for (auto& sh : v) for (auto& p : sh.pts) grow(p.x, p.y); };
  if (zoom) {
    scan(s.greens);
  } else {
    scan(s.fairways); scan(s.greens); scan(s.bunkers); scan(s.water);
    if (s.hasTee) grow(s.tee.x, s.tee.y);
  }
  if (s.hasPin) grow(s.pin.x, s.pin.y);
  if (s.hasPlayer) grow(s.player.x, s.player.y);

  if (!any || x1 - x0 < 1e-3f || y1 - y0 < 1e-3f) {
    flagIcon(m.x + m.w / 2.0f - 10, m.y + m.h / 2.0f - 30, mix(M_ROUGH, 0xFFFFFF, 0.45f));
    text(FONT_SMALL, m.x + m.w / 2.0f, m.y + m.h / 2.0f + 22, "Waiting for", mix(M_ROUGH, 0xFFFFFF, 0.55f), ALIGN_CENTER);
    text(FONT_SMALL, m.x + m.w / 2.0f, m.y + m.h / 2.0f + 40, "course data", mix(M_ROUGH, 0xFFFFFF, 0.55f), ALIGN_CENTER);
    return;
  }

  const float pad = zoom ? 26 : 14;
  float aw = m.w - 2 * pad, ah = m.h - 2 * pad;
  float sc = fminf(aw / (x1 - x0), ah / (y1 - y0));
  float ox = m.x + pad + (aw - (x1 - x0) * sc) * 0.5f - x0 * sc;
  float oy = m.y + pad + (ah - (y1 - y0) * sc) * 0.5f - y0 * sc;
  auto X = [&](float x, float y) { PtF q = T(x, y); return ox + q.x * sc; };
  auto Y = [&](float x, float y) { PtF q = T(x, y); return oy + q.y * sc; };

  auto drawSet = [&](const std::vector<Shape>& v, uint32_t fill, uint32_t edge, float edgeW, bool stripes) {
    PtF tmp[SHAPE_MAX_PTS];
    for (const Shape& sh : v) {
      int n = (int)sh.pts.size();
      if (n < 3) continue;
      if (n > SHAPE_MAX_PTS) n = SHAPE_MAX_PTS;
      for (int i = 0; i < n; i++) {
        PtF q = T(sh.pts[i].x, sh.pts[i].y);
        tmp[i] = {ox + q.x * sc, oy + q.y * sc};
      }
      polyFill(tmp, n, fill);
      if (stripes) {
        int band = zoom ? 6 : 8;
        // the map is rotated so tee->pin points up, so vertical bands run along the hole, like mower passes down a fairway
        for (int x = (int)m.x; x < m.x + m.w; x += 2 * band) polyFill(tmp, n, 0xFFFFFF, 24, 0, H, x, x + band);
      }
      if (edgeW > 0) polyStroke(tmp, n, edgeW, edge, 150);
    }
  };

  if (!zoom) drawSet(s.water, M_WATER, mix(M_WATER, 0xFFFFFF, 0.35f), 1.0f, false);
  if (!zoom) drawSet(s.fairways, M_FAIRWAY, mix(M_FAIRWAY, 0xFFFFFF, 0.25f), 1.0f, true);
  drawSet(s.greens, M_GREEN, mix(M_GREEN, 0xFFFFFF, 0.5f), 1.2f, true);
  if (!zoom) drawSet(s.bunkers, M_BUNKER, mix(M_BUNKER, 0x000000, 0.12f), 1.0f, false);

  if (!zoom && s.hasTee) {
    box(X(s.tee.x, s.tee.y) - 6, Y(s.tee.x, s.tee.y) - 3.5f, 12, 7, 2.5f, C_TEXT, 235);
  }
  if (s.hasPlayer && s.hasPin) {
    dashedLine(X(s.player.x, s.player.y), Y(s.player.x, s.player.y),
               X(s.pin.x, s.pin.y), Y(s.pin.x, s.pin.y), 1.4f, 4, 4, C_TEXT, 210);
  }
  if (s.hasPin) {
    float px = X(s.pin.x, s.pin.y), py = Y(s.pin.x, s.pin.y);
    circle(px, py, 2.8f, 0x0A0F1A);
    line(px, py, px, py - 17, 1.7f, C_TEXT);
    PtF f[3] = {{px + 0.8f, py - 17}, {px + 11, py - 13.2f}, {px + 0.8f, py - 9.5f}};
    polyFill(f, 3, C_RED);
  }
  if (s.hasPlayer) {
    float px = X(s.player.x, s.player.y), py = Y(s.player.x, s.player.y);
    circle(px, py, 10, C_BLUE, 70);
    circle(px, py, 5.4f, C_BLUE, 255, 1.8f, C_TEXT);
  }
}

// ---------------------------------------------------------------------------
// dashboard
// ---------------------------------------------------------------------------
// A rounded pill near the bottom with one line of text. alpha 255 = solid, 0 = gone.
static const uint32_t TIP_HOLD_MS = 3200, TIP_FADE_MS = 900;
static inline uint8_t tipAlpha(uint32_t elapsedMs) {
  if (elapsedMs < TIP_HOLD_MS) return 255;
  if (elapsedMs >= TIP_HOLD_MS + TIP_FADE_MS) return 0;
  return (uint8_t)(255 - 255 * (elapsedMs - TIP_HOLD_MS) / TIP_FADE_MS);
}
static void drawTip(const char* msg, uint8_t alpha) {
  if (!msg || !*msg || alpha == 0) return;
  float tw = (float)textWidth(FONT_SMALL, msg);
  float w = tw + 32; if (w > 456) w = 456;
  float h = 32, x = (W - w) * 0.5f, y = H - h - 10;
  box(x - 1, y - 1, w + 2, h + 2, 17, C_BORDER, (uint8_t)(alpha * 0.9f));
  box(x, y, w, h, 16, C_TILE, (uint8_t)(alpha * 0.94f));
  text(FONT_SMALL, W * 0.5f, (int)(y + 21), msg, C_TEXT, ALIGN_CENTER, 0, alpha);
}

// Shown while the pairing window is open: the PIN the phone must send.
static void drawPairing(const char* pin, uint32_t leftS) {
  const float w = 420, h = 200, x = (W - w) * 0.5f, y = (H - h) * 0.5f;
  box(x - 1, y - 1, w + 2, h + 2, 17, C_BORDER);
  box(x, y, w, h, 16, C_TILE);
  text(FONT_BODY, W * 0.5f, (int)(y + 38), "PAIR YOUR PHONE", C_TEXT, ALIGN_CENTER);
  text(FONT_BIG, W * 0.5f, (int)(y + 112), pin, C_GREEN, ALIGN_CENTER, 3.0f);
  text(FONT_SMALL, W * 0.5f, (int)(y + 148), "Type this PIN in the Handle Caddie app", C_MUTED, ALIGN_CENTER);
  char b[40]; snprintf(b, sizeof(b), "closes in %u s", (unsigned)leftS);
  text(FONT_SMALL, W * 0.5f, (int)(y + 176), b, C_MUTED, ALIGN_CENTER);
}

static void statTile(float x, float y, float w, float h, const char* lab, const char* val, const char* unit) {
  box(x, y, w, h, 10, C_TILE);
  label(lab, x + 12, y + 17);
  text(FONT_TITLE, x + 12, y + 40, val, C_TEXT);
  if (unit && *unit) {
    int vw = textWidth(FONT_TITLE, val);
    text(FONT_SMALL, x + 12 + vw + 4, y + 40, unit, C_MUTED);
  }
}

static void roundButton(const Rect& r, bool plus, uint32_t col, uint8_t fillA) {
  rrect(r.x, r.y, r.w, r.h, 16, col, col, fillA, 1.4f, col, 220);
  float cx = r.x + r.w / 2.0f, cy = r.y + r.h / 2.0f;
  box(cx - 10, cy - 2, 20, 4, 2, C_TEXT);
  if (plus) box(cx - 2, cy - 10, 4, 20, 2, C_TEXT);
}

static void puttPanel(const AppState& s) {
  roundButton(PUTT_MINUS, false, C_MUTED, 40);
  roundButton(PUTT_PLUS,  true,  C_GREEN, 50);

  float cx = LEFT_CARD.x + LEFT_CARD.w / 2.0f;
  label("PUTTS", cx, PUTT_MINUS.y + 15, C_MUTED, ALIGN_CENTER);
  char b[24];
  snprintf(b, sizeof(b), "%d", s.putts);
  text(FONT_BIG, cx, PUTT_MINUS.y + 50, b, C_TEXT, ALIGN_CENTER);

  rrect(HOLE_OUT.x, HOLE_OUT.y, HOLE_OUT.w, HOLE_OUT.h, 12, C_GREEN, C_GREEN, 255, 0, 0, 0);
  snprintf(b, sizeof(b), "HOLE OUT  -  %d", s.strokes + s.putts);
  text(FONT_BODY, HOLE_OUT.x + HOLE_OUT.w / 2.0f, HOLE_OUT.y + 26, b, C_BG, ALIGN_CENTER);
}

static void drawDashboard(const AppState& s) {
  fillScreen(C_BG);
  header(s, false);

  card(LEFT_CARD);
  const int lx = LEFT_CARD.x + 14;
  const int rx = LEFT_CARD.x + LEFT_CARD.w - 14;
  bool putt = puttMode(s);
  label("YARDS TO PIN", lx, LEFT_CARD.y + 28);

  // zone pill, or the "ON GREEN?" chip when we're close but not yet on the green
  if (nearGreen(s)) {
    const char* t = "ON GREEN?";
    int zw = textWidth(FONT_LABEL, t, 1.1f) + 24;
    float zx = rx - zw;
    pill(zx, LEFT_CARD.y + 12, zw, 24, C_AMBER, 40, C_AMBER);
    text(FONT_LABEL, zx + zw / 2.0f, LEFT_CARD.y + 28, t, C_AMBER, ALIGN_CENTER, 1.1f);
  } else {
    Zone z = putt ? ZONE_GREEN : s.zone;
    if (z != ZONE_UNKNOWN) {
      const char* zn = zoneName(z);
      uint32_t zc = zoneColor(z);
      int zw = textWidth(FONT_LABEL, zn, 1.1f) + 28;
      float zx = rx - zw;
      pill(zx, LEFT_CARD.y + 12, zw, 24, zc, 34, zc);
      circle(zx + 12, LEFT_CARD.y + 24, 3.0f, zc);
      text(FONT_LABEL, zx + 21, LEFT_CARD.y + 28, zn, zc, ALIGN_LEFT, 1.1f);
    }
  }

  char buf[24];
  if (s.toPin > 0) {
    snprintf(buf, sizeof(buf), "%d", s.toPin > 999 ? 999 : s.toPin);
    text(FONT_HERO, lx - 2, LEFT_CARD.y + 120, buf, C_TEXT);
  } else {
    text(FONT_BIG, lx, LEFT_CARD.y + 112, "--", C_DIM);
  }

  // front / back of green
  if (s.front > 0 || s.back > 0) {
    label("FRONT", rx, LEFT_CARD.y + 64, C_MUTED, ALIGN_RIGHT);
    snprintf(buf, sizeof(buf), s.front > 0 ? "%d" : "--", s.front);
    text(FONT_BODY, rx, LEFT_CARD.y + 83, buf, C_TEXT, ALIGN_RIGHT);
    label("BACK", rx, LEFT_CARD.y + 102, C_MUTED, ALIGN_RIGHT);
    snprintf(buf, sizeof(buf), s.back > 0 ? "%d" : "--", s.back);
    text(FONT_BODY, rx, LEFT_CARD.y + 121, buf, C_TEXT, ALIGN_RIGHT);
  }

  if (putt) {
    puttPanel(s);
  } else {
    // strokes + last shot tiles
    const float ty = STROKES_TILE.y, th = STROKES_TILE.h, tw = STROKES_TILE.w;
    snprintf(buf, sizeof(buf), "%d", s.strokes + s.putts);
    statTile(lx, ty, tw, th, "STROKES", buf, "");
    if (s.lastShot > 0) {
      snprintf(buf, sizeof(buf), "%d", s.lastShot);
      statTile(lx + tw + 8, ty, tw, th, "LAST SHOT", buf, "yd");
    } else {
      statTile(lx + tw + 8, ty, tw, th, "LAST SHOT", "--", "");
    }

    // club strip
    const Rect& cs = CLUB_STRIP;
    uint32_t ac = s.clubOut ? C_AMBER : C_GREEN;
    rrect(cs.x, cs.y, cs.w, cs.h, 12, ac, ac, 36, 1.2f, ac, 200);
    label(s.clubOut ? "CLUB IN HAND" : "RECOMMENDED", cs.x + 14, cs.y + 20, ac);
    const char* cn = s.clubOut && s.pulledClub[0] ? s.pulledClub : (s.club[0] ? s.club : "--");
    text(FONT_TITLE, cs.x + 14, cs.y + 44, cn, C_TEXT);
    if (s.clubCarry > 0) {
      label("CARRY", cs.x + cs.w - 14, cs.y + 20, C_MUTED, ALIGN_RIGHT);
      snprintf(buf, sizeof(buf), "%d yd", s.clubCarry);
      text(FONT_BODY, cs.x + cs.w - 14, cs.y + 44, buf, C_TEXT, ALIGN_RIGHT);
    }
  }

  drawMap(s);
}

// ---------------------------------------------------------------------------
// splash screen with loading bar (progress 0..1)
// ---------------------------------------------------------------------------
static void drawSplash(float progress, const char* msg) {
  fillScreen(C_BRAND);
  if (progress < 0) progress = 0;
  if (progress > 1) progress = 1;

  const float trk = 0.4f;                                   // letter spacing
  float wB = textWidthF(FONT_LOGOB, "HANDLE", trk);
  float wL = textWidthF(FONT_LOGOL, "CADDIE", trk);
  const float s = 1.45f, iconW = 40 * s, gap = 24, word = 14;
  float total = iconW + gap + wB + word + wL;
  float x0 = (W - total) * 0.5f;
  const int cy = 128;

  cartIcon(x0, cy - 16 * s, s, 0xFFFFFF, C_BRAND);
  float tx = x0 + iconW + gap;
  text(FONT_LOGOB, tx, cy + 14, "HANDLE", 0xFFFFFF, ALIGN_LEFT, trk);
  text(FONT_LOGOL, tx + wB + word, cy + 14, "CADDIE", 0xFFFFFF, ALIGN_LEFT, trk);

  // loading bar
  const float bw = 220, bh = 6, bx = (W - bw) * 0.5f, by = 196;
  rrect(bx, by, bw, bh, bh / 2, 0xFFFFFF, 0xFFFFFF, 38, 0, 0, 0);
  float fw = bw * progress;
  if (fw < bh) fw = bh;
  rrect(bx, by, fw, bh, bh / 2, 0xFFFFFF, 0xFFFFFF, 255, 0, 0, 0);

  if (msg && *msg) text(FONT_LABEL, W / 2.0f, by + 30, msg, mix(C_BRAND, 0xFFFFFF, 0.7f), ALIGN_CENTER, 1.6f);
}

// ---------------------------------------------------------------------------
// scorecard
// ---------------------------------------------------------------------------
static void scoreMark(float cx, float cy, int diff, uint32_t col) {
  if (diff <= -2)      { ring(cx, cy, 11.5f, 1.5f, col); ring(cx, cy, 8.0f, 1.5f, col); }
  else if (diff == -1) { ring(cx, cy, 10.5f, 1.6f, col); }
  else if (diff == 1)  { rrect(cx - 10, cy - 10, 20, 20, 4, col, col, 0, 1.6f, col, 255); }
  else if (diff >= 2)  { rrect(cx - 11.5f, cy - 11.5f, 23, 23, 5, col, col, 0, 1.5f, col, 255);
                         rrect(cx - 8, cy - 8, 16, 16, 3, col, col, 0, 1.5f, col, 255); }
}

static void drawNine(const AppState& s, int first, float top, bool isBack) {
  const float labX = 28, col0 = 100, colW = 34, totX = 432;
  const float rowH = 28;
  char b[16];

  // header row background
  box(24, top - 2, 432, rowH - 2, 8, C_TILE);
  label(isBack ? "IN" : "OUT", labX, top + 17, C_MUTED);
  label("PAR",  labX, top + rowH + 17, C_MUTED);
  label("SCORE", labX, top + 2 * rowH + 17, C_MUTED);
  label(isBack ? "IN" : "OUT", totX, top + 17, C_MUTED, ALIGN_CENTER);

  int parT = 0, scT = 0; bool allPlayed = true;
  for (int i = 0; i < 9; i++) {
    int h = first + i;
    float cx = col0 + i * colW;
    bool cur = (h + 1 == s.hole);
    if (cur) rrect(cx - 15, top - 2, 30, 3 * rowH - 2 + 0, 8, C_GREEN, C_GREEN, 22, 1.0f, C_GREEN, 140);
    snprintf(b, sizeof(b), "%d", h + 1);
    text(FONT_SMALL, cx, top + 17, b, cur ? C_GREEN : C_MUTED, ALIGN_CENTER);
    snprintf(b, sizeof(b), "%d", s.pars[h]);
    text(FONT_SMALL, cx, top + rowH + 18, b, C_TEXT, ALIGN_CENTER);
    parT += s.pars[h];

    if (s.scores[h] > 0) {
      int d = s.scores[h] - s.pars[h];
      uint32_t col = d <= -1 ? C_GREEN : (d == 0 ? C_TEXT : (d == 1 ? C_AMBER : C_RED));
      scoreMark(cx, top + 2 * rowH + 13, d, col);
      snprintf(b, sizeof(b), "%d", s.scores[h]);
      text(FONT_SMALL, cx, top + 2 * rowH + 18, b, col, ALIGN_CENTER);
      scT += s.scores[h];
    } else {
      allPlayed = false;
      text(FONT_SMALL, cx, top + 2 * rowH + 18, "-", C_DIM, ALIGN_CENTER);
    }
  }
  snprintf(b, sizeof(b), "%d", parT);
  text(FONT_BODY, totX, top + rowH + 19, b, C_TEXT, ALIGN_CENTER);
  if (scT > 0) {
    snprintf(b, sizeof(b), "%d", scT);
    text(FONT_BODY, totX, top + 2 * rowH + 19, b, allPlayed ? C_TEXT : C_MUTED, ALIGN_CENTER);
  } else {
    text(FONT_BODY, totX, top + 2 * rowH + 19, "-", C_DIM, ALIGN_CENTER);
  }
}

static void drawScorecard(const AppState& s) {
  fillScreen(C_BG);
  header(s, true);
  Rect all = {12, 52, 456, 256};
  card(all);

  drawNine(s, 0, 64, false);
  drawNine(s, 9, 160, true);

  // totals strip
  int parPlayed = 0, scoreT = 0, parAll = 0, played = 0;
  for (int i = 0; i < 18; i++) {
    parAll += s.pars[i];
    if (s.scores[i] > 0) { parPlayed += s.pars[i]; scoreT += s.scores[i]; played++; }
  }
  box(24, 254, 432, 44, 12, C_TILE);
  char b[32];
  label("THRU", 40, 272, C_MUTED);
  snprintf(b, sizeof(b), "%d", played);
  text(FONT_BODY, 40, 291, b, C_TEXT);
  label("PAR", 112, 272, C_MUTED);
  snprintf(b, sizeof(b), "%d", parAll);
  text(FONT_BODY, 112, 291, b, C_TEXT);
  label("SCORE", 184, 272, C_MUTED);
  snprintf(b, sizeof(b), "%d", scoreT);
  text(FONT_BODY, 184, 291, b, C_TEXT);

  int diff = scoreT - parPlayed;
  uint32_t dc = played == 0 ? C_DIM : (diff < 0 ? C_GREEN : (diff == 0 ? C_TEXT : (diff <= 4 ? C_AMBER : C_RED)));
  if (played == 0) snprintf(b, sizeof(b), "--");
  else if (diff == 0) snprintf(b, sizeof(b), "E");
  else snprintf(b, sizeof(b), "%+d", diff);
  text(FONT_BIG, 440, 291, b, dc, ALIGN_RIGHT);
  label("TO PAR", 440 - textWidth(FONT_BIG, b) - 14, 291, C_MUTED, ALIGN_RIGHT);
}

}  // namespace ui
