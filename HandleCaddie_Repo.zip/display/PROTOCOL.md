# HandleCaddie BLE protocol

Nordic UART service `6E400001-B5A3-F393-E0A9-E50E24DCCA9E`
Device name: `HandleCaddie_BLE`

- App -> unit: write to RX `6E400002-...` (write with response for anything big)
- Unit -> app: notifications on TX `6E400003-...`
- **Request a larger MTU after connecting** (`requestMtu(247)` or more). The default
  20-byte payload is too small for course polygons; with a larger MTU the unit still
  assembles messages split over several writes as long as each message ends in `\n`.
- One flat JSON object per message, UTF-8, terminated with `\n`. Every key is optional.

## App -> unit

| key | type | meaning |
|---|---|---|
| `hole` | int 1-18 | Switching holes clears per-hole data (strokes, last shot, map). Send this first. |
| `par`, `len` | int | Par and hole length in yards |
| `dist` | int | Yards to pin (the big number). `distance` also accepted. |
| `front`, `back` | int | Yards to front / back of the green (shown beside the big number) |
| `zone` | string | `"tee"`, `"fairway"`, `"rough"`, `"green"` |
| `strokes` | int | Full swings this hole, **not counting putts** - the app is the authority |
| `putts` | int | Putts this hole (the unit also lets the user enter these; see below) |
| `last` | int | Distance of the last shot, yards |
| `club`, `carry` | string, int | Recommended club and its expected carry |
| `pulled` | string | Name of the club actually in hand (overrides the recommendation on screen) |
| `clubOut` | bool | Force the "club in hand" state on/off |
| `fairway`, `green`, `bunkers`, `water` | polygon or list of polygons | `[[x,y],...]`, or `[[[x,y],...], [[x,y],...]]`. Max 48 points each. |
| `tee`, `pin`, `player` | `[x,y]` | Markers. Send `player` often (e.g. 1 Hz) to move the blue dot. |
| `pars`, `scores` | 18 ints | Scorecard. `0` in `scores` = not played yet. |

Map coordinates can be any consistent unit (yards, metres, projected lat/lon). The unit
auto-fits everything to the map card, so no scaling is needed. `y` grows downward, so
put the tee at larger `y` for tee-at-bottom orientation.

Example:

    {"hole":4,"par":4,"len":385,"dist":142,"zone":"fairway","strokes":2,"last":231,
     "club":"7 Iron","carry":150,"player":[112,232],"pin":[204,98],"tee":[58,388],
     "fairway":[[40,395],[78,395],[88,300],[110,230],[150,170],[200,120],[196,70]],
     "green":[[176,80],[208,70],[232,88],[228,116],[200,128],[176,112]],
     "bunkers":[[[150,118],[168,112],[172,132],[154,138]]]}\n

## Unit -> app

| message | meaning |
|---|---|
| `{"e":"pull"}` | A club left the bag (sensor confirmed gone for 0.5 s) |
| `{"e":"ret","ms":23500}` | Club put back; `ms` = how long it was out |
| `{"e":"str","n":3}` | The user corrected the stroke count by tapping the STROKES tile |
| `{"e":"green"}` | User tapped **ON GREEN?** (appears inside 60 yd). Treat as "now putting" even if GPS hasn't confirmed the green |
| `{"e":"putt","n":2}` | Putt count changed with the - / + buttons (absolute count, not a delta) |
| `{"e":"out","s":5,"p":2}` | **HOLE OUT** tapped. `s` = total strokes including putts, `p` = putts. Record the score and send the next `hole` |

Suggested app logic: on `pull`, note GPS position + zone + club; the next time you stop
moving (or the next `pull`), the distance between the two fixes is the shot distance.
Increment strokes on `pull` (or on `ret`) per your own rules, then send back
`strokes`, `last` and the next `club`.

## Offline behaviour
If the phone is not connected the unit shows "Searching", tapping the map card advances
the hole, and it keeps a rough stroke count (club out for 8 s or more, then returned).

## Putting flow
The cart stays off the green, so the unit handles putt entry:
1. Inside 60 yd (and not yet in zone `green`) the zone pill becomes an amber **ON GREEN?** button.
   When `zone` is `"green"` - from the app or from that tap - the left card switches to the putt panel and
   the map zooms to the green.
2. **- / +** change the putt count; each change is sent as `{"e":"putt","n":N}`.
3. **HOLE OUT** sends `{"e":"out",...}`. Offline, the unit stores the score itself and advances the hole.
4. Sending any `zone` from the app takes over again (it clears the manual putting state), and a new `hole`
   resets putts to 0.

## Course data (hole shapes)
The map needs polygons for each hole. OpenStreetMap has free golf mapping for many courses
(tags `golf=fairway`, `golf=green`, `golf=bunker`, `golf=tee`, `golf=water_hazard`,
`golf=lateral_water_hazard`, plus a `golf=hole` line from tee to pin - see
https://wiki.openstreetmap.org/wiki/Key:golf). Coverage varies by course, so check yours first.
Convert lat/lon to a local flat grid (metres east/south of the tee) and send those as the
coordinates. The unit rotates the hole so tee -> pin points up, so you don't need to.


## Caddie tip (phone -> unit)

`{"tip":"Birdie. Nicely played."}` shows one line of text in a pill near the bottom of whichever screen is up. It stays solid
for about 3.2 s, fades out over 0.9 s, then disappears by itself. Plain ASCII, at most 52 characters (the phone trims and
cleans it). A new tip replaces the one on screen. The phone sends one after a hole is finished (by score against par), and when
the cart guard stops the cart ("Cart holding: bunker ahead.").

## Who may connect (authentication)

With `DISPLAY_AUTH 1` (the default in `HandleCaddie.ino`) the display ignores every line from a phone until the phone has proved it holds the display's key, and sends nothing to it either. It uses exactly the same messages as the cart link (`cart_auth.h`, see CART_PROTOCOL.md):

| direction | message | meaning |
|---|---|---|
| app -> unit | `{"k":"hello"}` | "send me a challenge" (sent right after connecting) |
| unit -> app | `{"k":"chal","n":"<16 hex>","paired":0/1,"pairing":0/1,"sec":0,"fresh":0}` | fresh random challenge; `paired` = a key is stored; `pairing` = the PIN window is open |
| app -> unit | `{"k":"auth","h":"<32 hex>"}` | `h` = first 16 bytes of HMAC-SHA256(key, challenge text), hex |
| unit -> app | `{"k":"auth","ok":1}` or `{"k":"auth","ok":0,"left":3}` / `"wait":60` / `"np":1` | result; 5 wrong answers lock it out for 60 s |
| app -> unit | `{"k":"pair","pin":"123456"}` | only while the PIN window is open |
| unit -> app | `{"k":"paired","ok":1,"key":"<32 hex>"}` | the new key; store it |

- **First use:** with no key stored the display opens a 5 minute pairing window by itself and shows a PIN on its screen. Type it into the app (Play tab > Display).
- **Another phone later:** touch and hold the top-left corner of the dashboard for 4 seconds (a 2 minute window), or send `pair` over USB serial. The new phone replaces the old one. `unpair` over serial forgets the key.
- A phone that connects and does not authenticate within 10 seconds is disconnected, so a stranger cannot hold the one connection slot.
- The key lives in the display's flash (`Preferences`, namespace `hcdisp`).
- The link itself is **not** encrypted (unlike the cart's, which also uses Bluetooth LE Secure Connections): someone recording the radio during the few seconds of pairing could learn the key. Pair away from a crowd.
- An older app that knows nothing of this cannot use a display built with `DISPLAY_AUTH 1`; set `DISPLAY_AUTH 0` to go back. A newer app talking to an older display simply gets no challenge and carries on as before.
