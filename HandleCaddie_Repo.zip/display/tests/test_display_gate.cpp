// Host test of the display's Bluetooth gate:  g++ -std=c++17 -Wall -o /tmp/t_dg tests/test_display_gate.cpp && /tmp/t_dg
#include "../display_gate.h"
#include <cstdio>
using namespace cart;
static int fails = 0, passes = 0;
#define CHECK(c, m) do { if (c) { passes++; } else { fails++; printf("FAIL: %s\n", m); } } while (0)
static uint32_t rs = 12345;
static uint32_t rnd() { rs = rs * 1664525u + 1013904223u; return rs; }

static bool say(DisplayGate& g, const char* line, uint32_t now, char* reply, bool* kc) { bool k = false; bool app = g.onLine(line, now, reply, 300, &k); if (kc) *kc = k; return app; }
static void nonceOf(const char* chal, char* out) { getStr(chal, "n", out, 20); }
static void answer(const uint8_t* key, const char* chal, char* line) {
  char n[20], tag[40]; nonceOf(chal, n); Auth::tagFor(key, n, tag); snprintf(line, 120, "{\"k\":\"auth\",\"h\":\"%s\"}", tag);
}

int main() {
  // ---- first boot: no key -> pairing opens by itself, PIN is 6 digits
  DisplayGate g(rnd); g.begin(nullptr, 1000);
  CHECK(!g.paired() && g.pairingOpen(1000) && strlen(g.pin()) == 6, "no key: pairing window opens at boot with a 6 digit PIN");
  CHECK(g.pairingLeftS(1000) >= 299, "window is 5 minutes at first boot");
  char chal[300], reply[300], line[160];
  g.connected(2000, chal, sizeof(chal));
  CHECK(strstr(chal, "\"k\":\"chal\"") && strstr(chal, "\"paired\":0") && strstr(chal, "\"pairing\":1"), "challenge says: not paired, pairing open");
  // unauthenticated data is ignored
  CHECK(!say(g, "{\"hole\":4,\"dist\":150}", 2100, reply, nullptr), "unauthenticated hole data is NOT passed on");
  CHECK(reply[0] == 0, "and nothing is said back");
  // wrong PIN, then right PIN
  CHECK(!say(g, "{\"k\":\"pair\",\"pin\":\"000000\"}", 2200, reply, nullptr) && strstr(reply, "\"ok\":0"), "wrong PIN refused");
  snprintf(line, sizeof(line), "{\"k\":\"pair\",\"pin\":\"%s\"}", g.pin());
  bool kc = false;
  CHECK(!say(g, line, 2300, reply, &kc), "pairing line itself is not passed to the app");
  CHECK(strstr(reply, "\"ok\":1") && strstr(reply, "\"key\":\""), "right PIN: the key comes back");
  CHECK(kc && g.authed() && g.paired(), "paired and authenticated at once");
  uint8_t key[16]; bool erase = true;
  CHECK(g.takeKey(key, &erase) && !erase, "the new key is handed over to be stored");
  CHECK(say(g, "{\"hole\":4,\"dist\":150}", 2400, reply, nullptr), "now data passes through");
  CHECK(!g.pairingOpen(2400), "window closes after a successful pairing");

  // ---- reconnect with the key
  g.disconnected();
  CHECK(!g.authed(), "a dropped link is not authenticated any more");
  DisplayGate h(rnd); h.begin(key, 5000);
  CHECK(h.paired() && !h.pairingOpen(5000), "with a stored key the pairing window stays shut");
  h.connected(6000, chal, sizeof(chal));
  CHECK(strstr(chal, "\"paired\":1") && strstr(chal, "\"pairing\":0"), "challenge says: paired, pairing closed");
  CHECK(!say(h, "{\"hole\":9}", 6100, reply, nullptr), "unauthenticated lines ignored while paired");
  answer(key, chal, line);
  kc = false; CHECK(!say(h, line, 6200, reply, &kc) && strstr(reply, "\"ok\":1") && h.authed(), "correct answer authenticates");
  CHECK(say(h, "{\"hole\":9}", 6300, reply, nullptr), "data passes after authentication");
  CHECK(!say(h, line, 6400, reply, nullptr) && h.authed(), "replaying the answer is harmless");
  h.disconnected();
  // replay on a NEW connection fails (new nonce)
  h.connected(7000, chal, sizeof(chal));
  CHECK(!say(h, line, 7100, reply, nullptr) && !h.authed(), "a recorded answer from an earlier connection is useless");
  // wrong key
  uint8_t bad[16]; memcpy(bad, key, 16); bad[3] ^= 0x55;
  answer(bad, chal, line);
  h.disconnected(); h.connected(8000, chal, sizeof(chal)); answer(bad, chal, line);
  CHECK(!say(h, line, 8100, reply, nullptr) && !h.authed() && strstr(reply, "\"ok\":0"), "wrong key refused");
  // hello asks for a challenge again
  CHECK(!say(h, "{\"k\":\"hello\"}", 8200, reply, nullptr) && strstr(reply, "\"k\":\"chal\""), "hello gets a challenge");
  // lockout after repeated failures
  for (int i = 0; i < 6; i++) { char n[20]; nonceOf(reply, n); answer(bad, reply, line); say(h, line, 8300 + i, reply, nullptr); }
  CHECK(strstr(reply, "\"wait\"") != nullptr, "repeated wrong answers lock the display out for a while");

  // ---- stranger cannot hog the slot
  DisplayGate s(rnd); s.begin(key, 0);
  s.connected(1000, chal, sizeof(chal));
  CHECK(!s.shouldCut(5000), "not cut early");
  CHECK(s.shouldCut(11500), "an unauthenticated phone is cut after 10 s");
  CHECK(!s.shouldCut(12000), "cut only once");
  DisplayGate a(rnd); a.begin(key, 0); a.connected(1000, chal, sizeof(chal)); answer(key, chal, line); say(a, line, 1100, reply, nullptr);
  CHECK(!a.shouldCut(30000), "an authenticated phone is never cut");
  CHECK(!a.shouldCut(0) , "no crash on odd times");
  DisplayGate off(rnd); off.begin(key, 0);
  CHECK(!off.shouldCut(99999), "nothing to cut when nobody is connected");

  // ---- hold the corner to pair a new phone
  DisplayGate p(rnd); p.begin(key, 0);
  for (uint32_t t = 1000; t < 4800; t += 100) p.touch(true, t);
  CHECK(!p.pairingOpen(4800), "3.8 s of holding is not enough");
  p.touch(true, 5100);
  CHECK(p.pairingOpen(5100) && strlen(p.pin()) == 6, "4 s of holding opens the pairing window");
  CHECK(p.pairingLeftS(5100) >= 119, "for 2 minutes");
  DisplayGate q(rnd); q.begin(key, 0);
  for (uint32_t t = 1000; t < 3000; t += 100) q.touch(true, t);
  q.touch(false, 3100);
  for (uint32_t t = 3200; t < 5000; t += 100) q.touch(true, t);
  CHECK(!q.pairingOpen(5000), "lifting the finger restarts the hold");
  DisplayGate r2(rnd); r2.begin(key, 0);
  for (uint32_t t = 1000; t < 2000; t += 100) r2.touch(true, t);
  for (uint32_t t = 5000; t < 6000; t += 100) r2.touch(true, t);      // a long pause between touches is a new hold
  CHECK(!r2.pairingOpen(6000), "two short taps far apart do not add up");

  // ---- a second phone replaces the first
  DisplayGate m(rnd); m.begin(key, 0); m.openPairing(100);
  m.connected(200, chal, sizeof(chal));
  snprintf(line, sizeof(line), "{\"k\":\"pair\",\"pin\":\"%s\"}", m.pin());
  say(m, line, 300, reply, nullptr);
  uint8_t k2[16]; bool er; CHECK(m.takeKey(k2, &er) && memcmp(k2, key, 16) != 0, "pairing a new phone makes a different key");
  m.disconnected();
  m.connected(1000, chal, sizeof(chal)); answer(key, chal, line);
  CHECK(!say(m, line, 1100, reply, nullptr) && !m.authed(), "the old phone's key no longer works");
  m.disconnected(); m.connected(2000, chal, sizeof(chal)); answer(k2, chal, line); say(m, line, 2100, reply, nullptr);
  CHECK(m.authed(), "the new phone's key works");

  // ---- forget (serial 'unpair')
  m.forget(3000);
  CHECK(!m.paired() && m.pairingOpen(3000), "forget: unpaired, window open");
  uint8_t kk[16]; bool e2 = false; CHECK(m.takeKey(kk, &e2) && e2, "forget: the stored key is to be erased");

  // ---- junk lines
  DisplayGate j(rnd); j.begin(key, 0); j.connected(0, chal, sizeof(chal));
  CHECK(!say(j, "", 10, reply, nullptr) && !say(j, "garbage", 10, reply, nullptr) && !say(j, "{\"k\":", 10, reply, nullptr), "junk is ignored, no crash");
  CHECK(!say(j, "{\"k\":\"auth\"}", 10, reply, nullptr) && !j.authed(), "an auth line with no answer is refused");
  CHECK(!say(j, "4", 10, reply, nullptr), "a bare hole number is not passed while unauthenticated");

  printf("%d passed, %d failed\n", passes, fails);
  return fails ? 1 : 0;
}
