# Handle Caddie - Android controller

## Install
1. Copy `app/src/main/java/com/handlecaddie/controller/*` into your project (same package, folders `core ble data service ui`).
   Delete your old `MainActivity.kt` (the new one is `ui/MainActivity.kt`).
2. Replace your manifest with `app/src/main/AndroidManifest.xml` (or merge: see the permission notes inside it).
3. Add the lines from `app/build.gradle.kts.snippet`.
4. Build, install, accept the permission prompts, tap START ROUND (it starts by itself once permissions are granted).

## Courses, round format, bag
- **Play tab**: courses within ~19 miles of you are listed automatically (OpenStreetMap, nearest first; the closest is preselected).
  Pick a course, pick 18 holes / Front 9 / Back 9, tap START ROUND. The card collapses to "Course name - format" with an **Edit**
  button. Changing the format keeps your scores; changing the course starts a new round.
- **My Golf Bag tab**: swing-speed setting, **Add clubs** (drivers, fairway woods, hybrids, irons incl. full sets, wedges, putters by brand
  and model), editable carry per club, 14-club warning.
- **Distances are estimates.** Makers publish lofts, not carry distances, so each club's carry is estimated from its loft and your
  swing-speed setting. Type your own number in a Carry box and it is kept. The caddie recommends the shortest club that reaches the pin.
- **Lofts are typical for the model family** (e.g. a "game improvement" 7 iron is ~28 deg) and only drive the estimate. If yours differs, type your own carry.
- **Brand logos**: the app ships none (they are trademarks) and shows a plain initials badge. To show real logos, put your own files in
  `app/src/main/res/drawable/` named `brand_<id>.png`, with id one of: taylormade, callaway, titleist, ping, cobra, mizuno, srixon,
  cleveland, pxg, wilson, scotty, odyssey, bettinardi, lab, kirkland. Lowercase, no spaces. Then rebuild.

- **Scorecard**: tap a hole to correct its par (3-6). Holes whose par was guessed from length (the map had none) are marked "estimated", corrected ones "edited". Corrections are saved per course and also go to the display.

## Cart page (motor control)
- **Cart tab**: connect to the cart (`HandleCaddie_Cart`), pick Park / Follow / Manual, a STOP button, a forward-only joystick, follow distance
  (feet), top speed and downhill speed (mph), hill-hold switch, and live battery volts, speed, pitch, roll, slope, distance and direction to
  the fob, obstacle distance, motor and brake bars, trip and all-time miles, faults and status messages. Also "Set level" and "Clear fault".
- **Demo mode** (switch at the top of the page) drives the page from a built-in toy simulator so you can try it with no cart. It is clearly labelled and
  is not a model of the real cart. It is disabled while a real cart is connected.
- **The cart firmware does not speak this protocol yet.** CART_PROTOCOL.md is the contract the cart sketch must follow, including the safety rules
  (starts in Park, joystick dead-man timeout, faults override everything).

## How it works
Phone owns GPS, course map (OpenStreetMap), club recommendation and scoring. The display shows it and reports
club pull / return / putts back. Protocol: see HandleCaddie/PROTOCOL.md in the firmware project.

## Not yet verified (be aware)
- Compiled only as pure Kotlin (core/): 105 self-tests pass, and its messages were fed through the real firmware parser.
- ble/, service/, data/ and ui/ have NOT been compiled against the Android SDK. Expect a few small compile fixes.
- Never run on hardware. First test: walk outside with the display on and watch the Play tab.
- OSM golf data varies by course; if "Course: not mapped" appears, that course needs mapping or manual data.


## Green guard and shot learning
- Green guard (Cart tab): holds the cart before it follows you onto a green, using phone GPS and the map. Accuracy is limited by GPS error (a few yards) so it stops about 15 yd short; the cart switch always works. If the next tee is beyond the green the cart may wait behind. No enforcement if BLE drops.
- Learning: each time you pull a club, the distance from the previous pull is logged as that club's shot (ball to ball, includes roll, +/- a few yards). It records the club the caddie recommended; tap Recent shots to correct. After 3+ shots, your average is blended with the estimate. Toggle in My Golf Bag.
- The Android UI has not been compiled against the SDK; expect small compile fixes.

- Ball location: when a club comes out, the app uses the median of the last few seconds of GPS and, while the cart is following, moves it the follow distance toward the pin (cart stops that far behind where you stood). Max 6 m. GPS error is larger than this correction, so it only removes the systematic offset.

## Hazard guard (was "green guard") and caddie tips
- The guard now keeps the cart away from **greens, water and bunkers**, each with its own buffer (defaults 12 / 12 / 7 m, adjustable
  in the Cart tab). Poor GPS accuracy widens every buffer, and if the phone loses GPS (worse than 50 m) the cart holds until it recovers.
  It only *holds* the cart (stage one); steering around a hazard is a later stage. Test it with the wheels off the ground first.
- The phone sends a one-line "caddie tip" to the HandleCaddie display (after each hole by score, and when the guard stops the cart).
  The display shows it for ~3 s and fades it out. Wording lives in `core/CaddieVoice.kt`.
- Course data can come from your hosted copy (`HOSTED_BASE` in `CourseRepository.kt`); the map credit is on the setup screen.

## My Game: automatic stats and the Caddie Report
- Nothing to type in. For every finished hole the app keeps swings, putts (entered on the unit), whether the tee shot finished in the
  fairway (par 4/5, using the map and the ball-location estimate), the drive distance, and greens in regulation (needs putts entered;
  a hole with no putts entered is left out of the GIR and putting numbers, not counted as a miss).
- The **My Game** tab shows the Caddie Report for today's round as you go (score mix, fairways, greens, putts, longest drive, a
  comparison with your usual, and one "focus for next time"), four stat tiles, and **My rounds**: a finished round is saved
  automatically (or tap "Save the round so far"), with averages once you have two or more.
- Wording lives in `core/Stats.kt` (`CaddieReport`) and `core/CaddieVoice.kt`. Benchmarks used for the focus line are rough amateur
  figures (fairways 55%, greens 35%, 1.95 putts a hole) and are easy to change at the top of `CaddieReport`.

## Bench test and decision log (Cart tab)
- **Bench test** runs a made-up walk through the hazard guard instead of the real GPS, so the guard, the phone-to-cart link and the cart's own response can be tried with the wheels off the ground. Four scenarios: walk at a hazard (and back), walk across to the far side, weak GPS, GPS drops out. Each ends with pass/fail checks. Scores and stats are not touched while a test runs, and the cart is released when it ends.
- **GPS watchdog** (new, also on the course): if GPS fixes stop arriving for 5 s the guard treats the position as lost and the cart holds, until good fixes return.
- **Decision log** is always on: every hold, release, switch override, fob loss and cart link change is written down with the reason. Copy it from the Bench test card.
- The full procedure for the first session with the real cart is in `BENCH_TEST.md`.
- Core logic is in `core/BenchSim.kt` and covered by `tools/CoreSelfTest.kt`; the service wiring and screen (`service/CaddieService.kt`, `ui/BenchUi.kt`) are not compiled or run here.
- **The cart does not follow you across a hazard.** The guard lets go only when you are clear AND the cart's straight path to you stays out of the hazard's margin. Otherwise it keeps waiting (screen: "path blocked", display tip: "Cart waiting: path blocked."). You walk back around, or use the switch on the cart. Going around hazards by itself is stage 2.

## Your clubs (My Game tab)
- A "YOUR CLUBS" card lists every club with at least 3 usable shots: average distance, how steady it is (the +/- is the typical shot-to-shot variation), and the bag's own number when it differs by 5 yd or more.
- Up to three caddie remarks: a club that has got shorter or longer lately (last 4 shots against the earlier ones, 8 shots needed), your loosest or most reliable club, and gaps between clubs (a hole of 25 yd or more, or two clubs within 4 yd).
- Uses the same cleaned shot log as the club recommendation (bad-GPS shots and mis-hits are ignored). Core logic in `core/ClubInsights.kt`, tested in `tools/CoreSelfTest.kt`.

## Cart pairing and PIN
The cart ignores every command until this phone has paired with it. First time: connect, then type the 6-digit PIN shown on the cart's screen into Android's pairing dialog. The phone keeps the key it is given and proves it on every connection with a one-time challenge (nothing reusable goes over the air). "Forget" on the Link card removes the key. To pair another phone: six quick pause-switch flips on the cart while parked. The link is encrypted with Bluetooth LE Secure Connections: the first time, Android shows its own pairing dialog and you type the PIN from the cart's screen there; the app then finishes pairing by itself. The cart keeps one phone at a time.

## Plays-like yardage, battery forecast, find my cart

- **Plays-like (Play tab):** under the distance, a line such as "Plays 158: headwind 12 mph +8, uphill 13 ft +4" and the club to take for that number. Wind and temperature come from Open-Meteo (refreshed every 10 minutes), heights of the tee and pin from the US Geological Survey (US courses; one lookup per hole). Without internet it simply shows nothing. Rules of thumb: headwind +1% per mph, tailwind -0.5% per mph, +1.1 yd per metre uphill, about 1.8% per 10 C of cold, and thin air about 4% per 1000 m, which is added only for clubs whose distance was estimated from loft (typed-in or learned distances already include the local air).
- **Battery forecast (Cart tab):** learns charge per km from the cart's trip counter and compares it with the holes left. Warns on the display once if the battery may not last.
- **Cart left behind (Cart tab):** when the cart link drops and you keep walking, you get a message on the display and the app after 60 yd, and a stronger one at 150 yd, with the direction back to where it was last with you. Pressing Disconnect turns it off.

Tests: `tools/ExtrasSelfTest.kt` (34 checks). The two web lookups are written from the services' documented formats and have NOT been run against the live servers yet.

## Watch (Wear OS)

See WEAR_SETUP.md. The watch shows distance / club / cart status, buzzes for alerts, has Next hole and cart buttons, asks "Move on to hole N?" after a hole-out, and can supply your GPS position so the phone can stay on the cart (Cart tab > Watch). Tests for the message format: tools/ExtrasSelfTest.kt. NOT tested on a real watch.

## Phone on the cart: measured cart position, better go-around, GPS follow

Turn on Cart tab > Watch > "Use my watch for my position". Then:
- Your position is the watch's GPS; the phone's own GPS is the CART's position (mount it with a clear view of the sky).
- The hazard guard uses the measured cart position instead of estimating it from your trail.
- The go-around steers from the cart's GPS as it drives (position and heading corrected continuously), so its error no longer grows with distance. In simulation (25 runs each) every run reached the player and the cart stayed at least 8 m from the green edge, even with a 6% wheel error that made 11 of 25 unaided runs stop themselves.
- Optional "GPS follow when the fob is lost": if the fob has been out of reach for 6 s and you are more than 20 m ahead by GPS, the cart drives after your watch's position at up to 1.4 m/s and stops about 10 m short; the fob takes over again when it is back in range. In simulation (12 runs, a green beside the path) it never came within 5 m of the player, stayed 15 m off the green and caught up every time. It needs the wheel speed sensor wired, and it is a fallback, not a replacement for the fob.
- If the cart's GPS goes quiet for 8 s mid-route, the route ends and the cart stops.
Tests: tools/NavSelfTest.kt (70 checks).

## Round features: pace, lightning, misses, recap, unmapped courses

**Pace of play** (My Game tab, and a line on the Play tab). The clock starts when you take your first club out. Your target is minutes for 18 holes (default 4:15, change it with -15/+15); each hole gets a share by par (a par 3 a little less, a par 5 a little more). The caddie tells you how far ahead or behind you are, when you are likely to finish, and speaks up on the display when you slip (not on every hole, and again if it gets worse). Pause the clock for lunch or a long wait. Time stopped does not count.

**Storm alerts.** The phone cannot sense lightning, so this is two things: the weather forecast (a thunderstorm now, or in the next hour, is checked every 10 minutes, every 3 while a storm is near) and the flash-to-bang count you tap in ("Saw lightning or heard thunder?"). Bang under 30 seconds (about 6 miles) or any thunder with no count means TAKE COVER; it stays up until 30 minutes after the last thunder. The warning goes to the phone, the display tip line and the watch. Treat it as a second pair of eyes, not a detector. When in doubt, go in.

**Where you miss.** Each shot now records where it started, where it ended, how far to the side of the line to the pin it finished (right or left), and how far from the pin. Once a club has 5 or more tracked shots and the pattern is clearly bigger than GPS noise, the Play tab says "Your 7 Iron tends to miss right (9 yd on average). Aim about 9 yd left of the pin", and My Game lists every club. Tee shots on doglegs and long lay-ups get no sideways number (the line to the pin means nothing there). Older saved shots still load; they just have no miss data.

**Round recap.** My Game > "Share round recap" builds a plain-text summary (scorecard with Out/In and total, fairways, greens, putts, time per hole and the slowest hole, shots tracked and your miss, weather) and opens the Android share sheet.

**Courses that are not mapped hole by hole** (for example Logan River). Instead of an error you get "learning this course". Scoring, shot distances, pace, storms and the recap work from the first hole. The app learns each hole as you play it: the tee is where the first club of the hole comes out, the pin is where you stand at HOLE OUT. From the next round those holes show yardage to the pin, with the position averaged over rounds (a wildly different sighting is ignored). No hazards or green shapes are learned, so the green guard cannot protect those holes; keep the cart in manual there. Learned data is kept on the phone only.
Tests: tools/RoundSelfTest.kt (93 checks).

## Drive to the next tee, and display pairing

**Drive to the next tee** (Cart tab, off at every start, experimental). With the switch on, when you hole out and press Go on the watch (or tap "Send the cart to the next tee now"), the cart drives itself to the next tee and parks there instead of following you across the green. It plans round greens, water and bunkers with the same planner and the same safety stops as the go-around, but to a fixed spot. It does not start unless the cart is connected, still, fault-free, ready for routes, GPS is good, and the map knows the tee (a hole of an unmapped course not yet learned has no tee). The hazard guard holding the cart while you stand on the green does not cancel it. Limits, measured in simulation: with the phone on the cart (its GPS corrects the route) 10 of 10 runs parked within 8 m of the tee over about 130 m; by wheel counting alone the worst run ended 19.5 m off, so without cart GPS the app only goes up to 100 m. The cart has no sensors that see people or other carts: watch it, the cart's own switch always stops it, and so does Park in the app. Tests: tools/NavSelfTest.kt (70 checks).

**Display pairing.** The display now ignores every phone until it has paired (PIN on its screen, entered on the Play tab > Display). If you flash `DISPLAY_AUTH 1` firmware you need this app version; set `DISPLAY_AUTH 0` in HandleCaddie.ino to go back. Details in HandleCaddie/PROTOCOL.md.

## Manual driving: speed cap, creep, and from the watch

Cart tab > Manual drive (cart must be in Manual):
- **Top speed slider.** Caps the joystick, the watch buttons and creep. It starts at half speed (0.6 m/s, a slow walk) every time the app starts.
- **Creep / Creep left / Creep right.** One tap moves the cart about half a metre at a crawl (about 0.3 m/s for 1.5 s) and it stops by itself. For lining up at a tee.
- **Drive from the watch** (switch, off at every start). When on, the watch shows "Cart: drive": three hold buttons (forward-left, forward, forward-right) and STOP / Done. The cart only drives forward, so there is no reverse and no spin on the spot.

How the watch stays safe: while a button is held the watch sends its code about 7 times a second, and the phone treats each as a 0.35 s pulse. Letting go, the Bluetooth link dropping, or the watch app closing therefore stops it within about half a second, and the cart adds its own 500 ms stop if the phone goes quiet. A burst of queued messages cannot add time up. A finger on the phone's joystick always wins. Changing mode or pressing STOP cancels it. The wireless link between watch and phone is not instant and not guaranteed, so treat it as a convenience for slow positioning, not as an emergency stop: the cart's own switch is the stop.
Tests: tools/ExtrasSelfTest.kt (63 checks, incl. the pulse rules).

## How the app is built to stay up

- One thread runs all the service logic (GPS, cart, watch, timers), so those parts can never race each other. Network and big file reads stay on background threads.
- A message that makes the handler throw is written to the decision log and skipped; the round carries on. Three such errors in 10 seconds put the cart on hold for good (until the app is restarted), because the phone-side protection can no longer be trusted.
- A watch STOP is run directly on that thread, never through a queue that could drop it. The command queue is also eight times bigger than before.
- Screens only update while they are on screen (nothing is redrawn with the phone in your pocket).
- If Android refuses to start the round service in the background, the service ends quietly instead of crashing.
- Memory is bounded everywhere: the decision log keeps 300 lines, shots 1,500, round history 200, one course map in memory, and the saved course maps live on disk.
