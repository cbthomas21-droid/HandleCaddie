package com.handlecaddie.controller.wear

import android.os.VibrationEffect
import android.os.Vibrator
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService
import com.handlecaddie.controller.core.WatchProtocol

class PhoneListenerService : WearableListenerService() {
    override fun onMessageReceived(e: MessageEvent) {
        if (e.path != WatchProtocol.PATH_STATE) return
        val st = WatchProtocol.decodeState(String(e.data, Charsets.UTF_8)) ?: return
        val old = WatchModel.state.value
        WatchModel.state.value = st
        WatchModel.lastStateMs.value = System.currentTimeMillis()
        val v = getSystemService(Vibrator::class.java) ?: return
        when {
            st.advanceTo != null && st.advanceTo != old.advanceTo -> v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 120, 80, 120), -1))     // "move on?" - two taps
            st.alert != null && st.alert != old.alert -> v.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}
