package com.handlecaddie.controller.wear

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clip
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Text
import com.handlecaddie.controller.core.WatchCmd

class WatchMainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { WatchApp() } }
    }
}

private fun startGps(ctx: Context) = ctx.startForegroundService(Intent(ctx, GpsService::class.java))
private fun stopGps(ctx: Context) = ctx.startService(Intent(ctx, GpsService::class.java).setAction(GpsService.ACTION_STOP))

@Composable
private fun WatchApp() {
    val ctx = LocalContext.current
    val st by WatchModel.state.collectAsState()
    val gps by WatchModel.gpsRunning.collectAsState()
    val seen by WatchModel.lastStateMs.collectAsState()

    // location + notification permission, asked when the phone wants the watch's position
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) startGps(ctx)
    }
    val haveLocation = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    // the phone is using the watch for position: start sending (this app is on screen, which is when Android allows it)
    LaunchedEffect(st.posFromWatch, haveLocation) {
        if (st.posFromWatch && !gps) {
            if (haveLocation) startGps(ctx) else perms.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS))
        }
        if (!st.posFromWatch && gps) stopGps(ctx)
    }

    val adv = st.advanceTo
    if (adv != null) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Hole ${adv - 1} done", fontSize = 16.sp)
            Text("Move on to hole $adv?", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Column(Modifier.padding8(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip(onClick = { WatchLink.sendCmd(ctx, WatchCmd.ADVANCE_YES) }, label = { Text("Go") }, modifier = Modifier.fillMaxWidth())
                Chip(onClick = { WatchLink.sendCmd(ctx, WatchCmd.ADVANCE_NO) }, label = { Text("Later") }, modifier = Modifier.fillMaxWidth())
            }
        }
        return
    }

    var driving by remember { mutableStateOf(false) }
    if (driving && !st.drive) driving = false          // the phone switched it off
    if (driving) {
        DriveScreen(ctx) { driving = false }
        return
    }

    val stale = seen == 0L || System.currentTimeMillis() - seen > 15_000
    ScalingLazyColumn(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item { Text(if (stale) "Waiting for the phone…" else "Hole ${st.hole}  Par ${st.par}", fontSize = 14.sp) }
        item {
            Text(st.toPinYd?.toString() ?: "--", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFC107))
        }
        item { Text("yd to pin", fontSize = 11.sp) }
        st.playsYd?.let { item { Text("plays like $it", fontSize = 13.sp, color = Color(0xFF03EEEF)) } }
        st.club?.let { item { Text(it, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) } }
        item {
            val cart = st.cartMode?.let { "Cart: $it" + (st.socPct?.let { b -> "  $b%" } ?: "") } ?: "No cart"
            Text(cart, fontSize = 13.sp)
        }
        st.holdText?.let { item { Text("Waiting: $it", fontSize = 13.sp, color = Color(0xFFFFC107), fontWeight = FontWeight.Bold) } }
        st.alert?.let { item { Text(it, fontSize = 12.sp, color = Color(0xFFFF6B6B)) } }
        item { Chip(onClick = { WatchLink.sendCmd(ctx, WatchCmd.NEXT) }, label = { Text("Next hole") }, modifier = Modifier.fillMaxWidth()) }
        if (st.cartMode != null) {
            item { Chip(onClick = { WatchLink.sendCmd(ctx, WatchCmd.FOLLOW) }, label = { Text("Cart: follow") }, modifier = Modifier.fillMaxWidth()) }
            item { Chip(onClick = { WatchLink.sendCmd(ctx, WatchCmd.PARK) }, label = { Text("Cart: park") }, modifier = Modifier.fillMaxWidth()) }
            if (st.drive) item { Chip(onClick = { WatchLink.sendCmd(ctx, WatchCmd.MANUAL); driving = true }, label = { Text("Cart: drive") }, modifier = Modifier.fillMaxWidth()) }
            item { Button(onClick = { WatchLink.sendCmd(ctx, WatchCmd.STOP) }) { Text("STOP") } }
        }
        item {
            Text(if (st.posFromWatch) (if (gps) "Sending my GPS" else "GPS needed - tap below") else "Phone has my GPS", fontSize = 11.sp)
        }
        if (st.posFromWatch && !gps) item { Chip(onClick = { if (haveLocation) startGps(ctx) else perms.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.POST_NOTIFICATIONS)) }, label = { Text("Start GPS") }, modifier = Modifier.fillMaxWidth()) }
    }
}

private fun Modifier.padding8() = this.then(Modifier.padding(horizontal = 12.dp, vertical = 8.dp))


/**
 * Hold-to-drive. Three buttons: forward-left, forward, forward-right (the cart only drives forward). While a button is held the
 * watch sends its code about 7 times a second; the phone treats each code as a 0.35 s pulse, so letting go (or the link dropping)
 * stops the cart within a moment. STOP parks it at once. "Done" leaves manual mode.
 */
@Composable
private fun DriveScreen(ctx: Context, onDone: () -> Unit) {
    DisposableEffect(Unit) { onDispose { WatchLink.sendDrive(ctx, "0") } }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Hold to drive", fontSize = 12.sp)
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HoldButton(ctx, "l", "↰", Modifier.weight(1f))
            HoldButton(ctx, "f", "↑", Modifier.weight(1.2f))
            HoldButton(ctx, "r", "↱", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { WatchLink.sendDrive(ctx, "0"); WatchLink.sendCmd(ctx, WatchCmd.STOP) }, modifier = Modifier.weight(1f)) { Text("STOP") }
            Button(onClick = { WatchLink.sendDrive(ctx, "0"); WatchLink.sendCmd(ctx, WatchCmd.PARK); onDone() }, modifier = Modifier.weight(1f)) { Text("Done") }
        }
    }
}

@Composable
private fun HoldButton(ctx: Context, code: String, label: String, modifier: Modifier) {
    val scope = rememberCoroutineScope()
    var down by remember { mutableStateOf(false) }
    Box(
        modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(if (down) Color(0xFF03EEEF) else Color(0xFF1C3D5A))
            .pointerInput(code) {
                awaitEachGesture {
                    awaitFirstDown()
                    down = true
                    val job = scope.launch { while (true) { WatchLink.sendDrive(ctx, code); delay(140) } }
                    waitForUpOrCancellation()
                    job.cancel(); down = false
                    WatchLink.sendDrive(ctx, "0")
                }
            },
        contentAlignment = Alignment.Center,
    ) { Text(label, fontSize = 28.sp, color = if (down) Color.Black else Color.White) }
}
