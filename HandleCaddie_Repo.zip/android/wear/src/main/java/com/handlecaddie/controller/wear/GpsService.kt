package com.handlecaddie.controller.wear

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

/** While running, sends the watch's GPS position to the phone once a second. Start it from the watch app (Android only lets a visible app start it). */
class GpsService : Service() {
    private val fused by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private val callback = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) {
            val l = r.lastLocation ?: return
            WatchLink.sendGps(applicationContext, l.latitude, l.longitude, l.accuracy)
        }
    }
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (!running) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Position for Handle Caddie", NotificationManager.IMPORTANCE_LOW))
            val n = Notification.Builder(this, CHANNEL).setContentTitle("Handle Caddie").setContentText("Sending your position to the phone").setSmallIcon(android.R.drawable.ic_menu_mylocation).setOngoing(true).build()
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            try {
                fused.requestLocationUpdates(LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1_000L).setMinUpdateIntervalMillis(500L).build(), callback, mainLooper)
                running = true; WatchModel.gpsRunning.value = true
            } catch (e: SecurityException) { stopSelf() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        runCatching { fused.removeLocationUpdates(callback) }
        running = false; WatchModel.gpsRunning.value = false
        super.onDestroy()
    }

    companion object { const val CHANNEL = "hc_gps"; const val ACTION_STOP = "hc.stop" }
}
