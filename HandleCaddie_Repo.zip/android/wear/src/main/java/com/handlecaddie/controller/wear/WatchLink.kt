package com.handlecaddie.controller.wear

import android.content.Context
import com.google.android.gms.wearable.Wearable
import com.handlecaddie.controller.core.WatchCmd
import com.handlecaddie.controller.core.WatchProtocol
import com.handlecaddie.controller.core.WatchState
import kotlinx.coroutines.flow.MutableStateFlow

/** What the watch screen shows. Written by [PhoneListenerService], read by the screen. */
object WatchModel {
    val state = MutableStateFlow(WatchState())
    val lastStateMs = MutableStateFlow(0L)
    val gpsRunning = MutableStateFlow(false)
}

object WatchLink {
    private fun sendToPhone(ctx: Context, path: String, text: String) {
        val msgs = Wearable.getMessageClient(ctx)
        Wearable.getNodeClient(ctx).connectedNodes.addOnSuccessListener { nodes ->
            for (n in nodes) msgs.sendMessage(n.id, path, text.toByteArray(Charsets.UTF_8))
        }
    }

    fun sendCmd(ctx: Context, cmd: WatchCmd) = sendToPhone(ctx, WatchProtocol.PATH_CMD, cmd.wire)
    fun sendDrive(ctx: Context, code: String) = sendToPhone(ctx, WatchProtocol.PATH_DRIVE, code)
    fun sendGps(ctx: Context, lat: Double, lon: Double, accuracyM: Float) = sendToPhone(ctx, WatchProtocol.PATH_GPS, WatchProtocol.encodeGps(lat, lon, accuracyM))
}
