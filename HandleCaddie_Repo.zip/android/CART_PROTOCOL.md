# Handle Caddie cart link (phone <-> cart ESP32)

Transport: BLE Nordic UART service (same UUIDs as the display: service 6E400001-..., app->cart RX 6E400002-..., cart->app TX 6E400003-... notify).
**Advertise the name `HandleCaddie_Cart`** (the display advertises `HandleCaddie_BLE`; the phone tells them apart by name).
Messages are flat JSON, one per line, terminated by `\n`, at most ~240 bytes. Request MTU 247 like the display firmware does.

## Phone -> cart
| message | meaning |
|---|---|
| `{"k":"hello"}` | link just came up: reply with a `cfg` and a `tel` right away |
| `{"k":"mode","m":"park"\|"follow"\|"manual"}` | requested mode |
| `{"k":"joy","x":-1..1,"y":0..1}` | joystick, 10 per second while the finger is down. x = steer (+ right), y = forward speed fraction. No reverse |
| `{"k":"set","fd":2.5}` | follow distance, metres, 1.5 - 6.0 |
| `{"k":"set","vm":1.6}` | follow top speed, m/s, 0.5 - 1.6 |
| `{"k":"set","dc":1.2}` | downhill speed limit, m/s, 0.6 - 1.6 |
| `{"k":"set","hh":1}` | hold brake when parked on a slope (1/0) |
| `{"k":"hold","on":1}` | green guard: stop and wait (1) / release (0). Resent every 2 s while holding |
| `{"k":"cmd","c":"stop"}` | go to PARK now |
| `{"k":"cmd","c":"clear"}` | clear TIP / IMU faults - only if level (not tipped) and IMU ok |
| `{"k":"cmd","c":"level"}` | take the current pitch/roll as zero (only while parked) |
| `{"k":"cmd","c":"trip0"}` | reset the trip odometer |

`set` messages carry one key each, but accept several in one message. Clamp every value to the ranges above and **reply with a `cfg`** so the phone sees what was really applied.

## Cart -> phone
Telemetry about 5 times a second (`tel`), and `cfg` on `hello` and after every change:

    {"k":"tel","m":"follow","v":20.4,"soc":78,"pit":-3.2,"rol":1.1,"spd":1.2,"rng":2.7,"brg":-8,
     "ml":35,"mr":38,"bk":0,"obs":-1,"trip":1234.5,"tot":98000,"ft":0,"fg":8}
    {"k":"cfg","fd":2.5,"vm":1.6,"dc":1.2,"hh":1,"fw":"0.1"}

| key | unit |
|---|---|
| m | the mode the cart is REALLY in: park / follow / manual |
| v, soc | pack volts, percent |
| pit, rol | degrees. pitch + = nose up, roll + = left side up |
| spd | m/s |
| rng | metres to the fob, -1 = no reading |
| brg | degrees, + = fob on the left; omit or null = unknown |
| ml, mr, bk | left motor, right motor, brake: 0..100 |
| obs | nearest ultrasonic echo, metres, -1 = clear |
| trip, tot | metres |
| ft | fault bits: 1 tip, 2 imu, 4 low battery, 8 e-stop (same as `cart::Fault`) |
| fg | status bits: 1 fob lost, 2 obstacle, 4 too far, 8 descent, 16 slope hold, 32 slowed, 64 auto-hold (green guard), 128 paused (cart switch), 256 override (switch pressed while auto-held) (same as `cart::Flag`) |

## Who may drive the cart (pairing and PIN)
The cart ignores every command, and sends no telemetry, until the phone has proved it holds the cart's key.

**Every connection:** the cart sends `{"k":"chal","n":"<16 hex>","paired":0|1,"pairing":0|1}` (a fresh random nonce; `paired` = it has a key; `pairing` = the pairing window is open). A paired phone answers `{"k":"auth","h":"<32 hex>"}` where `h` = the first 16 bytes of HMAC-SHA256(key, nonce text as ASCII), lowercase hex. A nonce is good for one answer.
Replies: `{"k":"auth","ok":1}` (accepted; the cart now starts in PARK and sends `cfg` and `tel`), `{"k":"auth","ok":0,"left":N}` (wrong, N tries left), `{"k":"auth","ok":0,"wait":S}` (5 failures: locked for S seconds), `{"k":"auth","ok":0,"np":1}` (the cart has no key). A refusal comes with a fresh challenge; the phone does not answer it automatically.
`{"k":"hello"}` before authentication makes the cart resend the unused challenge.

**Pairing:** the window opens by itself at first boot with no key (5 min), by six pause-switch flips within 5 s while parked, or by the serial command `pair` (`unpair` forgets the key). It lasts 2 min, shows a random 6-digit PIN on the cart's screen, and allows 5 tries. The phone sends `{"k":"pair","pin":"123456"}`; the cart replies `{"k":"paired","ok":1,"key":"<32 hex>"}` (the phone stores the key) or `{"k":"paired","ok":0,"left":N}` / `{"k":"paired","ok":0,"closed":1}`. Pairing again replaces the key.

**Encrypted link (Bluetooth LE Secure Connections):** the cart requires an encrypted, bonded link before it reads or sends anything. The Bluetooth passkey is the same 6-digit PIN as above while the pairing window is open (outside the window it is a random number nobody knows, so an unpaired phone cannot pair at all). The first connection makes Android show its own pairing dialog: type the PIN. Bluetooth then encrypts the link with keys no listener can derive (ECDH P-256 plus the passkey, which also guards against a man in the middle), and remembers the pairing (bond) for later connections. The cart sends its `chal` only once the link is encrypted, with two extra fields: `"sec":1` (link is encrypted) and `"fresh":1` (this very connection was just paired with the PIN as passkey). When both are 1 and the window is open, the phone finishes pairing with `{"k":"pair"}` (no PIN: Bluetooth already proved it) and the key arrives inside the encrypted link. Five wrong passkeys close the window. The cart keeps one bond at a time (pairing a new phone removes the others). The application-level key and challenge stay as a second layer. `#define CART_BLE_ENCRYPT 0` in `Cart.ino` turns the Bluetooth layer off (older behaviour: PIN typed in the app, link unencrypted).

## Safety rules the cart MUST implement (the app cannot enforce them)
1. **Boot and every new BLE connection start in PARK.** Never resume the last mode.
2. **`joy` is only obeyed in MANUAL.** If no `joy` frame has arrived for **500 ms**, speed command = 0 (finger lifted, app crashed, phone out of range).
3. **Losing the BLE link drops MANUAL to PARK.** FOLLOW does not need the phone (it runs on the fob), so it may continue.
4. Manual speed = `y * 1.2 m/s` at most. Steering uses the same forward-only wheel mix as FOLLOW.
5. Faults (tip, IMU, e-stop, low battery) override every request. `mode` / `joy` / `clear` must not defeat a latched fault.
6. Descent control and slope hold stay active in MANUAL.
7. Clamp every `set` value; ignore unknown keys; never crash on a malformed line.
8. The physical e-stop is in series with the motor supply and does not go through software.

The reference firmware (`HandleCaddieCart/Cart/Cart.ino`) implements all of the above, including MANUAL.


## Green guard and the latching switch
- The cart has no GPS. The phone estimates where the cart is (about the follow distance back along your walked path) and sends `hold` when it is too near a green.
- Switch = your own pause (flag 128). Any switch change while auto-held means "I override": report flag 256 and drop the auto-hold until the phone sends `hold:1` again or `hold:0`.
- An auto-hold persists if BLE drops, until `hold:0`, an override, or reconnect (which starts in PARK). Suggested LED: blinking amber = auto-hold, steady = paused.
- The switch's LED is rated 12-24 V, so drive it from the battery rail through a transistor/MOSFET, not an ESP32 pin.

## Driving a route round a hazard (phase 2, experimental)

The phone plans, the cart follows by dead reckoning (wheel speed + gyro). The cart needs the wheel speed sensor wired (`HAS_HALL 1`) and a settled gyro (about 20 s stationary after power-up). `cfg` carries `"nav":1` when the firmware supports it; telemetry carries `"nr":1` when the cart is ready right now.

Route frame: origin = where the cart stands when the route starts, +X = the way it faces, +Y = its left (metres).

Phone -> cart:
- `{"k":"navp","i":N,"x":..,"y":..}` stage point N (0..23). `i` = 0 clears anything staged and any finished route.
- `{"k":"navgo","n":N,"v":1.0}` make the N staged points the route. Reply `{"k":"nav","ok":1}` or `ok:0` (bad geometry: legs outside 0.2..100 m, more than 250 m, first point more than 12 m from the cart). While a route is running a new commit swaps the route and keeps the pose.
- `{"k":"mode","m":"nav"}` start driving. Refused with `{"k":"nav","ok":0}` if there is no committed route, a fault, no wheel sensor or the gyro has not settled.
- `{"k":"navhb"}` heartbeat, at least once every 2.5 s or the cart stops.

Cart -> phone (telemetry, in addition to the usual): `"yw"` gyro heading since power-up (deg, + = left; always sent), `"nr"` ready flag, and while a route exists `"nx","ny"` (pose in the route frame, m), `"nh"` heading (deg), `"ni"` leg, `"ns"` state: 0 idle, 1 ready, 2 driving, 3 arrived, 4 lost phone, 5 too long, 6 off the route, 7 not progressing, 8 gyro and wheels disagree.

The cart stops by itself on: no heartbeat for 2.5 s, 5 m off the route, 25 s without progress, 420 s total, gyro/wheel mismatch, any fault, an obstacle, the pause switch, or any other mode request.

### Driving to a fixed spot (next tee)

No new messages: the phone uses the same `navp` / `navgo` / `mode nav` / `navhb` sequence as above, but the route ends at the next tee instead of at the player, and the phone does not hand back to `follow` at the end. When the cart reports `"ns":3` (arrived) the phone checks the position against the fob or the cart's GPS if either is available (re-planning up to three times if the cart is more than 6 m short), then sends `{"k":"mode","m":"park"}`. The cart's own rules above (heartbeat, off-route, no progress, switch, obstacle) apply unchanged. The cart cannot tell a tee drive from a go-around.

### Watch driving (phone side only, no new cart messages)

The watch sends `f` / `l` / `r` / `0` on the Wear OS path `/hc/drive`. The phone turns each into a 0.35 s pulse of the normal `joy` frames (10 per second), scaled by the speed cap. The cart sees nothing new: it still stops on its own after 500 ms without a `joy` frame, and still only obeys `joy` in MANUAL.
