# Bench test plan (wheels off the ground)

Do these in order. Stop at the first thing that surprises you and send me the **decision log** (Cart tab > Bench test > Copy).

## 0. Safety set-up (every time)
- Lift the cart so **all wheels are clear of the ground** (blocks under the frame, not your hands).
- Keep a way to cut motor power in one move (the pack switch or unplugging the battery) within reach.
- Keep hands, cables and clothing away from the wheels, even though they are off the ground.
- Start with the cart's own E-stop pressed, release it only when a step says so.

## 1. Phone only (no cart, nothing can move)
1. Open the app, pick a course that has greens, water or bunkers, make sure **Hazard guard** is on.
2. Cart tab > turn **Demo** on (a built-in pretend cart), switch it to **Follow**.
3. Bench test > run **Walk at a hazard**, **Walk across to the far side**, **Weak GPS** and **GPS drops out** one after the other (about 75 s, 125 s, 45 s and 40 s).
4. Expected: every run ends with **ALL CHECKS PASSED**; the demo cart's status shows "Waiting - green ahead" while held; the display shows a one-line tip when it first holds.
5. Turn the guard **off**: the test buttons grey out with a note. Turn it back on.

## 2. Cart link (wheels off, motors idle)
0. **First time only, pairing:** a cart with no key opens pairing by itself for 5 minutes after power-up and shows a 6-digit PIN on its screen (and the serial monitor). Connect from the Cart tab. Android shows its own **pairing dialog**: type the PIN from the cart's screen there (nothing to type in the app itself). The link is then encrypted and the Link card says "Paired and encrypted". If anything goes wrong the card tells you what to do; if the phone can't connect after the cart was reset, press Forget or remove "HandleCaddie_Cart" in Android's Bluetooth settings and pair again. Later: flip the pause switch 6 times quickly while parked (or type `pair` on the serial console) to open pairing again; `unpair` on serial forgets the key. Check: a second phone, or this phone after "Forget", must NOT be able to drive the cart; the controls stay greyed until paired.
1. Power the cart, connect from the Cart tab. Expect: Park mode, battery voltage and tilt numbers that look sane, no faults.
2. Tilt the cart a little by hand: pitch and roll change. Tip it past the limit: a tip fault appears and the cart refuses Follow/Manual until cleared.
3. Press the E-stop: fault shows in the app. Release and clear.

## 3. Capture the UWB serial output (the one thing I can't do for you)
The cart's UWB reading code is a guess until I see real lines from the BU03 kits.
1. Power one BU03 anchor kit from USB and open its serial port at the baud rate in the AT manual (115200 unless it says otherwise).
2. Run the tag nearby. Copy 30 lines of what the anchor prints (a screenshot is fine) and send them to me.
3. Do not wire anything to the cart until I've checked the format.

## 4. Follow, wheels up
1. With UWB wired and the fob powered, switch the cart to **Follow** with the fob 2 to 3 m away.
2. Expect the wheels to spin up gently (the app shows left and right motor %), the faster the farther you stand, up to the speed limit.
3. Move the fob left and right: the left and right motor numbers should differ in the direction that would turn the cart toward you. If they steer **away** from you, tell me before going further.
4. Carry the fob out of range (or switch it off): the cart must stop and the app shows "Fob signal lost".

## 5. Hazard guard with the real cart
1. Cart in **Follow**, fob within 3 m so it is actively driving the wheels.
2. Run **Walk at a hazard**.
3. Expected, as the simulated walk reaches the hazard:
   - the wheels stop, the cart's screen shows "GREEN AHEAD", the app shows "Waiting - green ahead";
   - the decision log shows `HOLD`, then `-> cart: hold ON`;
   - the display shows "Cart holding ... ahead";
   - on the walk back the log shows `RELEASE`, `-> cart: hold OFF`, and the wheels spin again.
4. Result lines must all be ticks, including **The cart agreed with the phone**.
5. **Switch override:** start the test again; while the cart is held, flip the pause switch on the cart. Expect: the hold drops, the log shows `OVERRIDDEN`, the wheels run. This is the "I know better" button.
6. Run **Walk across to the far side**. Expect the cart to stop as before, then **stay stopped** while the simulated you is out the far side (the screen says the cart's straight path to you would cross the hazard, and the display shows "Cart waiting: path blocked."). It only goes again once you are back on its side. The cart must never drive toward the hazard in this test.
7. Run **GPS drops out**. Expect the cart to stop about 5 to 6 seconds after the simulated GPS stops, and run again a few seconds after it returns.

## 6. Safe-stop checks (try each, note what happens)
| Do this | Must happen |
|---|---|
| Press E-stop while following | Wheels stop at once, E-stop fault shown |
| Flip the pause switch while following | Cart pauses; flip again, it resumes |
| Lose the fob (switch it off) | Cart stops, "Fob signal lost" |
| Put your hand in front of the cart's ultrasonic sensor | Cart slows, then stops ("Obstacle") |
| Tip the cart past the limit | Motors cut, tip fault; Follow refused until cleared |
| Phone Bluetooth off **while held for a hazard** | Cart stays held (the hold is only dropped by the switch or a new connection) |
| Phone Bluetooth off **while following freely** | Cart keeps following the fob (by design: it runs on the fob alone) |
| Close the app while following | Same as the line above |

The last two rows are the one gap I know of: if the phone link is lost and the cart was **not** held, nothing is watching for hazards. The cart still follows the fob and still obeys the switch, the obstacle sensor and the E-stop. Tell me if you want the cart to stop when the phone link drops near hazards instead; it needs a small firmware change.

## 7. What to send me after a session
- The decision log (Copy button).
- Any step where the result differed from "Expected".
- Photos or a few lines from the serial capture in step 3.

## 8. Going round a hazard (phase 2) - do this ONLY after sections 1-6 pass

Needs: wheel speed sensor wired and wheel diameter set correctly in Cart.ino; the Cart page shows the "Go around hazards" card as Ready.

1. Wheels OFF the ground. Switch "Go around hazards" on. Nothing happens by itself: it only starts when the guard is holding and you are clear of the hazard but the straight way to the cart crosses it.
2. Use the section 5 "cross" bench scenario. The decision log should show `go-around: heading ... route N points`, then the cart's wheels spin and the card says it is driving. With the wheels up the cart cannot actually move, so it will report no progress and stop itself after about 25 s: that stop IS the test (log: "stopped: not making progress").
3. Safe-stop checks (wheels up, each should stop the wheels within a second or two): flip the pause switch; turn Bluetooth off on the phone; switch the phone to airplane mode; tap Park; cover the fob.
4. Only then, on flat open grass with the cart on the ground and a person beside it, try a short real route round a cone (a "green" drawn by hand in a test course is simplest). Walk across the cone area and out the other side. The cart should drive round and hand back to Follow when it is within about 9 m of you.
5. Send me the decision log.

Known limits, so a failure here is not a surprise: heading is estimated from the gyro and your walking path (about 4 to 10 degrees off), the cart has no GPS so a long route can end several yards off, and the fob only reaches about 12 m. If the cart does not come within range it waits where it is.

## 9. Phone on the cart / GPS follow (after section 8)

1. Mount the phone on the cart handle, screen up, clear sky. Wear the watch with its app open (WEAR_SETUP.md). Cart tab > Watch: "Use my watch for my position" ON. Both "Cart GPS (phone) OK" and the watch line "Position from the watch" should show.
2. Walk away with the cart following: the Cart tab hazard guard should show a distance that matches reality (it now uses the phone's GPS as the cart).
3. GPS follow, wheels OFF the ground first: switch "GPS follow" on, move the fob out of range (cover it in foil or switch it off), walk 25+ m away with the watch. After about 6 s the log should show `gps-follow: fob out of reach...` and the wheels spin; with wheels up it stops itself after about 25 s (no progress): that is the pass.
4. Then outdoors on open grass, cart on the ground, someone beside it: the cart should follow you at walking pace, stop about 10 yd short, and hand back to the fob as soon as it is in range. Pause the watch app (or turn off Bluetooth on the watch) while it drives: it must stop within about 8 s.

## 10. Round features (no cart needed; walk it)

1. **Pace.** Start a round, take a club out: the log shows "pace: clock started". On My Game the pace card shows a time. Change the target to 2:00 for a short test: after a few minutes it should say you are behind and the display should show a tip at the next hole change. Pause the clock and check the minutes stop.
2. **Storm.** Tap "Saw lightning or heard thunder?" > "Under 10 s": the red TAKE COVER banner appears on the Play tab, the display shows a tip and the watch shows an alert. "False alarm, clear it" removes it. "30-60 s" gives a yellow watch that fades by itself after 15 minutes.
3. **Misses.** Hit 6 balls with the same club from the same spot at a pin straight ahead. After the sixth, a steady lean right or left of 4+ yards should show on the Play tab (if you hit them straight there should be NO tip).
4. **Recap.** Finish 2 holes and tap Share round recap. Check the text.
5. **Unmapped course.** Pick a course that is not mapped (Logan River). The setup card says "learning this course". Play a hole: the first club of the hole and HOLE OUT should each add to "holes known" only after both tee and pin were seen. Start a New round: that hole should now show a yardage.

## 11. Display pairing (after the display is flashed with DISPLAY_AUTH 1)

1. Power the display with no key stored: it shows a PIN and opens a 5 minute window. In the app open Play tab > Display, type the PIN. The card should turn to "paired". Restart both: it should reconnect by itself without a PIN.
2. With a second phone (or after tapping Forget in the app) the display must show nothing from that phone: no hole, no distances. Touch and hold the top-left corner of the display for 4 s to open a 2 minute window and pair again.
3. An old app version must be unable to drive the display. That is expected.

## 12. Drive to the next tee (after sections 8 and 9 pass; wheels OFF the ground first)

1. Cart tab > "Drive to the next tee" ON. Finish a hole in the app (hole out) so the watch asks "Move on to hole N?". Press Go on the watch. With wheels up the log should show `tee-drive: hole N, X m to the tee...` then the wheels spin and the cart stops itself after ~25 s (no progress): that is the pass. Park from the app must stop it at once.
2. Same with the cart's own switch: flip it mid-route; the wheels must stop and the log should say it was stopped.
3. Turn the switch off, press Go: the cart must just go to Follow as before.
4. Outdoors, cart on the ground, a second person next to it with a hand on the switch, a tee 40-60 m away with open grass between: it should park within a few yards of the tee. Check the log line "tee-drive: parked (N m from the tee ...)" against where it really stopped and send me both numbers. Try the same with the phone on the cart (watch for position) and without; unaided runs over about 60 m are expected to drift.
5. Refusals to check: cart moving, no GPS, tee unknown (an unmapped hole), tee more than 230 m (100 m unaided), already at the tee. Each should log `tee-drive: not attempted - <reason>` and the cart should follow as normal.

## 13. Manual driving: cap, creep, watch (wheels OFF the ground first)

1. Cart in Manual. Slider at the default: push the joystick fully forward; the speed readout should top out near 0.6 m/s (1.3 mph). Raise the slider and check it follows.
2. Tap Creep: wheels turn for about 1.5 s, slowly, and stop by themselves. Creep left / right: the wheel on the outside turns faster.
3. Turn "Drive from the watch" ON. On the watch tap "Cart: drive". Hold the forward button: wheels turn. Let go: they must stop within about half a second. Do it ten times and note the longest stop delay.
4. While holding forward, turn the watch's Bluetooth off (or walk the phone out of range): the wheels must stop within about a second. Do this with the wheels up before ever trying it on the ground.
5. Hold forward on the watch and touch the phone's joystick: the finger takes over. Press STOP on the watch: the cart must go to Park at once.
6. Switch "Drive from the watch" off: the watch's "Cart: drive" chip disappears and any held button does nothing.
Send me the longest stop delay from step 3 and 4; if it is over a second I will shorten the pulse.
