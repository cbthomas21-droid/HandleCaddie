plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.handlecaddie.controller"
    compileSdk = 34                      // must be 33 or higher (BleLink uses the API 33 GATT callbacks)
    defaultConfig {
        applicationId = "com.handlecaddie.controller"      // the watch app MUST use exactly the same id
        minSdk = 26; targetSdk = 34
        versionCode = 1; versionName = "1.0"
    }
    // One fixed debug key (committed on purpose, it protects nothing): every build is signed the same, so a new build installs over the old
    // one, and the phone and watch apps share a signature (the watch link needs that).
    signingConfigs { getByName("debug") { storeFile = file("../ci/debug.keystore"); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android" } }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("com.google.android.gms:play-services-wearable:18.2.0")
}
