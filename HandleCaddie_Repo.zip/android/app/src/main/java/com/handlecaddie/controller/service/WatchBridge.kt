package com.handlecaddie.controller.service

import android.content.Context
import com.google.android.gms.wearable.MessageClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Node
import com.google.android.gms.wearable.Wearable
import com.handlecaddie.controller.core.WatchCmd
import com.handlecaddie.controller.core.WatchProtocol

/**
 * The phone's end of the Wear OS link. Needs the watch app installed (same application id, same signing key) and
 * `implementation("com.google.android.gms:play-services-wearable:18.2.0")`. Everything here is best effort: with no watch it does nothing.
 */
class WatchBridge(
    ctx: Context,
    private val onGps: (lat: Double, lon: Double, accuracyM: Float) -> Unit,
    private val onCmd: (WatchCmd) -> Unit,
    private val onDrive: (String) -> Unit,
    private val onConnected: (Boolean) -> Unit,
) : MessageClient.OnMessageReceivedListener {
    private val messages = Wearable.getMessageClient(ctx)
    private val nodeClient = Wearable.getNodeClient(ctx)
    @Volatile private var nodes: List<Node> = emptyList()
    @Volatile private var lastNodeCheck = 0L

    fun start() { messages.addListener(this); refreshNodes() }
    fun stop() { runCatching { messages.removeListener(this) } }

    /** Ask who is connected (cheap; call about every 10 s). */
    fun refreshNodes() {
        nodeClient.connectedNodes
            .addOnSuccessListener { list -> nodes = list.filter { it.isNearby }; onConnected(nodes.isNotEmpty()) }
            .addOnFailureListener { nodes = emptyList(); onConnected(false) }
    }

    fun send(stateJson: String) {
        val bytes = stateJson.toByteArray(Charsets.UTF_8)
        for (n in nodes) messages.sendMessage(n.id, WatchProtocol.PATH_STATE, bytes)
    }

    override fun onMessageReceived(e: MessageEvent) {
        val text = String(e.data, Charsets.UTF_8)
        when (e.path) {
            WatchProtocol.PATH_GPS -> WatchProtocol.decodeGps(text)?.let { onGps(it.first, it.second, it.third) }
            WatchProtocol.PATH_CMD -> WatchCmd.fromWire(text.trim())?.let(onCmd)
            WatchProtocol.PATH_DRIVE -> onDrive(text)
        }
    }
}
