package com.handlecaddie.controller.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.handlecaddie.controller.core.CaddieReport
import com.handlecaddie.controller.core.ClubInsights
import com.handlecaddie.controller.core.Dispersion
import com.handlecaddie.controller.core.PaceLevel
import com.handlecaddie.controller.core.RoundStats
import com.handlecaddie.controller.core.RoundSummary
import com.handlecaddie.controller.service.CaddieHub
import com.handlecaddie.controller.service.Command
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * "My Game": the Caddie Report for today's round (live, hole by hole) and the history of saved rounds.
 * All numbers come from the unit's club pulls, the phone's GPS and the putts entered on the unit - nothing to type in.
 */
@Composable
internal fun MyGameTab(send: (Command) -> Unit) {
    val ctx = LocalContext.current
    val recap by CaddieHub.recap.collectAsStateWithLifecycle()
    LaunchedEffect(recap) {
        recap?.let { text ->
            val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, text); putExtra(android.content.Intent.EXTRA_SUBJECT, "My round") }
            runCatching { ctx.startActivity(android.content.Intent.createChooser(i, "Share round recap").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
            send(Command.RecapShown)
        }
    }
    val pace by CaddieHub.pace.collectAsStateWithLifecycle()
    val holes by CaddieHub.holeStats.collectAsStateWithLifecycle()
    val game by CaddieHub.game.collectAsStateWithLifecycle()
    val setup by CaddieHub.setup.collectAsStateWithLifecycle()
    val history by CaddieHub.history.collectAsStateWithLifecycle()
    val saved by CaddieHub.roundSaved.collectAsStateWithLifecycle()
    val bag by CaddieHub.bag.collectAsStateWithLifecycle()
    val shots by CaddieHub.shots.collectAsStateWithLifecycle()
    val clubs = remember(bag, shots) { ClubInsights.build(bag, shots) }
    val misses = remember(bag, shots) { Dispersion.lines(bag, shots) }

    val stats = remember(holes) { RoundStats(holes) }
    val report = remember(holes, history, game.roundComplete, setup.course) {
        CaddieReport.build(stats, setup.course?.name, history, game.roundComplete)
    }

    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // ---- the report
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("CADDIE REPORT", color = Cyan, fontWeight = FontWeight.Bold)
                Text(report.headline, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                report.lines.forEach { Text("•  $it", color = Color.White, fontSize = 14.sp) }
                report.focus?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                }
                if (stats.played > 0) {
                    Spacer(Modifier.height(4.dp))
                    if (saved) Text("Saved to your rounds below.", color = Dim, fontSize = 12.sp)
                    else {
                        Button(
                            onClick = { send(Command.SaveRound) }, Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                        ) { Text(if (game.roundComplete) "Save this round" else "Save the round so far", color = Navy, fontWeight = FontWeight.Bold) }
                        if (!game.roundComplete) Text("A finished round is saved automatically.", color = Dim, fontSize = 12.sp)
                    }
                }
            }
        }

        // ---- the numbers
        if (stats.played > 0) {
            Button(onClick = { send(Command.MakeRecap) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                Text("Share round recap", color = Navy, fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("SCORE", "${stats.score}", "${CaddieReport.signed(stats.toPar)} through ${stats.played}")
                StatTile("FAIRWAYS", if (stats.fairwayChances > 0) "${stats.fairwaysHit}/${stats.fairwayChances}" else "-", pct(stats.fairwaysHit, stats.fairwayChances))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("GREENS IN REG", if (stats.girHoles > 0) "${stats.girs}/${stats.girHoles}" else "-", pct(stats.girs, stats.girHoles))
                StatTile("PUTTS", if (stats.puttHoles > 0) "${stats.putts}" else "-", if (stats.puttHoles > 0) String.format(Locale.US, "%.1f a hole", stats.puttsPerHole) else "enter putts on the unit")
            }
        }

        // ---- pace of play
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("PACE OF PLAY", color = Cyan, fontWeight = FontWeight.Bold)
                if (pace.level == PaceLevel.NOT_STARTED) {
                    Text("The clock starts when you take your first club out. I'll tell you when you slip behind your target.", color = Dim, fontSize = 13.sp)
                } else {
                    Text(if (pace.paused) "Clock paused" else pace.text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    pace.finishMs?.let { f -> if (!pace.paused) Text("At this pace you finish about ${SimpleDateFormat("h:mm a", Locale.US).format(Date(f))}.", color = Dim, fontSize = 13.sp) }
                    if (pace.holeAllowedMin > 0) Text("This hole: ${pace.holeElapsedMin} min so far, about ${pace.holeAllowedMin} min is the pace.", color = Dim, fontSize = 12.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.OutlinedButton(onClick = { send(Command.SetPaceTarget(pace.targetMin - 15)) }) { Text("-15") }
                    Text("Target for 18: ${pace.targetMin / 60}h ${"%02d".format(pace.targetMin % 60)}m", color = Color.White, fontSize = 14.sp)
                    androidx.compose.material3.OutlinedButton(onClick = { send(Command.SetPaceTarget(pace.targetMin + 15)) }) { Text("+15") }
                }
                if (pace.level != PaceLevel.NOT_STARTED) {
                    androidx.compose.material3.OutlinedButton(onClick = { send(Command.PauseRound(!pace.paused)) }, Modifier.fillMaxWidth()) {
                        Text(if (pace.paused) "Resume the clock" else "Pause the clock (lunch, a long wait)")
                    }
                }
            }
        }

        // ---- the clubs: what the shot log says about each one
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("YOUR CLUBS", color = Cyan, fontWeight = FontWeight.Bold)
                if (clubs.stats.isEmpty()) {
                    Text("Hit each club a few times with the unit and I'll learn how far you really hit it, and how steady it is.", color = Dim, fontSize = 13.sp)
                } else {
                    clubs.lines.forEach { Text(it, color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Medium) }
                    Spacer(Modifier.height(2.dp))
                    clubs.stats.forEach { s ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text(s.name, color = Color.White, fontSize = 14.sp)
                                Text("${s.n} shots" + (if (abs(s.avgYd - s.bagYd) >= 5) "  ·  bag says ${s.bagYd}" else ""), color = Dim, fontSize = 11.sp)
                            }
                            Text("${s.avgYd} yd" + (s.spreadYd?.let { "  \u00B1$it" } ?: ""), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("Distances are ball to ball, so they include roll. Only your most recent shots count.", color = Dim, fontSize = 11.sp)
                    if (misses.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("WHERE YOU MISS", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        misses.forEach { Text(it, color = Color.White, fontSize = 13.sp) }
                        Text("Sideways miss against the line from the ball to the pin, by phone GPS. A pattern is only shown when it is clearly bigger than GPS noise (5 or more shots).", color = Dim, fontSize = 11.sp)
                    }
                }
            }
        }

        // ---- the history
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MY ROUNDS", color = Cyan, fontWeight = FontWeight.Bold)
                if (history.isEmpty()) {
                    Text("Your finished rounds will build up here, so you can see how your game is moving.", color = Dim, fontSize = 13.sp)
                } else {
                    averages(history)?.let { Text(it, color = Gold, fontSize = 13.sp) }
                    val fmt = remember { SimpleDateFormat("MMM d", Locale.US) }
                    history.asReversed().take(30).forEach { r ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text("${fmt.format(Date(r.dateMs))}  ·  ${r.course}", color = Color.White, fontSize = 14.sp)
                                Text(detail(r), color = Dim, fontSize = 12.sp)
                            }
                            Text("${r.score} (${CaddieReport.signed(r.toPar)})", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.StatTile(label: String, value: String, sub: String) {
    Card(Modifier.weight(1f), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, color = Dim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = Dim, fontSize = 12.sp)
        }
    }
}

private fun pct(n: Int, of: Int) = if (of == 0) "no data yet" else "${(100.0 * n / of).roundToInt()}%"

private fun detail(r: RoundSummary): String {
    val parts = ArrayList<String>()
    parts += "${r.holes} holes"
    r.fairwayPct?.let { parts += "FW ${it.roundToInt()}%" }
    r.girPct?.let { parts += "GIR ${it.roundToInt()}%" }
    r.puttsPerHole?.let { parts += String.format(Locale.US, "%.1f putts/hole", it) }
    return parts.joinToString("  ·  ")
}

/** One line over all saved 18-hole-equivalent rounds, once there are at least two to average. */
private fun averages(h: List<RoundSummary>): String? {
    if (h.size < 2) return null
    val parts = ArrayList<String>()
    val full = h.filter { it.holes >= 18 }
    if (full.size >= 2) parts += "Average score ${full.map { it.score }.average().roundToInt()}"
    h.mapNotNull { it.fairwayPct }.takeIf { it.size >= 2 }?.let { parts += "fairways ${it.average().roundToInt()}%" }
    h.mapNotNull { it.girPct }.takeIf { it.size >= 2 }?.let { parts += "greens ${it.average().roundToInt()}%" }
    h.mapNotNull { it.puttsPerHole }.takeIf { it.size >= 2 }?.let { parts += String.format(Locale.US, "%.1f putts/hole", it.average()) }
    return if (parts.isEmpty()) null else "Over ${h.size} rounds: " + parts.joinToString("  ·  ")
}
