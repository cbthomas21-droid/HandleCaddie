package com.handlecaddie.controller.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.ParcelUuid
import com.handlecaddie.controller.core.DeviceEvent
import com.handlecaddie.controller.core.LineBuffer
import com.handlecaddie.controller.core.Protocol
import java.util.UUID
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Link to the ESP32 over the Nordic UART service.
 *
 * What this fixes compared with a bare GATT callback:
 *  - requests a large MTU (the default 20-byte payload cannot carry a hole map) and chunks writes to it
 *  - one GATT operation at a time (Android silently drops overlapping ones)
 *  - all GATT callbacks are funnelled through one channel, so state is only touched from one coroutine
 *  - scans by service UUID (the device name is often missing from scan results)
 *  - reconnects automatically with back-off, straight to the saved address (no re-scan needed)
 *  - closes the GATT object on every disconnect (otherwise Android runs out of GATT clients)
 *  - uses the Android 13+ callbacks/APIs where they exist
 *  - reassembles notifications into whole messages ([LineBuffer])
 *
 * Callers must hold the BLUETOOTH_SCAN / BLUETOOTH_CONNECT permissions (API 31+) or location (API 30-).
 */
@SuppressLint("MissingPermission")
class BleLink(
    context: Context,
    private val scope: CoroutineScope,
    /** Only accept a device advertising this name (when the scan result carries a name). */
    private val wantName: String? = null,
    /** Never accept a device advertising this name (so the display link can't grab the cart, and vice versa). */
    private val rejectName: String? = null,
    private val addrKey: String = "addr",
    /** The other link's saved-address key: that device is not ours. */
    private val otherAddrKey: String? = null,
    /** True for the cart: its link is encrypted, so the phone must be bonded (Android shows its own pairing dialog the first time). */
    private val bondRequired: Boolean = false,
) {

    sealed interface LinkState {
        data object Idle : LinkState
        data object Scanning : LinkState
        data object Connecting : LinkState
        /** Android's pairing dialog is up: type the passkey shown on the unit. */
        data object Pairing : LinkState
        data class Connected(val mtu: Int) : LinkState
        data class Reconnecting(val attempt: Int) : LinkState
        data class Failed(val reason: String) : LinkState
    }

    val state = MutableStateFlow<LinkState>(LinkState.Idle)
    /** Whole, parsed messages from the unit. */
    val events = MutableSharedFlow<DeviceEvent>(extraBufferCapacity = 64)
    /** Every whole line received, unparsed - for links that speak a different protocol (the cart). */
    val raw = MutableSharedFlow<String>(extraBufferCapacity = 64)

    // ---- everything below is touched only by the event loop, except the @Volatile fields read by send()
    private val app = context.applicationContext
    private val adapter: BluetoothAdapter? = (app.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private val prefs = app.getSharedPreferences("ble", Context.MODE_PRIVATE)

    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var rx: BluetoothGattCharacteristic? = null
    @Volatile private var mtu = 23
    @Volatile private var pendingWrite: CompletableDeferred<Int>? = null

    private enum class Stage { NONE, CONNECTING, AWAIT_MTU, AWAIT_SERVICES, AWAIT_CCCD, READY, BONDING }
    private var stage = Stage.NONE
    private var wanted = false
    private var attempts = 0
    private var session = 0
    private var scanCb: ScanCallback? = null
    private var reconnectJob: Job? = null
    private val lines = LineBuffer()
    private val writeMutex = Mutex()
    private var myAddr: String? = null

    private sealed interface G {
        data object Start : G
        data object Stop : G
        data object Reconnect : G
        data class ScanHit(val device: BluetoothDevice, val name: String?) : G
        data class ScanEnd(val cb: ScanCallback, val failed: Int) : G
        data class ConnState(val g: BluetoothGatt, val status: Int, val newState: Int) : G
        data class MtuChanged(val g: BluetoothGatt, val mtu: Int, val status: Int) : G
        data class MtuTimeout(val session: Int) : G
        data class ConnectTimeout(val session: Int) : G
        data class Bond(val addr: String, val state: Int, val prev: Int) : G
        data class BondTimeout(val session: Int) : G
        data class Services(val g: BluetoothGatt, val status: Int) : G
        data class DescWrite(val g: BluetoothGatt, val status: Int) : G
        data class CharWrite(val g: BluetoothGatt, val status: Int) : G
        data class Notif(val g: BluetoothGatt, val bytes: ByteArray) : G
    }

    private val inbox = Channel<G>(Channel.UNLIMITED)

    private var securityFailures = 0
    private val bondReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != BluetoothDevice.ACTION_BOND_STATE_CHANGED) return
            @Suppress("DEPRECATION") val d = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
            inbox.trySend(G.Bond(d.address, i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1), i.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE, -1)))
        }
    }

    init {
        if (bondRequired) {
            val f = IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
            if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(bondReceiver, f, Context.RECEIVER_NOT_EXPORTED) else app.registerReceiver(bondReceiver, f)
        }
        scope.launch { for (e in inbox) runCatching { handle(e) }.onFailure { fail("BLE error: ${it.message}") } }
    }

    // ------------------------------------------------------------------ public API
    /** True if this link has connected before (so it can be started quietly without a long scan). */
    fun hasSavedAddress() = prefs.getString(addrKey, null) != null

    /** Stop listening for pairing changes (call when the service ends). */
    fun close() { if (bondRequired) runCatching { app.unregisterReceiver(bondReceiver) } }

    /**
     * Make Android forget the pairing with this unit (the encryption keys), e.g. after the cart was reset. Takes effect for the next
     * connection. Uses the hidden removeBond() through reflection, the usual way; if the phone refuses, the person can do it in
     * Android's Bluetooth settings.
     */
    fun forgetBond(): Boolean {
        val addr = prefs.getString(addrKey, null) ?: return false
        val dev = runCatching { adapter?.getRemoteDevice(addr) }.getOrNull() ?: return false
        return runCatching { BluetoothDevice::class.java.getMethod("removeBond").invoke(dev) as? Boolean }.getOrNull() ?: false
    }

    fun start() { inbox.trySend(G.Start) }
    fun stop() { inbox.trySend(G.Stop) }

    /** Sends one message (already '\n'-terminated), split to the negotiated MTU. False if it did not go out. */
    suspend fun send(line: String): Boolean = writeMutex.withLock {
        val g = gatt; val ch = rx
        if (g == null || ch == null || state.value !is LinkState.Connected) return false
        for (chunk in Protocol.chunk(line, (mtu - 3).coerceAtLeast(20))) {
            val done = CompletableDeferred<Int>()
            pendingWrite = done
            if (!writeChunk(g, ch, chunk)) { pendingWrite = null; return false }
            val status = withTimeoutOrNull(3_000) { done.await() }
            pendingWrite = null
            if (status != BluetoothGatt.GATT_SUCCESS) return false
        }
        true
    }

    // ------------------------------------------------------------------ event loop
    private fun handle(e: G) {
        when (e) {
            G.Start -> { wanted = true; attempts = 0; reconnectJob?.cancel(); connectSavedOrScan() }
            G.Stop -> { wanted = false; reconnectJob?.cancel(); stopScan(); teardown(); state.value = LinkState.Idle }
            G.Reconnect -> if (wanted && gatt == null && stage != Stage.BONDING) connectSavedOrScan()

            is G.ScanHit -> {
                val addr = e.device.address
                val notOurs = (e.name != null && wantName != null && e.name != wantName) ||
                    (e.name != null && rejectName != null && e.name == rejectName) ||
                    (addr in claimed && addr != myAddr) ||
                    (otherAddrKey != null && prefs.getString(otherAddrKey, null) == addr)
                if (!notOurs) {
                    stopScan()
                    prefs.edit().putString(addrKey, addr).apply()
                    openGatt(e.device)
                }
            }
            is G.ScanEnd -> if (scanCb === e.cb) {
                stopScan()
                if (e.failed != 0) fail("Bluetooth scan failed (error ${e.failed})") else scheduleReconnect()
            }

            is G.ConnState -> if (e.g === gatt) {
                if (e.newState == BluetoothProfile.STATE_CONNECTED && e.status == BluetoothGatt.GATT_SUCCESS) {
                    stage = Stage.AWAIT_MTU
                    val s = session
                    if (!e.g.requestMtu(REQUESTED_MTU)) discover(e.g) else scope.launch { delay(3_000); inbox.send(G.MtuTimeout(s)) }
                } else {
                    onLost()
                }
            }
            is G.MtuChanged -> if (e.g === gatt && stage == Stage.AWAIT_MTU) {
                mtu = if (e.status == BluetoothGatt.GATT_SUCCESS) e.mtu else 23
                discover(e.g)
            }
            is G.MtuTimeout -> if (e.session == session && stage == Stage.AWAIT_MTU) gatt?.let { mtu = 23; discover(it) }
            is G.ConnectTimeout -> if (e.session == session && stage != Stage.READY && stage != Stage.NONE && stage != Stage.BONDING) onLost()
            is G.Bond -> if (stage == Stage.BONDING && e.addr == myAddr) {
                if (e.state == BluetoothDevice.BOND_BONDED) {
                    securityFailures = 0
                    val dev = runCatching { adapter?.getRemoteDevice(e.addr) }.getOrNull()
                    if (dev != null) openGatt(dev) else onLost()
                } else if (e.state == BluetoothDevice.BOND_NONE && e.prev == BluetoothDevice.BOND_BONDING) {
                    wanted = false; teardown()
                    fail("Pairing didn't finish. Press Connect and type the PIN shown on the cart's screen.")
                }
            }
            is G.BondTimeout -> if (e.session == session && stage == Stage.BONDING) {
                wanted = false; teardown(); fail("Pairing timed out. Press Connect and type the PIN shown on the cart's screen.")
            }

            is G.Services -> if (e.g === gatt) {
                val svc = e.g.getService(SERVICE_UUID)
                val txc = svc?.getCharacteristic(TX_UUID)
                val rxc = svc?.getCharacteristic(RX_UUID)
                if (e.status != BluetoothGatt.GATT_SUCCESS || txc == null || rxc == null) {
                    if (e.status == BluetoothGatt.GATT_SUCCESS) { wanted = false; teardown(); fail("That device is not a Handle Caddie") } else onLost()
                } else {
                    rx = rxc
                    stage = Stage.AWAIT_CCCD
                    if (!enableNotifications(e.g, txc)) onLost()
                }
            }
            is G.DescWrite -> if (e.g === gatt && stage == Stage.AWAIT_CCCD) {
                if (e.status == BluetoothGatt.GATT_SUCCESS) {
                    stage = Stage.READY; attempts = 0
                    state.value = LinkState.Connected(mtu)
                } else {
                    // 5 / 15 / 137 = the unit wanted an encrypted link and the keys did not match (it was reset, or paired with another phone)
                    if (bondRequired && (e.status == 5 || e.status == 15 || e.status == 137) && ++securityFailures >= 2) {
                        forgetBond(); wanted = false; teardown()
                        fail("The cart doesn't recognise this phone's pairing. Open the cart's pairing (6 quick switch flips), press Connect, and type the PIN.")
                    } else onLost()
                }
            }
            is G.CharWrite -> pendingWrite?.complete(e.status)
            is G.Notif -> if (e.g === gatt) for (l in lines.feed(e.bytes)) { raw.tryEmit(l); Protocol.parse(l)?.let { events.tryEmit(it) } }
        }
    }

    // ------------------------------------------------------------------ connection management
    private fun connectSavedOrScan() {
        val addr = prefs.getString(addrKey, null)?.takeIf { it !in claimed || it == myAddr }
        val dev = if (addr != null && attempts <= MAX_DIRECT_ATTEMPTS) runCatching { adapter?.getRemoteDevice(addr) }.getOrNull() else null
        if (dev != null) openGatt(dev) else startScan()
    }

    private fun startScan() {
        val scanner = adapter?.takeIf { it.isEnabled }?.bluetoothLeScanner
        if (scanner == null) { fail("Turn Bluetooth on"); return }
        stopScan()
        state.value = LinkState.Scanning
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                inbox.trySend(G.ScanHit(result.device, result.scanRecord?.deviceName ?: runCatching { result.device.name }.getOrNull()))
            }
            override fun onScanFailed(errorCode: Int) { inbox.trySend(G.ScanEnd(this, errorCode)) }
        }
        scanCb = cb
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        try { scanner.startScan(listOf(filter), settings, cb) } catch (e: SecurityException) { fail("Bluetooth permission missing"); return }
        scope.launch { delay(SCAN_TIMEOUT_MS); inbox.send(G.ScanEnd(cb, 0)) }
    }

    private fun stopScan() {
        val cb = scanCb ?: return
        scanCb = null
        runCatching { adapter?.bluetoothLeScanner?.stopScan(cb) }
    }

    private fun openGatt(device: BluetoothDevice) {
        if (bondRequired && device.bondState != BluetoothDevice.BOND_BONDED) { startBonding(device); return }
        teardown()
        session++
        myAddr = device.address
        claimed += device.address
        stage = Stage.CONNECTING
        state.value = if (attempts == 0) LinkState.Connecting else LinkState.Reconnecting(attempts)
        mtu = 23
        lines.clear()
        gatt = try { device.connectGatt(app, false, callback, BluetoothDevice.TRANSPORT_LE) }
               catch (e: SecurityException) { fail("Bluetooth permission missing"); null }
        val s = session
        scope.launch { delay(CONNECT_TIMEOUT_MS); inbox.send(G.ConnectTimeout(s)) }
    }

    /** First connection to an encrypted unit: have Android pair with it. Android shows the passkey dialog; the person types the cart's PIN. */
    private fun startBonding(device: BluetoothDevice) {
        teardown()
        session++
        myAddr = device.address
        claimed += device.address
        stage = Stage.BONDING
        state.value = LinkState.Pairing
        lines.clear()
        val ok = if (device.bondState == BluetoothDevice.BOND_BONDING) true else runCatching { device.createBond() }.getOrDefault(false)
        if (!ok) { wanted = false; teardown(); fail("Android would not start pairing. Check that Bluetooth is on."); return }
        val s = session
        scope.launch { delay(BOND_TIMEOUT_MS); inbox.send(G.BondTimeout(s)) }
    }

    private fun discover(g: BluetoothGatt) { stage = Stage.AWAIT_SERVICES; if (!g.discoverServices()) onLost() }

    /** Close the GATT object and forget the characteristics. Always close(): leaking GATT clients ends in status 133. */
    private fun teardown() {
        val g = gatt
        myAddr?.let { claimed -= it }
        myAddr = null
        gatt = null; rx = null; stage = Stage.NONE
        pendingWrite?.complete(-1); pendingWrite = null
        if (g != null) runCatching { g.disconnect() }.also { runCatching { g.close() } }
    }

    private fun onLost() {
        teardown()
        lines.clear()
        if (wanted) scheduleReconnect() else state.value = LinkState.Idle
    }

    private fun scheduleReconnect() {
        if (!wanted) return
        attempts++
        state.value = LinkState.Reconnecting(attempts)
        val wait = minOf(15_000L, 1_000L shl minOf(attempts - 1, 4))
        reconnectJob?.cancel()
        reconnectJob = scope.launch { delay(wait); inbox.send(G.Reconnect) }
    }

    private fun fail(reason: String) { stopScan(); state.value = LinkState.Failed(reason) }

    // ------------------------------------------------------------------ Android-version-specific GATT calls
    @Suppress("DEPRECATION")
    private fun writeChunk(g: BluetoothGatt, ch: BluetoothGattCharacteristic, bytes: ByteArray): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(ch, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == 0   // BluetoothStatusCodes.SUCCESS
        } else {
            ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            ch.value = bytes
            g.writeCharacteristic(ch)
        }
    } catch (e: Exception) { false }

    @Suppress("DEPRECATION")
    private fun enableNotifications(g: BluetoothGatt, tx: BluetoothGattCharacteristic): Boolean = try {
        val cccd = tx.getDescriptor(CCCD_UUID)
        if (cccd == null || !g.setCharacteristicNotification(tx, true)) false
        else if (Build.VERSION.SDK_INT >= 33) {
            g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == 0
        } else {
            cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(cccd)
        }
    } catch (e: Exception) { false }

    // ------------------------------------------------------------------ GATT callback: just forward to the loop
    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) { inbox.trySend(G.ConnState(g, status, newState)) }
        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) { inbox.trySend(G.MtuChanged(g, mtu, status)) }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) { inbox.trySend(G.Services(g, status)) }
        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) { inbox.trySend(G.DescWrite(g, status)) }
        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) { inbox.trySend(G.CharWrite(g, status)) }

        // Android 13+ delivers the value directly; older versions use the deprecated overload below.
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            inbox.trySend(G.Notif(g, value))
        }
        @Deprecated("Used on Android 12 and below")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            @Suppress("DEPRECATION") val v = c.value ?: return
            inbox.trySend(G.Notif(g, v.copyOf()))
        }
    }

    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
        val RX_UUID: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")   // app -> unit
        val TX_UUID: UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")   // unit -> app (notify)
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        /** Addresses currently in use by any BleLink (display or cart), so one device is never opened twice. */
        private val claimed: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()
        private const val REQUESTED_MTU = 247
        private const val SCAN_TIMEOUT_MS = 20_000L
        private const val CONNECT_TIMEOUT_MS = 15_000L
        private const val BOND_TIMEOUT_MS = 90_000L
        private const val MAX_DIRECT_ATTEMPTS = 4
    }
}
