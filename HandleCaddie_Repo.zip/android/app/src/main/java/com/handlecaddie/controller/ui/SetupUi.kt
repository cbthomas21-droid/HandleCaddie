package com.handlecaddie.controller.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.handlecaddie.controller.core.Catalog
import com.handlecaddie.controller.core.CourseChoice
import com.handlecaddie.controller.core.Formats
import com.handlecaddie.controller.core.RoundFormat
import com.handlecaddie.controller.service.CaddieHub
import com.handlecaddie.controller.service.Command
import com.handlecaddie.controller.service.CourseStatus
import com.handlecaddie.controller.service.NearbyStatus

private val Chip = Color(0xFF1C3D5A)

/** A rounded selectable label (used for round format, club types, brands, lofts). */
@Composable
internal fun Pill(text: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) Cyan else Chip)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(text, color = if (selected) Navy else if (enabled) Color.White else Dim, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

/**
 * Round badge for a brand. If the app contains a drawable called `brand_<id>` (e.g. `brand_titleist.png`) that image is
 * shown; otherwise a plain coloured badge with the brand's initials. The app ships no logos.
 */
@Composable
internal fun BrandBadge(brandId: String, size: Dp = 36.dp) {
    val ctx = LocalContext.current
    val brand = Catalog.brand(brandId)
    val res = remember(brandId) { ctx.resources.getIdentifier("brand_$brandId", "drawable", ctx.packageName) }
    if (res != 0) {
        Image(painterResource(res), brand.name, Modifier.size(size), contentScale = ContentScale.Fit)
    } else {
        Box(Modifier.size(size).clip(CircleShape).background(Color(brand.color)), contentAlignment = Alignment.Center) {
            Text(brand.initials, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * (if (brand.initials.length > 2) 0.30f else 0.38f)).sp)
        }
    }
}

internal fun loftText(d: Double) = if (d <= 0.0) "" else if (d % 1.0 == 0.0) d.toInt().toString() else d.toString()

/**
 * Course + round-format card. Open: a list of courses near you and the 18 / front 9 / back 9 choice.
 * After "Start round" it collapses to one summary line with an Edit button.
 */
@Composable
internal fun SetupSection(send: (Command) -> Unit) {
    val setup by CaddieHub.setup.collectAsStateWithLifecycle()
    val nearby by CaddieHub.nearby.collectAsStateWithLifecycle()
    val cachedSet by CaddieHub.cachedCourses.collectAsStateWithLifecycle()
    val course by CaddieHub.course.collectAsStateWithLifecycle()
    val ready = course as? CourseStatus.Ready
    val formats = ready?.formats ?: RoundFormat.entries
    val only9 = formats == listOf(RoundFormat.FRONT_9)
    fun label(f: RoundFormat) = if (f == RoundFormat.FRONT_9 && only9) "9 holes" else Formats.label(f, null)
    val chosen = setup.course

    if (setup.confirmed && chosen != null) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(chosen.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        when (course) {
                            is CourseStatus.Loading -> "${label(setup.format)}  ·  loading course map…"
                            is CourseStatus.Error -> (course as CourseStatus.Error).message
                            else -> label(setup.format) + (if (ready?.learning == true) "  ·  learning this course (${ready.knownHoles} of 18 holes known)" else "")
                        },
                        color = if (course is CourseStatus.Error) Gold else Cyan, fontSize = 14.sp,
                    )
                }
                if (course is CourseStatus.Error) OutlinedButton(onClick = { send(Command.ReloadCourse) }) { Text("Retry") }
                Spacer(Modifier.width(6.dp))
                OutlinedButton(onClick = { send(Command.EditSetup) }) { Text("Edit") }
            }
        }
        return
    }

    var showAll by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("1.  Course", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            val found = (nearby as? NearbyStatus.Ready)?.courses.orEmpty()
            // a course restored from earlier today stays on the list even if the search hasn't returned it
            val list: List<CourseChoice> = (listOfNotNull(chosen) + found).distinctBy { it.key }
            when (val n = nearby) {
                NearbyStatus.None -> if (list.isEmpty()) Text("Waiting for a GPS fix to find courses near you…", color = Dim)
                NearbyStatus.Loading -> Text("Finding courses near you…", color = Dim)
                is NearbyStatus.Error -> {
                    Text(n.message, color = Gold)
                    OutlinedButton(onClick = { send(Command.RefreshNearby) }) { Text("Search again") }
                }
                is NearbyStatus.Ready -> if (list.isEmpty()) {
                    Text("No courses found within 19 miles.", color = Gold)
                    OutlinedButton(onClick = { send(Command.RefreshNearby) }) { Text("Search again") }
                }
            }
            val shown = if (showAll) list else list.take(6)
            shown.forEach { c ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { send(Command.SelectCourse(c)) }.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = c.key == chosen?.key, onClick = { send(Command.SelectCourse(c)) })
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                        val ready = c.key in cachedSet
                        Text((if (c.distanceM > 0) String.format("%.1f mi away", c.miles) else "") + (if (ready) (if (c.distanceM > 0) "  ·  " else "") + "map ready" else ""), color = if (ready) Cyan else Dim, fontSize = 12.sp)
                    }
                }
            }
            if (list.size > 6) {
                OutlinedButton(onClick = { showAll = !showAll }) { Text(if (showAll) "Show fewer" else "Show all ${list.size}") }
            }

            when (course) {
                CourseStatus.Loading -> Text("Loading the hole map… (can take up to a minute the first time)", color = Dim)
                is CourseStatus.Error -> {
                    Text((course as CourseStatus.Error).message, color = Gold)
                    OutlinedButton(onClick = { send(Command.ReloadCourse) }) { Text("Retry") }
                }
                is CourseStatus.Ready -> if ((course as CourseStatus.Ready).learning) {
                    Text(
                        "This course isn't mapped hole by hole yet, so I'll learn it as you play it: ${(course as CourseStatus.Ready).knownHoles} of 18 holes known so far. " +
                            "Scoring, shot distances, pace and storm alerts work now. Yardage to the pin appears on each hole from the next round.",
                        color = Gold, fontSize = 13.sp,
                    )
                }
                else -> {}
            }

            Text("2.  Round", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                formats.forEach { f -> Pill(label(f), selected = setup.format == f, enabled = chosen != null) { send(Command.SetFormat(f)) } }
            }
            Text("Picking a different course starts a new round (scores are cleared).", color = Dim, fontSize = 12.sp)

            Spacer(Modifier.height(2.dp))
            Button(
                onClick = { send(Command.StartRound) }, Modifier.fillMaxWidth(), enabled = ready != null && chosen != null,
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, disabledContainerColor = Chip),
            ) { Text("START ROUND", color = if (ready != null && chosen != null) Navy else Dim, fontWeight = FontWeight.Bold) }
            // required credit for the map data (OpenStreetMap, ODbL licence)
            val uri = androidx.compose.ui.platform.LocalUriHandler.current
            Text(
                "Course data © OpenStreetMap contributors (ODbL)", color = Dim, fontSize = 11.sp,
                textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline,
                modifier = Modifier.clickable { runCatching { uri.openUri("https://www.openstreetmap.org/copyright") } },
            )
            // say why the button is grey instead of leaving the player guessing
            if (ready == null) {
                Text(
                    when {
                        chosen == null -> "Choose a course above first."
                        course is CourseStatus.Loading -> "Waiting for the hole map to download…"
                        course is CourseStatus.Error -> "The hole map hasn't loaded, so there are no yardages to show yet. Tap Retry above, or tap the course again."
                        else -> "Tap the course above to load its hole map."
                    },
                    color = Dim, fontSize = 12.sp,
                )
            }
        }
    }
}
