package com.handlecaddie.controller.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.handlecaddie.controller.core.Catalog
import com.handlecaddie.controller.core.Club
import com.handlecaddie.controller.core.ClubModel
import com.handlecaddie.controller.core.ClubType
import com.handlecaddie.controller.core.Clubs
import com.handlecaddie.controller.core.DistanceModel
import com.handlecaddie.controller.core.Learning
import com.handlecaddie.controller.core.SwingProfile
import com.handlecaddie.controller.service.CaddieHub
import com.handlecaddie.controller.service.Command

/** One editable line of the bag. The text fields are kept as strings until the bag is saved. */
private class BagRow(val club: Club) {
    var carry by mutableStateOf(club.carryYd.toString())
}

private const val MAX_CLUBS = 14      // Rules of Golf limit

@Composable
internal fun BagTab(send: (Command) -> Unit) {
    val saved by CaddieHub.bag.collectAsStateWithLifecycle()
    val swing by CaddieHub.swing.collectAsStateWithLifecycle()
    val useLearning by CaddieHub.useLearning.collectAsStateWithLifecycle()
    val rows = remember(saved) { mutableStateListOf<BagRow>().apply { addAll(saved.map(::BagRow)) } }
    var picking by remember { mutableStateOf(false) }

    /** Turn what is typed into clubs. A typed carry sticks; an untouched estimate follows swing-speed changes. */
    fun current(): List<Club> = rows.map { r ->
        val c = r.club
        val typed = r.carry.toIntOrNull()?.takeIf { it > 0 } ?: c.carryYd
        if (!c.isPutter && typed != c.carryYd) c.copy(carryYd = typed, estimated = false) else c
    }
    fun commit() = send(Command.SetBag(Clubs.sorted(current())))

    if (picking) {
        ClubPicker(
            bag = current(), swing = swing,
            onAdd = { added -> rows.addAll(added.map(::BagRow)); commit() },
            onClose = { picking = false },
        )
        return
    }

    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CartIcon(Modifier.size(34.dp, 28.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("My Golf Bag  ·  ${rows.size} / $MAX_CLUBS clubs", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                }
                if (rows.size > MAX_CLUBS) Text("More than $MAX_CLUBS clubs isn't allowed in a round.", color = Gold, fontSize = 13.sp)
                Text("Swing speed", color = Dim, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SwingProfile.entries.forEach { p -> Pill(p.label, selected = p == swing) { send(Command.SetSwing(p)) } }
                }
                Text(
                    "Makers publish loft, not carry distance, so carries here are estimates from loft at a swing speed of ${swing.detail}. " +
                        "Type your own number in any Carry box and it stays. The caddie recommends the shortest club that reaches the pin.",
                    color = Dim, fontSize = 12.sp,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Learn from my shots", color = Color.White)
                        Text("After 3+ shots with a club, use your own average distance instead of the estimate.", color = Dim, fontSize = 12.sp)
                    }
                    Switch(checked = useLearning, onCheckedChange = { send(Command.SetLearning(it)) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { picking = true }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                        Text("Add clubs", color = Navy, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { commit() }, Modifier.weight(1f)) { Text("Save changes") }
                }
            }
        }
        itemsIndexed(rows) { i, r ->
            val c = r.club
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val b = Catalog.brandByName(c.brand)
                    if (b != null) BrandBadge(b.id, 36.dp) else Spacer(Modifier.size(36.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = Color.White, fontWeight = FontWeight.Bold)
                        val sub = when {
                            c.brand.isEmpty() -> "Custom club"
                            else -> "${c.brand} ${c.model}"
                        }
                        Text(sub, color = Dim, fontSize = 12.sp)
                        if (!c.isPutter && c.loft > 0 && !c.estimated) {
                            Text("Use estimate", color = Cyan, fontSize = 12.sp, modifier = Modifier.clickable {
                                rows[i] = BagRow(c.copy(carryYd = DistanceModel.estimate(c.loft, c.type, swing), estimated = true)); commit()
                            })
                        } else if (c.estimated) Text("estimated carry", color = Dim, fontSize = 11.sp)
                        if (useLearning && !c.isPutter) {
                            if (c.learnedN >= Learning.MIN_SHOTS) Text("Your average: ${c.learnedYd} yd  ·  ${c.learnedN} shots", color = Cyan, fontSize = 12.sp)
                            else if (c.learnedN > 0) Text("${c.learnedN} shot${if (c.learnedN == 1) "" else "s"} recorded (needs ${Learning.MIN_SHOTS})", color = Dim, fontSize = 11.sp)
                        }
                    }
                    if (!c.isPutter) {
                        OutlinedTextField(
                            r.carry, { v -> r.carry = v.filter(Char::isDigit).take(3) }, Modifier.width(84.dp),
                            singleLine = true, label = { Text("Carry") }, textStyle = TextStyle(fontSize = 14.sp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        )
                    }
                    Text("✕", color = Dim, fontSize = 18.sp, modifier = Modifier.clickable { rows.removeAt(i); commit() }.padding(6.dp))
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

/** Pick brand-name clubs from the catalog. Replaces the bag list while open. */
@Composable
private fun ClubPicker(bag: List<Club>, swing: SwingProfile, onAdd: (List<Club>) -> Unit, onClose: () -> Unit) {
    var type by remember { mutableStateOf(ClubType.DRIVER) }
    var brandId by remember { mutableStateOf<String?>(null) }
    var open by remember { mutableStateOf<String?>(null) }
    val types = ClubType.entries.filter { it != ClubType.OTHER }
    val brands = Catalog.brandsFor(type)
    val models = Catalog.models(type, brandId?.takeIf { id -> brands.any { it.id == id } })

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Add clubs  ·  ${bag.size} in bag", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            Button(onClick = onClose, colors = ButtonDefaults.buttonColors(containerColor = Cyan)) { Text("Done", color = Navy, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            types.forEach { t -> Pill(t.label, selected = t == type) { type = t; brandId = null; open = null } }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Pill("All brands", selected = brandId == null) { brandId = null }
            brands.forEach { b ->
                Column(
                    Modifier.clickable { brandId = if (brandId == b.id) null else b.id }.padding(horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    BrandBadge(b.id, if (brandId == b.id) 44.dp else 36.dp)
                    Text(b.name, color = if (brandId == b.id) Cyan else Dim, fontSize = 10.sp)
                }
            }
        }
        Text("Lofts shown are typical for each model. If your club differs, type your own carry in My Golf Bag.", color = Dim, fontSize = 12.sp)

        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(models, key = { "${it.brandId}|${it.model}|${it.type}" }) { m ->
                val id = "${m.brandId}|${m.model}"
                ModelCard(m, bag, swing, expanded = open == id, onToggle = { open = if (open == id) null else id }, onAdd = onAdd)
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun ModelCard(m: ClubModel, bag: List<Club>, swing: SwingProfile, expanded: Boolean, onToggle: () -> Unit, onAdd: (List<Club>) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.clickable(onClick = onToggle).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BrandBadge(m.brandId, 32.dp)
                Column(Modifier.weight(1f)) {
                    Text(m.title, color = Color.White, fontWeight = FontWeight.Bold)
                    val lofts = m.options.map { loftText(it.loft) }
                    Text(
                        when (m.type) {
                            ClubType.DRIVER, ClubType.WEDGE -> lofts.joinToString("  ·  ") { "$it°" }
                            ClubType.PUTTER -> "Putter"
                            else -> "${m.options.first().name} – ${m.options.last().name}"
                        },
                        color = Dim, fontSize = 12.sp,
                    )
                }
                Text(if (expanded) "▲" else "▼", color = Cyan)
            }
            if (expanded) {
                Spacer(Modifier.height(10.dp))
                if (m.type == ClubType.IRON) {
                    val missing = m.options.filter { !Catalog.inBag(bag, m, it) }
                    Button(
                        onClick = { onAdd(missing.map { m.toClub(it, swing) }) }, enabled = missing.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                    ) { Text(if (missing.isEmpty()) "Full set added" else "Add full set (${missing.first().name} – ${missing.last().name})", color = Navy, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(8.dp))
                }
                m.options.chunked(3).forEach { rowOpts ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                        rowOpts.forEach { o ->
                            val have = Catalog.inBag(bag, m, o)
                            val text = when (m.type) {
                                ClubType.DRIVER -> "${loftText(o.loft)}°"
                                ClubType.PUTTER -> "Add putter"
                                else -> "${o.name}  ${loftText(o.loft)}°"
                            }
                            Pill(if (have) "✓ $text" else text, selected = false, enabled = !have) { onAdd(listOf(m.toClub(o, swing))) }
                        }
                    }
                }
            }
        }
    }
}

/**
 * The last few recorded strokes. The caddie records the club it RECOMMENDED; tap a shot to say which club you really hit
 * (or to delete it), so the learned distances are right.
 */
@Composable
internal fun RecentShots(send: (Command) -> Unit) {
    val shots by CaddieHub.shots.collectAsStateWithLifecycle()
    val bag by CaddieHub.bag.collectAsStateWithLifecycle()
    var open by remember { mutableStateOf<Long?>(null) }
    if (shots.isEmpty()) return

    fun label(key: String?): String {
        val c = bag.firstOrNull { Clubs.key(it) == key }
        return c?.name ?: key?.substringBefore('|')?.ifEmpty { null } ?: "Unknown club"
    }

    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("RECENT SHOTS", color = Cyan, fontWeight = FontWeight.Bold)
            shots.takeLast(4).reversed().forEach { s ->
                Column(Modifier.fillMaxWidth().clickable { open = if (open == s.id) null else s.id }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Hole ${s.hole}  ·  ${label(s.club)}", color = Color.White)
                        Text("${s.distanceYd} yd" + (s.offLineYd?.takeIf { kotlin.math.abs(it) >= 3 }?.let { "  ·  ${kotlin.math.abs(it)} ${if (it > 0) "R" else "L"}" } ?: ""), color = Gold, fontWeight = FontWeight.Bold)
                    }
                    if (open == s.id) {
                        Spacer(Modifier.height(6.dp))
                        Text("Which club did you really hit?", color = Dim, fontSize = 12.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            bag.filter { !it.isPutter }.forEach { c -> Pill(c.name, selected = Clubs.key(c) == s.club) { send(Command.SetShotClub(s.id, Clubs.key(c))); open = null } }
                            Pill("Delete shot", selected = false) { send(Command.DeleteShot(s.id)); open = null }
                        }
                    }
                }
            }
            Text("Distance is ball to ball by phone GPS, good to a few yards.", color = Dim, fontSize = 11.sp)
        }
    }
}
