package com.handlecaddie.controller.core

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * The phone's half of the cart's "who may drive me" check (the cart's half is cart_auth.h; the rules are in CART_PROTOCOL.md).
 * The cart sends a fresh challenge on every connection; the phone answers with HMAC-SHA256(key, challenge). The key is made
 * when the phone is paired, by typing the PIN the cart shows on its own screen.
 */
object CartAuth {
    const val KEY_HEX_LEN = 32
    const val TAG_HEX_LEN = 32
    const val PIN_LEN = 6

    fun validKeyHex(s: String?) = s != null && s.length == KEY_HEX_LEN && s.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }
    fun validPin(s: String?) = s != null && s.length == PIN_LEN && s.all { it in '0'..'9' }

    private fun hexToBytes(h: String) = ByteArray(h.length / 2) { i -> h.substring(2 * i, 2 * i + 2).toInt(16).toByte() }

    /** First 16 bytes of HMAC-SHA256(key, nonce text), as 32 lowercase hex characters. Same on the cart. */
    fun tag(keyHex: String, nonce: String): String {
        require(validKeyHex(keyHex)) { "bad key" }
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(hexToBytes(keyHex), "HmacSHA256"))
        val out = mac.doFinal(nonce.toByteArray(Charsets.US_ASCII))
        return out.take(TAG_HEX_LEN / 2).joinToString("") { "%02x".format(it) }
    }
}

/** The words the person sees. The same challenge/answer/pairing flow protects the cart and the display; only the wording and the "how to pair" differ. */
data class AuthWords(val device: String, val howToPair: String) {
    companion object {
        val CART = AuthWords("cart", "On the cart, flip the pause switch 6 times quickly. A PIN appears on its screen.")
        val DISPLAY = AuthWords("display", "On the display, touch and hold the top-left corner for 4 seconds. A PIN appears on its screen.")
    }
}

enum class CartAuthState { UNKNOWN, CHECKING, AUTHED, NEEDS_PAIRING, PAIRING_OPEN, REJECTED, LOCKED }

/** What the Cart page shows about the cart's security. [message] is plain words for the person. */
data class CartAuthStatus(val state: CartAuthState = CartAuthState.UNKNOWN, val message: String = "")

/**
 * The decisions, with no Bluetooth in them so they can be tested: what to do when the cart says something about
 * authentication. [send] = a line to send to the cart; [saveKey] = a new key to store; [current] resets to UNKNOWN on each new connection.
 */
object CartAuthFlow {
    data class Step(val status: CartAuthStatus, val send: String? = null, val saveKey: String? = null)

    fun onMessage(msg: CartMsg, storedKey: String?, current: CartAuthStatus, words: AuthWords = AuthWords.CART): Step {
        val key = storedKey?.takeIf { CartAuth.validKeyHex(it) }
        val dev = words.device
        val HOW_TO_PAIR = words.howToPair
        return when (msg) {
            is CartMsg.Chal -> when {
                // Android just paired with the cart using the cart's PIN as the Bluetooth passkey: that already proved the PIN, so finish
                // pairing without asking for it again. (Only while the cart says its pairing window is open.)
                msg.pairing && msg.secure && msg.fresh && current.state != CartAuthState.CHECKING && current.state != CartAuthState.AUTHED ->
                    Step(CartAuthStatus(CartAuthState.CHECKING, "Finishing pairing with the $dev…"), send = CartProtocol.pair(null))
                // we have a key and the cart has one: prove it. (Not again right after a refusal: the cart sends a new challenge with
                // every refusal, and answering that would only burn the few tries it allows.)
                key != null && msg.paired && current.state != CartAuthState.REJECTED && current.state != CartAuthState.LOCKED &&
                    current.state != CartAuthState.AUTHED ->
                    Step(CartAuthStatus(CartAuthState.CHECKING, "Checking this phone with the $dev…"), send = CartProtocol.auth(key, msg.nonce))
                current.state == CartAuthState.AUTHED -> Step(current)
                current.state == CartAuthState.LOCKED -> Step(current)
                msg.pairing -> Step(CartAuthStatus(CartAuthState.PAIRING_OPEN, "Type the 6-digit PIN shown on the $dev's screen."))
                current.state == CartAuthState.REJECTED -> Step(current)
                else -> Step(CartAuthStatus(CartAuthState.NEEDS_PAIRING,
                    if (key != null && !msg.paired) "This $dev has been reset and doesn't know this phone. $HOW_TO_PAIR" else "This phone isn't paired with the $dev yet. $HOW_TO_PAIR"))
            }
            is CartMsg.AuthAck -> when {
                msg.ok -> Step(CartAuthStatus(CartAuthState.AUTHED, ""))
                msg.waitS != null -> Step(CartAuthStatus(CartAuthState.LOCKED, "Too many wrong tries. The $dev will listen again in ${msg.waitS} s."))
                msg.notPaired -> Step(CartAuthStatus(CartAuthState.NEEDS_PAIRING, "The $dev has no paired phone. $HOW_TO_PAIR"))
                else -> Step(CartAuthStatus(CartAuthState.REJECTED, "The $dev didn't accept this phone, so it may have been paired with another one. $HOW_TO_PAIR"))
            }
            is CartMsg.PairAck -> when {
                msg.ok && CartAuth.validKeyHex(msg.keyHex) -> Step(CartAuthStatus(CartAuthState.AUTHED, ""), saveKey = msg.keyHex!!.lowercase())
                msg.ok -> Step(CartAuthStatus(CartAuthState.REJECTED, "The $dev's reply made no sense. Try pairing again."))
                msg.closed -> Step(CartAuthStatus(CartAuthState.NEEDS_PAIRING, "Pairing closed. $HOW_TO_PAIR"))
                else -> Step(CartAuthStatus(CartAuthState.PAIRING_OPEN, "That PIN is wrong." + (msg.left?.let { " $it ${if (it == 1) "try" else "tries"} left." } ?: "")))
            }
            // an older cart without this check just starts sending data: treat it as open
            is CartMsg.Tel, is CartMsg.Cfg ->
                if (current.state == CartAuthState.UNKNOWN) Step(CartAuthStatus(CartAuthState.AUTHED, "")) else Step(current)
            is CartMsg.NavAck -> Step(current)          // route traffic is the session's business, not authentication's
        }
    }
}
