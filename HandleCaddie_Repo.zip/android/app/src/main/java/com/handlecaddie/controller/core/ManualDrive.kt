package com.handlecaddie.controller.core

/**
 * Manual driving from places other than the on-screen joystick: the watch's hold buttons and the creep buttons.
 *
 * The rule that makes this safe: a drive request is only ever a SHORT pulse. It lapses by itself after [WATCH_PULSE_MS]
 * unless the next frame arrives, and a late burst of queued frames cannot add time up (each frame sets the end of the pulse,
 * it never extends it beyond now + the pulse length). The cart adds its own 500 ms "no joystick frame" stop on top.
 */
object ManualDrive {
    const val WATCH_PULSE_MS = 350L          // each watch frame keeps the cart driving this long; stop pressing and it stops this soon after the last frame lands
    const val CREEP_MS = 1_500L              // one tap of "creep"
    const val CREEP_SPEED_MS = 0.30          // creep speed in m/s, whatever the speed cap says
    const val STEER = 0.7                    // how hard the left / right buttons steer (the cart can only steer while moving forward)
    const val CAP_MIN = 0.2; const val CAP_MAX = 1.0; const val CAP_DEFAULT = 0.5   // fraction of the cart's 1.2 m/s manual top speed

    /** What the speed cap does to a forward request. */
    fun scale(y: Double, cap: Double): Double = y.coerceIn(0.0, 1.0) * cap.coerceIn(CAP_MIN, CAP_MAX)

    /** Joystick fraction that gives about [CREEP_SPEED_MS] after the cap is applied (so creep is slow whatever the cap is). */
    fun creepFraction(cap: Double): Double = (CREEP_SPEED_MS / CartConfig.MANUAL_MAX_MS / cap.coerceIn(CAP_MIN, CAP_MAX)).coerceIn(0.05, 1.0)

    /** Watch button codes on the wire: f = forward, l = forward and left, r = forward and right, 0 = let go. */
    fun decodeWatch(code: String): Pair<Double, Double>? = when (code.trim()) {
        "f" -> 0.0 to 1.0
        "l" -> -STEER to 1.0
        "r" -> STEER to 1.0
        "0" -> 0.0 to 0.0
        else -> null
    }
}

/** One pending timed drive request (from the watch or a creep tap). */
class TimedDrive {
    private var x = 0.0; private var y = 0.0; private var until = 0L

    fun pulse(nowMs: Long, x: Double, y: Double, durationMs: Long) {
        if (y <= 0.0) { clear(); return }
        this.x = x.coerceIn(-1.0, 1.0); this.y = y.coerceIn(0.0, 1.0); this.until = nowMs + durationMs
    }
    fun clear() { x = 0.0; y = 0.0; until = 0L }
    val pending get() = until != 0L

    /** The request if it is still valid at [nowMs], otherwise null (and it forgets it). */
    fun current(nowMs: Long): Pair<Double, Double>? {
        if (until == 0L) return null
        if (nowMs >= until) { clear(); return null }
        return x to y
    }
}
