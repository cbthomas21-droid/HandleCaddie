package com.handlecaddie.controller.core

/**
 * Turns the recorded shots into the player's own club distances.
 *
 * What a "shot" is: the distance between the place one club was pulled from the bag and the place the next one was
 * (both measured by the PHONE's GPS, in your pocket, a few yards from the ball and the same few yards each time, so the
 * offset mostly cancels). It is a ball-to-ball distance, so it includes roll: a driver reads longer than its carry.
 * Each reading is good to a few yards, which is why a club needs [MIN_SHOTS] shots before its average is used, and why
 * the average is blended with the club's estimate until there are plenty.
 */
object Learning {
    const val MIN_SHOTS = 3
    const val MAX_SHOTS = 20            // only the most recent shots count, so the numbers follow your game
    const val MAX_ACCURACY_M = 15f      // shots measured with worse GPS than this are ignored

    /** Drop mis-hits and glitches: keep shots within 30% of the median. */
    fun robust(ds: List<Int>): List<Int> {
        if (ds.size < 3) return ds
        val s = ds.sorted()
        val med = if (s.size % 2 == 1) s[s.size / 2].toDouble() else (s[s.size / 2 - 1] + s[s.size / 2]) / 2.0
        return ds.filter { it >= 0.7 * med && it <= 1.3 * med }
    }

    /** [base] clubs with `learnedYd` / `learnedN` filled in from [shots]. With [use] false they are cleared. */
    fun apply(base: List<Club>, shots: List<ShotRecord>, use: Boolean): List<Club> = base.map { c ->
        if (!use || c.isPutter) return@map c.copy(learnedYd = 0, learnedN = 0)
        val key = Clubs.key(c)
        val kept = robust(shots.filter { it.club == key && it.accuracyM <= MAX_ACCURACY_M }.takeLast(MAX_SHOTS).map { it.distanceYd })
        if (kept.size < MIN_SHOTS) return@map c.copy(learnedYd = 0, learnedN = kept.size)
        val prior = if (c.estimated) 3.0 else 6.0            // a number the player typed is trusted more than a loft estimate
        val blended = (kept.size * kept.average() + prior * c.carryYd) / (kept.size + prior)
        c.copy(learnedYd = Math.round(blended).toInt(), learnedN = kept.size)
    }

    /** Bag as the player saved it: no learned numbers. */
    fun strip(bag: List<Club>) = bag.map { it.copy(learnedYd = 0, learnedN = 0) }

    // ---- stored form of the shot log: one tab-separated line per shot
    fun encode(shots: List<ShotRecord>): String = shots.joinToString("\n") {
        listOf(it.id, it.hole, (it.club ?: "").replace('\t', ' ').replace('\n', ' '), it.distanceYd, it.accuracyM,
            it.fromLat, it.fromLon, it.toLat, it.toLon, it.offLineYd ?: "", it.toPinYd ?: "", it.timeMs).joinToString("\t")
    }

    fun decode(raw: String?): List<ShotRecord> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split("\n").mapNotNull { line ->
            val f = line.split("\t")
            if (f.size < 5) return@mapNotNull null
            ShotRecord(
                hole = f[1].toIntOrNull() ?: return@mapNotNull null, club = f[2].ifEmpty { null },
                distanceYd = f[3].toIntOrNull() ?: return@mapNotNull null,
                id = f[0].toLongOrNull() ?: return@mapNotNull null, accuracyM = f[4].toFloatOrNull() ?: 0f,
                fromLat = f.getOrNull(5)?.toDoubleOrNull() ?: 0.0, fromLon = f.getOrNull(6)?.toDoubleOrNull() ?: 0.0,
                toLat = f.getOrNull(7)?.toDoubleOrNull() ?: 0.0, toLon = f.getOrNull(8)?.toDoubleOrNull() ?: 0.0,
                offLineYd = f.getOrNull(9)?.toIntOrNull(), toPinYd = f.getOrNull(10)?.toIntOrNull(), timeMs = f.getOrNull(11)?.toLongOrNull() ?: 0L,
            )
        }
    }
}
