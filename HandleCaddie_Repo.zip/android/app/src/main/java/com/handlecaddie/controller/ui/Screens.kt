package com.handlecaddie.controller.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.handlecaddie.controller.ble.BleLink.LinkState
import com.handlecaddie.controller.core.Catalog
import com.handlecaddie.controller.core.CartAuthState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType
import com.handlecaddie.controller.core.Clubs
import com.handlecaddie.controller.core.Dispersion
import com.handlecaddie.controller.core.PaceLevel
import com.handlecaddie.controller.core.StormLevel
import com.handlecaddie.controller.core.Learning
import com.handlecaddie.controller.core.ParSource
import com.handlecaddie.controller.core.GameState
import com.handlecaddie.controller.core.Zone
import com.handlecaddie.controller.service.CaddieHub
import com.handlecaddie.controller.service.Command

// Same palette as the display so the two feel like one product.
internal val Navy = Color(0xFF011A2E)
internal val Panel = Color(0xFF122C44)
internal val Cyan = Color(0xFF03EEEF)
internal val Gold = Color(0xFFFFE000)
internal val Green = Color(0xFF38C138)
internal val Dim = Color(0xFF8FA6BA)

@Composable
fun CaddieTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Navy) { content() }
    }
}

@Composable
fun HomeScreen(
    permissionsGranted: Boolean,
    permissionsDenied: Boolean,
    onGrant: () -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
    send: (Command) -> Unit,
) {
    var tab by remember { mutableStateOf(0) }
    val running by CaddieHub.serviceRunning.collectAsState()

    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Brand()
        Spacer(Modifier.height(8.dp))
        if (!permissionsGranted) {
            PermissionCard(permissionsDenied, onGrant)
            return@Column
        }
        if (!running) {
            Button(onClick = onStart, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                Text("START ROUND", color = Navy, fontWeight = FontWeight.Bold)
            }
            return@Column
        }
        ScrollableTabRow(selectedTabIndex = tab, containerColor = Navy, contentColor = Cyan, edgePadding = 0.dp) {
            listOf("Play", "Scorecard", "My Game", "My Golf Bag", "Cart").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, maxLines = 1) })
            }
        }
        Spacer(Modifier.height(12.dp))
        when (tab) {
            0 -> PlayTab(send, onStop)
            1 -> ScorecardTab(send)
            2 -> MyGameTab(send)
            3 -> BagTab(send)
            else -> CartTab(send)
        }
    }
}

@Composable
private fun Brand() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        CartIcon(Modifier.size(40.dp, 33.dp))
        Spacer(Modifier.width(10.dp))
        Text("HANDLE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("CADDIE", color = Color.White, fontWeight = FontWeight.Light, fontSize = 20.sp)
    }
}

/**
 * The Handle Caddie golf-cart mark, the same vector shape the display draws (same tracing grid, ported from
 * ui_screens.h cartIcon). [bg] must match what is behind it: the wheel arches are cut out with that colour.
 * Aspect ratio is 572 : 468 (about 1.22 : 1).
 */
@Composable
fun CartIcon(modifier: Modifier = Modifier, color: Color = Color.White, bg: Color = Navy) {
    Canvas(modifier) {
        val k = size.width / 572f
        fun x(zx: Float) = (zx - 76f) * k
        fun y(zy: Float) = (zy - 140f) * k
        fun poly(vararg p: Pair<Float, Float>) = drawPath(
            Path().apply { moveTo(x(p[0].first), y(p[0].second)); for (i in 1 until p.size) lineTo(x(p[i].first), y(p[i].second)); close() }, color,
        )
        fun seg(x1: Float, y1: Float, x2: Float, y2: Float, w: Float, a: Float = 1f) =
            drawLine(color.copy(alpha = a), Offset(x(x1), y(y1)), Offset(x(x2), y(y2)), strokeWidth = w * k, cap = StrokeCap.Round)

        poly(135f to 140f, 555f to 140f, 545f to 182f, 145f to 182f)                                   // roof
        drawRoundRect(color, Offset(x(180f), y(178f)), Size(44f * k, 212f * k), CornerRadius(3f * k))   // rear post
        poly(492f to 180f, 524f to 180f, 574f to 388f, 544f to 388f)                                   // windshield post
        seg(250f, 292f, 262f, 372f, 20f, 0.82f)                                                        // seat back
        drawRoundRect(color.copy(alpha = 0.9f), Offset(x(238f), y(366f)), Size(125f * k, 28f * k), CornerRadius(6f * k))   // seat
        seg(412f, 340f, 462f, 298f, 20f); seg(448f, 318f, 498f, 372f, 20f)                              // steering wheel
        poly(                                                                                           // body with floor well
            135f to 380f, 385f to 380f, 388f to 476f, 496f to 476f, 496f to 408f, 556f to 386f,
            628f to 428f, 648f to 478f, 604f to 524f, 92f to 524f, 76f to 508f, 100f to 420f,
        )
        for (wx in listOf(190f, 587f)) {                                                               // wheels
            val c = Offset(x(wx), y(535f))
            drawCircle(bg, 73f * k, c)       // wheel-arch gap
            drawCircle(color, 63f * k, c)
            drawCircle(bg, 19f * k, c)       // hub
        }
    }
}

@Composable
private fun PermissionCard(denied: Boolean, onGrant: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Permissions needed", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(
                "Bluetooth connects to the display on your cart. Location measures yardage to the pin and " +
                    "detects which part of the hole you're on. Android also requires location access for Bluetooth scanning.",
                color = Dim,
            )
            if (denied) Text("Some permissions were denied. Enable them in system Settings > Apps > Handle Caddie.", color = Gold)
            Button(onClick = onGrant, colors = ButtonDefaults.buttonColors(containerColor = Cyan)) {
                Text("Grant access", color = Navy, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ----------------------------------------------------------------------------------------------- Play
@Composable
private fun PlayTab(send: (Command) -> Unit, onStop: () -> Unit) {
    val g by CaddieHub.game.collectAsState()
    val link by CaddieHub.link.collectAsState()
    val setup by CaddieHub.setup.collectAsState()

    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        StatusRow(link, g.gpsAccuracyM, send)
        val da by CaddieHub.displayAuth.collectAsState()
        if (link is LinkState.Connected && da.state != CartAuthState.AUTHED && da.state != CartAuthState.UNKNOWN) DisplayPairCard(da.state, da.message, send)
        SetupSection(send)
        if (!setup.confirmed) return@Column
        StormBanner(send)

        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("HOLE ${g.holeNumber}", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("PAR ${g.par}  ·  ${g.lengthYd} yd", color = Dim)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    Text(g.toPinYd?.toString() ?: "--", color = Gold, fontWeight = FontWeight.Bold, fontSize = 72.sp)
                    Text(" yd to pin", color = Dim, modifier = Modifier.padding(bottom = 14.dp))
                }
                Text("Front ${g.frontYd ?: "--"}   Back ${g.backYd ?: "--"}", color = Color.White)
                if (g.toPinYd == null && course0Learning()) Text("New course for me: I'll learn this hole as you play it. Yardages start next round.", color = Gold, fontSize = 12.sp)
                val pace by CaddieHub.pace.collectAsState()
                if (pace.level != PaceLevel.NOT_STARTED) {
                    val pc = when (pace.level) { PaceLevel.AHEAD, PaceLevel.ON_TIME -> Green; PaceLevel.SLIGHT -> Gold; else -> Color(0xFFFF6B6B) }
                    Text(if (pace.paused) "Clock paused" else pace.text, color = pc, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
                val pls by CaddieHub.playsLike.collectAsState()
                pls.pl?.takeIf { it.changed }?.let { pl ->
                    Spacer(Modifier.height(4.dp))
                    Text(pl.summary, color = Cyan, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    pls.club?.let { c -> Text("Take: ${c.name} (${c.useYd} yd) for ${pl.playsYd}", color = Color.White, fontSize = 14.sp) }
                }
                Spacer(Modifier.height(8.dp))
                val club = g.club
                if (club == null) {
                    Text("Recommended: --", color = Color.White, fontSize = 18.sp)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Catalog.brandByName(club.brand)?.let { BrandBadge(it.id, 34.dp); Spacer(Modifier.width(10.dp)) }
                        Column {
                            Text("Recommended: ${club.name} (${club.useYd} yd${if (club.learnedN >= Learning.MIN_SHOTS) " · your avg" else ""})", color = Color.White, fontSize = 18.sp)
                            if (club.brand.isNotEmpty()) {
                                Text("${club.brand} ${club.model}" + (if (club.loft > 0) "  ·  ${loftText(club.loft)}°" else ""), color = Dim, fontSize = 13.sp)
                            }
                        }
                    }
                    val allShots by CaddieHub.shots.collectAsState()
                    val aim = remember(club, allShots) { Dispersion.aimTip(allShots, Clubs.key(club), club.name) }
                    aim?.let { Text(it, color = Cyan, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Stat("ZONE", zoneLabel(g.zone), Modifier.weight(1f))
            Stat("STROKES", "${g.strokes}", Modifier.weight(1f))
            Stat("PUTTS", "${g.putts}", Modifier.weight(1f))
            Stat("LAST", g.lastShotYd?.let { "$it yd" } ?: "--", Modifier.weight(1f))
        }
        RecentShots(send)
        if (g.clubOut) Text("Club out of the bag", color = Green, fontWeight = FontWeight.Bold)
        if (g.roundComplete) Text("Round complete  ·  ${g.totalScore} strokes", color = Gold, fontWeight = FontWeight.Bold)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { send(Command.PrevHole) }, Modifier.weight(1f)) { Text("Prev hole") }
            OutlinedButton(onClick = { send(Command.NextHole) }, Modifier.weight(1f)) { Text("Next hole") }
        }
        LightningPicker(send)
        OutlinedButton(onClick = onStop, Modifier.fillMaxWidth()) { Text("End round & stop tracking") }
    }
}

@Composable
private fun course0Learning(): Boolean {
    val c by CaddieHub.course.collectAsState()
    return (c as? com.handlecaddie.controller.service.CourseStatus.Ready)?.learning == true
}

/** Shown only while there is a storm to warn about. */
@Composable
private fun StormBanner(send: (Command) -> Unit) {
    val st by CaddieHub.storm.collectAsState()
    if (st.level == StormLevel.CLEAR) return
    val danger = st.level == StormLevel.TAKE_COVER
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = if (danger) Color(0xFF7A1F1F) else Color(0xFF5A4A12))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(if (danger) "LIGHTNING RISK: TAKE COVER" else "STORM WATCH", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(st.text, color = Color.White, fontSize = 14.sp)
            Text("The phone cannot sense lightning. This comes from the weather forecast and from what you tell it below.", color = Color(0xFFDDDDDD), fontSize = 11.sp)
            OutlinedButton(onClick = { send(Command.StormClear) }) { Text("False alarm, clear it") }
        }
    }
}

/** The old flash-to-bang count: tap how long you waited between the flash and the thunder. */
@Composable
private fun LightningPicker(send: (Command) -> Unit) {
    var open by remember { mutableStateOf(false) }
    if (!open) { OutlinedButton(onClick = { open = true }, Modifier.fillMaxWidth()) { Text("Saw lightning or heard thunder?") }; return }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("How long from the flash to the thunder?", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Every 5 seconds is about a mile. Under 30 seconds means take cover.", color = Dim, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Under 10 s", selected = false) { send(Command.FlashBang(5)); open = false }
                Pill("10-30 s", selected = false) { send(Command.FlashBang(20)); open = false }
                Pill("30-60 s", selected = false) { send(Command.FlashBang(45)); open = false }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Thunder, no flash seen", selected = false) { send(Command.FlashBang(null)); open = false }
                Pill("Cancel", selected = false) { open = false }
            }
        }
    }
}

/** Shown while the display is connected but has not accepted this phone: says why, and takes the PIN shown on the display. */
@Composable
private fun DisplayPairCard(state: CartAuthState, message: String, send: (Command) -> Unit) {
    var pin by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                when (state) {
                    CartAuthState.CHECKING -> "Checking this phone with the display…"
                    CartAuthState.LOCKED -> "The display is not listening"
                    CartAuthState.PAIRING_OPEN -> "Pair with the display"
                    else -> "The display hasn't accepted this phone yet"
                },
                color = Gold, fontWeight = FontWeight.Bold,
            )
            if (message.isNotBlank()) Text(message, color = Color.White, fontSize = 13.sp)
            Text("Until it does, the display shows no hole data and ignores this phone.", color = Dim, fontSize = 12.sp)
            if (state == CartAuthState.PAIRING_OPEN) {
                OutlinedTextField(
                    value = pin, onValueChange = { v -> pin = v.filter { it.isDigit() }.take(6) }, singleLine = true,
                    label = { Text("6-digit PIN from the display") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(onClick = { send(Command.DisplayPair(pin)) }, enabled = pin.length == 6, modifier = Modifier.fillMaxWidth()) { Text("Pair") }
            }
        }
    }
}

@Composable
private fun StatusRow(link: LinkState, acc: Float?, send: (Command) -> Unit) {
    val (text, color) = when (link) {
        LinkState.Idle -> "Display: not connected" to Gold
        LinkState.Scanning -> "Display: searching…" to Gold
        LinkState.Connecting -> "Display: connecting…" to Gold
        LinkState.Pairing -> "Display: pairing…" to Gold
        is LinkState.Connected -> "Display: connected" to Green
        is LinkState.Reconnecting -> "Display: reconnecting (${link.attempt})" to Gold
        is LinkState.Failed -> "Display: ${link.reason}" to Color(0xFFFF6B6B)
    }
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text, color = color, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            if (link !is LinkState.Connected) {
                OutlinedButton(onClick = { send(Command.Connect) }) { Text("Connect") }
            }
        }
        Text(acc?.let { "GPS accuracy ±${it.toInt()} m" } ?: "GPS: searching…", color = Dim, fontSize = 12.sp)
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = Dim, fontSize = 10.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

private fun zoneLabel(z: Zone) = when (z) {
    Zone.TEE -> "Tee"; Zone.FAIRWAY -> "Fairway"; Zone.ROUGH -> "Rough"; Zone.GREEN -> "Green"; Zone.UNKNOWN -> "--"
}

// ------------------------------------------------------------------------------------------ Scorecard
@Composable
private fun ScorecardTab(send: (Command) -> Unit) {
    val g by CaddieHub.game.collectAsState()
    var editing by remember { mutableStateOf<Int?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Total ${g.totalScore}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text(
                if (g.playedHoles == 0) "E" else (if (g.toPar > 0) "+${g.toPar}" else if (g.toPar == 0) "E" else "${g.toPar}"),
                color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp,
            )
        }
        Text("Tap a hole to correct its par.", color = Dim, fontSize = 12.sp)
        LazyColumn(Modifier.height(430.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items((g.firstHole..g.lastHole).toList()) { n ->
                val i = n - 1
                val s = g.scores[i]
                val src = g.parSources[i]
                Column(
                    Modifier.fillMaxWidth().background(if (n == g.holeNumber) Panel else Navy)
                        .clickable { editing = if (editing == n) null else n }.padding(horizontal = 10.dp, vertical = 8.dp),
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Hole $n", color = Color.White)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Par ${g.pars[i]}", color = Dim)
                            when (src) {
                                ParSource.ESTIMATED -> Text("estimated", color = Gold, fontSize = 10.sp)
                                ParSource.EDITED -> Text("edited", color = Cyan, fontSize = 10.sp)
                                ParSource.MAP -> {}
                            }
                        }
                        Text(if (s > 0) "$s" else "-", color = scoreColor(s, g.pars[i]), fontWeight = FontWeight.Bold)
                    }
                    if (editing == n) {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(3, 4, 5, 6).forEach { p -> Pill("Par $p", selected = g.pars[i] == p) { send(Command.SetPar(n, p)) } }
                            if (src == ParSource.EDITED) Pill("Reset", selected = false) { send(Command.SetPar(n, 0)) }
                        }
                        if (src == ParSource.ESTIMATED) {
                            Text("The map has no par for this hole, so it was guessed from its length.", color = Gold, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }
        OutlinedButton(onClick = { send(Command.NewRound) }, Modifier.fillMaxWidth()) { Text("New round (clears scores)") }
    }
}

private fun scoreColor(s: Int, par: Int) = when {
    s == 0 -> Dim
    s < par -> Green
    s == par -> Color.White
    else -> Gold
}
