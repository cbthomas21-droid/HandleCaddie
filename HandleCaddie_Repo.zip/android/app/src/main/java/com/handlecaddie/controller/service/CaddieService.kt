package com.handlecaddie.controller.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.handlecaddie.controller.ble.BleLink
import com.handlecaddie.controller.core.CartConfig
import com.handlecaddie.controller.core.ManualDrive
import com.handlecaddie.controller.core.TimedDrive
import com.handlecaddie.controller.core.CartAuth
import com.handlecaddie.controller.core.CartAuthFlow
import com.handlecaddie.controller.core.CartAuthState
import com.handlecaddie.controller.core.CartAuthStatus
import com.handlecaddie.controller.core.CartFault
import com.handlecaddie.controller.core.CartFlag
import com.handlecaddie.controller.core.CartUnits
import com.handlecaddie.controller.core.Club
import com.handlecaddie.controller.core.BenchRunner
import com.handlecaddie.controller.core.BenchScenario
import com.handlecaddie.controller.core.BenchScenarios
import com.handlecaddie.controller.core.Geo
import com.handlecaddie.controller.core.GuardOut
import com.handlecaddie.controller.core.XY
import com.handlecaddie.controller.core.GreenGuard
import com.handlecaddie.controller.core.GreenMap
import com.handlecaddie.controller.core.GuardState
import com.handlecaddie.controller.core.AdvanceOffer
import com.handlecaddie.controller.core.WatchCmd
import com.handlecaddie.controller.core.WatchProtocol
import com.handlecaddie.controller.core.WatchState
import com.handlecaddie.controller.core.BatteryForecast
import com.handlecaddie.controller.core.CartLocator
import com.handlecaddie.controller.core.Clubs
import com.handlecaddie.controller.core.Conditions
import com.handlecaddie.controller.core.ConditionsParse
import com.handlecaddie.controller.core.HoleProfile
import com.handlecaddie.controller.core.PlaysLikeCalc
import com.handlecaddie.controller.data.ConditionsClient
import com.handlecaddie.controller.core.Heading
import com.handlecaddie.controller.core.HeadingEstimate
import com.handlecaddie.controller.core.HeadingEstimator
import com.handlecaddie.controller.core.NavAct
import com.handlecaddie.controller.core.NavCode
import com.handlecaddie.controller.core.NavInput
import com.handlecaddie.controller.core.NavPhase
import com.handlecaddie.controller.core.NavSession
import com.handlecaddie.controller.core.NavSimCart
import com.handlecaddie.controller.core.Learning
import com.handlecaddie.controller.core.CartMode
import com.handlecaddie.controller.core.CartMsg
import com.handlecaddie.controller.core.CartProtocol
import com.handlecaddie.controller.core.CartSimulator
import com.handlecaddie.controller.core.CartTelemetry
import com.handlecaddie.controller.core.Course
import com.handlecaddie.controller.core.CourseChoice
import com.handlecaddie.controller.core.DistanceModel
import com.handlecaddie.controller.core.Formats
import com.handlecaddie.controller.core.RoundFormat
import com.handlecaddie.controller.core.DeviceEvent
import com.handlecaddie.controller.core.Fix
import com.handlecaddie.controller.core.Protocol
import com.handlecaddie.controller.core.RoundSummary
import com.handlecaddie.controller.core.RoundStats
import com.handlecaddie.controller.core.CaddieVoice
import com.handlecaddie.controller.core.AuthWords
import com.handlecaddie.controller.core.CaddieReport
import com.handlecaddie.controller.core.LearnObs
import com.handlecaddie.controller.core.LearnedCourses
import com.handlecaddie.controller.core.LearnedHole
import com.handlecaddie.controller.core.LightningGuard
import com.handlecaddie.controller.core.PaceCoach
import com.handlecaddie.controller.core.PaceLevel
import com.handlecaddie.controller.core.RoundRecap
import com.handlecaddie.controller.core.StormLevel
import com.handlecaddie.controller.core.LatLon
import com.handlecaddie.controller.core.GameEngine
import com.handlecaddie.controller.data.CourseRepository
import com.handlecaddie.controller.data.RoundStore
import com.handlecaddie.controller.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Runs the whole round. It is a foreground service (location + connected device) so GPS and the Bluetooth
 * link keep working with the screen off and the phone in a pocket. The UI is just an observer of [CaddieHub].
 *
 * Threading: every input (GPS fix, unit event, command, course result) goes into ONE queue handled by ONE
 * coroutine, so [GameEngine] is never touched concurrently. Output lines go into a second queue with ONE
 * sender, so BLE writes can't interleave and a slow write never blocks GPS handling.
 */
class CaddieService : Service() {

    private sealed interface In {
        class Gps(val fix: Fix) : In
        class Dev(val ev: DeviceEvent) : In
        class CourseLoaded(val course: Course, val key: String) : In
        class CourseFailed(val message: String, val key: String) : In
        class NearbyLoaded(val courses: List<CourseChoice>) : In
        class NearbyFailed(val message: String) : In
        data object LinkUp : In
        class DisplayAuth(val m: CartMsg) : In       // the display said something about who may use it
        data object DisplayReady : In                // this phone was accepted by the display: send it the whole picture
        data object Resync : In
        data object Tick : In                 // once a second: the GPS watchdog
        data object Bench : In                // one simulated second of a bench test
        class NavAck(val ok: Boolean) : In    // the cart answered a route message
        data object PlaysLikeRefresh : In     // weather or heights arrived
        data object LocatorDisarm : In
        class CartGps(val fix: Fix) : In      // phone riding on the cart: this is the CART's position
        data object WatchGo : In              // the watch's Go button
        data object NavCancel : In            // someone changed the cart's mode: end any go-around
        class Cmd(val c: Command) : In
    }

    /**
     * Everything the service does runs on ONE thread (still off the main thread). That removes whole classes of race between the
     * GPS handler, the cart handlers, the watch and the timers, because only one of them runs at any moment. Slow work (network, disk
     * reads of a whole course) is moved to Dispatchers.IO explicitly where it happens. An exception nobody caught is written to the
     * decision log instead of killing the service in the middle of a round.
     */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default.limitedParallelism(1) +
            kotlinx.coroutines.CoroutineExceptionHandler { _, e -> runCatching { log("internal error: ${e.javaClass.simpleName}: ${e.message}") } },
    )
    private val inbox = Channel<In>(Channel.UNLIMITED)
    private val outbox = Channel<String>(Channel.UNLIMITED)
    private val engine = GameEngine()

    private lateinit var ble: BleLink
    private lateinit var cartBle: BleLink
    private lateinit var store: RoundStore
    private lateinit var repo: CourseRepository
    private lateinit var fused: FusedLocationProviderClient

    @Volatile private var lastFix: Fix? = null          // read by the weather loop on another thread
    private var nearbyRequested = false
    private var prefetchJob: kotlinx.coroutines.Job? = null
    private var prefetchKeys: List<String> = emptyList()
    private var guardTipShown = false
    private var statsSaved = -1
    private var roundSaved = false
    private var lastPlaceSavedAt = 0L
    @Volatile private var loadedKey: String? = null     // the course the engine is actually holding (null while one loads)
    private var lastResync = 0L
    private var displayKey: String? = null
    private var answeredDisplayNonce: String? = null
    private var displayHelloAt = 0L
    private var displayHellos = 0

    // ---- pace of play, lightning, learning an unmapped course
    private val pace = PaceCoach()
    private val paceLock = Any()
    private val lightning = LightningGuard()
    private val stormLock = Any()
    private var lastStormLevel = StormLevel.CLEAR
    private var learnedHoles: List<LearnedHole> = emptyList()

    // ---- bag with learned distances, and the green guard
    private var baseBag: List<Club> = emptyList()          // the bag as the player saved it (no learned numbers)
    private var useLearning = true
    private var shotsSaved = -1
    private val guard = GreenGuard()
    private var greenMap: GreenMap? = null
    private var holdSent: Boolean? = null
    private var lastGuardState: GuardState? = null
    private var lastBlocked = false
    private var cartKey: String? = null            // the key from pairing this phone with the cart
    private var answeredNonce: String? = null      // each challenge is answered once
    private var lastCartFlags = 0
    private var lastCartFaults = 0
    @Volatile private var benchActive = false           // while true the real GPS is ignored and the bench feeds the guard
    private var benchRunner: BenchRunner? = null
    private var benchJob: kotlinx.coroutines.Job? = null
    private val logLock = Any()
    private var holdSentMs = 0L

    // ---- cart link. Independent of the golf engine, so it has its own queues.
    private val cartOut = Channel<String>(Channel.UNLIMITED)
    private val cartJoy = Channel<String>(Channel.CONFLATED)      // only the newest stick position is worth sending
    private val sim = CartSimulator()
    @Volatile private var lastTelMs = 0L

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(r: LocationResult) {
            if (benchActive) return                 // a bench test is feeding the guard made-up positions
            if (CaddieHub.positionFromWatch.value) {          // the phone is riding on the cart: its GPS is the CART's position, not yours
                val cl = r.lastLocation ?: return
                inbox.trySend(In.CartGps(Fix(cl.latitude, cl.longitude, cl.accuracy, SystemClock.elapsedRealtime())))
                return
            }
            val l = r.lastLocation ?: return
            inbox.trySend(In.Gps(Fix(l.latitude, l.longitude, l.accuracy, SystemClock.elapsedRealtime())))
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        // Android 12+ refuses to start a foreground service from the background (for instance after the system restarted us); Android 14 also needs the location permission first
        try { startInForeground("Starting round…") } catch (e: Exception) { stopSelf(); return }
        CaddieHub.serviceRunning.value = true

        store = RoundStore(this)
        repo = CourseRepository(this)
        baseBag = Learning.strip(store.loadBag())
        useLearning = store.loadLearn()
        CaddieHub.useLearning.value = useLearning
        engine.loadShots(store.loadShots())
        CaddieHub.history.value = store.loadHistory()
        shotsSaved = engine.shotsVersion
        refreshBag()
        guard.cfg = store.loadGuard()
        cartKey = store.loadCartKey()
        displayKey = store.loadDisplayKey()
        CaddieHub.guard.value = GuardStatus(cfg = guard.cfg)
        CaddieHub.swing.value = store.loadSwing()
        pace.targetMin = store.loadPaceTarget()
        engine.wallClock = { System.currentTimeMillis() }
        engine.onLearn = { o -> learn(o) }          // called from the one thread that runs the engine
        // show the course list from the last time right away, before GPS or the network answer (the real search refreshes it)
        store.loadLastPlace()?.let { (la, lo) ->
            scope.launch { repo.nearbyCached(LatLon(la, lo))?.let { inbox.send(In.NearbyLoaded(it)) } }
        }
        // today's course + format, if the app was restarted mid-round
        store.loadSetup()?.let { CaddieHub.setup.value = RoundSetup(it.course, it.format, it.confirmed && it.course != null) }
        ble = BleLink(this, scope, rejectName = CART_NAME, otherAddrKey = "addr_cart")
        cartBle = BleLink(this, scope, wantName = CART_NAME, addrKey = "addr_cart", otherAddrKey = "addr", bondRequired = true)
        fused = LocationServices.getFusedLocationProviderClient(this)

        // unit -> app
        scope.launch { ble.events.collect { inbox.trySend(In.Dev(it)) } }
        // the display's answers about who may use it (challenge, result of our answer, result of pairing)
        scope.launch { ble.raw.collect { line -> CartProtocol.parse(line)?.let { m -> if (m is CartMsg.Chal || m is CartMsg.AuthAck || m is CartMsg.PairAck) inbox.trySend(In.DisplayAuth(m)) } } }
        scope.launch {
            ble.state.collect { st ->
                CaddieHub.link.value = st
                if (st is BleLink.LinkState.Connected) inbox.trySend(In.LinkUp)
                else CaddieHub.displayAuth.value = com.handlecaddie.controller.core.CartAuthStatus()
            }
        }
        // UI -> service. Cart commands are acted on at once; golf commands go through the engine's queue.
        scope.launch { CaddieHub.commands.collect { if (it is CartCommand) cartCommand(it) else inbox.trySend(In.Cmd(it)) } }
        startCart()
        startConditions()
        watch = WatchBridge(this, onGps = { la, lo, ac -> lastWatchGpsMs = SystemClock.elapsedRealtime(); if (CaddieHub.positionFromWatch.value && !benchActive) inbox.trySend(In.Gps(Fix(la, lo, ac, SystemClock.elapsedRealtime()))) },
            onCmd = { watchCommand(it) }, onDrive = { watchDrive(it) }, onConnected = { CaddieHub.watchConnected.value = it })
        watch.start()
        // GPS watchdog: once a second, if fixes have stopped arriving the guard holds the cart
        scope.launch { while (true) { delay(1_000); inbox.trySend(In.Tick) } }
        // keep the round on disk and the notification fresh
        scope.launch {
            CaddieHub.game.map { it.holeNumber to it.scores }.distinctUntilChanged().collect { (h, s) ->
                loadedKey?.let { key -> store.saveRound(h, s, key) }
                updateNotification("Hole $h  ·  ${CaddieHub.game.value.toPinYd ?: "--"} yd to pin")
            }
        }

        // pace of play: a new hole closes the old one and may earn a word from the caddie
        scope.launch {
            CaddieHub.game.map { it.holeNumber }.distinctUntilChanged().collect { h -> paceHoleChanged(h) }
        }
        scope.launch {
            CaddieHub.game.map { it.roundComplete }.distinctUntilChanged().collect { done ->
                if (done) synchronized(paceLock) { pace.finish(System.currentTimeMillis()); loadedKey?.let { store.savePace(it, pace.encode()) } }
            }
        }
        scope.launch {
            for (i in inbox) {
                try { handle(i) } catch (e: Exception) { handleFailed(i, e) }
                CaddieHub.game.value = engine.state
            }
        }
        scope.launch {
            for (line in outbox) {
                if (ble.state.value is BleLink.LinkState.Connected && !ble.send(line)) inbox.trySend(In.Resync)
            }
        }

        startLocation()
        ble.start()
        if (CaddieHub.setup.value.course != null) loadSelected()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onDestroy() {
        runCatching { fused.removeLocationUpdates(locationCallback) }
        if (::watch.isInitialized) watch.stop()
        if (::ble.isInitialized) ble.stop()
        if (::cartBle.isInitialized) { cartBle.stop(); cartBle.close() }
        CaddieHub.cartDemo.value = false
        CaddieHub.cartMode.value = CartMode.PARK
        CaddieHub.cartFresh.value = false
        CaddieHub.cartLink.value = BleLink.LinkState.Idle
        CaddieHub.joystick.value = Joy()
        // Ending the round reopens the course + format card for the next start (today's pick stays preselected).
        val setup = CaddieHub.setup.value
        CaddieHub.setup.value = setup.copy(confirmed = false)
        if (::store.isInitialized) store.saveSetup(setup.course, setup.format, false)
        CaddieHub.nearby.value = NearbyStatus.None
        CaddieHub.course.value = CourseStatus.None
        CaddieHub.serviceRunning.value = false
        CaddieHub.link.value = BleLink.LinkState.Idle
        scope.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ the one place the engine is used
    private val errorTimes = ArrayDeque<Long>()
    private var failSafe = false                 // set after repeated internal errors: the cart stays held (see guardStep)

    /**
     * A message made the handler throw. Write it down and carry on with the next one. If it keeps happening (3 times in 10 s) the
     * phone-side protection cannot be trusted, so the cart is told to hold until the round is restarted by the player.
     */
    private fun handleFailed(i: In, e: Exception) {
        val now = SystemClock.elapsedRealtime()
        errorTimes.addLast(now); while (errorTimes.isNotEmpty() && now - errorTimes.first() > 10_000L) errorTimes.removeFirst()
        log("internal error while handling ${i.javaClass.simpleName}: ${e.javaClass.simpleName}: ${e.message}")
        if (errorTimes.size >= 3 && !failSafe) {
            failSafe = true
            if (cartLive()) { holdSent = true; holdSentMs = now; if (CaddieHub.cartDemo.value) sim.hold = true else outboxCart(CartProtocol.hold(true)) }
            log("HOLD: repeated internal errors - the cart is held until you restart the app.")
        }
    }

    private fun outboxCart(line: String) { if (CaddieHub.cartDemo.value) return; cartOut.trySend(line) }

    private fun handle(i: In) {
        val out: List<String> = when (i) {
            is In.Gps -> {
                lastFix = i.fix
                if (!nearbyRequested && i.fix.accuracyM <= 30f) requestNearby()
                if (i.fix.accuracyM <= 100f && i.fix.timeMs - lastPlaceSavedAt > 60_000) { lastPlaceSavedAt = i.fix.timeMs; store.saveLastPlace(i.fix.latLon.lat, i.fix.latLon.lon) }
                val lines = engine.onFix(i.fix)
                guardStep(i.fix)
                locUpdate(i.fix)
                updatePlaysLike()
                lines
            }
            is In.Dev -> {
                // With the cart following, the club comes out about the follow distance behind the ball
                val cartLive = cartLive()
                engine.ballOffsetM = if (cartLive && CaddieHub.cartMode.value == CartMode.FOLLOW) CaddieHub.cartConfig.value.followM else 0.0
                if (i.ev is DeviceEvent.Pull) paceMaybeStart()
                val lines = engine.onDevice(i.ev, SystemClock.elapsedRealtime())
                if (i.ev is com.handlecaddie.controller.core.DeviceEvent.HoleOut) advance.onHoleOut(engine.state.holeNumber.takeIf { !engine.state.roundComplete }, SystemClock.elapsedRealtime())
                lines
            }
            In.LinkUp -> {
                answeredDisplayNonce = null
                CaddieHub.displayAuth.value = com.handlecaddie.controller.core.CartAuthStatus()
                outbox.trySend(CartProtocol.hello())             // an older display ignores this; a newer one answers with a challenge
                displayHelloAt = SystemClock.elapsedRealtime(); displayHellos = 1
                engine.resend()
            }
            is In.DisplayAuth -> { displayAuthStep(i.m); emptyList() }
            In.DisplayReady -> engine.resend()
            In.Resync -> {
                val now = SystemClock.elapsedRealtime()
                if (now - lastResync < 3_000) emptyList() else { lastResync = now; engine.resend() }
            }
            is In.NearbyLoaded -> {
                CaddieHub.nearby.value = NearbyStatus.Ready(i.courses)
                startPrefetch(i.courses)
                // nothing picked yet: preselect the closest course, the player can change it
                if (CaddieHub.setup.value.course == null) i.courses.firstOrNull()?.let { selectCourse(it) }
                emptyList()
            }
            is In.NearbyFailed -> { CaddieHub.nearby.value = NearbyStatus.Error(i.message); nearbyRequested = false; emptyList() }
            is In.CourseLoaded -> {
                val setup = CaddieHub.setup.value
                if (i.key != setup.course?.key) emptyList()          // an older request that was overtaken
                else {
                    engine.loadCourse(i.course)
                    loadedKey = i.key
                    learnedHoles = if (i.course.learning) LearnedCourses.decode(store.loadLearned(i.key)) else emptyList()
                    synchronized(paceLock) { pace.restore(store.loadPace(i.key)); pace.targetMin = store.loadPaceTarget() }
                    store.loadScores(i.key)?.let { engine.restoreScores(it) }
                    store.loadHoleStats(i.key)?.let { engine.restoreHoleStats(it) }
                    engine.setParEdits(store.loadPars(i.key))
                    greenMap = GreenMap.build(i.course)
                    guard.setMap(greenMap)
                    holdSent = null
                    CaddieHub.guard.value = CaddieHub.guard.value.copy(state = GuardState.FREE, cartToHazardM = null, hasHazards = greenMap?.isEmpty == false, hazard = null, lostGps = false)
                    val ok = Formats.available(i.course)
                    val fmt = if (setup.format in ok) setup.format else ok.first()
                    CaddieHub.setup.value = setup.copy(format = fmt)
                    store.saveSetup(setup.course, fmt, setup.confirmed)
                    CaddieHub.course.value = CourseStatus.Ready(i.course.name, i.course.holes.size, ok, i.course.learning, LearnedCourses.knownCount(learnedHoles))
                    engine.setFormat(fmt)
                }
            }
            is In.CourseFailed -> {
                if (i.key == CaddieHub.setup.value.course?.key) CaddieHub.course.value = CourseStatus.Error(i.message)
                emptyList()
            }
            is In.Cmd -> command(i.c)
            In.Tick -> { if (!benchActive) guardWatchdog(SystemClock.elapsedRealtime()); navTick(SystemClock.elapsedRealtime()); batteryTick(); watchTick(SystemClock.elapsedRealtime()); gpsFollowCheck(SystemClock.elapsedRealtime()); paceTick(); stormTick(); displayHelloTick(SystemClock.elapsedRealtime()); emptyList() }
            is In.NavAck -> { navSession?.let { navApply(it.onAck(i.ok, SystemClock.elapsedRealtime())) }; emptyList() }
            In.PlaysLikeRefresh -> { updatePlaysLike(); emptyList() }
            is In.CartGps -> { cartGpsIn(i.fix); emptyList() }
            In.WatchGo -> {
                val offered = advance.current(CaddieHub.game.value.holeNumber, SystemClock.elapsedRealtime())
                if (offered != null) {
                    if (CaddieHub.teeDriveEnabled.value && teeDriveStart(offered, SystemClock.elapsedRealtime())) {
                        advance.dismiss()
                        log("watch: Go - cart sent to the tee of hole $offered")
                    } else {
                        advance.dismiss()
                        if (cartLive() && CaddieHub.cartMode.value != CartMode.MANUAL) cartCommand(CartCommand.SetMode(CartMode.FOLLOW))
                        log("watch: Go - cart set to follow for hole ${CaddieHub.game.value.holeNumber}")
                    }
                }
                emptyList()
            }
            In.LocatorDisarm -> { locator.disarm(); CaddieHub.locator.value = LocatorStatus(); emptyList() }
            In.NavCancel -> { navCancel("mode changed"); emptyList() }
            In.Bench -> { benchTick(); emptyList() }
        }
        for (line in out) outbox.trySend(line)
        syncShots()
        syncStats()
    }

    private fun command(c: Command): List<String> = when (c) {
        Command.Connect -> { ble.start(); emptyList() }
        Command.Disconnect -> { ble.stop(); emptyList() }
        Command.NextHole -> engine.nextHole()
        Command.PrevHole -> engine.prevHole()
        Command.ReloadCourse -> { loadSelected(); emptyList() }
        Command.RefreshNearby -> { requestNearby(); emptyList() }
        Command.NewRound -> {
            store.clearRound()
            synchronized(paceLock) { pace.reset() }
            val key = loadedKey
            val c = CaddieHub.setup.value.course
            if (engine.course?.learning == true && key != null && c != null) {
                // a second round on an unmapped course: holes learned in the first one now have yardages
                val rebuilt = LearnedCourses.build(c.name, c.center, learnedHoles)
                engine.loadCourse(rebuilt)
                engine.setParEdits(store.loadPars(key))
                CaddieHub.course.value = CourseStatus.Ready(rebuilt.name, rebuilt.holes.size, Formats.available(rebuilt), true, LearnedCourses.knownCount(learnedHoles))
                engine.setFormat(CaddieHub.setup.value.format)
            }
            engine.newRound()
        }
        is Command.SetPaceTarget -> {
            val m = c.minutes.coerceIn(120, 360)
            store.savePaceTarget(m)
            synchronized(paceLock) { pace.targetMin = m; loadedKey?.let { k -> if (pace.started) store.savePace(k, pace.encode()) } }
            paceTick(); emptyList()
        }
        is Command.PauseRound -> {
            val now = System.currentTimeMillis()
            synchronized(paceLock) { if (c.paused) pace.pause(now) else pace.resume(now); loadedKey?.let { k -> if (pace.started) store.savePace(k, pace.encode()) } }
            paceTick(); emptyList()
        }
        is Command.FlashBang -> {
            synchronized(stormLock) { lightning.flashToBang(c.seconds, System.currentTimeMillis()) }
            stormTick(); emptyList()
        }
        Command.StormClear -> { synchronized(stormLock) { lightning.reset() }; stormTick(); emptyList() }
        Command.MakeRecap -> { makeRecap(); emptyList() }
        Command.RecapShown -> { CaddieHub.recap.value = null; emptyList() }
        Command.SaveRound -> { saveRoundSummary(); emptyList() }
        Command.StartRound -> {
            val s = CaddieHub.setup.value
            if (s.course != null && CaddieHub.course.value is CourseStatus.Ready) {
                CaddieHub.setup.value = s.copy(confirmed = true)
                store.saveSetup(s.course, s.format, true)
            }
            emptyList()
        }
        Command.EditSetup -> { CaddieHub.setup.value = CaddieHub.setup.value.copy(confirmed = false); emptyList() }
        is Command.SelectCourse -> {
            when {
                c.course.key != CaddieHub.setup.value.course?.key -> selectCourse(c.course)
                CaddieHub.course.value !is CourseStatus.Ready && CaddieHub.course.value !is CourseStatus.Loading -> loadSelected()   // tapping it again retries
            }
            emptyList()
        }
        is Command.SetFormat -> {
            val s = CaddieHub.setup.value.copy(format = c.format)
            CaddieHub.setup.value = s
            store.saveSetup(s.course, s.format, s.confirmed)
            engine.setFormat(c.format)
        }
        is Command.SetPar -> {
            val lines = engine.setPar(c.hole, c.par)
            loadedKey?.let { store.savePars(it, engine.parEditList()) }
            lines
        }
        is CartCommand -> emptyList()      // handled in cartCommand()
        is Command.SetBag -> { baseBag = Learning.strip(c.bag); store.saveBag(baseBag); refreshBag(); emptyList() }
        is Command.SetSwing -> {
            store.saveSwing(c.swing); CaddieHub.swing.value = c.swing
            baseBag = DistanceModel.reestimate(baseBag, c.swing)
            store.saveBag(baseBag); refreshBag()
            emptyList()
        }
        is Command.SetShotClub -> { engine.setShotClub(c.id, c.clubKey); emptyList() }
        is Command.DeleteShot -> { engine.deleteShot(c.id); emptyList() }
        is Command.SetLearning -> { useLearning = c.on; store.saveLearn(c.on); CaddieHub.useLearning.value = c.on; refreshBag(); emptyList() }
        is Command.StartBench -> { startBench(c.scenario); emptyList() }
        Command.StopBench -> { stopBench("stopped"); emptyList() }
        is Command.DisplayPair -> {
            if (!CartAuth.validPin(c.pin)) CaddieHub.displayAuth.value = CartAuthStatus(CartAuthState.PAIRING_OPEN, "The PIN is 6 digits.")
            else outbox.trySend(CartProtocol.pair(c.pin))
            emptyList()
        }
        Command.DisplayForget -> {
            displayKey = null; store.clearDisplayKey(); answeredDisplayNonce = null
            CaddieHub.displayAuth.value = CartAuthStatus()
            log("display pairing: this phone's key was forgotten")
            outbox.trySend(CartProtocol.hello())
            emptyList()
        }
        Command.ClearLog -> { synchronized(logLock) { CaddieHub.decisionLog.value = emptyList() }; emptyList() }
        is Command.SetGuard -> {
            guard.cfg = guard.cfg.copy(enabled = c.enabled, baseMarginM = c.greenM.coerceIn(6.0, 20.0), waterMarginM = c.waterM.coerceIn(6.0, 20.0), bunkerMarginM = c.bunkerM.coerceIn(3.0, 15.0))
            store.saveGuard(guard.cfg)
            CaddieHub.guard.value = CaddieHub.guard.value.copy(cfg = guard.cfg)
            if (!c.enabled) guard.reset()
            emptyList()
        }
    }

    /** A different course means a different round: scores start again and the format goes back to 18 holes. */
    private fun selectCourse(c: CourseChoice) {
        store.clearRound()
        loadedKey = null
        CaddieHub.setup.value = RoundSetup(c, RoundFormat.ALL_18, confirmed = false)
        store.saveSetup(c, RoundFormat.ALL_18, false)
        loadSelected()
    }

    private fun loadSelected() {
        val c = CaddieHub.setup.value.course ?: return
        CaddieHub.course.value = CourseStatus.Loading
        scope.launch {
            try { val course = repo.load(c); CaddieHub.cachedCourses.value = CaddieHub.cachedCourses.value + c.key; inbox.send(In.CourseLoaded(course, c.key)) }
            catch (e: CourseRepository.NotMappedException) {
                // not mapped hole by hole: play it anyway and learn it (scores, shot distances, pace now; yardages from the second round)
                val learned = LearnedCourses.decode(store.loadLearned(c.key))
                inbox.send(In.CourseLoaded(LearnedCourses.build(c.name, c.center, learned), c.key))
            }
            catch (e: Exception) { inbox.send(In.CourseFailed(e.message ?: "Could not load the course", c.key)) }
        }
    }

    private fun requestNearby() {
        val f = lastFix
        if (f == null) { CaddieHub.nearby.value = NearbyStatus.Error("Waiting for a GPS fix…"); return }
        nearbyRequested = true
        CaddieHub.nearby.value = NearbyStatus.Loading
        scope.launch {
            // the saved list for this area first (instant), then the fresh search on top of it
            val cached = repo.nearbyCached(f.latLon)
            if (cached != null) inbox.send(In.NearbyLoaded(cached))
            try { inbox.send(In.NearbyLoaded(repo.nearby(f.latLon))) }
            catch (e: Exception) { if (cached == null) inbox.send(In.NearbyFailed(e.message ?: "Could not search for courses")) }
        }
    }

    /** Quietly download the hole maps of the nearest courses so choosing one later is instant (and works offline). */
    private fun startPrefetch(courses: List<CourseChoice>) {
        val keys = courses.take(5).map { it.key }
        if (keys == prefetchKeys && prefetchJob?.isActive == true) return      // same list again: let the running download finish
        prefetchKeys = keys
        prefetchJob?.cancel()
        CaddieHub.cachedCourses.value = courses.filter { repo.isCached(it) }.map { it.key }.toSet()
        prefetchJob = scope.launch {
            repo.prefetch(courses.sortedBy { it.distanceM }) { key -> CaddieHub.cachedCourses.value = CaddieHub.cachedCourses.value + key }
        }
    }

    // ------------------------------------------------------------------ learned distances
    /** Rebuild the working bag from the saved one + the shot history, and publish it. */
    private fun refreshBag() {
        val b = Learning.apply(baseBag, engine.shots, useLearning)
        engine.bag = b
        CaddieHub.bag.value = b
        CaddieHub.shots.value = engine.shots.toList()
    }

    /** Save the shot log and refresh the learned distances whenever a shot was added, corrected or deleted. */
    private fun syncShots() {
        if (engine.shotsVersion == shotsSaved) return
        shotsSaved = engine.shotsVersion
        store.saveShots(engine.shots)
        refreshBag()
    }

    /** Publish the finished holes for the Caddie Report, keep them across an app restart, and file a completed round in the history once. */
    private fun syncStats() {
        if (engine.statsVersion == statsSaved) return
        statsSaved = engine.statsVersion
        val l = engine.holeStats()
        CaddieHub.holeStats.value = l
        loadedKey?.let { store.saveHoleStats(it, l) }
        if (l.isEmpty()) { roundSaved = false; CaddieHub.roundSaved.value = false }
        else if (engine.state.roundComplete && !roundSaved) saveRoundSummary()
    }

    private fun saveRoundSummary() {
        if (roundSaved) return
        val stats = RoundStats(engine.holeStats())
        if (stats.played == 0) return
        val summary = RoundSummary.from(stats, CaddieHub.setup.value.course?.name ?: "Round", System.currentTimeMillis())
        val all = (CaddieHub.history.value + summary).takeLast(200)
        store.saveHistory(all)
        CaddieHub.history.value = all
        roundSaved = true; CaddieHub.roundSaved.value = true
    }

    // ------------------------------------------------------------------ green guard
    private fun guardStep(fix: Fix) {
        val m = greenMap ?: return guardApply(null, null, fix.accuracyM.toDouble(), null)
        guardLocal(m.toLocal(fix.latLon), fix.accuracyM.toDouble(), fix.timeMs)
    }

    /** One position (already in the map's frame) for the guard. Used for real GPS fixes and by the bench test. */
    private fun guardLocal(pos: XY, accuracyM: Double, nowMs: Long) {
        val m = greenMap
        val overridden = CaddieHub.cart.value.flags and CartFlag.OVERRIDE != 0
        val out = if (m == null) null else guard.step(pos, accuracyM, CaddieHub.cartConfig.value.followM, overridden, nowMs)
        guardApply(out, m, accuracyM, null)
        navFeed(pos, accuracyM, nowMs)
        navMaybeStart(out)
    }

    /** No fix for a while: the guard treats it as lost GPS. Does nothing while fixes are arriving. */
    private fun guardWatchdog(nowMs: Long) {
        val m = greenMap ?: return
        val overridden = CaddieHub.cart.value.flags and CartFlag.OVERRIDE != 0
        val out = guard.staleOut(nowMs, CaddieHub.cartConfig.value.followM, overridden) ?: return
        guardApply(out, m, null, (guard.cfg.staleFixMs / 1000L).toInt())
    }

    /** The cart can be told things: the built-in demo, or a real cart that has accepted this phone. */
    private fun cartLive() = CaddieHub.cartDemo.value || cartAuthedLive()
    private fun cartAuthedLive() = cartBle.state.value is BleLink.LinkState.Connected && CaddieHub.cartAuth.value.state == CartAuthState.AUTHED

    private fun yd(m: Double) = Math.round(CartUnits.metresToYards(m)).toInt()

    /** @param staleS set when this decision comes from the watchdog (no fix for at least this many seconds) */
    private fun guardApply(out: GuardOut?, m: GreenMap?, accuracyM: Double?, staleS: Int?) {
        val st = when {
            !guard.cfg.enabled -> GuardState.OFF
            out == null -> GuardState.NO_DATA
            else -> out.state
        }
        CaddieHub.guard.value = GuardStatus(guard.cfg, st, out?.cartToHazardM, m?.isEmpty == false, out?.hazard, out?.lostGps == true, out?.pathBlocked == true)
        if (st != lastGuardState) {
            val gps = accuracyM?.let { ", GPS +/-${yd(it)} yd" } ?: ""
            when {
                st == GuardState.HOLDING && out != null && out.lostGps && staleS != null -> log("HOLD: no GPS fix for ${staleS}+ s, so the position can't be trusted")
                st == GuardState.HOLDING && out != null && out.lostGps -> log("HOLD: GPS lost$gps")
                st == GuardState.HOLDING && out != null -> log("HOLD: ${out.hazard?.label ?: "hazard"} ahead. Cart is about ${yd(out.cartToHazardM ?: 0.0)} yd from it, limit ${yd(out.marginM)} yd$gps")
                st == GuardState.FREE && lastGuardState == GuardState.HOLDING -> log("RELEASE: you are clear of the hazard$gps")
                st == GuardState.FREE && lastGuardState == GuardState.OVERRIDDEN -> log("Guard armed again (cart is well clear)")
                st == GuardState.OVERRIDDEN -> log("OVERRIDDEN: the switch on the cart was used, hold dropped")
                st == GuardState.OFF -> log("Guard is switched off")
                st == GuardState.NO_DATA -> log("Guard has no hazard data for this course")
            }
            lastGuardState = st
        }
        // clear of the hazard but the cart's straight way to you leads across it: say so once, so the wait doesn't look like a fault
        val blockedNow = out?.pathBlocked == true
        if (blockedNow && !lastBlocked) {
            log("HOLD continues: you are clear of the ${out?.hazard?.label ?: "hazard"}, but the cart's straight path to you would cross it. Walk back around, or use the switch.")
            if (CaddieHub.cartMode.value == CartMode.FOLLOW) outbox.trySend(Protocol.tip(CaddieVoice.pathBlocked()))
        }
        lastBlocked = blockedNow
        // one short line on the display the moment the cart stops (not repeated while it stays held)
        val holdingNow = out?.hold == true && CaddieHub.cartMode.value == CartMode.FOLLOW
        if (holdingNow && !guardTipShown) outbox.trySend(Protocol.tip(CaddieVoice.cartHolding(out?.hazard?.label, out?.lostGps == true)))
        guardTipShown = holdingNow

        // Tell the cart. Only while it is following (Park and Manual don't need it). Repeat every 2 s while holding so a missed message heals.
        val live = cartLive()
        val want = (failSafe || out?.hold == true) && (CaddieHub.cartMode.value == CartMode.FOLLOW || CaddieHub.cartMode.value == CartMode.NAV)
        val now = SystemClock.elapsedRealtime()
        if (!live) { holdSent = null; return }
        if (want != holdSent || (want && now - holdSentMs >= 2_000)) {
            if (want != holdSent) log("-> cart: hold ${if (want) "ON" else "OFF"}${if (CaddieHub.cartDemo.value) " (demo cart)" else ""}")
            if (CaddieHub.cartDemo.value) sim.hold = want else cartOut.trySend(CartProtocol.hold(want))
            holdSent = want; holdSentMs = now
        }
    }

    // ------------------------------------------------------------------ decision log
    private fun log(text: String) {
        if (text.startsWith("HOLD") || text.startsWith("RELEASE") || text.startsWith("cart FAULT") || text.startsWith("cart: left behind") || text.startsWith("battery:") || text.startsWith("storm:") || text.startsWith("pace:") || text.startsWith("go-around: stopped") || text.startsWith("go-around: ") && text.contains("back to following")) { watchAlert = text.take(48); watchAlertMs = SystemClock.elapsedRealtime() }
        synchronized(logLock) { CaddieHub.decisionLog.value = (CaddieHub.decisionLog.value + LogLine(System.currentTimeMillis(), text)).takeLast(300) }
    }

    /** Writes cart status changes (switch pressed, fob lost, obstacle, faults...) into the log. */
    private fun noteCartState(flags: Int, faults: Int) {
        val mask = CartFlag.FOB_LOST or CartFlag.OBSTACLE or CartFlag.TOO_FAR or CartFlag.AUTO_HOLD or CartFlag.PAUSED or CartFlag.OVERRIDE
        val changed = (flags xor lastCartFlags) and mask
        if (changed != 0) {
            for (bit in listOf(CartFlag.AUTO_HOLD, CartFlag.OVERRIDE, CartFlag.PAUSED, CartFlag.FOB_LOST, CartFlag.OBSTACLE, CartFlag.TOO_FAR)) {
                if (changed and bit == 0) continue
                val name = CartFlag.names(bit).firstOrNull() ?: continue
                log(if (flags and bit != 0) "cart: $name" else "cart: no longer \"$name\"")
            }
        }
        lastCartFlags = flags
        if (faults != lastCartFaults) {
            val now = CartFault.names(faults)
            log(if (now.isEmpty()) "cart: faults cleared" else "cart FAULT: " + now.joinToString(", "))
            lastCartFaults = faults
        }
    }

    // ------------------------------------------------------------------ bench test
    private fun benchMessage(text: String) { CaddieHub.bench.value = BenchStatus(message = text); log("bench: $text") }

    private fun startBench(sc: BenchScenario) {
        stopBench(null)
        if (!guard.cfg.enabled) return benchMessage("The hazard guard is switched off. Turn it on first.")
        val m = greenMap
        if (m == null || m.isEmpty) return benchMessage("This course map has no greens, water or bunkers to test against. Pick a course first.")
        val hole = engine.course?.hole(engine.state.holeNumber)
        val from = if (hole != null) { val sh = Geo.toLocal(m.origin, hole.origin); XY(hole.tee.x + sh.x, hole.tee.y + sh.y) } else XY(0.0, 0.0)
        val followM = CaddieHub.cartConfig.value.followM
        val plan = BenchScenarios.build(sc, m, from, guard.cfg, followM) ?: return benchMessage("Could not find a clear straight walk to a hazard from this hole's tee. Try another hole.")
        benchRunner = BenchRunner(plan, withCart = true)
        benchActive = true
        guard.reset(); lastGuardState = null; lastBlocked = false; guardTipShown = false; holdSent = null
        CaddieHub.guard.value = CaddieHub.guard.value.copy(state = GuardState.FREE, cartToHazardM = null, hazard = null, lostGps = false, pathBlocked = false)
        val live = cartLive()
        log("bench: started \"${sc.label}\" (${plan.seconds} s, aiming at ${plan.targetKind.label}, follow ${yd(followM)} yd). Real GPS is ignored until it ends.")
        if (!live) log("bench: no cart connected, so only the phone side is checked")
        else if (CaddieHub.cartMode.value != CartMode.FOLLOW) log("bench: the cart is not in Follow, so holds are decided but not sent. Switch it to Follow to test the cart.")
        CaddieHub.bench.value = BenchStatus(running = true, scenario = sc, second = 0, total = plan.seconds, note = "starting")
        benchJob = scope.launch { repeat(plan.seconds + 1) { inbox.send(In.Bench); delay(1_000) } }
    }

    private fun benchTick() {
        val r = benchRunner ?: return
        val s = r.current
        if (s == null) { finishBench(); return }
        val m = greenMap ?: return
        val now = SystemClock.elapsedRealtime()
        if (s.accuracyM != null) guardLocal(s.pos, s.accuracyM, now) else guardWatchdog(now)
        val hold = CaddieHub.guard.value.state == GuardState.HOLDING
        val cartHold = if (CaddieHub.cartFresh.value && CaddieHub.cartMode.value == CartMode.FOLLOW) CaddieHub.cart.value.flags and CartFlag.AUTO_HOLD != 0 else null
        r.record(hold, cartHold)
        val dist = m.distanceM(s.pos)
        CaddieHub.bench.value = BenchStatus(true, r.plan.scenario, r.tick, r.plan.seconds, s.note, dist, s.accuracyM)
        if (r.tick % 10 == 0) log("sim ${r.tick} s: ${s.note}, ${dist?.let { "${yd(it)} yd from the nearest hazard" } ?: "no hazard"}, GPS ${s.accuracyM?.let { "+/-${yd(it)} yd" } ?: "none"}")
        if (r.done) finishBench()
    }

    private fun finishBench() {
        val r = benchRunner ?: return
        val sum = r.summary()
        for (c in sum.checks) log("bench ${if (c.passed) "PASS" else "FAIL"}: ${c.name}${if (c.passed) "" else " - " + c.detail}")
        log(if (sum.allPassed) "bench: ALL ${sum.checks.size} CHECKS PASSED" else "bench: ${sum.failures} OF ${sum.checks.size} CHECKS FAILED")
        CaddieHub.bench.value = BenchStatus(running = false, scenario = r.plan.scenario, second = r.plan.seconds, total = r.plan.seconds, summary = sum)
        endBench()
    }

    private fun stopBench(why: String?) {
        if (benchRunner == null && !benchActive) return
        val sc = benchRunner?.plan?.scenario
        if (why != null) { log("bench: $why"); CaddieHub.bench.value = BenchStatus(scenario = sc, message = "Test $why.") }
        endBench()
    }

    /** Back to real GPS, and make sure the cart is not left holding for a hazard that was only simulated. */
    private fun endBench() {
        benchJob?.cancel(); benchJob = null
        benchRunner = null
        benchActive = false
        guard.reset(); lastGuardState = null; lastBlocked = false; guardTipShown = false
        CaddieHub.guard.value = CaddieHub.guard.value.copy(state = GuardState.FREE, cartToHazardM = null, hazard = null, lostGps = false, pathBlocked = false)
        val live = cartLive()
        if (live && holdSent == true) {
            if (CaddieHub.cartDemo.value) sim.hold = false else cartOut.trySend(CartProtocol.hold(false))
            log("-> cart: hold OFF (bench test over)")
        }
        holdSent = null
    }



    // ------------------------------------------------------------------ plays-like yardage, battery forecast, find my cart
    @Volatile private var conditions: Conditions? = null
    private val heights = HashMap<String, Pair<Double?, Double?>>()      // "course:hole" -> tee, pin height (m above sea level)
    private val heightsAsked = HashSet<String>()
    private val battery = BatteryForecast()
    private val batteryLock = Any()
    private var batteryWarned = false
    private val locator = CartLocator()
    private var locOrigin: com.handlecaddie.controller.core.LatLon? = null

    private fun fmt(v: Double) = String.format(java.util.Locale.US, "%.5f", v)

    /** Weather for where you are, every 10 minutes (a minute later if it failed). Quietly does nothing offline. */
    private fun startConditions() {
        scope.launch(Dispatchers.IO) {
            while (true) {
                val f = lastFix
                var wait = 60_000L
                if (f != null) {
                    val json = ConditionsClient.get(String.format(java.util.Locale.US, ConditionsParse.WEATHER_URL, fmt(f.lat), fmt(f.lon)))
                    val c = json?.let { ConditionsParse.weather(it, System.currentTimeMillis()) }
                    if (c != null) { conditions = c; wait = 600_000L; inbox.trySend(In.PlaysLikeRefresh) }
                    json?.let { ConditionsParse.storm(it, System.currentTimeMillis()) }?.let { sf -> synchronized(stormLock) { lightning.forecast(sf) } }
                    if (CaddieHub.storm.value.level != StormLevel.CLEAR && wait > 180_000L) wait = 180_000L
                }
                delay(wait)
            }
        }
    }

    /** Height of the tee and the pin of this hole, asked once per hole (US Geological Survey, US courses only). */
    private fun ensureHeights(key: String, hole: com.handlecaddie.controller.core.Hole) {
        if (synchronized(heights) { key in heights } || !synchronized(heightsAsked) { heightsAsked.add(key) }) return
        scope.launch(Dispatchers.IO) {
            fun h(p: XY): Double? {
                val ll = Geo.toLatLon(hole.origin, p)
                return ConditionsClient.get(String.format(java.util.Locale.US, ConditionsParse.ELEVATION_URL, fmt(ll.lon), fmt(ll.lat)))?.let { ConditionsParse.elevationM(it) }
            }
            val tee = h(hole.tee); val pin = h(hole.pin)
            if (tee != null && pin != null) { synchronized(heights) { heights[key] = Pair(tee, pin) }; inbox.trySend(In.PlaysLikeRefresh) }
            else synchronized(heightsAsked) { heightsAsked.remove(key) }           // try again next time
        }
    }

    private fun updatePlaysLike() {
        val g = CaddieHub.game.value
        val toPin = g.toPinYd; val player = g.player
        val course = engine.course
        val hole = course?.hole(g.holeNumber)
        if (toPin == null || player == null || hole == null || g.zone == com.handlecaddie.controller.core.Zone.GREEN) { CaddieHub.playsLike.value = PlaysLikeStatus(); return }
        val key = "${loadedKey ?: ""}:${hole.number}"
        ensureHeights(key, hole)
        val hh = synchronized(heights) { heights[key] }
        val delta = HoleProfile.elevDelta(hole.tee, hole.pin, player, hh?.first, hh?.second)
        // clubs whose distance was only estimated from loft assume sea level; ones typed in or learned on a course already include local air
        val includeAlt = g.club?.estimated == true
        val bearing = Geo.compassDeg(player, hole.pin)
        val c = conditions
        val pl = PlaysLikeCalc.compute(toPin, bearing, c, delta, hh?.first, includeAlt)
        val club = if (pl.changed) Clubs.recommend(engine.bag, pl.playsYd) else null
        CaddieHub.playsLike.value = PlaysLikeStatus(pl, club, c?.tempC, c?.windMs?.let { it * PlaysLikeCalc.MPS_TO_MPH }, c?.windFromDeg)
    }

    private fun batteryTick() {
        if (!CaddieHub.cartFresh.value) { CaddieHub.battery.value = BatteryStatus(); return }
        val g = CaddieHub.game.value
        val t = CaddieHub.cart.value
        val done = (g.holeNumber - g.firstHole).coerceAtLeast(0)
        val left = (g.lastHole - g.holeNumber + 1).coerceAtLeast(0)
        val perHole = if (done >= 2 && t.tripM in 100.0..20_000.0) t.tripM / done else null
        val f = synchronized(batteryLock) { battery.forecast(t.socPct, left, perHole) }
        CaddieHub.battery.value = BatteryStatus(f.text, f.warn)
        if (f.warn && !batteryWarned) {
            batteryWarned = true
            log("battery: ${f.text}")
            outbox.trySend(Protocol.tip("Cart battery may not last the round."))
        }
        if (!f.warn) batteryWarned = false
    }

    private fun locUpdate(fix: Fix) {
        val o = locOrigin ?: fix.latLon.also { locOrigin = it }
        val linkUp = CaddieHub.cartDemo.value || cartBle.state.value is BleLink.LinkState.Connected
        val r = locator.update(linkUp, Geo.toLocal(o, fix.latLon), fix.timeMs)
        CaddieHub.locator.value = LocatorStatus(r.awayM?.let { yd(it) }, r.bearingDeg, r.alert)
        if (r.newAlert) {
            val d = r.awayM?.let { yd(it) } ?: 0
            val hole = CaddieHub.game.value.holeNumber
            log("cart: left behind - you are $d yd from where it was last connected (hole $hole)")
            outbox.trySend(Protocol.tip(if (r.alert == CartLocator.Alert.FAR_BEHIND) "Your cart is $d yd back. Left it behind?" else "Cart not connected, $d yd back."))
        }
    }


    // ------------------------------------------------------------------ who may use the display
    /** A challenge that went out before we were listening is simply asked for again, a few times. An older display never answers; that is fine. */
    private fun displayHelloTick(now: Long) {
        if (displayHellos == 0 || displayHellos >= 4) return
        if (CaddieHub.displayAuth.value.state != CartAuthState.UNKNOWN || CaddieHub.link.value !is BleLink.LinkState.Connected) { displayHellos = 0; return }
        if (now - displayHelloAt >= 2_500L) { displayHelloAt = now; displayHellos++; outbox.trySend(CartProtocol.hello()) }
    }

    /** What the display said about who may use it: answer its challenge, keep a new key, tell the screen. Runs on the inbox thread. */
    private fun displayAuthStep(m: CartMsg) {
        if (m is CartMsg.Chal && m.nonce == answeredDisplayNonce) return
        val before = CaddieHub.displayAuth.value
        val step = CartAuthFlow.onMessage(m, displayKey, before, AuthWords.DISPLAY)
        step.send?.let { if (m is CartMsg.Chal) answeredDisplayNonce = m.nonce; outbox.trySend(it) }
        step.saveKey?.let { displayKey = it; store.saveDisplayKey(it); log("display pairing: new key saved") }
        if (step.status != before) {
            CaddieHub.displayAuth.value = step.status
            when (step.status.state) {
                CartAuthState.AUTHED -> { log("display pairing: this phone is accepted"); inbox.trySend(In.DisplayReady) }
                CartAuthState.CHECKING, CartAuthState.UNKNOWN -> {}
                else -> log("display pairing: ${step.status.state.name.lowercase().replace('_', ' ')} - ${step.status.message}")
            }
        }
    }

    // ------------------------------------------------------------------ pace of play
    private fun paceHoles(): List<Pair<Int, Int>> {
        val g = engine.state
        return (g.firstHole..g.lastHole).map { it to g.pars[it - 1] }
    }

    /** The first club out of the bag starts the clock. */
    private fun paceMaybeStart() {
        synchronized(paceLock) {
            if (pace.started) return
            pace.start(engine.state.holeNumber, System.currentTimeMillis())
            loadedKey?.let { store.savePace(it, pace.encode()) }
        }
        log("pace: clock started, target ${pace.targetMin / 60}h ${pace.targetMin % 60}m for 18 holes")
    }

    private fun paceHoleChanged(hole: Int) {
        val now = System.currentTimeMillis()
        val tip: String?
        synchronized(paceLock) {
            if (!pace.started) return
            pace.setHoles(paceHoles())
            pace.onHole(hole, now)
            loadedKey?.let { store.savePace(it, pace.encode()) }
            val st = pace.status(now, hole)
            tip = if (pace.shouldTip(st, hole)) CaddieVoice.pace(st.level, st.behindMin, engine.state.par) else null
        }
        if (tip != null) { log("pace: $tip"); outbox.trySend(Protocol.tip(tip)) }
    }

    private fun paceTick() {
        val now = System.currentTimeMillis()
        val st = synchronized(paceLock) { pace.setHoles(paceHoles()); pace.status(now, engine.state.holeNumber).copy(paused = pace.paused) }
        if (CaddieHub.pace.value != st) CaddieHub.pace.value = st
    }

    // ------------------------------------------------------------------ lightning
    private fun stormTick() {
        val now = System.currentTimeMillis()
        val st = synchronized(stormLock) { lightning.status(now) }
        if (CaddieHub.storm.value != st) CaddieHub.storm.value = st
        if (st.level != lastStormLevel) {
            val was = lastStormLevel
            lastStormLevel = st.level
            val line = CaddieVoice.storm(st.level, st.minutes)
            log("storm: $line")
            if (st.level != StormLevel.CLEAR || was == StormLevel.TAKE_COVER) outbox.trySend(Protocol.tip(line))
        }
    }

    // ------------------------------------------------------------------ learning an unmapped course
    private fun learn(o: LearnObs) {
        val key = loadedKey ?: return
        learnedHoles = LearnedCourses.merge(learnedHoles, o)
        store.saveLearned(key, LearnedCourses.encode(learnedHoles))
        val s = CaddieHub.course.value
        if (s is CourseStatus.Ready && s.learning) CaddieHub.course.value = s.copy(knownHoles = LearnedCourses.knownCount(learnedHoles))
    }

    // ------------------------------------------------------------------ round recap
    private fun makeRecap() {
        val now = System.currentTimeMillis()
        val holes = engine.holeStats()
        val stats = RoundStats(holes)
        val course = CaddieHub.setup.value.course?.name
        val report = CaddieReport.build(stats, course, CaddieHub.history.value, engine.state.roundComplete)
        val q = synchronized(paceLock) {
            if (pace.started) Quad(pace.holeMinutes(now), pace.totalMinutes(now), pace.targetMin, pace.startMs - 3_600_000L)
            else Quad(emptyMap(), 0, null, now - 12 * 3_600_000L)
        }
        val since = q.d
        val roundShots = engine.shots.filter { it.timeMs > 0 && it.timeMs >= since }
        val w = conditions?.let { c ->
            listOfNotNull(c.tempC?.let { "${Math.round(it * 9 / 5 + 32)} F" }, c.windMs?.let { "wind ${Math.round(it * PlaysLikeCalc.MPS_TO_MPH)} mph" }).takeIf { it.isNotEmpty() }?.joinToString(", ")
        }
        val date = java.text.SimpleDateFormat("EEE MMM d, yyyy", java.util.Locale.US).format(java.util.Date(now))
        CaddieHub.recap.value = RoundRecap.build(course, date, holes, report, q.a, q.b, q.c, roundShots, engine.bag, w)
    }

    private data class Quad(val a: Map<Int, Int>, val b: Int, val c: Int?, val d: Long)

    // ------------------------------------------------------------------ Wear OS watch
    private lateinit var watch: WatchBridge
    private val advance = AdvanceOffer()
    @Volatile private var lastWatchGpsMs = 0L
    @Volatile private var watchAlert: String? = null
    @Volatile private var watchAlertMs = 0L
    private var lastWatchJson: String? = null
    private var lastWatchSentMs = 0L
    private var lastNodeCheckMs = 0L

    // watch hold-to-drive and creep: short pulses only (see ManualDrive)
    private val timedDrive = TimedDrive()
    private fun watchDrive(code: String) {
        val v = ManualDrive.decodeWatch(code) ?: return
        val now = SystemClock.elapsedRealtime()
        if (!CaddieHub.watchDriveEnabled.value || CaddieHub.cartMode.value != CartMode.MANUAL || !(CaddieHub.cartDemo.value || cartAuthedLive())) { timedDrive.clear(); return }
        timedDrive.pulse(now, v.first, v.second, ManualDrive.WATCH_PULSE_MS)
    }

    private fun watchCommand(cmd: WatchCmd) {
        when (cmd) {
            WatchCmd.NEXT -> inbox.trySend(In.Cmd(Command.NextHole))
            WatchCmd.BACK -> inbox.trySend(In.Cmd(Command.PrevHole))
            WatchCmd.FOLLOW -> scope.launch { cartCommand(CartCommand.SetMode(CartMode.FOLLOW)) }
            WatchCmd.PARK -> scope.launch { cartCommand(CartCommand.SetMode(CartMode.PARK)) }
            WatchCmd.STOP -> scope.launch { timedDrive.clear(); cartCommand(CartCommand.Do("stop")) }          // never through a buffer that could drop it
            WatchCmd.MANUAL -> if (CaddieHub.watchDriveEnabled.value) scope.launch { cartCommand(CartCommand.SetMode(CartMode.MANUAL)) }
            WatchCmd.ADVANCE_YES -> inbox.trySend(In.WatchGo)
            WatchCmd.ADVANCE_NO -> advance.dismiss()
        }
    }

    /** Once a second: keep the watch's screen current, and note how fresh its GPS is. */
    private fun watchTick(now: Long) {
        CaddieHub.watchGpsAgeS.value = if (lastWatchGpsMs == 0L) null else ((now - lastWatchGpsMs) / 1000L).toInt()
        if (now - lastNodeCheckMs > 10_000L) { lastNodeCheckMs = now; watch.refreshNodes() }
        if (!CaddieHub.watchConnected.value) return
        val g = CaddieHub.game.value
        val pl = CaddieHub.playsLike.value
        val live = cartLive()
        val gs = CaddieHub.guard.value
        val hold = if (gs.state == GuardState.HOLDING) (if (gs.lostGps) "GPS lost" else if (gs.pathBlocked) "Path blocked" else gs.hazard?.let { "${it.label} ahead" } ?: "Holding") else null
        val st = WatchState(
            hole = g.holeNumber, par = g.par, toPinYd = g.toPinYd, playsYd = pl.pl?.takeIf { it.changed }?.playsYd,
            club = (pl.club ?: g.club)?.name,
            cartMode = if (live) CaddieHub.cartMode.value.wire else null,
            socPct = if (live && CaddieHub.cartFresh.value) CaddieHub.cart.value.socPct else null,
            holdText = hold, alert = watchAlert?.takeIf { now - watchAlertMs < 8_000L },
            advanceTo = advance.current(g.holeNumber, now), posFromWatch = CaddieHub.positionFromWatch.value,
            drive = live && CaddieHub.watchDriveEnabled.value,
        )
        val json = WatchProtocol.encodeState(st)
        if (json != lastWatchJson || now - lastWatchSentMs >= 5_000L) { lastWatchJson = json; lastWatchSentMs = now; watch.send(json) }
    }


    /** The phone is riding on the cart, so this fix is the CART's position. */
    private fun cartGpsIn(fix: Fix) {
        val m = greenMap
        val xy = if (m != null) m.toLocal(fix.latLon) else { val o = locOrigin ?: fix.latLon.also { locOrigin = it }; Geo.toLocal(o, fix.latLon) }
        lastCartXY = xy; lastCartAcc = fix.accuracyM.toDouble(); lastCartGpsMs = fix.timeMs
        guard.cartFix(xy, fix.accuracyM.toDouble(), fix.timeMs)
        val t = fix.timeMs / 1000.0
        cartHeadingEst.addPlayer(t, xy)
        val tel = CaddieHub.cart.value
        tel.yawDeg?.let { cartHeadingEst.addCart(t, it, tel.speedMs) }
    }

    /**
     * GPS follow: the phone is on the cart, the fob is out of reach, you are well ahead by GPS: send the cart after you, stopping short.
     * Off by default; works only with a wheel speed sensor (the same route driving as the hazard go-around).
     */
    private fun gpsFollowCheck(now: Long) {
        CaddieHub.cartGpsAgeS.value = if (lastCartGpsMs == 0L) null else ((now - lastCartGpsMs) / 1000L).toInt()
        val tel = CaddieHub.cart.value
        if (tel.rangeM != null) fobLostSinceMs = 0L else if (fobLostSinceMs == 0L) fobLostSinceMs = now
        if (!CaddieHub.gpsFollowEnabled.value || !CaddieHub.positionFromWatch.value || benchActive || CaddieHub.cartDemo.value) return
        if (navSession?.active == true || now - navEndedMs < 15_000L) return
        if (!cartLive() || !CaddieHub.cartFresh.value || CaddieHub.cartMode.value != CartMode.FOLLOW) return
        if (fobLostSinceMs == 0L || now - fobLostSinceMs < 6_000L) return                  // the fob has to have been gone for a while
        if (tel.faults != 0 || !tel.navReady || tel.speedMs > 0.15) return
        if (CaddieHub.guard.value.state == GuardState.HOLDING) return
        val cart = lastCartXY ?: return; val player = lastPlayer ?: return
        if (now - lastCartGpsMs > 3_000L || now - lastGpsMs > 3_000L) return
        if (lastCartAcc > 10.0 || lastAcc > 10.0) return
        if (Geo.dist(cart, player) < 20.0) return
        val m = greenMap ?: GreenMap(locOrigin ?: return, emptyList())                       // no hazard data: plain straight chase
        val parts = ArrayList<HeadingEstimate>()
        tel.yawDeg?.let { y -> cartHeadingEst.estimate(y, now / 1000.0)?.let { parts += it } }
        val h = Heading.fuse(parts)
        if (h == null) { navEndedMs = now; log("gps-follow: not attempted - cannot tell which way the cart is facing yet"); return }
        val session = NavSession(m, guard.cfg, { a, c -> guard.pathClearFrom(a, c) })
        navSession = session; navKind = 2
        log("gps-follow: fob out of reach, you are ${Geo.dist(cart, player).toInt()} m ahead; the cart follows your watch")
        navApply(session.start(now, cart, h, player, lastAcc, lastCartAcc, 10.0))
        if (session.active) navSet(session.phase, "Following your watch's GPS…") else navEnd(true, session.status)
    }

    // ------------------------------------------------------------------ go round a hazard (phase 2, experimental)
    private val headingEst = HeadingEstimator()
    private var navSession: NavSession? = null
    private var navSim: NavSimCart? = null              // the demo cart's stand-in while it drives a route
    private val navSimLock = Any()
    private var navKind = 0                            // 1 = round a hazard, 2 = GPS follow (chase), 3 = drive to the next tee
    private var lastCartXY: XY? = null
    private var lastCartAcc = 99.0
    @Volatile private var lastCartGpsMs = 0L
    private val cartHeadingEst = HeadingEstimator(lagS = 0.0)       // the cart's own GPS track against its gyro
    private var fobLostSinceMs = 0L
    private var navEndedMs = 0L
    private var navHoldTried = false                    // one attempt per hold
    private var navLastFailMs = 0L
    private var lastPlayer: XY? = null
    private var lastAcc = 99.0
    private var lastGpsMs = 0L

    private fun navSet(phase: NavPhase, text: String) { CaddieHub.nav.value = NavStatus(phase, text) }

    /** Every position fix: keep what the heading estimator and the route checks need. */
    private fun navFeed(pos: XY, accuracyM: Double, nowMs: Long) {
        lastPlayer = pos; lastAcc = accuracyM; lastGpsMs = SystemClock.elapsedRealtime()
        val tS = nowMs / 1000.0
        headingEst.addPlayer(tS, pos)
        val t = CaddieHub.cart.value
        val yaw = t.yawDeg
        if (CaddieHub.cartFresh.value && !CaddieHub.cartDemo.value && yaw != null && CaddieHub.cartMode.value == CartMode.FOLLOW) headingEst.addCart(tS, yaw, t.speedMs)
    }

    /** The guard is holding because the way to you crosses a hazard: offer the cart a way round. */
    private fun navMaybeStart(out: GuardOut?) {
        if (out == null || !out.hold || !out.pathBlocked) { if (out == null || !out.hold) navHoldTried = false; return }
        if (!CaddieHub.navEnabled.value || benchActive || navHoldTried || navSession?.active == true) return
        val demo = CaddieHub.cartDemo.value
        val tel = CaddieHub.cart.value
        val now = SystemClock.elapsedRealtime()
        if (!cartLive() || !CaddieHub.cartFresh.value || CaddieHub.cartMode.value != CartMode.FOLLOW) return
        if (now - navLastFailMs < 60_000L) return
        val why = when {
            out.lostGps -> "GPS lost"
            lastAcc > 12.0 -> "GPS not accurate enough (+/-${lastAcc.toInt()} m)"
            tel.faults != 0 -> "the cart reports a fault"
            !demo && !CaddieHub.cartConfig.value.navSupported -> "this cart's software cannot drive routes"
            !demo && !tel.navReady -> "the cart cannot drive routes yet (needs its wheel speed sensor and a settled turn sensor)"
            tel.speedMs > 0.15 -> "the cart is still moving"
            else -> null
        }
        if (why != null) { navHoldTried = true; log("go-around: not attempted - $why"); return }
        navHoldTried = true
        val m = greenMap ?: return
        val hold = guard.holdPosition() ?: return
        val player = lastPlayer ?: return
        val parts = ArrayList<HeadingEstimate>()
        val onCart = guard.cartMeasured()
        tel.yawDeg?.let { y -> (if (onCart) cartHeadingEst else headingEst).estimate(y, SystemClock.elapsedRealtime() / 1000.0)?.let { parts += it } }
        guard.holdDirection()?.let { parts += Heading.fromTrail(it) }
        val b = tel.bearingDeg; val r = tel.rangeM
        if (b != null && r != null) Heading.fromUwb(hold, player, b, r)?.let { parts += it }
        val h = Heading.fuse(parts)
        if (h == null) { log("go-around: not attempted - cannot tell which way the cart is facing"); return }
        val session = NavSession(m, guard.cfg, { a, c -> guard.pathClearFrom(a, c) })
        navSession = session
        if (demo) synchronized(navSimLock) { navSim = NavSimCart(hold, h.thetaRad + Math.toRadians(4.0), wheelScale = 1.03, gyroBiasRadS = 0.001).also { it.fob = player } }
        log("go-around: you are clear of the hazard but the cart is blocked; trying a way round")
        navKind = 1
        navApply(session.start(now, hold, h, player, lastAcc, if (onCart) lastCartAcc else null))
        if (session.active) navSet(session.phase, "Sending the route…") else navEnd(true, session.status)
    }

    /** Where the tee of [hole] is in the guard's map frame, or null when it is not known (an unmapped hole not yet learned). */
    private fun teeGoal(hole: Int): XY? {
        val course = engine.course ?: return null
        val h = course.holes.firstOrNull { it.number == hole } ?: return null
        if (h.blind) return null
        val origin = course.holes.firstOrNull()?.origin ?: return null
        val shift = Geo.toLocal(origin, h.origin)
        return XY(h.tee.x + shift.x, h.tee.y + shift.y)
    }

    /**
     * Drive the cart to the tee of [hole] and park it there. Every precondition is a reason to NOT start; the cart then simply follows
     * as before. Returns true when a route was sent.
     */
    private fun teeDriveStart(hole: Int, now: Long): Boolean {
        fun no(why: String): Boolean { log("tee-drive: not attempted - $why"); navSet(NavPhase.FAILED, "Tee drive not started: $why"); return false }
        val demo = CaddieHub.cartDemo.value
        val tel = CaddieHub.cart.value
        if (benchActive) return no("the bench test is running")
        if (navSession?.active == true) return no("the cart is already driving a route")
        if (!cartLive() || !CaddieHub.cartFresh.value) return no("the cart is not connected")
        if (CaddieHub.cartMode.value == CartMode.MANUAL) return no("the cart is in manual mode")
        if (tel.faults != 0) return no("the cart reports a fault")
        if (!demo && !CaddieHub.cartConfig.value.navSupported) return no("this cart's software cannot drive routes")
        if (!demo && !tel.navReady) return no("the cart cannot drive routes yet (needs its wheel speed sensor and a settled turn sensor)")
        if (tel.speedMs > 0.15) return no("the cart is still moving")
        val m = greenMap ?: return no("no course map")
        val goal = teeGoal(hole) ?: return no("the tee of hole $hole is not known yet")
        val player = lastPlayer ?: return no("no GPS position")
        if (now - lastGpsMs > 3_000L || lastAcc > 12.0) return no("GPS is not accurate enough (+/-${lastAcc.toInt()} m)")
        // where the cart is: its own GPS if the phone rides on it, else where the guard holds it, else just behind you
        val onCart = lastCartGpsMs != 0L && now - lastCartGpsMs <= 3_000L && lastCartAcc <= 10.0
        val start = (if (onCart) lastCartXY else null) ?: guard.holdPosition() ?: guard.estimateCart(player, CaddieHub.cartConfig.value.followM)
        val dist = Geo.dist(start, goal)
        if (dist < 8.0) return no("the cart is already at the tee")
        if (dist > 230.0) return no("the tee is ${dist.toInt()} m away; the cart's route limit is 250 m")
        if (!onCart && dist > 100.0) return no("the tee is ${dist.toInt()} m away and the cart has no GPS of its own here; counting wheel turns alone drifts too far over more than 100 m")
        val parts = ArrayList<HeadingEstimate>()
        tel.yawDeg?.let { y -> (if (onCart) cartHeadingEst else headingEst).estimate(y, now / 1000.0)?.let { parts += it } }
        guard.holdDirection()?.let { parts += Heading.fromTrail(it) }
        val b = tel.bearingDeg; val r = tel.rangeM
        if (b != null && r != null) Heading.fromUwb(start, player, b, r)?.let { parts += it }
        val h = Heading.fuse(parts) ?: return no("cannot tell which way the cart is facing")
        val session = NavSession(m, guard.cfg, { a, c -> guard.pathClearFrom(a, c) })
        navSession = session; navKind = 3
        if (demo) synchronized(navSimLock) { navSim = NavSimCart(start, h.thetaRad + Math.toRadians(4.0), wheelScale = 1.03, gyroBiasRadS = 0.001).also { it.fob = player } }
        log("tee-drive: hole $hole, ${dist.toInt()} m to the tee; heading ${Math.round(Math.toDegrees(h.thetaRad))} deg (+/-${Math.round(h.sigmaDeg)}, ${h.source})${if (onCart) ", cart GPS helping" else ""}")
        navApply(session.start(now, start, h, player, lastAcc, if (onCart) lastCartAcc else null, 0.0, goal))
        if (session.active) { navSet(session.phase, "Sending the route to the tee…"); return true }
        val why = session.status
        navEnd(true, why); return false
    }

    private fun navSendLine(line: String) {
        val ns = navSim
        if (ns != null) {
            val replies = synchronized(navSimLock) { ns.handle(line) }
            for (r in replies) (CartProtocol.parse(r) as? CartMsg.NavAck)?.let { inbox.trySend(In.NavAck(it.ok)) }
        } else cartSend(line)
    }

    private fun navApply(acts: List<NavAct>) {
        for (a in acts) when (a) {
            is NavAct.Send -> navSendLine(a.line)
            is NavAct.Log -> log(a.text)
            is NavAct.Stop -> {
                navSendLine(CartProtocol.mode(CartMode.PARK))
                if (CaddieHub.cartDemo.value) sim.mode = CartMode.PARK
                CaddieHub.cartMode.value = CartMode.PARK
                navEnd(true, a.reason)
            }
            is NavAct.Parked -> {
                navSendLine(CartProtocol.mode(CartMode.PARK))
                if (CaddieHub.cartDemo.value) sim.mode = CartMode.PARK
                CaddieHub.cartMode.value = CartMode.PARK
                guard.resumeFrom(a.cartWorld, lastAcc)
                navEnd(false, "Parked at the tee. Press Follow when you are ready to go.")
            }
            is NavAct.Handover -> {
                navSendLine(CartProtocol.hold(false)); holdSent = false
                navSendLine(CartProtocol.mode(CartMode.FOLLOW))
                if (CaddieHub.cartDemo.value) { sim.hold = false; sim.mode = CartMode.FOLLOW }
                guard.resumeFrom(a.cartWorld, lastAcc)
                CaddieHub.cartMode.value = CartMode.FOLLOW
                navEnd(false, "Reached you; following again")
            }
        }
        navSession?.let { s -> if (s.active) navSet(s.phase, when (s.phase) { NavPhase.WAIT_ACK -> "Sending the route…"; NavPhase.STARTING -> "Starting…"; else -> if (navKind == 3) "Driving to the next tee" else s.status.ifEmpty { "Driving round the hazard" } }) }
    }

    private fun navEnd(failed: Boolean, text: String) {
        navSession = null; navKind = 0; navEndedMs = SystemClock.elapsedRealtime()
        synchronized(navSimLock) { navSim = null }
        if (failed) navLastFailMs = SystemClock.elapsedRealtime()
        navSet(if (failed) NavPhase.FAILED else NavPhase.DONE, if (failed) "Stopped: $text. The cart waits where it is." else text)
    }

    private fun navCancel(why: String) {
        val s = navSession ?: return
        if (s.active) { log("go-around: ended ($why)"); navApply(s.cancel()) }
    }

    /** Once a second: feed the session the phone's view of things. */
    private fun navTick(nowMs: Long) {
        val s = navSession ?: return
        if (!s.active) return
        // the normal guard says it is time to follow again (you walked back round): end the go-around, leave the cart parked
        val holding = CaddieHub.guard.value.state == GuardState.HOLDING
        if (navKind == 1 && !holding) { navCancel("the hazard guard let go"); return }
        if (navKind == 2 && holding) { navCancel("the hazard guard stepped in"); return }
        // kind 3 (drive to the next tee): you are usually standing on the green, so the guard is HOLDING by design - it must not cancel this
        val player = lastPlayer ?: return navCancel("no position")
        val demo = CaddieHub.cartDemo.value
        val telAge = if (demo) 0L else nowMs - lastTelMs
        val gpsOk = nowMs - lastGpsMs < 3_000L && lastAcc < guard.cfg.unusableAccuracyM
        val cf = lastCartXY.takeIf { lastCartGpsMs != 0L }
        navApply(s.tick(NavInput(nowMs, player, lastAcc, gpsOk, CaddieHub.cart.value, telAge, cf, lastCartAcc, if (cf == null) Long.MAX_VALUE else nowMs - lastCartGpsMs)))
    }

    // ------------------------------------------------------------------ motorised cart
    private fun startCart() {
        // link state -> UI, and say hello (in Park) every time the link comes up
        scope.launch {
            var wasUp = false
            cartBle.state.collect { st ->
                CaddieHub.cartLink.value = st
                val up = st is BleLink.LinkState.Connected
                if (up != wasUp) log(if (up) "cart link: connected" else "cart link: lost")
                if (up != wasUp) { answeredNonce = null; CaddieHub.cartAuth.value = CartAuthStatus() }      // every connection proves itself again
                if (up && !wasUp) { holdSent = null; CaddieHub.cartMode.value = CartMode.PARK; cartOut.trySend(CartProtocol.hello()); cartOut.trySend(CartProtocol.mode(CartMode.PARK)) }
                if (!up && wasUp) { CaddieHub.cartMode.value = CartMode.PARK; CaddieHub.cartFresh.value = false }
                wasUp = up
            }
        }
        // cart -> UI
        scope.launch {
            cartBle.raw.collect { line ->
                if (CaddieHub.cartDemo.value) return@collect
                val m = CartProtocol.parse(line) ?: return@collect
                handleAuthMessage(m)
                if (CaddieHub.cartAuth.value.state != CartAuthState.AUTHED) return@collect       // nothing else counts until the cart has accepted us
                when (m) {
                    is CartMsg.Tel -> {
                        lastTelMs = SystemClock.elapsedRealtime()
                        CaddieHub.cart.value = m.t
                        noteCartState(m.t.flags, m.t.faults)
                        synchronized(batteryLock) { battery.add(m.t.tripM, m.t.socPct) }
                        CaddieHub.cartMode.value = m.t.mode          // the cart is the authority on what mode it is really in
                    }
                    is CartMsg.Cfg -> CaddieHub.cartConfig.value = m.c
                    is CartMsg.NavAck -> inbox.trySend(In.NavAck(m.ok))
                    else -> {}
                }
            }
        }
        // service -> cart (two senders; BleLink serialises the actual writes)
        scope.launch { for (l in cartOut) cartBle.send(l) }
        scope.launch { for (l in cartJoy) cartBle.send(l) }
        // joystick: 10 frames a second while the finger is down AND the cart is in Manual; zeros when it lifts
        scope.launch {
            var wasActive = false; var zeros = 0
            while (true) {
                delay(100)
                val j0 = CaddieHub.joystick.value
                val td = if (CaddieHub.cartMode.value == CartMode.MANUAL) timedDrive.current(SystemClock.elapsedRealtime()) else { timedDrive.clear(); null }
                // a finger on the screen always wins over a watch / creep pulse
                val j = if (j0.active) j0 else if (td != null) Joy(td.first, td.second, true) else j0
                if (j.active && CaddieHub.cartMode.value == CartMode.MANUAL) {
                    cartSendJoy(j.x, j.y); wasActive = true; zeros = 0
                } else if (wasActive) {
                    cartSendJoy(0.0, 0.0)
                    if (++zeros >= 3) wasActive = false
                }
            }
        }
        // demo cart + freshness
        scope.launch {
            while (true) {
                delay(200)
                if (CaddieHub.cartDemo.value) {
                    val ns = navSim
                    if (ns != null) synchronized(navSimLock) { lastPlayer?.let { ns.fob = it }; repeat(4) { ns.step(0.05) }; CaddieHub.cart.value = ns.telemetry(); CaddieHub.cartMode.value = ns.mode }
                    else CaddieHub.cart.value = sim.step(0.2)
                    noteCartState(CaddieHub.cart.value.flags, CaddieHub.cart.value.faults)
                    CaddieHub.cartFresh.value = true
                } else {
                    CaddieHub.cartFresh.value = cartBle.state.value is BleLink.LinkState.Connected && SystemClock.elapsedRealtime() - lastTelMs < 2_500
                }
            }
        }
        if (cartBle.hasSavedAddress()) cartBle.start()      // a cart we have used before: reconnect quietly
    }

    /** What the cart said about who may drive it: answer challenges, keep a new key, tell the screen. */
    private fun handleAuthMessage(m: CartMsg) {
        if (m is CartMsg.Chal) { if (m.nonce == answeredNonce) return }
        val before = CaddieHub.cartAuth.value
        val step = CartAuthFlow.onMessage(m, cartKey, before)
        step.send?.let { if (m is CartMsg.Chal) answeredNonce = m.nonce; cartOut.trySend(it) }
        step.saveKey?.let { cartKey = it; store.saveCartKey(it); log("cart pairing: new key saved") }
        if (step.status != before) {
            CaddieHub.cartAuth.value = step.status
            when (step.status.state) {
                CartAuthState.AUTHED -> { log("cart pairing: this phone is accepted"); holdSent = null; CaddieHub.cartMode.value = CartMode.PARK }
                CartAuthState.CHECKING, CartAuthState.UNKNOWN -> {}
                else -> log("cart pairing: ${step.status.state.name.lowercase().replace('_', ' ')} - ${step.status.message}")
            }
        }
    }

    private fun cartSendJoy(x: Double, y0: Double) {
        val y = ManualDrive.scale(y0, CaddieHub.manualCap.value)
        if (CaddieHub.cartDemo.value) { sim.joyX = x; sim.joyY = y } else cartJoy.trySend(CartProtocol.joy(x, y))
    }

    private fun cartSend(line: String) { if (!CaddieHub.cartDemo.value) cartOut.trySend(line) }

    private fun cartCommand(c: CartCommand) {
        val demo = CaddieHub.cartDemo.value
        val live = demo || cartAuthedLive()
        when (c) {
            CartCommand.Connect -> { if (!demo) cartBle.start() }
            CartCommand.Disconnect -> { cartBle.stop(); CaddieHub.cartMode.value = CartMode.PARK; inbox.trySend(In.LocatorDisarm) }
            is CartCommand.Pair -> {
                if (!CartAuth.validPin(c.pin)) CaddieHub.cartAuth.value = CartAuthStatus(CartAuthState.PAIRING_OPEN, "The PIN is 6 digits.")
                else if (cartBle.state.value is BleLink.LinkState.Connected) cartOut.trySend(CartProtocol.pair(c.pin))
            }
            CartCommand.ForgetKey -> {
                cartKey = null; store.clearCartKey(); answeredNonce = null
                CaddieHub.cartAuth.value = CartAuthStatus()
                log("cart pairing: this phone's key was forgotten"); cartBle.forgetBond()
                if (cartBle.state.value is BleLink.LinkState.Connected) cartOut.trySend(CartProtocol.hello())      // asks the cart for a fresh challenge
            }
            is CartCommand.SetGpsFollow -> { CaddieHub.gpsFollowEnabled.value = c.on; if (!c.on && navKind == 2) inbox.trySend(In.NavCancel); log("gps-follow: ${if (c.on) "switched ON (experimental)" else "switched off"}") }
            is CartCommand.SetManualCap -> CaddieHub.manualCap.value = c.cap.coerceIn(ManualDrive.CAP_MIN, ManualDrive.CAP_MAX)
            is CartCommand.SetWatchDrive -> { CaddieHub.watchDriveEnabled.value = c.on; if (!c.on) timedDrive.clear(); log("watch drive: ${if (c.on) "ALLOWED (hold-to-drive on the watch)" else "off"}") }
            is CartCommand.Creep -> {
                if (CaddieHub.cartMode.value == CartMode.MANUAL && live) timedDrive.pulse(SystemClock.elapsedRealtime(), c.x.coerceIn(-ManualDrive.STEER, ManualDrive.STEER), ManualDrive.creepFraction(CaddieHub.manualCap.value), ManualDrive.CREEP_MS)
            }
            is CartCommand.SetTeeDrive -> { CaddieHub.teeDriveEnabled.value = c.on; if (!c.on && navKind == 3) inbox.trySend(In.NavCancel); log("tee-drive: ${if (c.on) "switched ON (experimental)" else "switched off"}") }
            CartCommand.DriveToTee -> {
                val hole = advance.current(CaddieHub.game.value.holeNumber, SystemClock.elapsedRealtime())
                if (!CaddieHub.teeDriveEnabled.value) log("tee-drive: switch is off")
                else if (hole == null) { log("tee-drive: finish the hole first (hole out), then send the cart"); navSet(NavPhase.FAILED, "Tee drive: finish the hole first.") }
                else if (teeDriveStart(hole, SystemClock.elapsedRealtime())) advance.dismiss()
            }
            is CartCommand.SetWatchPosition -> { CaddieHub.positionFromWatch.value = c.on; log("watch: position from ${if (c.on) "the watch (phone GPS ignored)" else "the phone"}") }
            is CartCommand.SetNav -> { CaddieHub.navEnabled.value = c.on; if (!c.on) inbox.trySend(In.NavCancel); log("go-around: ${if (c.on) "switched ON (experimental)" else "switched off"}") }
            is CartCommand.SetMode -> if (live) {
                timedDrive.clear()
                if (navSession?.active == true || navSim != null) inbox.trySend(In.NavCancel)
                CaddieHub.cartMode.value = c.mode
                if (demo) sim.mode = c.mode else cartSend(CartProtocol.mode(c.mode))
            }
            is CartCommand.SetFollow -> if (live) {
                val v = c.metres.coerceIn(CartConfig.FOLLOW_MIN_M, CartConfig.FOLLOW_MAX_M)
                CaddieHub.cartConfig.value = CaddieHub.cartConfig.value.copy(followM = v); sim.config = CaddieHub.cartConfig.value
                cartSend(CartProtocol.setFollow(v))
            }
            is CartCommand.SetMaxSpeed -> if (live) {
                val v = c.ms.coerceIn(CartConfig.SPEED_MIN_MS, CartConfig.SPEED_MAX_MS)
                CaddieHub.cartConfig.value = CaddieHub.cartConfig.value.copy(maxSpeedMs = v); sim.config = CaddieHub.cartConfig.value
                cartSend(CartProtocol.setMaxSpeed(v))
            }
            is CartCommand.SetDescent -> if (live) {
                val v = c.ms.coerceIn(CartConfig.DESCENT_MIN_MS, CartConfig.DESCENT_MAX_MS)
                CaddieHub.cartConfig.value = CaddieHub.cartConfig.value.copy(descentMs = v); sim.config = CaddieHub.cartConfig.value
                cartSend(CartProtocol.setDescent(v))
            }
            is CartCommand.SetHillHold -> if (live) {
                CaddieHub.cartConfig.value = CaddieHub.cartConfig.value.copy(hillHold = c.on); sim.config = CaddieHub.cartConfig.value
                cartSend(CartProtocol.setHillHold(c.on))
            }
            is CartCommand.Do -> if (live) {
                if (c.name == "stop") {
                    timedDrive.clear()
                    inbox.trySend(In.NavCancel)
                    CaddieHub.cartMode.value = CartMode.PARK
                    if (demo) sim.mode = CartMode.PARK
                }
                if (demo) { if (c.name == "trip0") sim.newTrip() } else cartSend(CartProtocol.cmd(c.name))
            }
            is CartCommand.Demo -> {
                if (c.on && cartBle.state.value is BleLink.LinkState.Connected) return          // never mix a real cart with the simulator
                CaddieHub.cartDemo.value = c.on
                sim.reset(); sim.config = CaddieHub.cartConfig.value
                CaddieHub.cartMode.value = CartMode.PARK
                if (!c.on) { CaddieHub.cart.value = CartTelemetry(); CaddieHub.cartFresh.value = false }
            }
        }
    }

    // ------------------------------------------------------------------ platform plumbing
    private fun startLocation() {
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1_000L).setMinUpdateIntervalMillis(500L).build()
        try { fused.requestLocationUpdates(req, locationCallback, Looper.getMainLooper()) }
        catch (e: SecurityException) { CaddieHub.course.value = CourseStatus.Error("Location permission is needed") }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Round in progress", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CaddieService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(applicationInfo.icon)
            .setContentTitle("Handle Caddie")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "End round", stop).build())
            .build()
    }

    private fun startInForeground(text: String) {
        val n = notification(text)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION or ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else startForeground(NOTIF_ID, n)
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text))
    }

    companion object {
        private const val CART_NAME = "HandleCaddie_Cart"
        const val ACTION_STOP = "com.handlecaddie.controller.STOP"
        private const val CHANNEL = "round"
        private const val NOTIF_ID = 1
    }
}
