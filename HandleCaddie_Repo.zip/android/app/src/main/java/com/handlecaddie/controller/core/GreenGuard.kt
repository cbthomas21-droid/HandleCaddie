package com.handlecaddie.controller.core

enum class Hazard(val label: String) { GREEN("green"), WATER("water"), BUNKER("bunker") }

/** How close a point is to the tightest hazard: [slackM] = distance minus that hazard's buffer (<= 0 means inside its buffer). */
data class Clearance(val slackM: Double, val hazard: Hazard, val distanceM: Double)

/**
 * Every green, water hazard and bunker on the course in ONE flat frame (metres east / north of [origin]), so the guard can
 * keep the cart off any of them, not just the current hole's.
 */
class GreenMap(
    val origin: LatLon,
    val greens: List<List<XY>>,
    val water: List<List<XY>> = emptyList(),
    val bunkers: List<List<XY>> = emptyList(),
) {
    val isEmpty get() = greens.isEmpty() && water.isEmpty() && bunkers.isEmpty()

    fun toLocal(p: LatLon) = Geo.toLocal(origin, p)

    private fun distTo(list: List<List<XY>>, p: XY): Double? {
        var best: Double? = null
        for (g in list) {
            val d = if (Geo.pointInPolygon(p, g)) 0.0 else Geo.distToPolygonEdge(p, g)
            if (best == null || d < best) best = d
        }
        return best
    }

    /** 0 inside a hazard, otherwise the distance to the nearest edge of any kind. Null if the map has no hazards. */
    fun distanceM(p: XY): Double? = listOfNotNull(distTo(greens, p), distTo(water, p), distTo(bunkers, p)).minOrNull()

    /** The hazard with the least room left once each kind's own buffer is taken off its distance. Null if the map is empty. */
    fun clearance(p: XY, greenBufferM: Double, waterBufferM: Double, bunkerBufferM: Double): Clearance? {
        var best: Clearance? = null
        fun consider(list: List<List<XY>>, kind: Hazard, buffer: Double) {
            val d = distTo(list, p) ?: return
            val c = Clearance(d - buffer, kind, d)
            if (best == null || c.slackM < best!!.slackM) best = c
        }
        consider(greens, Hazard.GREEN, greenBufferM); consider(water, Hazard.WATER, waterBufferM); consider(bunkers, Hazard.BUNKER, bunkerBufferM)
        return best
    }

    companion object {
        fun build(course: Course): GreenMap? {
            val first = course.holes.firstOrNull() ?: return null
            val origin = first.origin
            val g = ArrayList<List<XY>>(); val w = ArrayList<List<XY>>(); val b = ArrayList<List<XY>>()
            for (h in course.holes) {
                val shift = Geo.toLocal(origin, h.origin)       // hole-local -> shared frame (a pure translation at this scale)
                fun move(src: List<List<XY>>, dst: ArrayList<List<XY>>) { for (r in src) dst += r.map { XY(it.x + shift.x, it.y + shift.y) } }
                move(h.greens, g); move(h.water, w); move(h.bunkers, b)
            }
            return GreenMap(origin, g, w, b)
        }
    }
}

data class GuardCfg(
    val enabled: Boolean = true,
    /** Keep the cart at least this far from a green edge when GPS is perfect. Grows with the reported GPS error. */
    val baseMarginM: Double = 12.0,
    /** Same for water hazards (rolling in is the worst outcome) and bunkers (can be tighter so the cart can hug the fairway). */
    val waterMarginM: Double = 12.0,
    val bunkerMarginM: Double = 7.0,
    val accuracyFactor: Double = 1.0,
    val maxAccuracyCountedM: Double = 20.0,
    /** Resume once YOU are this far beyond every hazard's own buffer (and have been for [resumeFixes] fixes in a row). */
    val resumeClearM: Double = 6.0,
    val resumeFixes: Int = 3,
    /** After you override a hold, don't hold again until the cart is this much farther than the margin. */
    val rearmExtraM: Double = 5.0,
    /** GPS worse than this: we don't trust the numbers, so hold anywhere near a green. */
    val unusableAccuracyM: Double = 25.0,
    /** GPS this bad = the phone has effectively lost its position: hold wherever you are until it recovers. */
    val lostAccuracyM: Double = 50.0,
    val trailMaxM: Double = 60.0,
    /** No GPS fix for this long = the phone has lost its position, treated like [lostAccuracyM] (the cart holds). */
    val staleFixMs: Long = 5_000L,
    /** How fast the real cart is assumed to drive toward you after a hold ends (its top follow speed). */
    val pursuitSpeedMs: Double = 1.6,
    /** A measured cart position (phone riding on the cart) older than this is ignored and the cart is estimated from your trail again. */
    val cartFixMaxAgeMs: Long = 3_000L,
)

enum class GuardState { OFF, FREE, HOLDING, OVERRIDDEN, NO_DATA }

data class GuardOut(
    val hold: Boolean,
    val state: GuardState,
    val cartToHazardM: Double? = null,
    val playerToHazardM: Double? = null,
    val marginM: Double = 0.0,
    /** What is holding the cart (or the nearest hazard when free); null with no hazard data. */
    val hazard: Hazard? = null,
    /** The hold is because GPS is lost, not because of a hazard. */
    val lostGps: Boolean = false,
    /** You are clear of the hazard but the cart's straight path to you still crosses it, so the cart keeps waiting. */
    val pathBlocked: Boolean = false,
)

/**
 * Decides when the cart should stop and wait so it doesn't follow you onto a green. Pure logic, no clock: call [step]
 * once per GPS fix.
 *
 * The cart has no GPS. Its position is estimated from YOUR path: the point [followM] metres back along the trail of
 * places you have walked (so it works round corners too). The margin is the GPS error budget: the cart must still be
 * [GuardCfg.baseMarginM] + the reported accuracy away from the nearest green edge, which leaves room for the map and
 * GPS errors and for the cart to roll to a stop after the hold is sent.
 */
class GreenGuard(var cfg: GuardCfg = GuardCfg()) {
    private var map: GreenMap? = null
    private var trail = ArrayList<XY>()
    private var state = GuardState.FREE
    private var awayCount = 0
    private var holdHazard: Hazard? = null
    private var holdLost = false
    private var lastPlayer: XY? = null
    private var lastFixMs = Long.MIN_VALUE
    private var holdPos: XY? = null          // where the cart was (estimated) when it was told to wait: it stays there
    private var pursuit: XY? = null          // after a hold ends: the real cart, driving straight at you (not along your trail)
    private var pursuitFloor = 0.0           // while pursuing, the cart must not get closer to a hazard than where it started
    private var measuredCart: XY? = null    // the phone rides on the cart: its own GPS position, when fresh
    private var measuredAcc = 99.0
    private var measuredMs = Long.MIN_VALUE
    private var holdDir: Double? = null      // the way the cart was probably facing when it was told to wait (radians, east = 0, counter-clockwise)

    /** The cart's own GPS position (phone riding on the cart). Used in place of the trail estimate while it is fresh. */
    fun cartFix(pos: XY, accuracyM: Double, nowMs: Long) { measuredCart = pos; measuredAcc = accuracyM; measuredMs = nowMs }

    /** The measured cart position if there is a fresh, usable one. */
    private fun measured(): XY? {
        val c = measuredCart ?: return null
        if (measuredAcc > cfg.unusableAccuracyM) return null
        if (lastFixMs != Long.MIN_VALUE && lastFixMs > 0L && kotlin.math.abs(lastFixMs - measuredMs) > cfg.cartFixMaxAgeMs) return null
        return c
    }

    /** True while the guard is working from a measured cart position rather than an estimate. */
    fun cartMeasured(): Boolean = measured() != null

    fun setMap(m: GreenMap?) { map = m; reset() }

    fun reset() { measuredCart = null; trail = ArrayList(); state = GuardState.FREE; awayCount = 0; lastPlayer = null; lastFixMs = Long.MIN_VALUE; holdPos = null; pursuit = null }

    /** Where the cart was (estimated) when it was told to wait, or null when it is not holding. */
    fun holdPosition(): XY? = if (state == GuardState.HOLDING) (measured() ?: holdPos) else null

    /** The way the cart was probably facing when the hold began (from your trail), or null when unknown / not holding. */
    fun holdDirection(): Double? = if (state == GuardState.HOLDING) holdDir else null

    /** Same test the guard uses to resume: true when a straight run from [from] to [to] never goes closer to a hazard than where it starts. */
    fun pathClearFrom(from: XY, to: XY): Boolean { val m = map ?: return true; return pathClear(m, from, to) }

    /**
     * The cart drove round the hazard on its own and is now at [pos] (a position the caller trusts, e.g. checked against the fob range):
     * stop holding and carry on from there. The cart then heads straight for you, the same model as after an ordinary resume.
     */
    fun resumeFrom(pos: XY, accuracyM: Double) {
        val m = map ?: return
        val acc = cfg.accuracyFactor * accuracyM.coerceIn(0.0, cfg.maxAccuracyCountedM)
        pursuitFloor = minOf(m.clearance(pos, cfg.baseMarginM + acc, cfg.waterMarginM + acc, cfg.bunkerMarginM + acc)!!.slackM, 0.0)
        state = GuardState.FREE; awayCount = 0; pursuit = pos; holdPos = null; holdDir = null
    }

    /** Where the cart probably is: [followM] of walked path behind [player]. */
    fun estimateCart(player: XY, followM: Double): XY {
        var remaining = followM
        var from = player
        for (i in trail.indices.reversed()) {
            val p = trail[i]
            val seg = Geo.dist(from, p)
            if (seg >= remaining) {
                if (seg < 1e-9) return p
                val f = remaining / seg
                return XY(from.x + (p.x - from.x) * f, from.y + (p.y - from.y) * f)
            }
            remaining -= seg
            from = p
        }
        return from            // the trail is shorter than the follow distance: the cart is still at the start of it
    }

    /**
     * @param player  your position in the [GreenMap] frame
     * @param overridden the cart says you overrode a hold with the button
     */
    fun step(player: XY, accuracyM: Double, followM: Double, overridden: Boolean, nowMs: Long = 0L): GuardOut {
        // time since the last fix drives the cart model; a caller without a clock (nowMs 0) is taken to give one fix a second
        val dt = if (lastFixMs == Long.MIN_VALUE || nowMs <= 0L) 1.0 else ((nowMs - lastFixMs) / 1000.0).coerceIn(0.0, 3.0)
        lastPlayer = player; lastFixMs = nowMs
        return evaluate(player, accuracyM, followM, overridden, dt)
    }

    /**
     * Watchdog. Call about once a second with the clock. If no fix has arrived for [GuardCfg.staleFixMs] the phone has lost
     * its position, so the guard acts as if GPS were lost (the cart holds until good fixes return). Returns null while fixes are
     * still arriving, when the guard is off, or when it has never had a fix (nothing to hold against).
     */
    fun staleOut(nowMs: Long, followM: Double, overridden: Boolean): GuardOut? {
        val p = lastPlayer ?: return null
        val m = map
        if (!cfg.enabled || m == null || m.isEmpty) return null
        if (nowMs - lastFixMs <= cfg.staleFixMs) return null
        return evaluate(p, cfg.lostAccuracyM + 1.0, followM, overridden, 0.0)
    }

    /**
     * True when driving in a straight line from [from] to [to] never takes the cart closer to a hazard than where it starts.
     * (It starts at the edge of the margin, so "not closer" is the test, not "outside the margin".)
     */
    private fun pathClear(m: GreenMap, from: XY, to: XY): Boolean {
        fun slack(p: XY) = m.clearance(p, cfg.baseMarginM, cfg.waterMarginM, cfg.bunkerMarginM)!!.slackM
        val floor = minOf(slack(from), 0.0) - 0.5
        val len = Geo.dist(from, to)
        val n = maxOf(2, Math.ceil(len / maxOf(1.0, len / 80.0)).toInt())
        for (i in 0..n) {
            val f = i.toDouble() / n
            if (slack(XY(from.x + (to.x - from.x) * f, from.y + (to.y - from.y) * f)) < floor) return false
        }
        return true
    }

    private fun evaluate(player: XY, accuracyM: Double, followM: Double, overridden: Boolean, dtS: Double): GuardOut {
        val m = map
        if (!cfg.enabled) { state = GuardState.OFF; return GuardOut(false, GuardState.OFF) }
        if (m == null || m.isEmpty) { state = GuardState.NO_DATA; return GuardOut(false, GuardState.NO_DATA) }
        if (state == GuardState.OFF || state == GuardState.NO_DATA) state = GuardState.FREE

        // breadcrumb trail
        if (trail.isEmpty() || Geo.dist(trail.last(), player) >= 1.0) {
            trail.add(player)
            var len = 0.0
            for (i in trail.size - 1 downTo 1) { len += Geo.dist(trail[i], trail[i - 1]); if (len > cfg.trailMaxM) { trail = ArrayList(trail.subList(i, trail.size)); break } }
        }

        // After a hold ends the real cart sets off straight at you, so that is where it is, not "followM back along your trail"
        pursuit?.let { c ->
            val d = Geo.dist(c, player)
            val stepM = cfg.pursuitSpeedMs * dtS
            val moved = if (d <= stepM || d < 1e-9) player else XY(c.x + (player.x - c.x) * stepM / d, c.y + (player.y - c.y) * stepM / d)
            pursuit = if (Geo.dist(moved, player) <= followM + 1.0) null else moved
        }
        val fixed = measured()
        if (fixed != null) pursuit = null              // the real cart's position is known: no need to model it
        val cart = fixed ?: pursuit ?: estimateCart(player, followM)
        val acc = cfg.accuracyFactor * accuracyM.coerceIn(0.0, cfg.maxAccuracyCountedM)     // GPS error widens every buffer
        val cartAcc = if (fixed != null) cfg.accuracyFactor * measuredAcc.coerceIn(0.0, cfg.maxAccuracyCountedM) else acc
        val cartC = m.clearance(cart, cfg.baseMarginM + cartAcc, cfg.waterMarginM + cartAcc, cfg.bunkerMarginM + cartAcc)!!
        val playerC = m.clearance(player, cfg.baseMarginM + acc, cfg.waterMarginM + acc, cfg.bunkerMarginM + acc)!!
        val playerBase = m.clearance(player, cfg.baseMarginM, cfg.waterMarginM, cfg.bunkerMarginM)!!   // without the GPS allowance, for resuming
        val untrusted = accuracyM > cfg.unusableAccuracyM
        val lost = accuracyM > cfg.lostAccuracyM

        var blocked = false
        when (state) {
            GuardState.FREE -> {
                val worse = if (pursuit != null) cartC.slackM < pursuitFloor - 0.75 else cartC.slackM <= 0
                if (worse || (untrusted && playerC.slackM <= 10.0) || lost) {
                    state = GuardState.HOLDING; awayCount = 0; holdHazard = cartC.hazard; holdLost = lost && cartC.slackM > 0
                    holdPos = cart; pursuit = null
                    val ahead = estimateCart(player, maxOf(0.0, followM - 3.0))
                    holdDir = if (Geo.dist(cart, ahead) >= 1.0) Math.atan2(ahead.y - cart.y, ahead.x - cart.x) else null
                }
            }
            GuardState.HOLDING -> {
                if (overridden) { state = GuardState.OVERRIDDEN; pursuit = null }
                else {
                    awayCount = if (playerBase.slackM >= cfg.resumeClearM && !untrusted) awayCount + 1 else 0
                    if (awayCount >= cfg.resumeFixes) {
                        val from = fixed ?: holdPos ?: cart
                        if (pathClear(m, from, player)) {
                            state = GuardState.FREE; awayCount = 0
                            pursuitFloor = minOf(m.clearance(from, cfg.baseMarginM + cartAcc, cfg.waterMarginM + cartAcc, cfg.bunkerMarginM + cartAcc)!!.slackM, 0.0)
                            pursuit = if (fixed != null) null else from
                        } else blocked = true       // you are clear, but the cart's way to you leads across the hazard: it keeps waiting
                    }
                }
            }
            GuardState.OVERRIDDEN -> if (cartC.slackM > cfg.rearmExtraM) state = GuardState.FREE
            else -> {}
        }
        val shown = if (state == GuardState.HOLDING) (holdHazard ?: cartC.hazard) else cartC.hazard
        return GuardOut(state == GuardState.HOLDING, state, cartC.distanceM, playerC.distanceM, cartC.distanceM - cartC.slackM, shown, state == GuardState.HOLDING && holdLost, state == GuardState.HOLDING && blocked)
    }
}
