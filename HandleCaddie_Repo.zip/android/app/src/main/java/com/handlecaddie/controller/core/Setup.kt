package com.handlecaddie.controller.core

/** Which holes are being played. Hole numbers outside the range are ignored everywhere (navigation, scorecard, auto-advance). */
enum class RoundFormat(val first: Int, val last: Int) {
    ALL_18(1, 18), FRONT_9(1, 9), BACK_9(10, 18);

    operator fun contains(hole: Int) = hole in first..last

    companion object {
        fun fromName(s: String?) = entries.firstOrNull { it.name == s } ?: ALL_18
    }
}

/** A golf course found near the player (from OpenStreetMap). The holes are only downloaded once one is picked. */
data class CourseChoice(
    val osmType: String,        // "way", "relation" or "node"
    val osmId: Long,
    val name: String,
    val lat: Double,
    val lon: Double,
    val distanceM: Double = 0.0,
) {
    val key get() = "${osmType}_$osmId"
    val center get() = LatLon(lat, lon)
    val miles get() = distanceM / 1609.344
}

object Formats {
    /** Formats that make sense for what is mapped: a 9-hole course only offers 9, a half-mapped one only the half. */
    fun available(course: Course?): List<RoundFormat> {
        if (course == null) return RoundFormat.entries
        val nums = course.holes.map { it.number }
        val front = nums.any { it in 1..9 }
        val back = nums.any { it in 10..18 }
        return buildList {
            if (front && back) add(RoundFormat.ALL_18)
            if (front) add(RoundFormat.FRONT_9)
            if (back) add(RoundFormat.BACK_9)
        }.ifEmpty { listOf(RoundFormat.ALL_18) }
    }

    fun label(f: RoundFormat, course: Course?): String {
        val onlyFront = course != null && course.holes.none { it.number > 9 }
        return when (f) {
            RoundFormat.ALL_18 -> "18 holes"
            RoundFormat.FRONT_9 -> if (onlyFront) "9 holes" else "Front 9"
            RoundFormat.BACK_9 -> "Back 9"
        }
    }
}
