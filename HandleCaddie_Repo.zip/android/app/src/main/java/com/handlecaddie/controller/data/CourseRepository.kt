package com.handlecaddie.controller.data

import android.content.Context
import com.handlecaddie.controller.core.Course
import com.handlecaddie.controller.core.CourseChoice
import com.handlecaddie.controller.core.CourseParser
import com.handlecaddie.controller.core.LatLon
import java.io.File
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Loads hole shapes from OpenStreetMap (Overpass API) once, then keeps the raw JSON on disk so every later
 * round at that course works offline. Please keep the User-Agent and the caching - the Overpass servers are a
 * free community service.
 *
 * Every network step has a time budget, so a busy server ends in a readable error + Retry instead of an
 * endless "loading".
 */
class CourseRepository(context: Context) {
    private val dir = File(context.applicationContext.filesDir, "courses").apply { mkdirs() }

    class NotMappedException(msg: String) : Exception(msg)
    private class HttpError(val code: Int, val host: String) : Exception("HTTP $code from $host")

    // ---- hosted course data (built monthly from OpenStreetMap, see courses-site/). Empty HOSTED_BASE = feature off.
    private fun hostedIndexFile() = File(dir, "hosted_index.json")

    private fun httpGet(url: String, timeoutMs: Int): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs; c.readTimeout = timeoutMs
        c.setRequestProperty("User-Agent", "HandleCaddie/1.0 (golf push-cart companion app)")
        try { if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null } finally { c.disconnect() }
    } catch (e: Exception) { null }

    /** Courses near [center] from the hosted list (refreshed at most daily), or null if unavailable / none within 50 km. */
    private suspend fun hostedNearby(center: LatLon, allowDownload: Boolean): List<CourseChoice>? = withContext(Dispatchers.IO) {
        if (HOSTED_BASE.isEmpty()) return@withContext null
        val f = hostedIndexFile()
        if (allowDownload && (!f.exists() || System.currentTimeMillis() - f.lastModified() > 24 * 3_600_000L)) {
            httpGet("$HOSTED_BASE/index.json", 8_000)?.let { if (it.length > 50) runCatching { f.writeText(it) } }
        }
        if (!f.exists()) return@withContext null
        runCatching { CourseParser.parseNearby(f.readText(), center) }.getOrNull()
            ?.filter { it.distanceM <= 50_000 }?.takeIf { it.isNotEmpty() }
    }

    private fun nearbyFile(center: LatLon) =
        File(dir, String.format(Locale.US, "nearby_%.1f_%.1f.json", Math.round(center.lat * 10) / 10.0, Math.round(center.lon * 10) / 10.0))

    /** The course list saved for this area from an earlier search, instantly (no network), or null. Distances are recomputed from [center]. */
    suspend fun nearbyCached(center: LatLon): List<CourseChoice>? {
        hostedNearby(center, allowDownload = false)?.let { return it }
        return nearbyCachedOverpass(center)
    }

    private suspend fun nearbyCachedOverpass(center: LatLon): List<CourseChoice>? = withContext(Dispatchers.IO) {
        val f = nearbyFile(center)
        if (!f.exists()) null else runCatching { CourseParser.parseNearby(f.readText(), center) }.getOrNull()?.takeIf { it.isNotEmpty() }
    }

    /** True when the hole map of [c] is already on the phone (works offline, opens instantly). */
    fun isCached(c: CourseChoice) = File(dir, "course_${c.key}.json").let { it.exists() && it.length() > 200 }

    /** Named golf courses within ~19 miles, nearest first. Falls back to the last list for this area when offline. */
    suspend fun nearby(center: LatLon): List<CourseChoice> {
        hostedNearby(center, allowDownload = true)?.let { return it }       // one small file, no live map query
        return nearbyOverpass(center)
    }

    private suspend fun nearbyOverpass(center: LatLon): List<CourseChoice> = withContext(Dispatchers.IO) {
        val file = nearbyFile(center)
        if (file.exists() && System.currentTimeMillis() - file.lastModified() < 12 * 3_600_000L) {
            runCatching { CourseParser.parseNearby(file.readText(), center) }.getOrNull()?.takeIf { it.isNotEmpty() }?.let { return@withContext it }
        }
        val json = try {
            fetch(CourseParser.nearbyQuery(center), 30_000).also { file.writeText(it) }
        } catch (e: Exception) {
            if (file.exists()) file.readText() else throw Exception("Couldn't search for courses (${describe(e)}).")
        }
        CourseParser.parseNearby(json, center)
    }

    /** Holes of one chosen course. The raw JSON is cached so a later round there works offline. */
    suspend fun load(choice: CourseChoice): Course {
        userLoads.incrementAndGet()                       // the background prefetch waits while the player is waiting for a course
        try { return loadInternal(choice) } finally { userLoads.decrementAndGet() }
    }

    /**
     * Quietly downloads the hole maps of the nearest [maxCount] courses that aren't on the phone yet, one at a time with
     * a pause between (the Overpass servers are a shared free service). Gives up after 3 failures in a row (server busy or
     * no signal) and never competes with a course the player is actually waiting for. [onCached] gets each key as it lands.
     */
    suspend fun prefetch(courses: List<CourseChoice>, maxCount: Int = 5, onCached: (String) -> Unit = {}) {
        var failures = 0
        for (c in courses.take(maxCount)) {
            if (isCached(c)) { onCached(c.key); continue }
            while (userLoads.get() > 0) delay(1_000)
            if (failures >= 3) return
            try { loadInternal(c); onCached(c.key); failures = 0 }
            catch (e: NotMappedException) { failures = 0 }              // simply not mapped: skip, not a server problem
            catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { failures++ }
            delay(2_000)
        }
    }

    private suspend fun loadInternal(choice: CourseChoice): Course = withContext(Dispatchers.IO) {
      keyLocks.getOrPut(choice.key) { Mutex() }.withLock {        // a prefetch and a tap on the same course share ONE download
        val file = File(dir, "course_${choice.key}.json")
        if (file.exists()) {
            val cached = runCatching { CourseParser.parse(file.readText(), choice.name) }.getOrNull()
            if (cached != null && cached.holes.size >= 3) return@withLock cached
        }

        // 0) the pre-built file from our own server: one small download, no map query
        if (HOSTED_BASE.isNotEmpty()) {
            httpGet("$HOSTED_BASE/c/${choice.key}.json", 10_000)?.let { json ->
                val course = runCatching { CourseParser.parse(json, choice.name) }.getOrNull()
                if (course != null && course.holes.size >= 3) { file.writeText(json); return@withLock course }
            }
        }

        // 1) holes inside the course's own boundary (no neighbours)  2) fallback: everything within 2 km of its centre
        class Step(val label: String, val query: String, val budgetMs: Long)
        val steps = listOfNotNull(
            CourseParser.holesInCourseQuery(choice)?.let { Step("course boundary", it, 25_000) },
            Step("2 km radius", CourseParser.overpassQuery(choice.center, 2000), 35_000),
        )
        val problems = ArrayList<String>()
        var reachedServer = false
        var mostHoles = 0
        for (s in steps) {
            try {
                val json = fetch(s.query, s.budgetMs)
                reachedServer = true
                val course = CourseParser.parse(json, choice.name)
                if (course.holes.size >= 3) { file.writeText(json); return@withLock course }
                mostHoles = maxOf(mostHoles, course.holes.size)
                problems += "${s.label}: ${course.holes.size} holes found"
            } catch (e: Exception) {
                problems += "${s.label}: ${describe(e)}"
            }
        }
        if (reachedServer && problems.all { it.endsWith("holes found") }) {
            throw NotMappedException("${choice.name} isn't mapped hole-by-hole in OpenStreetMap yet (found $mostHoles holes).")
        }
        throw Exception("Couldn't load the hole map (${problems.joinToString("; ")}). Tap Retry.")
      }
    }

    private fun describe(e: Exception) = when (e) {
        is UnknownHostException -> "no internet connection"
        is SocketTimeoutException -> "server too slow"
        is HttpError -> if (e.code == 429 || e.code >= 500) "map server busy, HTTP ${e.code}" else "HTTP ${e.code}"
        else -> e.message ?: e.javaClass.simpleName
    }

    /**
     * POST [query] to the Overpass servers and return the first good answer, within [budgetMs] in total.
     * Servers are "hedged": the first is asked at once, the next only if there is still no answer after [HEDGE_MS],
     * and so on - so one slow or dead server no longer eats the whole budget, and a healthy one answers at full speed.
     * A server that says "busy" (429/5xx) or answers 200 with a "query timed out" remark counts as failed. If every
     * server failed and time remains, one more round is made after a short pause.
     */
    private suspend fun fetch(query: String, budgetMs: Long): String {
        val deadline = System.currentTimeMillis() + budgetMs
        var last: Exception? = null
        for (round in 0..1) {
            val left = deadline - System.currentTimeMillis()
            if (left < 4_000) break
            try { return race(query, left) } catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { last = e }
            if (last is HttpError && last.code in 400..499 && last.code != 429) break      // our query is wrong: retrying can't help
            delay(1_500)
        }
        throw last ?: SocketTimeoutException("no time left")
    }

    private suspend fun race(query: String, totalMs: Long): String = kotlinx.coroutines.coroutineScope {
        val results = kotlinx.coroutines.channels.Channel<Result<String>>(ENDPOINTS.size)
        val deadline = System.currentTimeMillis() + totalMs
        ENDPOINTS.forEachIndexed { n, endpoint ->
            launch(Dispatchers.IO) {
                delay(n * HEDGE_MS)
                val left = deadline - System.currentTimeMillis()
                if (left < 2_000) { results.send(Result.failure(SocketTimeoutException("no time left"))); return@launch }
                results.send(runCatching { post(endpoint, query, left) })
            }
        }
        var last: Throwable? = null
        repeat(ENDPOINTS.size) {
            val r = results.receive()
            if (r.isSuccess) { coroutineContext[kotlinx.coroutines.Job]?.children?.forEach { it.cancel() }; return@coroutineScope r.getOrThrow() }
            last = r.exceptionOrNull()
        }
        throw (last as? Exception) ?: SocketTimeoutException("no answer")
    }

    /** One HTTP POST. Cancelling the coroutine closes the socket, so a losing server in the race stops downloading. */
    private suspend fun post(endpoint: String, query: String, budgetMs: Long): String {
        val c = URL(endpoint).openConnection() as HttpURLConnection
        val job = coroutineContext[kotlinx.coroutines.Job]
        val handle = job?.invokeOnCompletion { c.disconnect() }
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = minOf(6_000L, budgetMs).toInt()
            c.readTimeout = budgetMs.toInt()
            c.setRequestProperty("User-Agent", "HandleCaddie/1.0 (golf push-cart companion app)")
            c.setRequestProperty("Accept", "*/*")
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            c.outputStream.use { it.write(("data=" + URLEncoder.encode(query, "UTF-8")).toByteArray()) }
            if (c.responseCode != 200) throw HttpError(c.responseCode, URL(endpoint).host)
            val text = c.inputStream.bufferedReader().use { it.readText() }
            // Overpass answers 200 even when it gave up: the JSON then carries a "remark" and is empty or cut short
            if (text.takeLast(500).contains("runtime error")) throw HttpError(504, URL(endpoint).host)
            return text
        } finally { handle?.dispose(); c.disconnect() }
    }

    private companion object {
        val keyLocks = ConcurrentHashMap<String, Mutex>()
        val userLoads = AtomicInteger(0)
        /**
         * Where the pre-built course data lives (GitHub Pages), no trailing slash. Example:
         * "https://YOURNAME.github.io/handlecaddie-courses". Leave empty to use only the live OpenStreetMap queries.
         */
        const val HOSTED_BASE = ""
        const val HEDGE_MS = 5_000L        // ask the next server if the previous hasn't answered after this long
        val ENDPOINTS = listOf(
            "https://overpass-api.de/api/interpreter",
            "https://overpass.private.coffee/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter",
        )
    }
}
