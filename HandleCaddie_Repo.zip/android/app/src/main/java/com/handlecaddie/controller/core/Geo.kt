package com.handlecaddie.controller.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class LatLon(val lat: Double, val lon: Double)

/** Local planar coordinates in METRES: x = east, y = SOUTH (so y grows downward like the display). */
data class XY(val x: Double, val y: Double)

object Geo {
    private const val EARTH_R = 6_371_008.8
    const val YD_PER_M = 1.0936133

    fun yards(m: Double) = m * YD_PER_M

    /** Great-circle distance in metres (haversine). */
    fun distanceM(a: LatLon, b: LatLon): Double {
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * EARTH_R * atan2(sqrt(h), sqrt(1 - h))
    }

    /** Equirectangular projection around [origin]; accurate to centimetres over a golf hole. */
    fun toLocal(origin: LatLon, p: LatLon): XY {
        val x = Math.toRadians(p.lon - origin.lon) * cos(Math.toRadians(origin.lat)) * EARTH_R
        val y = -Math.toRadians(p.lat - origin.lat) * EARTH_R
        return XY(x, y)
    }

    /** Inverse of [toLocal]. */
    fun toLatLon(origin: LatLon, p: XY): LatLon =
        LatLon(origin.lat - Math.toDegrees(p.y / EARTH_R), origin.lon + Math.toDegrees(p.x / (EARTH_R * cos(Math.toRadians(origin.lat)))))

    /** Compass bearing in degrees (0 = north, 90 = east) from [a] to [b] in the local frame, where +x is east and +y is SOUTH. */
    fun compassDeg(a: XY, b: XY): Double = (Math.toDegrees(atan2(b.x - a.x, -(b.y - a.y))) + 360.0) % 360.0

    fun dist(a: XY, b: XY): Double = sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y))

    fun pointInPolygon(p: XY, poly: List<XY>): Boolean {
        var inside = false
        var j = poly.size - 1
        for (i in poly.indices) {
            val a = poly[i]; val b = poly[j]
            if ((a.y > p.y) != (b.y > p.y) &&
                p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x
            ) inside = !inside
            j = i
        }
        return inside
    }

    fun distToSegment(p: XY, a: XY, b: XY): Double {
        val dx = b.x - a.x; val dy = b.y - a.y
        val l2 = dx * dx + dy * dy
        val t = if (l2 == 0.0) 0.0 else (((p.x - a.x) * dx + (p.y - a.y) * dy) / l2).coerceIn(0.0, 1.0)
        return dist(p, XY(a.x + t * dx, a.y + t * dy))
    }

    /** Distance from [p] to the polygon outline (0 on the edge; always >= 0, inside or out). */
    fun distToPolygonEdge(p: XY, poly: List<XY>): Double {
        var best = Double.MAX_VALUE
        var j = poly.size - 1
        for (i in poly.indices) { best = min(best, distToSegment(p, poly[j], poly[i])); j = i }
        return best
    }

    fun distToPolyline(p: XY, line: List<XY>): Double {
        if (line.size == 1) return dist(p, line[0])
        var best = Double.MAX_VALUE
        for (i in 0 until line.size - 1) best = min(best, distToSegment(p, line[i], line[i + 1]))
        return best
    }

    fun polylineLength(line: List<XY>): Double {
        var s = 0.0
        for (i in 0 until line.size - 1) s += dist(line[i], line[i + 1])
        return s
    }

    /** Area centroid for a simple polygon (falls back to the vertex mean for degenerate shapes). */
    fun centroid(poly: List<XY>): XY {
        var a = 0.0; var cx = 0.0; var cy = 0.0
        var j = poly.size - 1
        for (i in poly.indices) {
            val cr = poly[j].x * poly[i].y - poly[i].x * poly[j].y
            a += cr; cx += (poly[j].x + poly[i].x) * cr; cy += (poly[j].y + poly[i].y) * cr
            j = i
        }
        if (abs(a) < 1e-9) return XY(poly.sumOf { it.x } / poly.size, poly.sumOf { it.y } / poly.size)
        return XY(cx / (3 * a), cy / (3 * a))
    }

    /**
     * Where does the ray from [origin] along unit vector [dir] cross the polygon outline?
     * Returns (nearest, farthest) distance in metres, or null if it crosses fewer than 2 edges
     * (e.g. when [origin] is already inside the polygon).
     */
    fun raySpan(origin: XY, dir: XY, poly: List<XY>): Pair<Double, Double>? {
        var lo = Double.MAX_VALUE; var hi = -Double.MAX_VALUE; var n = 0
        var j = poly.size - 1
        for (i in poly.indices) {
            val a = poly[j]; val b = poly[i]; j = i
            val sx = b.x - a.x; val sy = b.y - a.y
            val denom = dir.x * sy - dir.y * sx
            if (abs(denom) < 1e-12) continue
            val ox = a.x - origin.x; val oy = a.y - origin.y
            val t = (ox * sy - oy * sx) / denom
            val u = (ox * dir.y - oy * dir.x) / denom
            if (t >= 0 && u >= 0 && u <= 1) { lo = min(lo, t); hi = max(hi, t); n++ }
        }
        return if (n >= 2 && hi - lo > 1e-6) lo to hi else null
    }

    /** Douglas-Peucker on a closed ring; returns a ring with at least 3 points. */
    fun simplifyRing(ring: List<XY>, tolM: Double): List<XY> {
        if (ring.size <= 4) return ring
        // split the ring at the vertex farthest from vertex 0 so both halves are open polylines
        var far = 1; var fd = -1.0
        for (i in 1 until ring.size) { val d = dist(ring[0], ring[i]); if (d > fd) { fd = d; far = i } }
        val h1 = dp(ring.subList(0, far + 1), tolM)
        val h2 = dp(ring.subList(far, ring.size) + ring[0], tolM)
        val out = h1.dropLast(1) + h2.dropLast(1)
        return if (out.size >= 3) out else ring
    }

    private fun dp(pts: List<XY>, tol: Double): List<XY> {
        if (pts.size < 3) return pts
        var idx = 0; var md = -1.0
        for (i in 1 until pts.size - 1) {
            val d = distToSegment(pts[i], pts.first(), pts.last())
            if (d > md) { md = d; idx = i }
        }
        return if (md > tol) dp(pts.subList(0, idx + 1), tol).dropLast(1) + dp(pts.subList(idx, pts.size), tol)
        else listOf(pts.first(), pts.last())
    }

    /** Simplify until the ring has at most [maxPts] points, raising the tolerance if necessary. */
    fun fitRing(ring: List<XY>, maxPts: Int, startTolM: Double = 1.0): List<XY> {
        var tol = startTolM
        var r = simplifyRing(ring, tol)
        var guard = 0
        while (r.size > maxPts && guard++ < 14) { tol *= 1.5; r = simplifyRing(ring, tol) }
        if (r.size > maxPts) { val step = r.size.toDouble() / maxPts; r = List(maxPts) { r[(it * step).toInt()] } }
        return r
    }

    @Suppress("unused") private val keepPi = PI
}
