package com.handlecaddie.controller.service

import com.handlecaddie.controller.ble.BleLink
import com.handlecaddie.controller.core.BenchScenario
import com.handlecaddie.controller.core.BenchSummary
import com.handlecaddie.controller.core.CartAuthStatus
import com.handlecaddie.controller.core.CartConfig
import com.handlecaddie.controller.core.CartMode
import com.handlecaddie.controller.core.CartTelemetry
import com.handlecaddie.controller.core.Club
import com.handlecaddie.controller.core.CourseChoice
import com.handlecaddie.controller.core.GuardCfg
import com.handlecaddie.controller.core.GuardState
import com.handlecaddie.controller.core.CartLocator
import com.handlecaddie.controller.core.PlaysLike
import com.handlecaddie.controller.core.PaceStatus
import com.handlecaddie.controller.core.StormStatus
import com.handlecaddie.controller.core.NavPhase
import com.handlecaddie.controller.core.RoundSummary
import com.handlecaddie.controller.core.HoleStat
import com.handlecaddie.controller.core.Hazard
import com.handlecaddie.controller.core.ShotRecord
import com.handlecaddie.controller.core.GameState
import com.handlecaddie.controller.core.RoundFormat
import com.handlecaddie.controller.core.SwingProfile
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

sealed interface CourseStatus {
    data object None : CourseStatus
    data object Loading : CourseStatus
    /** [learning]: the course is not mapped hole by hole, so holes are learned as you play ([knownHoles] of 18 so far). */
    data class Ready(val name: String, val holes: Int, val formats: List<RoundFormat>, val learning: Boolean = false, val knownHoles: Int = 0) : CourseStatus
    data class Error(val message: String) : CourseStatus
}

sealed interface NearbyStatus {
    data object None : NearbyStatus
    data object Loading : NearbyStatus
    data class Ready(val courses: List<CourseChoice>) : NearbyStatus
    data class Error(val message: String) : NearbyStatus
}

/** The course + format the player picked. While [confirmed] is false the setup card is open; once true it collapses to a summary. */
data class RoundSetup(val course: CourseChoice? = null, val format: RoundFormat = RoundFormat.ALL_18, val confirmed: Boolean = false)

sealed interface Command {
    data object Connect : Command
    data object Disconnect : Command
    data object NextHole : Command
    data object PrevHole : Command
    data object ReloadCourse : Command
    data object NewRound : Command
    data object RefreshNearby : Command
    data object StartRound : Command          // confirm the course + format
    data object EditSetup : Command           // reopen the course + format card
    data class SelectCourse(val course: CourseChoice) : Command
    data class SetFormat(val format: RoundFormat) : Command
    data class SetBag(val bag: List<Club>) : Command
    data class SetPar(val hole: Int, val par: Int) : Command       // par 0 = back to the map's value
    data class SetSwing(val swing: SwingProfile) : Command
    data class SetShotClub(val id: Long, val clubKey: String) : Command     // "I actually hit this club"
    data class DeleteShot(val id: Long) : Command
    data class SetLearning(val on: Boolean) : Command                       // use my own shot data for recommendations
    /** Save the round so far (or the finished round) to the history. Finished rounds are saved automatically. */
    object SaveRound : Command
    data class SetGuard(val enabled: Boolean, val greenM: Double, val waterM: Double, val bunkerM: Double) : Command
    /** Bench test: run a made-up GPS walk through the guard (and the cart) instead of the real GPS. */
    data class StartBench(val scenario: BenchScenario) : Command
    data object StopBench : Command
    data object ClearLog : Command
    /** Pair with the display: [pin] is the 6 digits on the display's screen. */
    data class DisplayPair(val pin: String) : Command
    /** Forget the display's key (this phone is no longer paired with it). */
    data object DisplayForget : Command
    data class SetPaceTarget(val minutes: Int) : Command                    // target time for 18 holes
    data class PauseRound(val paused: Boolean) : Command                    // lunch, a long wait: the clock stops
    /** A flash was followed by a bang after [seconds] (null = thunder heard, no count). */
    data class FlashBang(val seconds: Int?) : Command
    data object StormClear : Command                                        // tapped by mistake
    data object MakeRecap : Command                                         // build the shareable round recap into [CaddieHub.recap]
    data object RecapShown : Command
}

/** One line of the decision log: when (wall clock) and what the guard / cart did. */
data class LogLine(val timeMs: Long, val text: String)

/** The bench test as the screen sees it. [summary] is set once a run has finished. */
data class BenchStatus(
    val running: Boolean = false,
    val scenario: BenchScenario? = null,
    val second: Int = 0,
    val total: Int = 0,
    val note: String = "",
    val hazardM: Double? = null,       // distance from the simulated you to the nearest hazard
    val accuracyM: Double? = null,     // simulated GPS error, null = no fix this second
    val summary: BenchSummary? = null,
    val message: String = "",
)

/** The cart driving itself round a hazard (phase 2): what it is doing, in words for the Cart page. */
data class NavStatus(val phase: NavPhase = NavPhase.IDLE, val text: String = "")

/** Wind / hill / temperature / thin-air adjusted distance for the Play page. [club] = what to take for the adjusted distance. */
data class PlaysLikeStatus(val pl: PlaysLike? = null, val club: Club? = null, val tempC: Double? = null, val windMph: Double? = null, val windFromDeg: Double? = null)

/** Where the cart was last with you, once the link has dropped. */
data class LocatorStatus(val awayYd: Int? = null, val bearingDeg: Double? = null, val alert: CartLocator.Alert = CartLocator.Alert.NONE)

data class BatteryStatus(val text: String = "", val warn: Boolean = false)

/** Commands for the motorised cart. Handled straight away by the service, never queued behind golf logic. */
sealed interface CartCommand : Command {
    data object Connect : CartCommand
    data object Disconnect : CartCommand
    data class SetMode(val mode: CartMode) : CartCommand
    /** Allow the cart to drive itself round a hazard to meet you (experimental, off by default). */
    data class SetNav(val on: Boolean) : CartCommand
    /** Use the watch's GPS as YOUR position (the phone can stay on the cart). Phone GPS is ignored while this is on. */
    data class SetWatchPosition(val on: Boolean) : CartCommand
    /** With the phone on the cart and the fob out of reach: let the cart chase your watch's GPS position (experimental). */
    data class SetGpsFollow(val on: Boolean) : CartCommand
    /** Let the cart drive itself to the next tee when you hole out and press Go (experimental, off by default). */
    data class SetTeeDrive(val on: Boolean) : CartCommand
    /** Manual top speed as a fraction of the cart's manual maximum (all manual sources: finger, watch, creep). */
    data class SetManualCap(val cap: Double) : CartCommand
    /** Allow the watch's hold-to-drive buttons (off at every start). */
    data class SetWatchDrive(val on: Boolean) : CartCommand
    /** One slow nudge forward: x = -1..1 steer. Only in Manual. */
    data class Creep(val x: Double) : CartCommand
    /** Send the cart to the next tee now (needs the switch above, and a hole just finished). */
    data object DriveToTee : CartCommand
    data class SetFollow(val metres: Double) : CartCommand
    data class SetMaxSpeed(val ms: Double) : CartCommand
    data class SetDescent(val ms: Double) : CartCommand
    data class SetHillHold(val on: Boolean) : CartCommand
    /** "stop", "clear", "level", "trip0" - see CartProtocol.cmd */
    data class Do(val name: String) : CartCommand
    data class Demo(val on: Boolean) : CartCommand
    /** Pair with the cart: [pin] is the 6 digits on the cart's screen. */
    data class Pair(val pin: String) : CartCommand
    /** Forget the stored key (this phone is no longer paired). */
    data object ForgetKey : CartCommand
}

/** What the green guard is doing, for the Cart page. */
data class GuardStatus(
    val cfg: GuardCfg = GuardCfg(),
    val state: GuardState = GuardState.FREE,
    val cartToHazardM: Double? = null,
    val hasHazards: Boolean = false,
    val hazard: Hazard? = null,
    val lostGps: Boolean = false,
    val pathBlocked: Boolean = false,
)

/** The joystick, written directly by the UI (not through [Command]) so a stale position can never queue up. */
data class Joy(val x: Double = 0.0, val y: Double = 0.0, val active: Boolean = false)

/** The one place the UI looks. The service writes these; the UI only reads them and sends [Command]s. */
object CaddieHub {
    val game = MutableStateFlow(GameState())
    val link = MutableStateFlow<BleLink.LinkState>(BleLink.LinkState.Idle)
    /** Has this phone proved itself to the display? UNKNOWN = the display did not ask (older firmware): carries on as before. */
    val displayAuth = MutableStateFlow(CartAuthStatus())
    val course = MutableStateFlow<CourseStatus>(CourseStatus.None)
    val nearby = MutableStateFlow<NearbyStatus>(NearbyStatus.None)
    /** Keys of courses whose hole map is already stored on the phone (shown as "ready" in the course list). */
    val cachedCourses = MutableStateFlow<Set<String>>(emptySet())
    val setup = MutableStateFlow(RoundSetup())
    val bag = MutableStateFlow<List<Club>>(emptyList())
    val shots = MutableStateFlow<List<ShotRecord>>(emptyList())
    /** Finished holes of today's round, for the Caddie Report. */
    val holeStats = MutableStateFlow<List<HoleStat>>(emptyList())
    val history = MutableStateFlow<List<RoundSummary>>(emptyList())
    val roundSaved = MutableStateFlow(false)
    val useLearning = MutableStateFlow(true)
    val guard = MutableStateFlow(GuardStatus())
    val bench = MutableStateFlow(BenchStatus())
    /** Why the guard and the cart did what they did, newest last. Kept for the session; answers "why did it stop?". */
    val decisionLog = MutableStateFlow<List<LogLine>>(emptyList())
    val swing = MutableStateFlow(SwingProfile.AVERAGE)
    val serviceRunning = MutableStateFlow(false)

    // ---- motorised cart
    val cartLink = MutableStateFlow<BleLink.LinkState>(BleLink.LinkState.Idle)
    val cart = MutableStateFlow(CartTelemetry())
    val cartConfig = MutableStateFlow(CartConfig())
    /** Has this phone proved itself to the cart? Until it has, the cart ignores every command. */
    val cartAuth = MutableStateFlow(CartAuthStatus())
    val cartMode = MutableStateFlow(CartMode.PARK)          // the mode the phone last asked for
    val cartFresh = MutableStateFlow(false)                 // telemetry arrived in the last couple of seconds
    val watchConnected = MutableStateFlow(false)
    val positionFromWatch = MutableStateFlow(false)          // "phone rides on the cart": watch = you, phone GPS = the cart
    val gpsFollowEnabled = MutableStateFlow(false)
    val cartGpsAgeS = MutableStateFlow<Int?>(null)
    val watchGpsAgeS = MutableStateFlow<Int?>(null)          // seconds since the last watch position, null = none yet
    val playsLike = MutableStateFlow(PlaysLikeStatus())
    val locator = MutableStateFlow(LocatorStatus())
    val battery = MutableStateFlow(BatteryStatus())
    val pace = MutableStateFlow(PaceStatus())
    val storm = MutableStateFlow(StormStatus())
    /** Text of the round recap once asked for; the screen shares it, then sends [Command.RecapShown]. */
    val recap = MutableStateFlow<String?>(null)
    val manualCap = MutableStateFlow(com.handlecaddie.controller.core.ManualDrive.CAP_DEFAULT)
    val watchDriveEnabled = MutableStateFlow(false)          // watch hold-to-drive, off at every start
    val teeDriveEnabled = MutableStateFlow(false)           // "drive to the next tee" switch, off at every start
    val navEnabled = MutableStateFlow(false)                // "go round hazards" switch, off at every start
    val nav = MutableStateFlow(NavStatus())
    val cartDemo = MutableStateFlow(false)                  // numbers come from the built-in simulator, not a real cart
    val joystick = MutableStateFlow(Joy())
    val commands = MutableSharedFlow<Command>(extraBufferCapacity = 16)
}
