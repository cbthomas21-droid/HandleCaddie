package com.handlecaddie.controller.core

import org.json.JSONObject

/**
 * Builds a [Course] from OpenStreetMap golf data fetched from the Overpass API
 * (https://wiki.openstreetmap.org/wiki/Key:golf). Pure function of the JSON, so it can be
 * unit-tested and the result cached.
 */
object CourseParser {

    /** Overpass QL: everything golf-related around [center]. `out geom` returns coordinates inline. */
    fun overpassQuery(center: LatLon, radiusM: Int = 1800): String =
        "[out:json][timeout:30];(" +
            "way[\"golf\"~\"^(hole|green|fairway|bunker|tee|water_hazard|lateral_water_hazard)\$\"](around:$radiusM,${center.lat},${center.lon});" +
            "node[\"golf\"=\"pin\"](around:$radiusM,${center.lat},${center.lon});" +
            ");out geom;"

    private const val GOLF_KINDS = "^(hole|green|fairway|bunker|tee|water_hazard|lateral_water_hazard)\$"

    /** Every golf course (named or not) within [radiusM] of [center], as a centre point + tags. */
    fun nearbyQuery(center: LatLon, radiusM: Int = 30_000): String =
        "[out:json][timeout:25];nwr[\"leisure\"=\"golf_course\"](around:$radiusM,${center.lat},${center.lon});out center tags;"

    /** Named courses from [nearbyQuery], nearest first. Same-named neighbours within 1 km are one course. */
    fun parseNearby(json: String, from: LatLon, limit: Int = 20): List<CourseChoice> {
        val els = JSONObject(json).optJSONArray("elements") ?: return emptyList()
        val out = ArrayList<CourseChoice>()
        for (i in 0 until els.length()) {
            val el = els.getJSONObject(i)
            val type = el.optString("type")
            val name = tagsOf(el)["name"]?.trim().orEmpty()
            if (name.isEmpty() || !el.has("id")) continue
            val (lat, lon) = when {
                el.has("center") -> el.getJSONObject("center").let { it.getDouble("lat") to it.getDouble("lon") }
                el.has("lat") && el.has("lon") -> el.getDouble("lat") to el.getDouble("lon")
                else -> continue
            }
            val c = LatLon(lat, lon)
            out += CourseChoice(type, el.getLong("id"), name, lat, lon, Geo.distanceM(from, c))
        }
        val result = ArrayList<CourseChoice>()
        for (c in out.sortedBy { it.distanceM }) {
            if (result.none { it.name.equals(c.name, ignoreCase = true) && Geo.distanceM(it.center, c.center) < 1_000 }) result += c
        }
        return result.take(limit)
    }

    /**
     * Only the golf features inside the chosen course's own boundary, so a neighbouring course's holes
     * (same numbers!) can't leak in. Null for a bare node, which has no boundary - use [overpassQuery] then.
     */
    fun holesInCourseQuery(c: CourseChoice): String? {
        val sel = when (c.osmType) { "way" -> "way(${c.osmId})"; "relation" -> "rel(${c.osmId})"; else -> return null }
        return "[out:json][timeout:40];$sel;map_to_area->.a;(" +
            "way[\"golf\"~\"$GOLF_KINDS\"](area.a);node[\"golf\"=\"pin\"](area.a););out geom;"
    }

    private class Way(val kind: String, val tags: Map<String, String>, val pts: List<LatLon>)

    private fun tagsOf(o: JSONObject): Map<String, String> {
        val t = o.optJSONObject("tags") ?: return emptyMap()
        return t.keys().asSequence().associateWith { t.optString(it) }
    }

    fun parse(json: String, name: String): Course {
        val els = JSONObject(json).optJSONArray("elements") ?: return Course(name, emptyList())
        val ways = ArrayList<Way>()
        val pins = ArrayList<LatLon>()
        for (i in 0 until els.length()) {
            val el = els.getJSONObject(i)
            val tags = tagsOf(el)
            val kind = tags["golf"] ?: continue
            when (el.optString("type")) {
                "node" -> if (kind == "pin") pins += LatLon(el.getDouble("lat"), el.getDouble("lon"))
                "way" -> {
                    val g = el.optJSONArray("geometry") ?: continue
                    var pts = (0 until g.length()).map { LatLon(g.getJSONObject(it).getDouble("lat"), g.getJSONObject(it).getDouble("lon")) }
                    if (kind != "hole" && pts.size > 1 && pts.first() == pts.last()) pts = pts.dropLast(1)   // closed ring
                    if (kind == "hole" && pts.size >= 2 || kind != "hole" && pts.size >= 3) ways += Way(kind, tags, pts)
                }
            }
        }

        // one line of play per hole number (if several tees are mapped keep the longest)
        val lines = HashMap<Int, Way>()
        fun lenOf(w: Way) = w.pts.zipWithNext().sumOf { Geo.distanceM(it.first, it.second) }
        for (w in ways.filter { it.kind == "hole" }) {
            val n = w.tags["ref"]?.takeWhile { it.isDigit() }?.toIntOrNull() ?: continue
            val cur = lines[n]
            if (cur == null || lenOf(w) > lenOf(cur)) lines[n] = w
        }
        if (lines.isEmpty()) return Course(name, emptyList())

        // a shared planar frame just for deciding which feature belongs to which hole
        val g0 = lines.values.first().pts.first()
        fun g(p: LatLon) = Geo.toLocal(g0, p)
        class Info(val n: Int, val way: Way, val line: List<XY>)
        val infos = lines.entries.sortedBy { it.key }.map { (n, w) -> Info(n, w, w.pts.map(::g)) }

        class Feat(val way: Way, val ring: List<XY>, val c: XY)
        val feats = ways.filter { it.kind != "hole" }.map { w -> val r = w.pts.map(::g); Feat(w, r, Geo.centroid(r)) }

        val perHole = HashMap<Int, MutableList<Feat>>()
        for (f in feats) {
            val best: Info? = when (f.way.kind) {
                "green" -> infos.filter { Geo.dist(f.c, it.line.last()) <= 70 }.minByOrNull { Geo.dist(f.c, it.line.last()) }
                "tee" -> infos.filter { Geo.dist(f.c, it.line.first()) <= 60 }.minByOrNull { Geo.dist(f.c, it.line.first()) }
                else -> infos.filter { Geo.distToPolyline(f.c, it.line) <= (if (f.way.kind == "fairway") 100.0 else 90.0) }
                    .minByOrNull { Geo.distToPolyline(f.c, it.line) }
            }
            if (best != null) perHole.getOrPut(best.n) { ArrayList() } += f
        }

        val holes = infos.map { info ->
            val origin = info.way.pts.first()
            fun loc(p: LatLon) = Geo.toLocal(origin, p)
            val mine = perHole[info.n].orEmpty()
            fun rings(kinds: Set<String>) = mine.filter { it.way.kind in kinds }.map { f -> f.way.pts.map(::loc) }
            val greens = rings(setOf("green"))
            val lineLoc = info.way.pts.map(::loc)
            val lenYd = Geo.yards(Geo.polylineLength(lineLoc)).toInt()
            val end = lineLoc.last()
            val pinNode = pins.map(::loc).filter { Geo.dist(it, end) <= 60 }.minByOrNull { Geo.dist(it, end) }
            val pin = pinNode ?: greens.minByOrNull { Geo.dist(Geo.centroid(it), end) }?.let { Geo.centroid(it) } ?: end
            val taggedPar = info.way.tags["par"]?.toIntOrNull()?.takeIf { it in 3..6 }
            val par = taggedPar ?: if (lenYd < 250) 3 else if (lenYd < 470) 4 else 5
            val teeBoxes = rings(setOf("tee"))
            val tee = teeBoxes.firstOrNull()?.let { Geo.centroid(it) } ?: lineLoc.first()
            Hole(
                number = info.n, par = par, lengthYd = lenYd, origin = origin, tee = tee, pin = pin,
                teeBoxes = teeBoxes, fairways = rings(setOf("fairway")), greens = greens,
                bunkers = rings(setOf("bunker")), water = rings(setOf("water_hazard", "lateral_water_hazard")),
                parMapped = taggedPar != null,
            )
        }
        return Course(name, holes)
    }
}
