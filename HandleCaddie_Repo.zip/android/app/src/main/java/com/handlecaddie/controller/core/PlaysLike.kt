package com.handlecaddie.controller.core

import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt

/** Weather at the course. Any part can be unknown. Wind speed in m/s, wind direction = where it blows FROM (compass degrees). */
data class Conditions(val tempC: Double? = null, val windMs: Double? = null, val windFromDeg: Double? = null, val fetchedMs: Long = 0L)

/**
 * What a shot "plays like" once wind, uphill/downhill, temperature and thin air are counted. Each part is in yards (+ = plays longer).
 * Rules of thumb, the same kind a caddie uses; they are deliberately modest and capped so one bad reading cannot send you to the wrong club.
 */
data class PlaysLike(val actualYd: Int, val playsYd: Int, val windYd: Int, val elevYd: Int, val tempYd: Int, val altYd: Int, val headwindMph: Double?, val elevM: Double?) {
    val changed get() = abs(playsYd - actualYd) >= 2

    /** One short line, e.g. "Plays 158: headwind 12 mph +8, uphill 13 ft +4". Empty when nothing matters. */
    val summary: String get() {
        if (!changed) return ""
        val parts = ArrayList<String>()
        fun add(label: String, yd: Int) { if (abs(yd) >= 1) parts += "$label ${if (yd > 0) "+" else ""}$yd" }
        headwindMph?.let { add(if (it >= 0) "headwind ${it.roundToInt()} mph" else "tailwind ${(-it).roundToInt()} mph", windYd) }
        elevM?.let { add(if (it >= 0) "uphill ${(it * 3.28084).roundToInt()} ft" else "downhill ${(-it * 3.28084).roundToInt()} ft", elevYd) }
        add(if (tempYd > 0) "cold air" else "warm air", tempYd)
        add("thin air", altYd)
        return "Plays $playsYd" + if (parts.isEmpty()) "" else ": " + parts.joinToString(", ")
    }
}

object PlaysLikeCalc {
    const val MPS_TO_MPH = 2.23694
    private const val BASE_TEMP_C = 21.0

    /**
     * @param shotBearingDeg compass bearing from you to the pin
     * @param elevDeltaM     pin height minus your height (+ = uphill), null = unknown
     * @param altitudeM      height above sea level, null = unknown
     * @param includeAltitude false when the club distances were measured on a course (they already include local air)
     */
    fun compute(actualYd: Int, shotBearingDeg: Double, c: Conditions?, elevDeltaM: Double?, altitudeM: Double?, includeAltitude: Boolean): PlaysLike {
        val d = actualYd.toDouble()
        var hw: Double? = null
        var windYd = 0.0
        if (c?.windMs != null && c.windFromDeg != null) {
            val mph = c.windMs * MPS_TO_MPH
            hw = mph * cos(Math.toRadians(c.windFromDeg - shotBearingDeg))        // + = into your face
            windYd = d * (if (hw >= 0) 0.010 * hw else 0.005 * hw).coerceIn(-0.12, 0.25)    // headwind costs about twice what a tailwind gives back
        }
        val elevYd = if (elevDeltaM == null) 0.0 else (1.09 * elevDeltaM).coerceIn(-0.25 * d, 0.25 * d)
        val tempYd = if (c?.tempC == null) 0.0 else d * (0.0018 * (BASE_TEMP_C - c.tempC)).coerceIn(-0.04, 0.05)
        val altYd = if (!includeAltitude || altitudeM == null) 0.0 else -d * (0.0000380 * altitudeM).coerceIn(0.0, 0.08)
        val plays = (d + windYd + elevYd + tempYd + altYd).roundToInt()
        return PlaysLike(actualYd, plays, windYd.roundToInt(), elevYd.roundToInt(), tempYd.roundToInt(), altYd.roundToInt(), hw, elevDeltaM)
    }
}

/** Reading the two free web services the app asks (Open-Meteo for weather, USGS for height above sea level). Tolerant: anything odd gives null. */
object ConditionsParse {
    fun weather(json: String, nowMs: Long): Conditions? = try {
        val cur = JSONObject(json).getJSONObject("current")
        Conditions(
            tempC = cur.optDouble("temperature_2m").takeIf { !it.isNaN() },
            windMs = cur.optDouble("wind_speed_10m").takeIf { !it.isNaN() && it >= 0 },
            windFromDeg = cur.optDouble("wind_direction_10m").takeIf { !it.isNaN() },
            fetchedMs = nowMs,
        )
    } catch (e: Exception) { null }

    /** USGS EPQS: {"value": 1362.5, ...}; -1000000 means "no data here". */
    fun elevationM(json: String): Double? = try {
        val v = JSONObject(json).optDouble("value")
        if (v.isNaN() || v < -500.0 || v > 9000.0) null else v
    } catch (e: Exception) { null }

    /** Thunderstorm now / in the next few hours, from the same weather answer. Null when it can't be read. */
    fun storm(json: String, nowMs: Long): StormForecast? = try {
        val o = JSONObject(json)
        val nowS = nowMs / 1000L
        val cur = o.optJSONObject("current")?.optInt("weather_code", -1) ?: -1
        var minutes: Int? = if (cur in THUNDER_CODES) 0 else null
        val h = o.optJSONObject("hourly")
        val times = h?.optJSONArray("time"); val codes = h?.optJSONArray("weather_code")
        if (minutes == null && times != null && codes != null) {
            for (i in 0 until minOf(times.length(), codes.length())) {
                val t = times.optLong(i, 0L)
                if (codes.optInt(i, -1) in THUNDER_CODES && t + 3600 > nowS) { minutes = ((t - nowS) / 60L).toInt().coerceAtLeast(0); break }
            }
        }
        if (cur == -1 && times == null) null else StormForecast(thunderNow = cur in THUNDER_CODES, minutesToThunder = minutes, fetchedMs = nowMs)
    } catch (e: Exception) { null }

    val THUNDER_CODES = setOf(95, 96, 99)

    const val WEATHER_URL = "https://api.open-meteo.com/v1/forecast?current=temperature_2m,wind_speed_10m,wind_direction_10m,weather_code&hourly=weather_code&forecast_hours=4&timeformat=unixtime&wind_speed_unit=ms&latitude=%s&longitude=%s"
    const val ELEVATION_URL = "https://epqs.nationalmap.gov/v1/json?x=%s&y=%s&units=Meters&wkid=4326&includeDate=false"
}

/** Height along a hole, from heights measured at the tee and the pin (a straight slope between them). */
object HoleProfile {
    /** Your height and the pin's height relative to you, given the tee and pin heights. Null when either is unknown. */
    fun elevDelta(tee: XY, pin: XY, player: XY, teeElevM: Double?, pinElevM: Double?): Double? {
        if (teeElevM == null || pinElevM == null) return null
        val total = Geo.dist(tee, pin)
        if (total < 1.0) return 0.0
        val progress = (1.0 - Geo.dist(player, pin) / total).coerceIn(0.0, 1.0)
        val mine = teeElevM + (pinElevM - teeElevM) * progress
        return pinElevM - mine
    }
}
