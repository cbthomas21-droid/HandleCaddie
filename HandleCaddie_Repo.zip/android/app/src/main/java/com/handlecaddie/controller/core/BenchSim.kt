package com.handlecaddie.controller.core

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Bench test: feeds the hazard guard made-up GPS positions so the whole chain (guard -> phone -> cart) can be tried with the
 * cart's wheels off the ground and nobody walking anywhere. Pure logic, no clock and no Android, so it is unit-tested.
 *
 * Each scenario is a list of one-second steps. Every step says where "you" are, what the phone's GPS reports (or that no
 * fix arrived), and what the guard MUST be doing afterwards. The expectations are worked out from the map geometry alone,
 * not from the guard's own code, so a wrong guard shows up as a FAIL instead of agreeing with itself.
 */
enum class BenchScenario(val label: String, val blurb: String) {
    APPROACH("Walk at a hazard", "You walk toward the nearest green, water or bunker, stand on it, then walk back. The cart must stop in time and only go again once you are clear."),
    WEAK_GPS("Weak GPS", "You stand still while the GPS error grows to 70 m and recovers. The cart must hold while the position can't be trusted."),
    CROSS("Walk across to the far side", "You walk through a hazard and out the other side, then back. The cart must NOT follow you across it: it waits, and only comes once you are back on its side."),
    DROPOUT("GPS drops out", "You stand still, then GPS fixes stop arriving for 14 s (phone asleep, app stalled). The cart must hold, and go again after fixes return."),
}

enum class Expect { HOLD, FREE, ANY }

/** One simulated second. [accuracyM] null = no GPS fix arrived this second. [check] names the check this step counts toward. */
data class BenchStep(val pos: XY, val accuracyM: Double?, val expect: Expect, val check: String, val note: String)

class BenchPlan(val scenario: BenchScenario, val steps: List<BenchStep>, val targetKind: Hazard, val startDistM: Double) {
    val seconds get() = steps.size
}

object BenchScenarios {
    const val WALK_MS = 1.5          // a brisk walk; one step per second
    private const val WALK_ACC = 4.0

    /** Start point, direction of travel and the target hazard shape, picked so the straight walk meets no other hazard first. */
    private class Geo2(val start: XY, val target: List<XY>, val kind: Hazard, val dir: XY, val pathLen: Double)

    private fun centroid(p: List<XY>) = XY(p.sumOf { it.x } / p.size, p.sumOf { it.y } / p.size)

    private fun pick(map: GreenMap, from: XY, cfg: GuardCfg, followM: Double): Geo2? {
        val shapes = ArrayList<Pair<List<XY>, Hazard>>()
        map.greens.forEach { shapes += it to Hazard.GREEN }; map.water.forEach { shapes += it to Hazard.WATER }; map.bunkers.forEach { shapes += it to Hazard.BUNKER }
        val usable = shapes.filter { it.first.size >= 3 }
        if (usable.isEmpty()) return null
        val (poly, kind) = usable.minByOrNull { hypot(centroid(it.first).x - from.x, centroid(it.first).y - from.y) }!!
        val c = centroid(poly)
        val radius = poly.maxOf { hypot(it.x - c.x, it.y - c.y) }
        val margin = max(cfg.baseMarginM, max(cfg.waterMarginM, cfg.bunkerMarginM)) + 4.0
        val len = radius + margin + followM + 24.0
        val towardFrom = atan2(from.y - c.y, from.x - c.x)
        val angles = listOf(0.0, 30.0, -30.0, 60.0, -60.0, 90.0, -90.0, 120.0, -120.0, 150.0, -150.0, 180.0)
        for (deg in angles) {
            val a = towardFrom + Math.toRadians(deg)
            val dir = XY(-cos(a), -sin(a))                                   // walking from the start toward the shape
            val start = XY(c.x - dir.x * len, c.y - dir.y * len)
            if (pathIsClean(map, start, dir, len, poly)) return Geo2(start, poly, kind, dir, len)
        }
        return null
    }

    /** True when, all along the walk, the chosen shape is the nearest hazard (so its own buffer decides what the guard does). */
    private fun pathIsClean(map: GreenMap, start: XY, dir: XY, len: Double, poly: List<XY>): Boolean {
        var d = 0.0
        while (d <= len) {
            val p = XY(start.x + dir.x * d, start.y + dir.y * d)
            if (Geo.pointInPolygon(p, poly)) return true
            val toTarget = Geo.distToPolygonEdge(p, poly)
            val any = map.distanceM(p) ?: return false
            if (any < toTarget - 0.05) return false
            d += 1.0
        }
        return true
    }

    fun build(scenario: BenchScenario, map: GreenMap, from: XY, cfg: GuardCfg, followM: Double): BenchPlan? {
        if (map.isEmpty) return null
        val g = pick(map, from, cfg, followM) ?: return null
        val steps = when (scenario) {
            BenchScenario.APPROACH -> approach(map, g, cfg, followM)
            BenchScenario.CROSS -> cross(map, g, cfg, followM)
            BenchScenario.WEAK_GPS -> weakGps(g)
            BenchScenario.DROPOUT -> dropout(g)
        }
        return BenchPlan(scenario, steps, g.kind, Geo.dist(g.start, centroid(g.target)))
    }

    // ---------------------------------------------------------------------------------------------------- scenarios
    private fun approach(map: GreenMap, g: Geo2, cfg: GuardCfg, followM: Double): List<BenchStep> {
        val acc = cfg.accuracyFactor * min(WALK_ACC, cfg.maxAccuracyCountedM)
        fun slackWith(p: XY, extra: Double) = map.clearance(p, cfg.baseMarginM + extra, cfg.waterMarginM + extra, cfg.bunkerMarginM + extra)!!.slackM

        // out: walk until 3 steps inside the shape (or the far end)
        val out = ArrayList<XY>()
        var d = 0.0; var inside = 0
        while (d <= g.pathLen + 12.0 && inside < 3) {
            val p = XY(g.start.x + g.dir.x * d, g.start.y + g.dir.y * d)
            out += p
            if (Geo.pointInPolygon(p, g.target)) inside++
            d += WALK_MS
        }
        val steps = ArrayList<BenchStep>()
        for (p in out) {
            val s = slackWith(p, acc)
            val ex = when { s >= followM + 3.0 -> Expect.FREE; s <= -followM - 1.5 -> Expect.HOLD; else -> Expect.ANY }
            val check = if (ex == Expect.FREE) "Free while well clear" else "Held in time on the way in"
            steps += BenchStep(p, WALK_ACC, ex, check, "walking in")
        }
        val end = out.last()
        repeat(3) { steps += BenchStep(end, WALK_ACC, Expect.HOLD, "Stayed held while you stood there", "standing on it") }
        // back: the same path in reverse
        for (p in out.reversed()) {
            val base = slackWith(p, 0.0)
            val ex = when { base < cfg.resumeClearM - 0.01 -> Expect.HOLD; base >= cfg.resumeClearM + 2 * WALK_MS + 1.5 -> Expect.FREE; else -> Expect.ANY }
            val check = if (ex == Expect.HOLD) "Stayed held until you were clear" else "Went again once you were clear"
            steps += BenchStep(p, WALK_ACC, ex, check, "walking back")
        }
        return steps
    }


    /** Through the target and out the far side (the cart must not follow), a pause, then back the way you came. */
    private fun cross(map: GreenMap, g: Geo2, cfg: GuardCfg, followM: Double): List<BenchStep> {
        val acc = cfg.accuracyFactor * min(WALK_ACC, cfg.maxAccuracyCountedM)
        fun slackWith(p: XY, extra: Double) = map.clearance(p, cfg.baseMarginM + extra, cfg.waterMarginM + extra, cfg.bunkerMarginM + extra)!!.slackM
        val c = centroid(g.target)
        val radius = g.target.maxOf { hypot(it.x - c.x, it.y - c.y) }
        val centreAt = Geo.dist(g.start, c)                         // distance along the walk to the middle of the shape
        val endAt = centreAt + radius + 20.0                        // well out the far side

        val out = ArrayList<Pair<XY, Double>>()                     // position, distance walked
        var d = 0.0
        while (d <= endAt) { out += XY(g.start.x + g.dir.x * d, g.start.y + g.dir.y * d) to d; d += WALK_MS }
        val steps = ArrayList<BenchStep>()
        for ((p, at) in out) {
            val ex = if (at >= centreAt) Expect.HOLD else {
                val s = slackWith(p, acc)
                when { s >= followM + 3.0 -> Expect.FREE; s <= -followM - 1.5 -> Expect.HOLD; else -> Expect.ANY }
            }
            val check = if (at >= centreAt) "Did not follow you across" else if (ex == Expect.FREE) "Free while well clear" else "Held in time on the way in"
            steps += BenchStep(p, WALK_ACC, ex, check, if (at >= centreAt) "far side" else "walking in")
        }
        val end = out.last().first
        repeat(4) { steps += BenchStep(end, WALK_ACC, Expect.HOLD, "Did not follow you across", "waiting on the far side") }
        for ((p, at) in out.reversed()) {
            if (at >= centreAt) { steps += BenchStep(p, WALK_ACC, Expect.HOLD, "Did not follow you across", "coming back across"); continue }
            val base = slackWith(p, 0.0)
            val ex = when { base < cfg.resumeClearM - 0.01 -> Expect.HOLD; base >= cfg.resumeClearM + 2 * WALK_MS + 1.5 -> Expect.FREE; else -> Expect.ANY }
            val check = if (ex == Expect.HOLD) "Stayed held until you were clear" else "Went again once you were back on its side"
            steps += BenchStep(p, WALK_ACC, ex, check, "walking back")
        }
        return steps
    }

    private fun weakGps(g: Geo2): List<BenchStep> {
        val p = g.start
        val steps = ArrayList<BenchStep>()
        repeat(10) { steps += BenchStep(p, 5.0, Expect.FREE, "Free while GPS is good", "GPS good (5 m)") }
        repeat(10) { steps += BenchStep(p, 30.0, Expect.ANY, "Free while GPS is good", "GPS poor (30 m)") }
        repeat(10) { steps += BenchStep(p, 70.0, Expect.HOLD, "Held while GPS is lost", "GPS lost (70 m)") }
        repeat(4) { steps += BenchStep(p, 5.0, Expect.ANY, "Went again after GPS recovered", "GPS back (5 m)") }
        repeat(10) { steps += BenchStep(p, 5.0, Expect.FREE, "Went again after GPS recovered", "GPS good (5 m)") }
        return steps
    }

    private fun dropout(g: Geo2): List<BenchStep> {
        val p = g.start
        val steps = ArrayList<BenchStep>()
        repeat(10) { steps += BenchStep(p, 5.0, Expect.FREE, "Free while GPS is arriving", "GPS good") }
        repeat(7) { steps += BenchStep(p, null, Expect.ANY, "Held once fixes stopped", "no fix") }       // watchdog is allowed 5 s plus a little
        repeat(7) { steps += BenchStep(p, null, Expect.HOLD, "Held once fixes stopped", "no fix") }
        repeat(4) { steps += BenchStep(p, 5.0, Expect.ANY, "Went again after fixes returned", "GPS back") }
        repeat(10) { steps += BenchStep(p, 5.0, Expect.FREE, "Went again after fixes returned", "GPS good") }
        return steps
    }
}

/** One line of the result: a check, whether it held for every step, and where it first failed. */
data class BenchCheck(val name: String, val steps: Int, val failedAt: Int?, val detail: String) {
    val passed get() = failedAt == null
}

data class BenchSummary(val checks: List<BenchCheck>) {
    val allPassed get() = checks.isNotEmpty() && checks.all { it.passed }
    val failures get() = checks.count { !it.passed }
}

/**
 * Walks a [BenchPlan] one second at a time and judges the guard after each step. [record] is called with what the guard
 * decided; [cartAgrees] (optional) with whether the cart's own telemetry matches, when a cart is connected.
 */
class BenchRunner(val plan: BenchPlan, private val withCart: Boolean) {
    var tick = 0; private set
    val done get() = tick >= plan.steps.size
    val current get() = plan.steps.getOrNull(tick)

    private val order = LinkedHashMap<String, IntArray>()           // check -> [steps, firstFail(-1)]
    private val detail = HashMap<String, String>()
    private var cartDisagree = 0
    private var cartFailAt = -1
    private var cartSteps = 0
    private var held = false
    private var heldRun = 0

    /** @param hold what the guard decided for this second  @param cartHold the cart's own "holding for green" flag, null if there is no cart to ask */
    fun record(hold: Boolean, cartHold: Boolean?) {
        val s = current ?: return
        val e = order.getOrPut(s.check) { intArrayOf(0, -1) }
        if (s.expect != Expect.ANY) {
            e[0]++
            val bad = (s.expect == Expect.HOLD && !hold) || (s.expect == Expect.FREE && hold)
            if (bad && e[1] < 0) {
                e[1] = tick
                detail[s.check] = "at ${tick}s (${s.note}) the cart was ${if (hold) "held" else "free"} but should have been ${if (s.expect == Expect.HOLD) "held" else "free"}"
            }
        }
        if (withCart && cartHold != null) {
            heldRun = if (hold == held) heldRun + 1 else 1
            held = hold
            if (heldRun >= 3) {                                    // give the cart's telemetry (5 a second) a moment to catch up
                cartSteps++
                if (cartHold != hold) { cartDisagree++; if (cartDisagree >= 3 && cartFailAt < 0) cartFailAt = tick } else cartDisagree = 0
            }
        }
        tick++
    }

    fun summary(): BenchSummary {
        val list = ArrayList<BenchCheck>()
        for ((name, v) in order) if (v[0] > 0) list += BenchCheck(name, v[0], v[1].takeIf { it >= 0 }, detail[name] ?: "")
        if (withCart && cartSteps > 0) list += BenchCheck("The cart agreed with the phone", cartSteps, cartFailAt.takeIf { it >= 0 },
            if (cartFailAt >= 0) "at ${cartFailAt}s the cart's hold flag differed from the phone's decision for 3 s" else "")
        return BenchSummary(list)
    }
}

/** Runs a plan straight through a [GreenGuard], exactly as the service does (fix -> step, no fix -> watchdog). For tests. */
object BenchHarness {
    fun run(plan: BenchPlan, guard: GreenGuard, followM: Double): BenchSummary {
        val r = BenchRunner(plan, withCart = false)
        var hold = false
        while (!r.done) {
            val s = r.current!!
            val now = r.tick * 1000L
            val out = if (s.accuracyM != null) guard.step(s.pos, s.accuracyM, followM, false, now) else guard.staleOut(now, followM, false)
            if (out != null) hold = out.hold
            r.record(hold, null)
        }
        return r.summary()
    }
}
