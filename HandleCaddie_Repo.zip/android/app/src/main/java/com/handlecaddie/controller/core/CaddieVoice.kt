package com.handlecaddie.controller.core

/** The caddie's way of talking. One place for the wording, so the phone report and the display tips sound the same. */
object CaddieVoice {
    /** One line after a hole, by score against par. Short enough for the display. */
    fun holeResult(strokes: Int, par: Int): String {
        if (strokes <= 0) return "Hole done. On to the next."
        if (strokes == 1) return "Hole in one! Unbelievable."
        return when (strokes - par) {
            in Int.MIN_VALUE..-2 -> "Eagle! That's why you carry a caddie."
            -1 -> "Birdie. Nicely played."
            0 -> "Par. Solid."
            1 -> "Bogey. Shake it off."
            2 -> "Double. We'll get it back."
            else -> "Tough one. Next hole's yours."
        }
    }

    /** Shown when the guard stops the cart. [hazard] is the label of what it is stopping for, or null when GPS is lost. */
    fun cartHolding(hazard: String?, lostGps: Boolean): String = when {
        lostGps -> "Cart holding: lost GPS."
        hazard != null -> "Cart holding: $hazard ahead."
        else -> "Cart holding."
    }

    /** You are clear, but the cart's straight way to you would cross the hazard, so it keeps waiting. */
    fun pathBlocked(): String = "Cart waiting: path blocked."

    /** One line of pace advice for the display / watch. */
    fun pace(level: PaceLevel, behindMin: Int, par: Int): String = when (level) {
        PaceLevel.SLIGHT -> "A touch slow, $behindMin min over. Ready golf."
        PaceLevel.BEHIND -> "$behindMin min behind. Hit when ready, skip practice swings."
        PaceLevel.WAY_BEHIND -> "$behindMin min behind. Let's pick it up, par $par pace."
        PaceLevel.AHEAD -> "Ahead of pace. Nice rhythm."
        else -> "On pace."
    }

    fun storm(level: StormLevel, minutes: Int?): String = when (level) {
        StormLevel.TAKE_COVER -> "Lightning risk. Get to a building or car now."
        StormLevel.WATCH -> if (minutes != null && minutes > 0) "Storm possible in ~$minutes min. Watch the sky." else "Storm risk close by. Watch the sky."
        StormLevel.CLEAR -> "All clear."
    }
}
