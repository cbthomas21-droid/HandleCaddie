package com.handlecaddie.controller.core

import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Messages between the phone and the motorised-cart ESP32 (newline-terminated flat JSON over the Nordic UART service,
 * device name "HandleCaddie_Cart"). The cart firmware must implement the rules in CART_PROTOCOL.md; this file is the
 * phone's half.
 *
 *  cart -> phone, about 5 times a second:   {"k":"tel", ...}   telemetry
 *  cart -> phone, on connect and on change: {"k":"cfg", ...}   current settings
 *  phone -> cart:                           mode / joy / set / cmd / hello   (see [CartProtocol])
 */
enum class CartMode(val wire: String, val label: String) {
    PARK("park", "Park"), FOLLOW("follow", "Follow"), MANUAL("manual", "Manual"),
    /** Driving a route the phone sent (round a hazard). The app starts and ends it itself; it is never a button. */
    NAV("nav", "Route");

    companion object { fun fromWire(s: String?) = entries.firstOrNull { it.wire == s } }
}

/** Fault bits (same values as `cart::Fault` in cart_logic.h). Faults stop the cart whatever the app asks. */
object CartFault {
    const val TIP = 1; const val IMU = 2; const val LOWBATT = 4; const val ESTOP = 8

    fun names(bits: Int): List<String> = buildList {
        if (bits and TIP != 0) add("Tip-over detected")
        if (bits and IMU != 0) add("Tilt sensor fault")
        if (bits and LOWBATT != 0) add("Battery low")
        if (bits and ESTOP != 0) add("E-stop pressed")
    }
}

/** Status bits (same values as `cart::Flag`). Not faults: what the cart is doing right now. */
object CartFlag {
    const val FOB_LOST = 1; const val OBSTACLE = 2; const val TOO_FAR = 4; const val DESCENT = 8; const val HOLD = 16; const val SLOWED = 32
    const val AUTO_HOLD = 64      // waiting because the phone said "green ahead"
    const val PAUSED = 128        // paused with the switch on the cart
    const val OVERRIDE = 256      // the switch was used to override an automatic hold

    fun names(bits: Int): List<String> = buildList {
        if (bits and FOB_LOST != 0) add("Fob signal lost")
        if (bits and OBSTACLE != 0) add("Obstacle - stopped")
        if (bits and TOO_FAR != 0) add("You are too far away")
        if (bits and DESCENT != 0) add("Hill descent control")
        if (bits and HOLD != 0) add("Holding on slope")
        if (bits and SLOWED != 0) add("Slowed down")
        if (bits and AUTO_HOLD != 0) add("Waiting - green ahead")
        if (bits and PAUSED != 0) add("Paused with the switch")
        if (bits and OVERRIDE != 0) add("Green hold overridden")
    }
}

data class CartTelemetry(
    val mode: CartMode = CartMode.PARK,
    val packV: Double = 0.0,
    val socPct: Int = 0,
    val pitchDeg: Double = 0.0,        // + = nose up
    val rollDeg: Double = 0.0,         // + = left side up
    val speedMs: Double = 0.0,
    val rangeM: Double? = null,        // distance to the fob, null = no reading
    val bearingDeg: Double? = null,    // + = fob is on the left, null = unknown
    val motorLPct: Int = 0,            // 0..100 (the cart only drives forward)
    val motorRPct: Int = 0,
    val brakePct: Int = 0,
    val obstacleM: Double? = null,     // nearest ultrasonic echo, null = clear
    val tripM: Double = 0.0,
    val totalM: Double = 0.0,
    val faults: Int = 0,
    val flags: Int = 0,
    /** Gyro heading since power-up in degrees, + = counter-clockwise (left). Drifts slowly: only differences over seconds mean anything. */
    val yawDeg: Double? = null,
    /** The cart is able to drive a route (wheel speed sensor wired and the gyro has settled). */
    val navReady: Boolean = false,
    /** Route progress, present while the cart holds a route: x/y in the route frame (m), heading (deg), segment, [NavCode]. */
    val navX: Double? = null, val navY: Double? = null, val navHeadDeg: Double = 0.0, val navSeg: Int = 0, val navCode: Int = 0,
) {
    val speedMph get() = speedMs * 2.23694
    val tripMiles get() = tripM / 1609.344
    val totalMiles get() = totalM / 1609.344
    val slopePct get() = Math.tan(Math.toRadians(pitchDeg)) * 100.0
}

data class CartConfig(
    val followM: Double = 2.5,         // distance the cart keeps from you
    val maxSpeedMs: Double = 1.6,      // follow-mode top speed
    val descentMs: Double = 1.2,       // top speed while going down a slope
    val hillHold: Boolean = true,      // brake held when parked on a slope
    val firmware: String = "",
    val navSupported: Boolean = false, // firmware can drive a route (it still needs the wheel speed sensor)
) {
    companion object {
        const val FOLLOW_MIN_M = 1.5; const val FOLLOW_MAX_M = 6.0
        const val SPEED_MIN_MS = 0.5; const val SPEED_MAX_MS = 1.6
        const val DESCENT_MIN_MS = 0.6; const val DESCENT_MAX_MS = 1.6
        const val MANUAL_MAX_MS = 1.2    // joystick at full deflection, never faster than this
    }
}

/** `ns` codes from the cart (same as `cart::NavState`). */
object NavCode {
    const val IDLE = 0; const val READY = 1; const val RUN = 2; const val ARRIVED = 3
    const val ABORT_LINK = 4; const val ABORT_TIME = 5; const val ABORT_OFFPATH = 6; const val ABORT_STUCK = 7; const val ABORT_YAW = 8
    fun aborted(c: Int) = c >= ABORT_LINK
    fun describe(c: Int) = when (c) {
        IDLE -> "no route"; READY -> "route loaded"; RUN -> "driving the route"; ARRIVED -> "arrived"
        ABORT_LINK -> "stopped: lost contact with the phone"; ABORT_TIME -> "stopped: route took too long"
        ABORT_OFFPATH -> "stopped: drifted off the route"; ABORT_STUCK -> "stopped: not making progress"; ABORT_YAW -> "stopped: turn sensor disagreed with the wheels"
        else -> "unknown ($c)"
    }
}

sealed interface CartMsg {
    data class Tel(val t: CartTelemetry) : CartMsg
    data class Cfg(val c: CartConfig) : CartMsg
    /** The cart's challenge: answer it with [CartAuth.tag]. [paired] = it has a key; [pairing] = its pairing window is open. */
    data class Chal(val nonce: String, val paired: Boolean, val pairing: Boolean, val secure: Boolean = false, val fresh: Boolean = false) : CartMsg
    data class AuthAck(val ok: Boolean, val left: Int?, val waitS: Int?, val notPaired: Boolean) : CartMsg
    /** Reply to a route commit (ok = accepted) or to a refused start of one (ok = false). */
    data class NavAck(val ok: Boolean) : CartMsg
    data class PairAck(val ok: Boolean, val keyHex: String?, val left: Int?, val closed: Boolean) : CartMsg
}

object CartProtocol {

    // ---------------------------------------------------------------- cart -> phone
    fun parse(line: String): CartMsg? = try {
        val o = JSONObject(line.trim())
        when (o.optString("k")) {
            "tel" -> CartMsg.Tel(
                CartTelemetry(
                    mode = CartMode.fromWire(o.optString("m")) ?: CartMode.PARK,
                    packV = o.optDouble("v", 0.0), socPct = o.optInt("soc", 0).coerceIn(0, 100),
                    pitchDeg = o.optDouble("pit", 0.0), rollDeg = o.optDouble("rol", 0.0), speedMs = o.optDouble("spd", 0.0),
                    rangeM = o.optDouble("rng", -1.0).takeIf { it >= 0 },
                    bearingDeg = if (o.has("brg") && !o.isNull("brg")) o.optDouble("brg") else null,
                    motorLPct = o.optInt("ml", 0).coerceIn(0, 100), motorRPct = o.optInt("mr", 0).coerceIn(0, 100),
                    brakePct = o.optInt("bk", 0).coerceIn(0, 100),
                    obstacleM = o.optDouble("obs", -1.0).takeIf { it >= 0 },
                    tripM = o.optDouble("trip", 0.0), totalM = o.optDouble("tot", 0.0),
                    faults = o.optInt("ft", 0), flags = o.optInt("fg", 0),
                    yawDeg = if (o.has("yw")) o.optDouble("yw") else null, navReady = o.optInt("nr", 0) != 0,
                    navX = if (o.has("nx")) o.optDouble("nx") else null, navY = if (o.has("ny")) o.optDouble("ny") else null,
                    navHeadDeg = o.optDouble("nh", 0.0), navSeg = o.optInt("ni", 0), navCode = o.optInt("ns", 0),
                ),
            )
            "cfg" -> CartMsg.Cfg(
                CartConfig(
                    followM = o.optDouble("fd", 2.5).coerceIn(CartConfig.FOLLOW_MIN_M, CartConfig.FOLLOW_MAX_M),
                    maxSpeedMs = o.optDouble("vm", 1.6).coerceIn(CartConfig.SPEED_MIN_MS, CartConfig.SPEED_MAX_MS),
                    descentMs = o.optDouble("dc", 1.2).coerceIn(CartConfig.DESCENT_MIN_MS, CartConfig.DESCENT_MAX_MS),
                    hillHold = o.optInt("hh", 1) != 0, firmware = o.optString("fw", ""), navSupported = o.optInt("nav", 0) != 0,
                ),
            )
            "chal" -> o.optString("n", "").takeIf { it.isNotEmpty() }?.let { CartMsg.Chal(it, o.optInt("paired", 0) != 0, o.optInt("pairing", 0) != 0, o.optInt("sec", 0) != 0, o.optInt("fresh", 0) != 0) }
            "nav" -> CartMsg.NavAck(o.optInt("ok", 0) != 0)
            "auth" -> CartMsg.AuthAck(
                o.optInt("ok", 0) != 0, if (o.has("left")) o.optInt("left") else null, if (o.has("wait")) o.optInt("wait") else null, o.optInt("np", 0) != 0,
            )
            "paired" -> CartMsg.PairAck(
                o.optInt("ok", 0) != 0, o.optString("key", "").takeIf { it.isNotEmpty() }, if (o.has("left")) o.optInt("left") else null, o.optInt("closed", 0) != 0,
            )
            else -> null
        }
    } catch (e: Exception) { null }

    // ---------------------------------------------------------------- phone -> cart (each ends with '\n')
    private fun n(x: Double) = String.format(java.util.Locale.US, "%.2f", x)

    fun hello() = "{\"k\":\"hello\"}\n"

    /** The answer to the cart's challenge. [keyHex] is the 32-character key made when the phone was paired. */
    fun auth(keyHex: String, nonce: String) = "{\"k\":\"auth\",\"h\":\"${CartAuth.tag(keyHex, nonce)}\"}\n"

    /** Pairing: the 6-digit PIN shown on the cart's screen. */
    /** [pin] null = no PIN: allowed only right after Android paired with the cart using that PIN as its passkey (the cart checks). */
    fun pair(pin: String?) = if (pin == null) "{\"k\":\"pair\"}\n" else "{\"k\":\"pair\",\"pin\":\"$pin\"}\n"

    /** Automatic hold (green ahead): the cart stops and waits while staying in Follow, until hold off or the switch overrides it. */
    fun hold(on: Boolean) = "{\"k\":\"hold\",\"on\":${if (on) 1 else 0}}\n"
    fun mode(m: CartMode) = "{\"k\":\"mode\",\"m\":\"${m.wire}\"}\n"

    /** Route over BLE: stage points 0..n-1 (x ahead, y left, metres, in the frame of the cart's pose when the route starts), commit, then mode(NAV). */
    fun navPoint(i: Int, x: Double, y: Double) = "{\"k\":\"navp\",\"i\":$i,\"x\":${String.format(java.util.Locale.US, "%.2f", x)},\"y\":${String.format(java.util.Locale.US, "%.2f", y)}}\n"
    fun navCommit(n: Int, speedMs: Double) = "{\"k\":\"navgo\",\"n\":$n,\"v\":${n(speedMs)}}\n"
    /** Keep-alive while the phone is watching a route; the cart stops by itself 2.5 s after the last one. */
    fun navHeartbeat() = "{\"k\":\"navhb\"}\n"

    /** Joystick: x = steer (-1 left .. +1 right), y = forward speed (0..1). The cart only drives forward. */
    fun joy(x: Double, y: Double) = "{\"k\":\"joy\",\"x\":${n(x.coerceIn(-1.0, 1.0))},\"y\":${n(y.coerceIn(0.0, 1.0))}}\n"

    fun setFollow(m: Double) = "{\"k\":\"set\",\"fd\":${n(m.coerceIn(CartConfig.FOLLOW_MIN_M, CartConfig.FOLLOW_MAX_M))}}\n"
    fun setMaxSpeed(v: Double) = "{\"k\":\"set\",\"vm\":${n(v.coerceIn(CartConfig.SPEED_MIN_MS, CartConfig.SPEED_MAX_MS))}}\n"
    fun setDescent(v: Double) = "{\"k\":\"set\",\"dc\":${n(v.coerceIn(CartConfig.DESCENT_MIN_MS, CartConfig.DESCENT_MAX_MS))}}\n"
    fun setHillHold(on: Boolean) = "{\"k\":\"set\",\"hh\":${if (on) 1 else 0}}\n"

    /** [name]: "stop" (go to Park now), "clear" (clear tip / sensor faults, only works when level), "level" (set the tilt zero), "trip0". */
    fun cmd(name: String) = "{\"k\":\"cmd\",\"c\":\"$name\"}\n"
}

/** Unit helpers: the cart works in metres and m/s, the app shows feet and mph. */
object CartUnits {
    fun metresToFeet(m: Double) = m * 3.28084
    fun feetToMetres(ft: Double) = ft / 3.28084
    fun metresToYards(m: Double) = m * 1.09361
    fun yardsToMetres(y: Double) = y / 1.09361
    fun msToMph(v: Double) = v * 2.23694
    fun mphToMs(v: Double) = v / 2.23694
}

/**
 * A toy cart for DEMO mode, so the Cart page can be tried with no hardware. It is NOT a model of the real cart:
 * just enough behaviour (follow keeps its distance, descent slows it, manual obeys the stick) to see the page work.
 * Deterministic: time is the only input.
 */
class CartSimulator {
    private var t = 0.0
    private var speed = 0.0
    private var range = 4.0
    private var trip = 0.0
    private var total = 4_800.0
    private var volts = 20.6
    private var steerBearing = 0.0

    var config = CartConfig()
    var mode = CartMode.PARK
    var joyX = 0.0
    var joyY = 0.0
    var hold = false             // automatic hold from the green guard

    fun reset() { speed = 0.0; trip = 0.0; mode = CartMode.PARK; joyX = 0.0; joyY = 0.0; hold = false }
    fun newTrip() { trip = 0.0 }

    fun step(dt: Double): CartTelemetry {
        t += dt
        val pitch = 7.0 * sin(t / 9.0)
        val roll = 1.5 * sin(t / 3.1)
        val downhill = pitch < -4.0
        var flags = 0

        // you walk for 10 s, stand for 6 s
        val personV = if ((t % 16.0) < 10.0) 1.1 else 0.0

        var target = 0.0
        when (mode) {
            CartMode.PARK -> target = 0.0
            CartMode.FOLLOW -> {
                val err = range - config.followM
                target = if (err > 0.35 || speed > 0.05 && err > 0.0) min(config.maxSpeedMs, 0.9 * err + 0.8 * personV) else 0.0
                if (range > 12.0) { target = 0.0; flags = flags or CartFlag.TOO_FAR }
            }
            CartMode.MANUAL -> target = joyY * CartConfig.MANUAL_MAX_MS
            CartMode.NAV -> target = 0.0          // the toy cart does not drive routes (the demo uses NavSimCart for that)
        }
        if (hold && mode == CartMode.FOLLOW) { target = 0.0; flags = flags or CartFlag.AUTO_HOLD }
        if (downhill && mode != CartMode.PARK) { target = min(target, config.descentMs); flags = flags or CartFlag.DESCENT }
        if (mode == CartMode.PARK && abs(pitch) > 3.0 && config.hillHold) flags = flags or CartFlag.HOLD

        val a = if (target > speed) 0.7 else 2.4
        speed = if (target > speed) min(target, speed + a * dt) else max(target, speed - a * dt)

        range = max(0.3, range + (personV - speed) * dt)
        trip += speed * dt; total += speed * dt
        volts = max(15.2, volts - 0.0004 * dt * (1.0 + speed))

        steerBearing = 12.0 * sin(t / 5.0)
        val steer = if (mode == CartMode.MANUAL) joyX * 0.5 else (steerBearing / 90.0).coerceIn(-0.5, 0.5)
        val base = (speed / CartConfig.SPEED_MAX_MS * 100.0)
        val ml = (base * (1.0 + steer)).toInt().coerceIn(0, 100)
        val mr = (base * (1.0 - steer)).toInt().coerceIn(0, 100)

        val soc = (((volts / 5.0) - 3.0) / 1.2 * 100.0).toInt().coerceIn(0, 100)
        return CartTelemetry(
            mode = mode, packV = volts, socPct = soc, pitchDeg = pitch, rollDeg = roll, speedMs = speed,
            rangeM = range, bearingDeg = if (mode == CartMode.FOLLOW) steerBearing else null,
            motorLPct = ml, motorRPct = mr, brakePct = if (flags and CartFlag.HOLD != 0) 100 else 0,
            obstacleM = null, tripM = trip, totalM = total, faults = 0, flags = flags,
        )
    }
}
