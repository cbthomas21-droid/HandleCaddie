package com.handlecaddie.controller.core

import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

// ===================================================================================================================
// Where the ball went: sideways miss, per-club miss patterns
// ===================================================================================================================

object Shots {
    /** Sideways distance of [to] from the line [from]->[pin], in yards. + = right of the line as you face the pin. (Frame: +x east, +y south.) */
    fun lateralYd(from: XY, to: XY, pin: XY): Int {
        val d = Geo.dist(from, pin)
        if (d < 1.0) return 0
        val ux = (pin.x - from.x) / d; val uy = (pin.y - from.y) / d
        val rx = -uy; val ry = ux                                  // right-hand side in a frame whose y points down/south
        return Geo.yards((to.x - from.x) * rx + (to.y - from.y) * ry).roundToInt()
    }

    /** True when the tee-to-pin line is a fair picture of the way to play: every mapped fairway lies close to it. No fairway data = unknown = false. */
    fun straightHole(h: Hole, maxOffM: Double = 30.0): Boolean {
        if (h.fairways.isEmpty()) return false
        val a = h.tee; val b = h.pin
        val len = Geo.dist(a, b)
        if (len < 1.0) return false
        for (ring in h.fairways) for (p in ring) {
            val t = (((p.x - a.x) * (b.x - a.x) + (p.y - a.y) * (b.y - a.y)) / (len * len)).coerceIn(0.0, 1.0)
            if (Geo.dist(p, XY(a.x + t * (b.x - a.x), a.y + t * (b.y - a.y))) > maxOffM) return false
        }
        return true
    }
}

/** How one club misses. [meanYd] + = right. [significant] only when the pattern is bigger than GPS noise would make by chance. */
data class MissPattern(val clubKey: String, val n: Int, val meanYd: Double, val sdYd: Double, val rightCount: Int, val avgToPinYd: Int?, val significant: Boolean) {
    val aimYd get() = (-meanYd).roundToInt().coerceIn(-20, 20)
}

object Dispersion {
    const val MIN_SHOTS = 5
    private const val MIN_BIAS_YD = 4.0

    fun forClub(shots: List<ShotRecord>, key: String): MissPattern? {
        val s = shots.filter { it.club == key && it.offLineYd != null && it.accuracyM <= Learning.MAX_ACCURACY_M }.takeLast(Learning.MAX_SHOTS)
        if (s.size < MIN_SHOTS) return null
        val v = s.map { it.offLineYd!!.toDouble() }
        val mean = v.average()
        val sd = sqrt(v.sumOf { (it - mean) * (it - mean) } / (v.size - 1))
        val se = sd / sqrt(v.size.toDouble())
        val prox = s.mapNotNull { it.toPinYd }.takeIf { it.size >= MIN_SHOTS }?.average()?.roundToInt()
        return MissPattern(key, v.size, mean, sd, v.count { it > 0 }, prox, abs(mean) >= MIN_BIAS_YD && abs(mean) >= 2.0 * se)
    }

    /** "Your 7 Iron tends to miss right (9 yd on average). Aim about 9 yd left." Null when there is no real pattern. */
    fun aimTip(shots: List<ShotRecord>, key: String, name: String): String? {
        val m = forClub(shots, key)?.takeIf { it.significant } ?: return null
        val side = if (m.meanYd > 0) "right" else "left"
        val aimSide = if (m.meanYd > 0) "left" else "right"
        return "Your $name tends to miss $side (${abs(m.meanYd).roundToInt()} yd on average). Aim about ${abs(m.aimYd)} yd $aimSide of the pin."
    }

    /** One line per club with enough tracked shots, biggest bias first. */
    fun lines(bag: List<Club>, shots: List<ShotRecord>): List<String> {
        val out = ArrayList<Pair<Double, String>>()
        for (c in bag) {
            if (c.isPutter) continue
            val m = forClub(shots, Clubs.key(c)) ?: continue
            val txt = if (m.significant) "${c.name}: misses ${if (m.meanYd > 0) "right" else "left"} by ${abs(m.meanYd).roundToInt()} yd on average (${m.rightCount} of ${m.n} right)"
                      else "${c.name}: no steady miss (spread ±${m.sdYd.roundToInt()} yd)"
            out += (if (m.significant) abs(m.meanYd) else 0.0) to txt + (m.avgToPinYd?.let { ", ends $it yd from the pin on average" } ?: "")
        }
        return out.sortedByDescending { it.first }.map { it.second }
    }
}

// ===================================================================================================================
// Pace of play
// ===================================================================================================================

enum class PaceLevel { NOT_STARTED, AHEAD, ON_TIME, SLIGHT, BEHIND, WAY_BEHIND }

data class PaceStatus(
    val level: PaceLevel = PaceLevel.NOT_STARTED, val behindMin: Int = 0, val targetMin: Int = 255,
    val holeElapsedMin: Int = 0, val holeAllowedMin: Int = 0, val finishMs: Long? = null, val text: String = "", val paused: Boolean = false,
)

/**
 * Time-per-hole coach. The target is minutes for 18 holes; each hole gets a share by its par (par 3 a bit less, par 5 a bit more).
 * "Behind" = how much later than that schedule you started the current hole (or are running over on it). Time stopped with [pause] does not count.
 * Everything takes the wall clock as a parameter, so it is easy to test.
 */
class PaceCoach(var targetMin: Int = 255) {
    var startMs = 0L; private set
    private var holes: List<Pair<Int, Int>> = emptyList()           // hole number, par - in play order
    private val starts = LinkedHashMap<Int, Long>()
    private val ends = HashMap<Int, Long>()
    private var pausedAt = 0L
    private var pausedTotal = 0L
    private var lastTipHole = -10
    private var lastTipLevel = PaceLevel.ON_TIME
    val started get() = startMs > 0L
    val paused get() = pausedAt > 0L

    fun setHoles(l: List<Pair<Int, Int>>) { holes = l }
    fun reset() { startMs = 0L; starts.clear(); ends.clear(); pausedAt = 0L; pausedTotal = 0L; lastTipHole = -10; lastTipLevel = PaceLevel.ON_TIME }

    private fun adj(now: Long) = now - pausedTotal - (if (pausedAt > 0) now - pausedAt else 0L)
    private fun weight(par: Int) = when { par <= 3 -> 0.88; par == 4 -> 1.0; else -> 1.12 }
    private fun allot(par: Int) = targetMin / 18.0 * weight(par)

    fun start(hole: Int, now: Long) { if (!started) { startMs = adj(now); starts[hole] = startMs } }
    fun pause(now: Long) { if (started && !paused) pausedAt = now }
    fun resume(now: Long) { if (paused) { pausedTotal += now - pausedAt; pausedAt = 0L } }

    /** The current hole changed. Closes the previous hole. */
    fun onHole(hole: Int, now: Long) {
        if (!started || hole in starts) return
        val a = adj(now)
        starts.keys.lastOrNull()?.let { ends.putIfAbsent(it, a) }
        starts[hole] = a
    }

    /** The round is over (last hole out). */
    fun finish(now: Long) { if (started) starts.keys.lastOrNull()?.let { ends.putIfAbsent(it, adj(now)) } }

    fun status(now: Long, hole: Int): PaceStatus {
        val idx = holes.indexOfFirst { it.first == hole }
        if (!started || idx < 0) return PaceStatus(targetMin = targetMin)
        val a = adj(now)
        val before = holes.take(idx).sumOf { allot(it.second) }
        val here = allot(holes[idx].second)
        val holeStart = starts[hole] ?: a
        val behindAtStart = (holeStart - startMs) / 60000.0 - before
        val elapsed = (a - startMs) / 60000.0
        val behind = maxOf(behindAtStart, elapsed - (before + here))
        val total = holes.sumOf { allot(it.second) }
        val b = behind.roundToInt()
        val level = when { b <= -5 -> PaceLevel.AHEAD; b < 3 -> PaceLevel.ON_TIME; b < 8 -> PaceLevel.SLIGHT; b < 15 -> PaceLevel.BEHIND; else -> PaceLevel.WAY_BEHIND }
        val onHole = ((a - holeStart) / 60000.0).roundToInt()
        val finish = startMs + pausedTotal + ((total + behind) * 60000).toLong()
        val txt = when (level) {
            PaceLevel.AHEAD -> "${-b} min ahead of pace"
            PaceLevel.ON_TIME -> "On pace"
            else -> "$b min behind pace"
        }
        return PaceStatus(level, b, targetMin, onHole, here.roundToInt(), finish, "$txt  ·  ${here.roundToInt()} min a par ${holes[idx].second}")
    }

    /** Whether to speak up at the start of [hole]: when slipping, or every third hole while behind. At most once per hole. */
    fun shouldTip(st: PaceStatus, hole: Int): Boolean {
        if (st.level < PaceLevel.SLIGHT) { lastTipLevel = st.level; return false }
        val speak = st.level > lastTipLevel || hole - lastTipHole >= 3
        lastTipLevel = st.level
        if (speak) lastTipHole = hole
        return speak
    }

    /** Whole minutes spent per hole so far (the current hole counts up to [now]). */
    fun holeMinutes(now: Long): Map<Int, Int> {
        val a = adj(now)
        return starts.mapValues { (h, s) -> (((ends[h] ?: a) - s) / 60000.0).roundToInt() }
    }

    fun totalMinutes(now: Long): Int = if (!started) 0 else ((((ends.values.maxOrNull() ?: adj(now)).let { if (ends.size == starts.size) it else adj(now) }) - startMs) / 60000.0).roundToInt()

    fun encode(): String = "$targetMin|$startMs|$pausedTotal|$pausedAt|" + starts.entries.joinToString(";") { "${it.key}:${it.value}:${ends[it.key] ?: 0}" }
    fun restore(s: String?) {
        reset()
        val p = s?.split("|") ?: return
        if (p.size < 5) return
        targetMin = p[0].toIntOrNull() ?: targetMin
        startMs = p[1].toLongOrNull() ?: return
        pausedTotal = p[2].toLongOrNull() ?: 0L; pausedAt = p[3].toLongOrNull() ?: 0L
        for (e in p[4].split(";")) {
            val f = e.split(":"); if (f.size < 3) continue
            val h = f[0].toIntOrNull() ?: continue
            starts[h] = f[1].toLongOrNull() ?: continue
            f[2].toLongOrNull()?.takeIf { it > 0 }?.let { ends[h] = it }
        }
    }
}

// ===================================================================================================================
// Lightning
// ===================================================================================================================

enum class StormLevel { CLEAR, WATCH, TAKE_COVER }
data class StormForecast(val thunderNow: Boolean, val minutesToThunder: Int?, val fetchedMs: Long)
data class StormStatus(val level: StormLevel = StormLevel.CLEAR, val text: String = "", val allClearAtMs: Long? = null, val minutes: Int? = null)

/**
 * Not a lightning detector: the phone cannot sense lightning. It combines the weather forecast (thunderstorm now or within the hour)
 * with the old rule everybody can use: count the seconds from a flash to the bang. Under 30 s (about 6 miles), or any thunder heard,
 * means take cover, and stay under cover until 30 minutes after the last thunder.
 */
class LightningGuard(private val quietMs: Long = 30 * 60_000L, private val forecastValidMs: Long = 25 * 60_000L) {
    private var fc: StormForecast? = null
    private var lastDangerMs = 0L
    private var lastWatchMs = 0L
    private var watchMin: Int? = null

    fun forecast(f: StormForecast?) { fc = f; if (f?.thunderNow == true) lastDangerMs = maxOf(lastDangerMs, f.fetchedMs) }
    fun reset() { fc = null; lastDangerMs = 0L; lastWatchMs = 0L }

    /** You saw a flash and counted [seconds] before the bang. 0 or null = thunder with no count (treated as close). */
    fun flashToBang(seconds: Int?, nowMs: Long) {
        if (seconds == null || seconds <= 30) lastDangerMs = nowMs else if (seconds <= 60) lastWatchMs = nowMs
    }

    /** Miles from a flash-to-bang count (sound travels about a mile in 5 seconds). */
    fun miles(seconds: Int) = seconds / 5.0

    fun status(nowMs: Long): StormStatus {
        val f = fc?.takeIf { nowMs - it.fetchedMs <= forecastValidMs }
        if (lastDangerMs > 0 && nowMs - lastDangerMs < quietMs) {
            val until = lastDangerMs + quietMs
            return StormStatus(StormLevel.TAKE_COVER, "Lightning risk. Get inside a building or a car, not under a tree, and leave the clubs. Wait until ${hhmm(until, nowMs)} (30 min after the last thunder).", until, 0)
        }
        val m = f?.minutesToThunder
        if (m != null && m <= 60) return StormStatus(StormLevel.WATCH, "Thunderstorm in the forecast for your area in about $m min. Keep an eye on the sky and know where shelter is.", null, m)
        if (lastWatchMs > 0 && nowMs - lastWatchMs < 15 * 60_000L) return StormStatus(StormLevel.WATCH, "Thunder heard some way off (6-12 miles). If it gets closer, take cover.", null, null)
        return StormStatus()
    }

    private fun hhmm(t: Long, nowMs: Long): String {
        val mins = ((t - nowMs) / 60000L).toInt().coerceAtLeast(1)
        return "about $mins min from now"
    }
}

// ===================================================================================================================
// Learn an unmapped course while playing it
// ===================================================================================================================

/** What has been seen of one hole of an unmapped course: average tee and pin positions and how many sightings. */
data class LearnedHole(val n: Int, val teeLat: Double = 0.0, val teeLon: Double = 0.0, val teeN: Int = 0, val pinLat: Double = 0.0, val pinLon: Double = 0.0, val pinN: Int = 0) {
    val known get() = teeN > 0 && pinN > 0
}

object LearnedCourses {
    private const val OUTLIER_M = 40.0
    private const val MAX_N = 8

    /** Fold one sighting into the list. A sighting far from the average (after two or more) is ignored: someone skipped a hole, or the GPS jumped. */
    fun merge(list: List<LearnedHole>, o: LearnObs): List<LearnedHole> {
        val cur = list.firstOrNull { it.n == o.hole } ?: LearnedHole(o.hole)
        var h = cur
        o.tee?.let { t ->
            if (h.teeN < 2 || Geo.distanceM(LatLon(h.teeLat, h.teeLon), t) <= OUTLIER_M) {
                val n = minOf(h.teeN, MAX_N)
                h = h.copy(teeLat = (h.teeLat * n + t.lat) / (n + 1), teeLon = (h.teeLon * n + t.lon) / (n + 1), teeN = minOf(h.teeN + 1, MAX_N))
            }
        }
        o.pin?.let { p ->
            if (h.pinN < 2 || Geo.distanceM(LatLon(h.pinLat, h.pinLon), p) <= OUTLIER_M) {
                val n = minOf(h.pinN, MAX_N)
                h = h.copy(pinLat = (h.pinLat * n + p.lat) / (n + 1), pinLon = (h.pinLon * n + p.lon) / (n + 1), pinN = minOf(h.pinN + 1, MAX_N))
            }
        }
        return (list.filter { it.n != o.hole } + h).sortedBy { it.n }
    }

    fun encode(l: List<LearnedHole>) = l.joinToString(";") { "${it.n},${it.teeLat},${it.teeLon},${it.teeN},${it.pinLat},${it.pinLon},${it.pinN}" }
    fun decode(s: String?): List<LearnedHole> = s.orEmpty().split(";").mapNotNull { r ->
        val p = r.split(","); if (p.size < 7) return@mapNotNull null
        val n = p[0].toIntOrNull()?.takeIf { it in 1..18 } ?: return@mapNotNull null
        LearnedHole(n, p[1].toDoubleOrNull() ?: return@mapNotNull null, p[2].toDoubleOrNull() ?: return@mapNotNull null, p[3].toIntOrNull() ?: 0,
            p[4].toDoubleOrNull() ?: return@mapNotNull null, p[5].toDoubleOrNull() ?: return@mapNotNull null, p[6].toIntOrNull() ?: 0)
    }

    /** A playable course: learned holes have a tee and a pin; the rest are "blind" (scoring and shot distances only). */
    fun build(name: String, centre: LatLon, learned: List<LearnedHole>): Course {
        val holes = (1..18).map { n ->
            val l = learned.firstOrNull { it.n == n }
            if (l != null && l.known) {
                val tee = LatLon(l.teeLat, l.teeLon); val pin = LatLon(l.pinLat, l.pinLon)
                val len = Geo.yards(Geo.distanceM(tee, pin)).roundToInt()
                Hole(n, if (len < 250) 3 else if (len < 470) 4 else 5, len, tee, XY(0.0, 0.0), Geo.toLocal(tee, pin), parMapped = false)
            } else Hole(n, 4, 0, centre, XY(0.0, 0.0), XY(0.0, 0.0), parMapped = false, blind = true)
        }
        return Course(name, holes, learning = true)
    }

    fun knownCount(l: List<LearnedHole>) = l.count { it.known }
}

// ===================================================================================================================
// Round recap (text you can share)
// ===================================================================================================================

object RoundRecap {
    private fun signed(n: Int) = if (n > 0) "+$n" else if (n == 0) "E" else "$n"
    private fun hm(min: Int) = if (min >= 60) String.format(Locale.US, "%d:%02d", min / 60, min % 60) else "$min min"

    fun build(course: String?, dateText: String, holes: List<HoleStat>, report: Report, holeMinutes: Map<Int, Int>, totalMin: Int, targetMin: Int?,
              roundShots: List<ShotRecord>, bag: List<Club>, weather: String?): String {
        val sb = StringBuilder()
        sb.append("HandleCaddie round recap\n")
        sb.append(listOfNotNull(course?.takeIf { it.isNotBlank() }, dateText).joinToString("  ·  ")).append('\n')
        weather?.let { sb.append(it).append('\n') }
        sb.append('\n').append(report.headline).append('\n')
        if (holes.isNotEmpty()) {
            sb.append('\n')
            val hs = holes.sortedBy { it.hole }
            for (h in hs) {
                val name = when {
                    h.total == 1 -> "ace"; h.toPar <= -2 -> "eagle"; h.toPar == -1 -> "birdie"; h.toPar == 0 -> "par"; h.toPar == 1 -> "bogey"; h.toPar == 2 -> "double"; else -> "+${h.toPar}"
                }
                sb.append(String.format(Locale.US, "%2d  par %d  %2d  %s", h.hole, h.par, h.total, name))
                holeMinutes[h.hole]?.takeIf { it > 0 }?.let { sb.append("  ($it min)") }
                sb.append('\n')
            }
            val front = hs.filter { it.hole <= 9 }; val back = hs.filter { it.hole > 9 }
            if (front.isNotEmpty() && back.isNotEmpty()) sb.append("Out ${front.sumOf { it.total }}  In ${back.sumOf { it.total }}\n")
            sb.append("Total ${hs.sumOf { it.total }} (${signed(hs.sumOf { it.toPar })})\n")
        }
        if (report.lines.isNotEmpty()) { sb.append('\n'); report.lines.forEach { sb.append("- ").append(it).append('\n') } }
        if (totalMin > 0) {
            sb.append("\nTime: ${hm(totalMin)}")
            if (holes.size >= 3) sb.append(String.format(Locale.US, " (%.1f min a hole)", totalMin.toDouble() / holes.size))
            if (targetMin != null) { val t = targetMin * holes.size / 18; val d = totalMin - t; sb.append(if (abs(d) < 5) ", right on pace" else if (d > 0) ", ${d} min over target" else ", ${-d} min under target") }
            sb.append('\n')
            val slow = holeMinutes.filter { it.value > 0 }.maxByOrNull { it.value }
            if (slow != null && holeMinutes.size >= 3) sb.append("Slowest hole: ${slow.key} (${slow.value} min)\n")
        }
        val tracked = roundShots.size
        if (tracked > 0) {
            sb.append("\nShots tracked: $tracked\n")
            val misses = Dispersion.lines(bag, roundShots.map { it })
            roundShots.mapNotNull { it.offLineYd }.takeIf { it.size >= 8 }?.let { v ->
                val right = v.count { it > 0 }
                sb.append("Misses: $right right, ${v.size - right} left of the line to the pin\n")
            }
            misses.take(2).forEach { sb.append("- ").append(it).append('\n') }
        }
        report.focus?.let { sb.append('\n').append(it).append('\n') }
        return sb.toString().trimEnd() + "\n"
    }
}
