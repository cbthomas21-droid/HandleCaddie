package com.handlecaddie.controller.data

import android.content.Context
import com.handlecaddie.controller.core.Club
import com.handlecaddie.controller.core.Clubs
import com.handlecaddie.controller.core.CourseChoice
import com.handlecaddie.controller.core.GuardCfg
import com.handlecaddie.controller.core.HoleStat
import com.handlecaddie.controller.core.RoundSummary
import com.handlecaddie.controller.core.StatsCodec
import com.handlecaddie.controller.core.Learning
import com.handlecaddie.controller.core.ShotRecord
import com.handlecaddie.controller.core.RoundFormat
import com.handlecaddie.controller.core.SwingProfile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The saved course + format choice. */
data class SavedSetup(val course: CourseChoice?, val format: RoundFormat, val confirmed: Boolean)

/** Small SharedPreferences store: today's round + course choice (survive the app being killed) and the club bag. */
class RoundStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("round", Context.MODE_PRIVATE)
    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    // ---- scores (tied to a course, so another course never inherits them)
    fun saveRound(hole: Int, scores: List<Int>, courseKey: String?) {
        prefs.edit().putString("day", today()).putInt("hole", hole).putString("scores", scores.joinToString(","))
            .putString("scoreCourse", courseKey).apply()
    }

    /** Scores saved earlier today for [courseKey], or null (a new day or a different course starts a new round). */
    fun loadScores(courseKey: String?): List<Int>? {
        if (prefs.getString("day", null) != today()) return null
        if (prefs.getString("scoreCourse", null) != courseKey) return null
        val l = prefs.getString("scores", null)?.split(",")?.mapNotNull { it.toIntOrNull() } ?: return null
        return if (l.size == 18) l else null
    }

    // ---- the key made when this phone was paired with the cart (32 hex characters)
    fun saveCartKey(hex: String) { prefs.edit().putString("cartKey", hex).apply() }
    fun loadCartKey(): String? = prefs.getString("cartKey", null)
    fun clearCartKey() { prefs.edit().remove("cartKey").apply() }
    // ---- the key made when this phone was paired with the display (same idea, separate key)
    fun saveDisplayKey(hex: String) { prefs.edit().putString("displayKey", hex).apply() }
    fun loadDisplayKey(): String? = prefs.getString("displayKey", null)
    fun clearDisplayKey() { prefs.edit().remove("displayKey").apply() }

    fun clearRound() { prefs.edit().remove("day").remove("hole").remove("scores").remove("scoreCourse").remove("holeStats").remove("pace").remove("paceCourse").remove("paceDay").apply() }

    // ---- per-hole stats of today's round (same day + course rule as the scores) and the saved round history
    fun saveHoleStats(courseKey: String, stats: List<HoleStat>) { prefs.edit().putString("holeStats", StatsCodec.encodeHoles(stats)).putString("holeStatsCourse", courseKey).apply() }
    fun loadHoleStats(courseKey: String): List<HoleStat>? {
        if (prefs.getString("day", null) != today() || prefs.getString("holeStatsCourse", null) != courseKey) return null
        return StatsCodec.decodeHoles(prefs.getString("holeStats", null))
    }
    fun saveHistory(l: List<RoundSummary>) { prefs.edit().putString("history", StatsCodec.encodeHistory(l.takeLast(200))).apply() }
    fun loadHistory(): List<RoundSummary> = StatsCodec.decodeHistory(prefs.getString("history", null))

    // ---- course + format
    fun saveSetup(course: CourseChoice?, format: RoundFormat, confirmed: Boolean) {
        val e = prefs.edit().putString("setupDay", today()).putString("format", format.name).putBoolean("confirmed", confirmed)
        if (course == null) e.remove("scType") else {
            e.putString("scType", course.osmType).putLong("scId", course.osmId).putString("scName", course.name)
                .putString("scLat", course.lat.toString()).putString("scLon", course.lon.toString())
        }
        e.apply()
    }

    /** Today's choice, or null on a new day (the player is probably somewhere else). */
    fun loadSetup(): SavedSetup? {
        if (prefs.getString("setupDay", null) != today()) return null
        val type = prefs.getString("scType", null)
        val course = if (type == null) null else CourseChoice(
            type, prefs.getLong("scId", 0), prefs.getString("scName", "") ?: "",
            prefs.getString("scLat", null)?.toDoubleOrNull() ?: 0.0, prefs.getString("scLon", null)?.toDoubleOrNull() ?: 0.0,
        )
        return SavedSetup(course, RoundFormat.fromName(prefs.getString("format", null)), prefs.getBoolean("confirmed", false))
    }

    // ---- par corrections: kept per course for good, not just for today
    fun savePars(courseKey: String, edits: List<Int>) { prefs.edit().putString("pars_$courseKey", edits.joinToString(",")).apply() }
    fun loadPars(courseKey: String): List<Int> =
        prefs.getString("pars_$courseKey", null)?.split(",")?.map { it.toIntOrNull() ?: 0 }.orEmpty()

    // ---- pace of play (today's round only, same day + course rule as the scores) and the target time
    fun savePace(courseKey: String, text: String) { prefs.edit().putString("pace", text).putString("paceCourse", courseKey).putString("paceDay", today()).apply() }
    fun loadPace(courseKey: String): String? =
        if (prefs.getString("paceDay", null) == today() && prefs.getString("paceCourse", null) == courseKey) prefs.getString("pace", null) else null
    fun clearPace() { prefs.edit().remove("pace").remove("paceCourse").remove("paceDay").apply() }
    fun savePaceTarget(min: Int) { prefs.edit().putInt("paceTarget", min).apply() }
    fun loadPaceTarget() = prefs.getInt("paceTarget", 255)

    // ---- what was learned about an unmapped course: kept for good, so the second round there has yardages
    fun saveLearned(courseKey: String, text: String) { prefs.edit().putString("learned_$courseKey", text).apply() }
    fun loadLearned(courseKey: String): String? = prefs.getString("learned_$courseKey", null)

    // ---- bag
    // ---- last known place (so the course list can appear before the first GPS fix)
    fun saveLastPlace(lat: Double, lon: Double) { prefs.edit().putString("lastLat", lat.toString()).putString("lastLon", lon.toString()).apply() }
    fun loadLastPlace(): Pair<Double, Double>? {
        val la = prefs.getString("lastLat", null)?.toDoubleOrNull() ?: return null
        val lo = prefs.getString("lastLon", null)?.toDoubleOrNull() ?: return null
        return la to lo
    }

    fun saveBag(bag: List<Club>) { prefs.edit().putString("bag2", Clubs.encode(bag)).apply() }

    fun loadBag(): List<Club> {
        val new = Clubs.decode(prefs.getString("bag2", null))
        if (new.isNotEmpty()) return new
        return Clubs.decode(prefs.getString("bag", null)).ifEmpty { Clubs.DEFAULT }     // the old format
    }

    // ---- shot history (kept across rounds: this is what the learned distances come from)
    fun saveShots(shots: List<ShotRecord>) { prefs.edit().putString("shots", Learning.encode(shots.takeLast(1500))).apply() }
    fun loadShots(): List<ShotRecord> = Learning.decode(prefs.getString("shots", null))
    fun saveLearn(on: Boolean) { prefs.edit().putBoolean("learn", on).apply() }
    fun loadLearn() = prefs.getBoolean("learn", true)

    // ---- green guard
    fun saveGuard(c: GuardCfg) {
        prefs.edit().putBoolean("guardOn", c.enabled).putFloat("guardMargin", c.baseMarginM.toFloat())
            .putFloat("guardWater", c.waterMarginM.toFloat()).putFloat("guardBunker", c.bunkerMarginM.toFloat()).apply()
    }
    fun loadGuard(): GuardCfg {
        val d = GuardCfg()
        return GuardCfg(
            enabled = prefs.getBoolean("guardOn", true),
            baseMarginM = prefs.getFloat("guardMargin", d.baseMarginM.toFloat()).toDouble(),
            waterMarginM = prefs.getFloat("guardWater", d.waterMarginM.toFloat()).toDouble(),
            bunkerMarginM = prefs.getFloat("guardBunker", d.bunkerMarginM.toFloat()).toDouble(),
        )
    }

    fun saveSwing(p: SwingProfile) { prefs.edit().putString("swing", p.name).apply() }
    fun loadSwing() = SwingProfile.fromName(prefs.getString("swing", null))
}
