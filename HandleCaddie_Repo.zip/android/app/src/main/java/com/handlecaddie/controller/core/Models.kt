package com.handlecaddie.controller.core

enum class Zone(val wire: String?) {
    UNKNOWN(null), TEE("tee"), FAIRWAY("fairway"), ROUGH("rough"), GREEN("green");

    companion object { fun fromWire(s: String?) = entries.firstOrNull { it.wire == s } ?: UNKNOWN }
}

/** Everything about one hole, already projected into local metres around [origin] (the tee). */
data class Hole(
    val number: Int,
    val par: Int,
    val lengthYd: Int,
    val origin: LatLon,
    val tee: XY,
    val pin: XY,
    val teeBoxes: List<List<XY>> = emptyList(),
    val fairways: List<List<XY>> = emptyList(),
    val greens: List<List<XY>> = emptyList(),
    val bunkers: List<List<XY>> = emptyList(),
    val water: List<List<XY>> = emptyList(),
    val parMapped: Boolean = true,      // false when the map had no par tag and it was guessed from the length
    /** True for a hole of an unmapped course that has not been learned yet: the pin position is unknown, so no distances. */
    val blind: Boolean = false,
)

/** Where a hole's par came from. */
enum class ParSource { MAP, ESTIMATED, EDITED }

data class Course(val name: String, val holes: List<Hole>, val learning: Boolean = false) {
    fun hole(n: Int) = holes.firstOrNull { it.number == n }
}

data class Fix(val lat: Double, val lon: Double, val accuracyM: Float, val timeMs: Long) {
    val latLon get() = LatLon(lat, lon)
}

enum class ClubType(val label: String) {
    DRIVER("Drivers"), WOOD("Fairway woods"), HYBRID("Hybrids"), IRON("Irons"), WEDGE("Wedges"), PUTTER("Putters"), OTHER("Other")
}

/**
 * One club in the bag. [brand]/[model]/[loft] are empty/0 for hand-typed clubs. [estimated] is true while
 * [carryYd] is still the loft-based estimate; it turns false as soon as the player types their own number.
 */
data class Club(
    val name: String,
    val carryYd: Int,
    val brand: String = "",
    val model: String = "",
    val loft: Double = 0.0,
    val type: ClubType = ClubType.OTHER,
    val estimated: Boolean = false,
    /** From the player's own recorded shots (see [Learning]); never stored with the bag, recomputed from the shot log. */
    val learnedYd: Int = 0,
    val learnedN: Int = 0,
) {
    val isPutter get() = type == ClubType.PUTTER
    /** The distance the caddie uses: the player's own average once there are enough shots, otherwise the carry. */
    val useYd get() = if (learnedN >= Learning.MIN_SHOTS && learnedYd > 0) learnedYd else carryYd
}

object Clubs {
    /** Starting point until the player builds a bag from the catalog. */
    val DEFAULT = listOf(
        Club("Driver", 230), Club("3 Wood", 210), Club("5 Wood", 195), Club("4 Hybrid", 185),
        Club("5 Iron", 170), Club("6 Iron", 160), Club("7 Iron", 150), Club("8 Iron", 140),
        Club("9 Iron", 130), Club("P Wedge", 118), Club("G Wedge", 100), Club("S Wedge", 85),
        Club("L Wedge", 65),
    )

    /** Shortest club that still reaches [distYd]; the longest club if nothing does. Putters are never recommended. */
    fun recommend(bag: List<Club>, distYd: Int): Club? {
        val usable = bag.filter { !it.isPutter && it.useYd > 0 }
        if (usable.isEmpty()) return null
        val sorted = usable.sortedBy { it.useYd }
        return sorted.firstOrNull { it.useYd >= distYd } ?: sorted.last()
    }

    /** Identity of a club in the shot log: the same name from a different set is a different club. */
    fun key(c: Club) = "${c.name}|${c.brand}|${c.model}"


    /** Longest first, putters last - the order a bag is usually read in. */
    fun sorted(bag: List<Club>) = bag.sortedWith(compareBy<Club> { it.isPutter }.thenByDescending { it.useYd })

    /** Tab-separated lines, one per club. Reads the old "name:carry;name:carry" format too. */
    fun encode(bag: List<Club>): String = bag.joinToString("\n") { c ->
        fun t(x: String) = x.replace('\t', ' ').replace('\n', ' ')
        listOf(t(c.name), c.carryYd, t(c.brand), t(c.model), c.loft, c.type.name, if (c.estimated) 1 else 0).joinToString("\t")
    }

    fun decode(raw: String?): List<Club> {
        if (raw.isNullOrBlank()) return emptyList()
        if (!raw.contains('\t')) {
            return raw.split(";").mapNotNull { p ->
                val i = p.lastIndexOf(':')
                if (i <= 0) null else p.substring(i + 1).toIntOrNull()?.let { Club(p.substring(0, i), it) }
            }
        }
        return raw.split("\n").mapNotNull { line ->
            val f = line.split("\t")
            if (f.size < 2) return@mapNotNull null
            val carry = f[1].toIntOrNull() ?: return@mapNotNull null
            Club(
                name = f[0], carryYd = carry,
                brand = f.getOrElse(2) { "" }, model = f.getOrElse(3) { "" },
                loft = f.getOrNull(4)?.toDoubleOrNull() ?: 0.0,
                type = ClubType.entries.firstOrNull { it.name == f.getOrNull(5) } ?: ClubType.OTHER,
                estimated = f.getOrNull(6) == "1",
            )
        }
    }
}

data class GameState(
    val holeNumber: Int = 1,
    val par: Int = 4,
    val lengthYd: Int = 0,
    val zone: Zone = Zone.UNKNOWN,
    val toPinYd: Int? = null,
    val frontYd: Int? = null,
    val backYd: Int? = null,
    val strokes: Int = 0,          // full swings, not counting putts
    val putts: Int = 0,
    val lastShotYd: Int? = null,
    val clubOut: Boolean = false,
    val club: Club? = null,        // recommended club
    val player: XY? = null,
    val gpsAccuracyM: Float? = null,
    val pars: List<Int> = List(18) { 4 },
    val parSources: List<ParSource> = List(18) { ParSource.MAP },
    val scores: List<Int> = List(18) { 0 },   // 0 = not played
    val roundComplete: Boolean = false,
    val firstHole: Int = 1,        // the round format: 1-18, 1-9 or 10-18
    val lastHole: Int = 18,
) {
    val holeTotal get() = strokes + putts
    val playedHoles get() = scores.count { it > 0 }
    val totalScore get() = scores.sum()
    val toPar get() = scores.indices.filter { scores[it] > 0 }.sumOf { scores[it] - pars[it] }
}
