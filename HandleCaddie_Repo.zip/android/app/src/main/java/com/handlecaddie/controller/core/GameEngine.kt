package com.handlecaddie.controller.core

import kotlin.math.roundToInt

/** One recorded stroke: [club] is a [Clubs.key] (the club the caddie recommended, until the player corrects it). */
data class ShotRecord(
    val hole: Int, val club: String?, val distanceYd: Int, val id: Long = 0, val accuracyM: Float = 0f,
    /** Where the ball was and where it ended up (0.0 = not recorded, older shots). */
    val fromLat: Double = 0.0, val fromLon: Double = 0.0, val toLat: Double = 0.0, val toLon: Double = 0.0,
    /** Sideways miss against the line from the ball to the pin, yards, + = right. Null when that line means nothing (dogleg tee shot, lay-up). */
    val offLineYd: Int? = null,
    /** Distance to the pin where the ball ended up, yards. */
    val toPinYd: Int? = null,
    /** Wall-clock time of the shot (ms), 0 = unknown. */
    val timeMs: Long = 0L,
) {
    val hasPositions get() = fromLat != 0.0 || fromLon != 0.0
}

/** What the engine learned about an unmapped course: [tee] and/or [pin] as seen on [hole]. */
data class LearnObs(val hole: Int, val tee: LatLon?, val pin: LatLon?)

/**
 * All the golf logic, with no Android dependencies and no clock of its own (time comes in with each
 * call), so it is deterministic and unit-testable. Every method returns the lines (each ending in '\n')
 * that should be sent to the ESP32 as a result.
 */
class GameEngine(
    var bag: List<Club> = Clubs.DEFAULT,
    private val minSwingHoldMs: Long = 8_000,    // club out at least this long => counts as a stroke
    private val zoneConfirmFixes: Int = 2,       // fixes in a new zone before we believe it
    private val maxAccuracyM: Float = 25f,       // ignore worse GPS fixes
    private val liveIntervalMs: Long = 1_000,    // at most one live update per second
    private val autoAdvance: Boolean = true,     // move to the next hole when you reach its tee
) {
    var course: Course? = null; private set
    var state = GameState(); private set
    var format: RoundFormat = RoundFormat.ALL_18; private set
    private val parEdits = IntArray(18)          // player's par corrections per hole; 0 = use the map's value
    val shots = ArrayList<ShotRecord>()
    /** Goes up whenever [shots] changes, so the caller knows when to save it. */
    var shotsVersion = 0; private set
    /** Wall clock for stamping shots (the engine has none of its own). */
    var wallClock: () -> Long = { 0L }
    /** Called when the player's position tells us where a tee or a pin of an unmapped hole is. */
    var onLearn: (LearnObs) -> Unit = {}

    // ---- round stats: one record per finished hole, plus what the tee shot did
    private val holeStatMap = LinkedHashMap<Int, HoleStat>()
    private val holeShotCount = HashMap<Int, Int>()                 // swings measured so far per hole, this round
    private val teeNotes = HashMap<Int, Pair<Boolean?, Int>>()      // hole -> (fairway hit?, drive yards)
    var statsVersion = 0; private set

    fun holeStats(): List<HoleStat> = holeStatMap.values.sortedBy { it.hole }

    /** Restore finished-hole stats after the app was killed mid-round. */
    fun restoreHoleStats(l: List<HoleStat>) { holeStatMap.clear(); l.forEach { holeStatMap[it.hole] = it }; statsVersion++ }

    private fun clearRoundStats() { holeStatMap.clear(); holeShotCount.clear(); teeNotes.clear(); statsVersion++ }

    private fun recordHole(n: Int) {
        val tee = teeNotes[n]
        holeStatMap[n] = HoleStat(n, state.par, state.strokes, state.putts, tee?.first, tee?.second)
        statsVersion++
    }

    /** The first measured swing of a hole is the tee shot: note where it ended up. Par 3s only get the distance. */
    private fun noteTee(to: XY, yd: Int) {
        val h = hole
        val zone = if (h != null) classify(to, h) else null
        val fairway = when {
            state.par < 4 -> null
            zone == null || h?.fairways?.isEmpty() == true -> null
            zone == Zone.FAIRWAY || zone == Zone.GREEN -> true
            else -> false
        }
        teeNotes[state.holeNumber] = fairway to yd
    }

    private var hole: Hole? = null
    private var lastFix: Fix? = null
    private var manualGreen = false
    private var zoneCand: Zone? = null
    private var zoneCandCount = 0
    private var pullPos: XY? = null
    private var ballPos: XY? = null
    private val recent = ArrayDeque<Pair<Long, XY>>()
    /** How far the ball is in front of where the club comes out (the cart's follow distance), metres. 0 = no correction. */
    var ballOffsetM = 0.0
    private var pendingOrigin: XY? = null
    private var pendingClub: String? = null
    private var pendingAcc = 0f
    private var nextShotId = 1L
    private var sent: Wire? = null
    private var lastEmitMs = 0L
    private var nextTeeCount = 0

    // ------------------------------------------------------------------ setup
    fun loadCourse(c: Course) {
        course = c
        hole = null
        val ok = Formats.available(c)
        if (format !in ok) format = ok.first()
        parEdits.fill(0)
        clearRoundStats()
        state = state.copy(scores = List(18) { 0 }, roundComplete = false, firstHole = format.first, lastHole = format.last)
        refreshPars()
    }

    private fun parOf(h: Hole) = parEdits.getOrElse(h.number - 1) { 0 }.takeIf { it > 0 } ?: h.par

    private fun refreshPars() {
        val c = course
        state = state.copy(
            pars = List(18) { i -> c?.hole(i + 1)?.let(::parOf) ?: 4 },
            parSources = List(18) { i ->
                val h = c?.hole(i + 1)
                when {
                    parEdits[i] > 0 -> ParSource.EDITED
                    h != null && !h.parMapped -> ParSource.ESTIMATED
                    else -> ParSource.MAP
                }
            },
        )
        hole?.let { state = state.copy(par = parOf(it)) }
    }

    /** Restore the player's saved par corrections for this course (call right after [loadCourse]). */
    fun setParEdits(edits: List<Int>) {
        for (i in 0 until 18) parEdits[i] = edits.getOrElse(i) { 0 }.takeIf { it in 3..6 } ?: 0
        refreshPars()
    }

    fun parEditList(): List<Int> = parEdits.toList()

    /** Correct the par of [holeNo]; any value outside 3..6 clears the correction (back to the map's value). */
    fun setPar(holeNo: Int, par: Int): List<String> {
        if (holeNo !in 1..18) return emptyList()
        parEdits[holeNo - 1] = if (par in 3..6) par else 0
        refreshPars()
        return if (holeNo == state.holeNumber && hole != null) holeMessage() else emptyList()
    }

    /** Hole numbers that exist on the course and are part of the chosen format, in play order. */
    private fun holeNumbers(): List<Int> = course?.holes?.map { it.number }?.filter { it in format }?.sorted().orEmpty()

    /**
     * Switch between 18 / front 9 / back 9. Scores already entered are kept. If the current hole is outside
     * the new range we jump to the nearest hole inside it (or its first hole when there is no GPS fix yet).
     */
    fun setFormat(f: RoundFormat): List<String> {
        format = f
        state = state.copy(firstHole = f.first, lastHole = f.last, roundComplete = false)
        val nums = holeNumbers()
        if (nums.isEmpty()) return emptyList()
        if (hole != null && state.holeNumber in nums) return holeMessage()
        return lastFix?.let { selectNearest(it) } ?: selectHole(nums.first())
    }

    /** Restore the saved shot history (call once at start). */
    fun loadShots(list: List<ShotRecord>) {
        shots.clear(); shots.addAll(list)
        nextShotId = (list.maxOfOrNull { it.id } ?: 0L) + 1
        shotsVersion++
    }

    /** The player says a different club was hit. False if there is no such shot. */
    fun setShotClub(id: Long, clubKey: String): Boolean {
        val i = shots.indexOfFirst { it.id == id }
        if (i < 0) return false
        shots[i] = shots[i].copy(club = clubKey)
        shotsVersion++
        return true
    }

    /** Throw a shot away (mulligan, GPS glitch, not a real stroke). */
    fun deleteShot(id: Long): Boolean = shots.removeAll { it.id == id }.also { if (it) shotsVersion++ }

    /** Restore scores after the app was killed mid-round. */
    fun restoreScores(scores: List<Int>) { if (scores.size == 18) state = state.copy(scores = scores) }

    /** Pick the hole whose tee is closest to [fix] (start of a round, or the first fix after launch). */
    fun selectNearest(fix: Fix): List<String> {
        val c = course ?: return emptyList()
        val h = c.holes.filter { it.number in format }.minByOrNull { Geo.distanceM(fix.latLon, it.origin) } ?: return emptyList()
        lastFix = fix
        return selectHole(h.number)
    }

    fun selectHole(n: Int): List<String> {
        val c = course ?: return emptyList()
        val h = c.hole(n) ?: return emptyList()
        hole = h
        manualGreen = false; zoneCand = null; zoneCandCount = 0
        pullPos = null; ballPos = null; recent.clear(); pendingOrigin = null; pendingClub = null; nextTeeCount = 0
        state = state.copy(
            holeNumber = n, par = parOf(h), lengthYd = h.lengthYd, zone = Zone.UNKNOWN,
            toPinYd = null, frontYd = null, backYd = null, strokes = 0, putts = 0,
            lastShotYd = null, clubOut = false, club = null,
        )
        lastFix?.let { applyFix(it, h, confirmImmediately = true) }
        return holeMessage()
    }

    /** Wipe the scorecard and start again at the hole nearest to us (or hole 1). */
    fun newRound(): List<String> {
        clearRoundStats()
        state = state.copy(scores = List(18) { 0 }, roundComplete = false)
        val f = lastFix
        return if (f != null) selectNearest(f) else selectHole(1)
    }

    /** After a reconnect (or a failed write) the unit needs the whole picture again. */
    fun resend(): List<String> = holeMessage()

    fun nextHole(): List<String> {
        val nums = holeNumbers()
        if (nums.isEmpty()) return emptyList()
        return selectHole(nums.firstOrNull { it > state.holeNumber } ?: nums.first())
    }

    fun prevHole(): List<String> {
        val nums = holeNumbers()
        if (nums.isEmpty()) return emptyList()
        return selectHole(nums.lastOrNull { it < state.holeNumber } ?: nums.last())
    }

    private fun holeMessage(): List<String> {
        val h = hole ?: return emptyList()
        val (msg, wire) = Protocol.holeMessage(h, state)
        sent = wire
        return listOf(msg)
    }

    // ------------------------------------------------------------------ GPS
    fun onFix(fix: Fix): List<String> {
        state = state.copy(gpsAccuracyM = fix.accuracyM)
        if (fix.accuracyM > maxAccuracyM) return emptyList()
        lastFix = fix
        val c = course ?: return emptyList()
        val h = hole ?: return selectNearest(fix)

        val zoneBefore = state.zone
        applyFix(fix, h, confirmImmediately = state.zone == Zone.UNKNOWN)
        checkAutoAdvance(fix, c)?.let { return it }
        return emit(fix.timeMs, force = state.zone != zoneBefore)
    }

    private fun applyFix(fix: Fix, h: Hole, confirmImmediately: Boolean) {
        val p = Geo.toLocal(h.origin, fix.latLon)

        // zone, with a little hysteresis so GPS jitter on a boundary doesn't flicker
        val seen = if (manualGreen) Zone.GREEN else classify(p, h)
        var zone = state.zone
        if (seen == zone) { zoneCand = null; zoneCandCount = 0 }
        else if (confirmImmediately) { zone = seen }
        else {
            if (zoneCand == seen) zoneCandCount++ else { zoneCand = seen; zoneCandCount = 1 }
            if (zoneCandCount >= zoneConfirmFixes) { zone = seen; zoneCand = null; zoneCandCount = 0 }
        }

        var last = state.lastShotYd
        if (zone == Zone.GREEN && state.zone != Zone.GREEN) last = finishShot(p) ?: last

        recent.addLast(fix.timeMs to p)
        while (recent.size > 1 && fix.timeMs - recent.first().first > 8_000) recent.removeFirst()

        state = state.copy(zone = zone, player = p, lastShotYd = last)
        applyDistances(if (state.clubOut) (ballPos ?: p) else p, h)
    }

    /** Distances to the pin and to the front / back of the green along the line of sight, measured from [q]. */
    private fun applyDistances(q: XY, h: Hole) {
        if (h.blind) { state = state.copy(toPinYd = null, frontYd = null, backYd = null, club = null); return }
        val d = Geo.dist(q, h.pin)
        var front: Int? = null; var back: Int? = null
        if (d > 1.0) {
            val dir = XY((h.pin.x - q.x) / d, (h.pin.y - q.y) / d)
            val green = h.greens.minByOrNull { Geo.distToPolygonEdge(h.pin, it) }
            val span = green?.let { Geo.raySpan(q, dir, it) }
            if (span != null && span.first > 0) {
                front = Geo.yards(span.first).roundToInt(); back = Geo.yards(span.second).roundToInt()
            }
        }
        val toPin = Geo.yards(d).roundToInt()
        state = state.copy(
            toPinYd = toPin, frontYd = front, backYd = back,
            club = if (state.zone == Zone.GREEN) null else Clubs.recommend(bag, toPin),
        )
    }

    /**
     * Where the ball probably is when a club comes out. You stand at the cart, which stops about the follow distance
     * BEHIND where you stood at the ball. So: the median of the last few seconds of fixes (one fix is noisy), moved the
     * follow distance toward the pin. Honest limit: GPS is off by several metres, this only removes the systematic part.
     */
    internal fun estimateBall(): XY? {
        val here = state.player ?: return null
        val h = hole ?: return here
        val pts = recent.map { it.second }.filter { Geo.dist(it, here) <= 6.0 }.ifEmpty { listOf(here) }
        fun med(v: List<Double>) = v.sorted().let { if (it.size % 2 == 1) it[it.size / 2] else (it[it.size / 2 - 1] + it[it.size / 2]) / 2 }
        val c = XY(med(pts.map { it.x }), med(pts.map { it.y }))
        val toPin = Geo.dist(c, h.pin)
        val off = ballOffsetM.coerceIn(0.0, 6.0)
        if (off <= 0.0 || toPin < off * 3) return c                 // no correction, or already near the green: don't overshoot it
        return XY(c.x + (h.pin.x - c.x) / toPin * off, c.y + (h.pin.y - c.y) / toPin * off)
    }

    private fun classify(p: XY, h: Hole): Zone = when {
        h.blind -> Zone.UNKNOWN
        h.greens.isEmpty() && Geo.dist(p, h.pin) <= 10.0 -> Zone.GREEN
        h.greens.any { Geo.pointInPolygon(p, it) || Geo.distToPolygonEdge(p, it) <= 2.0 } -> Zone.GREEN
        h.teeBoxes.any { Geo.pointInPolygon(p, it) } || (h.teeBoxes.isEmpty() && Geo.dist(p, h.tee) <= 15.0) -> Zone.TEE
        h.fairways.any { Geo.pointInPolygon(p, it) || Geo.distToPolygonEdge(p, it) <= 1.0 } -> Zone.FAIRWAY
        else -> Zone.ROUGH
    }

    /** Arriving at the next tee moves us on, even if HOLE OUT was never tapped. */
    private fun checkAutoAdvance(fix: Fix, c: Course): List<String>? {
        if (!autoAdvance) return null
        val cur = hole ?: return null
        val next = holeNumbers().firstOrNull { it > cur.number }?.let { c.hole(it) } ?: return null
        if (next.blind || cur.blind) return null            // an unlearned hole has no tee to arrive at
        // at the next tee, and not just standing beside the current green
        val awayFromPin = Geo.dist(Geo.toLocal(cur.origin, fix.latLon), cur.pin) > 40.0
        val atNextTee = awayFromPin && Geo.distanceM(fix.latLon, next.origin) <= 12.0
        nextTeeCount = if (atNextTee) nextTeeCount + 1 else 0
        if (nextTeeCount < 3) return null
        if (state.scores[cur.number - 1] == 0 && state.holeTotal > 0) { saveScore(cur.number, state.holeTotal); recordHole(cur.number) }
        return selectHole(next.number)
    }

    private fun saveScore(holeNo: Int, total: Int) {
        state = state.copy(scores = state.scores.toMutableList().also { it[holeNo - 1] = total })
    }

    // ------------------------------------------------------------------ events from the unit
    fun onDevice(ev: DeviceEvent, nowMs: Long): List<String> {
        when (ev) {
            DeviceEvent.Pull -> {
                state = state.copy(clubOut = true)
                val ball = estimateBall()
                ballPos = ball; pullPos = ball
                if (course?.learning == true && state.strokes == 0 && state.putts == 0 && (holeShotCount[state.holeNumber] ?: 0) == 0 && ball != null && (state.gpsAccuracyM ?: 99f) <= 12f)
                    hole?.let { h -> onLearn(LearnObs(h.number, Geo.toLatLon(h.origin, ball), null)) }
                // the previous stroke ends where the next club comes out of the bag
                if (state.zone != Zone.GREEN) {
                    val d = finishShot(ball)
                    if (d != null) state = state.copy(lastShotYd = d)
                    hole?.let { h -> ball?.let { applyDistances(it, h) } }
                }
            }
            is DeviceEvent.Return -> {
                state = state.copy(clubOut = false)
                if (state.zone != Zone.GREEN && ev.heldMs >= minSwingHoldMs) {
                    state = state.copy(strokes = state.strokes + 1)
                    pendingOrigin = pullPos ?: state.player
                    ballPos = null
                    pendingClub = state.club?.let(Clubs::key)
                    pendingAcc = state.gpsAccuracyM ?: 0f
                }
            }
            is DeviceEvent.Strokes -> state = state.copy(strokes = ev.n.coerceIn(0, 30))
            DeviceEvent.OnGreen -> {
                manualGreen = true; ballPos = null
                val d = finishShot(state.player)
                state = state.copy(zone = Zone.GREEN, club = null, lastShotYd = d ?: state.lastShotYd)
            }
            is DeviceEvent.Putts -> state = state.copy(putts = ev.n.coerceIn(0, 9))
            is DeviceEvent.HoleOut -> return holeOut(ev)
        }
        return emit(nowMs, force = true)
    }

    private fun holeOut(ev: DeviceEvent.HoleOut): List<String> {
        val n = state.holeNumber
        if (course?.learning == true && (state.gpsAccuracyM ?: 99f) <= 12f)
            hole?.let { h -> state.player?.let { p -> onLearn(LearnObs(h.number, null, Geo.toLatLon(h.origin, p))) } }
        state = state.copy(strokes = (ev.strokes - ev.putts).coerceAtLeast(0), putts = ev.putts)
        saveScore(n, ev.strokes)
        recordHole(n)
        val next = holeNumbers().firstOrNull { it > n }
        val tip = Protocol.tip(CaddieVoice.holeResult(ev.strokes, state.par))
        return if (next != null) selectHole(next) + tip          // after the new hole's data, so it shows over the next hole
        else { state = state.copy(roundComplete = true); holeMessage() + tip }
    }

    /** Distance from where the last stroke started to [to]; records it. Null if no stroke is pending. */
    private fun finishShot(to: XY?): Int? {
        val from = pendingOrigin ?: return null
        pendingOrigin = null
        if (to == null) return null
        val yd = Geo.yards(Geo.dist(from, to)).roundToInt()
        if (yd < 5 || yd > 450) return null          // cart barely moved, or a GPS glitch
        val swingNo = (holeShotCount[state.holeNumber] ?: 0) + 1
        val h = hole
        var fromLl = LatLon(0.0, 0.0); var toLl = LatLon(0.0, 0.0)
        var off: Int? = null; var toPin: Int? = null
        if (h != null) {
            fromLl = Geo.toLatLon(h.origin, from); toLl = Geo.toLatLon(h.origin, to)
            if (!h.blind) {
                toPin = Geo.yards(Geo.dist(to, h.pin)).roundToInt()
                if (aimLineMeaningful(h, from, swingNo)) off = Shots.lateralYd(from, to, h.pin)
            }
        }
        shots += ShotRecord(state.holeNumber, pendingClub, yd, nextShotId++, maxOf(pendingAcc, state.gpsAccuracyM ?: 0f),
            fromLl.lat, fromLl.lon, toLl.lat, toLl.lon, off, toPin, wallClock())
        shotsVersion++
        holeShotCount[state.holeNumber] = swingNo
        if (swingNo == 1) noteTee(to, yd)
        return yd
    }

    /** Is "the line from the ball to the pin" the line the player was aiming along? Not for a tee shot round a dogleg, nor a long lay-up. */
    private fun aimLineMeaningful(h: Hole, from: XY, swingNo: Int): Boolean {
        val toPinYd = Geo.yards(Geo.dist(from, h.pin))
        if (toPinYd < 40) return false                                   // chips: the pin is the target but a few yards of GPS noise swamp it
        if (swingNo > 1) return toPinYd <= 230
        if (state.par <= 3) return true
        return Shots.straightHole(h)
    }

    // ------------------------------------------------------------------ output
    private fun emit(nowMs: Long, force: Boolean): List<String> {
        val (msg, wire) = Protocol.liveDiff(sent, Protocol.wireOf(state)) ?: return emptyList()
        if (!force && nowMs - lastEmitMs < liveIntervalMs) return emptyList()
        sent = wire
        lastEmitMs = nowMs
        return listOf(msg)
    }
}
