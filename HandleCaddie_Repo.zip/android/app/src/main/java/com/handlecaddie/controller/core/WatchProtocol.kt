package com.handlecaddie.controller.core

import org.json.JSONObject

/**
 * What the phone and a Wear OS watch say to each other. This file uses nothing but org.json, so the SAME file (same package name)
 * is copied into the watch app. Messages travel over the Wear OS Data Layer (MessageClient).
 *
 *   phone -> watch   "/hc/state"   [WatchState] as JSON, about once a second and on every change
 *   watch -> phone   "/hc/gps"     where the watch is (only when "position from watch" is on)
 *   watch -> phone   "/hc/cmd"     a button press ([WatchCmd])
 *   watch -> phone   "/hc/drive"   a drive button held down (see ManualDrive)
 */
data class WatchState(
    val hole: Int = 0, val par: Int = 0,
    val toPinYd: Int? = null, val playsYd: Int? = null, val club: String? = null,
    /** "park", "follow", "manual", "nav" - or null when no cart is connected. */
    val cartMode: String? = null, val socPct: Int? = null,
    /** Why the cart is waiting ("green ahead"...), or null. */
    val holdText: String? = null,
    /** A short message that deserves a buzz. The watch buzzes when this changes to something new. */
    val alert: String? = null,
    /** Non-null = ask "Move on to hole N? [Go] [Later]". */
    val advanceTo: Int? = null,
    /** True while the phone is using the watch's GPS as your position. */
    val posFromWatch: Boolean = false,
    /** True when the phone allows driving the cart from the watch (switch on the Cart tab). */
    val drive: Boolean = false,
)

enum class WatchCmd(val wire: String) {
    NEXT("next"), BACK("back"), FOLLOW("follow"), PARK("park"), STOP("stop"), ADVANCE_YES("go"), ADVANCE_NO("later"), MANUAL("manual");
    companion object { fun fromWire(s: String?) = entries.firstOrNull { it.wire == s } }
}

object WatchProtocol {
    const val PATH_STATE = "/hc/state"
    const val PATH_GPS = "/hc/gps"
    const val PATH_CMD = "/hc/cmd"
    const val PATH_DRIVE = "/hc/drive"     // watch -> phone: "f" "l" "r" while a drive button is held, "0" on release

    fun encodeState(s: WatchState): String = JSONObject().apply {
        put("h", s.hole); put("p", s.par)
        s.toPinYd?.let { put("d", it) }; s.playsYd?.let { put("pl", it) }; s.club?.let { put("c", it) }
        s.cartMode?.let { put("m", it) }; s.socPct?.let { put("b", it) }
        s.holdText?.let { put("hold", it) }; s.alert?.let { put("al", it) }; s.advanceTo?.let { put("adv", it) }
        if (s.posFromWatch) put("pw", 1)
        if (s.drive) put("dr", 1)
    }.toString()

    fun decodeState(json: String): WatchState? = try {
        val o = JSONObject(json)
        WatchState(
            hole = o.optInt("h"), par = o.optInt("p"),
            toPinYd = if (o.has("d")) o.optInt("d") else null, playsYd = if (o.has("pl")) o.optInt("pl") else null,
            club = o.optString("c").takeIf { it.isNotEmpty() }, cartMode = o.optString("m").takeIf { it.isNotEmpty() },
            socPct = if (o.has("b")) o.optInt("b") else null,
            holdText = o.optString("hold").takeIf { it.isNotEmpty() }, alert = o.optString("al").takeIf { it.isNotEmpty() },
            advanceTo = if (o.has("adv")) o.optInt("adv") else null, posFromWatch = o.optInt("pw", 0) != 0, drive = o.optInt("dr", 0) != 0,
        )
    } catch (e: Exception) { null }

    fun encodeGps(lat: Double, lon: Double, accuracyM: Float): String =
        JSONObject().put("la", lat).put("lo", lon).put("ac", accuracyM.toDouble()).toString()

    /** Returns (lat, lon, accuracy) or null if it is not a sane position. */
    fun decodeGps(json: String): Triple<Double, Double, Float>? = try {
        val o = JSONObject(json)
        val la = o.getDouble("la"); val lo = o.getDouble("lo"); val ac = o.optDouble("ac", 99.0)
        if (la in -90.0..90.0 && lo in -180.0..180.0 && !(la == 0.0 && lo == 0.0) && ac >= 0) Triple(la, lo, ac.toFloat()) else null
    } catch (e: Exception) { null }
}

/** "Move on to hole N?" - raised when a hole is holed out, until it is answered, the hole changes again, or it times out. */
class AdvanceOffer(private val timeoutMs: Long = 10 * 60_000L) {
    private var to: Int? = null
    private var atMs = 0L

    /** [nextHole] = the hole the round moves to, or null after the last hole. */
    fun onHoleOut(nextHole: Int?, nowMs: Long) { to = nextHole; atMs = nowMs }
    fun dismiss() { to = null }
    /** If the app has moved past the offered hole some other way, the offer is stale. */
    fun current(currentHole: Int, nowMs: Long): Int? {
        val t = to ?: return null
        if (nowMs - atMs > timeoutMs || currentHole > t) { to = null; return null }
        return t
    }
}
