package com.handlecaddie.controller.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.handlecaddie.controller.service.CaddieHub
import com.handlecaddie.controller.service.CaddieService
import com.handlecaddie.controller.service.Command
import kotlinx.coroutines.launch

/**
 * The activity owns nothing but the permission flow. All state lives in [CaddieHub] (written by the service),
 * so rotating, backgrounding or killing the UI never disturbs the round.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CaddieTheme {
                val ctx = this
                val needed = remember { requiredPermissions() }
                var granted by remember { mutableStateOf(hasAll(needed)) }
                var denied by remember { mutableStateOf(false) }
                val scope = rememberCoroutineScope()

                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
                    // Notifications are optional (the service still runs); everything else is required.
                    val ok = res.filterKeys { it != Manifest.permission.POST_NOTIFICATIONS }.values.all { it }
                    granted = ok; denied = !ok
                    if (ok) startRound()
                }

                LaunchedEffect(Unit) { if (granted) startRound() }

                HomeScreen(
                    permissionsGranted = granted,
                    permissionsDenied = denied,
                    onGrant = { launcher.launch(needed) },
                    onStart = { if (granted) startRound() else launcher.launch(needed) },
                    onStop = { stopService(Intent(ctx, CaddieService::class.java)) },
                    send = { c: Command -> scope.launch { CaddieHub.commands.emit(c) } },
                )
            }
        }
    }

    private fun startRound() {
        if (!CaddieHub.serviceRunning.value) {
            ContextCompat.startForegroundService(this, Intent(this, CaddieService::class.java))
        }
    }

    private fun hasAll(p: Array<String>) = p.all {
        it == Manifest.permission.POST_NOTIFICATIONS ||
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * API 31+: SCAN + CONNECT (runtime) and location (the service reads GPS, so location is needed anyway).
     * API 30 and below: BLE scanning itself requires location.
     */
    private fun requiredPermissions(): Array<String> {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 31) {
            l += Manifest.permission.BLUETOOTH_SCAN
            l += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        return l.toTypedArray()
    }
}
