package com.handlecaddie.controller.core

/**
 * A club brand as shown in the picker. [initials] + [color] draw a plain badge. These are NOT the companies'
 * logos (those are trademarks): drop your own copy of a logo into res/drawable as `brand_<id>.png` and the
 * app shows it instead of the badge (see README).
 */
data class Brand(val id: String, val name: String, val initials: String, val color: Long)

/** One selectable club of a model: what it is called in the bag, and its loft in degrees. */
data class ClubOption(val name: String, val loft: Double)

class ClubModel(val brandId: String, val model: String, val type: ClubType, val options: List<ClubOption>) {
    val brand get() = Catalog.brand(brandId)
    val title get() = "${brand.name} $model"

    fun toClub(opt: ClubOption, swing: SwingProfile) = Club(
        name = opt.name,
        carryYd = DistanceModel.estimate(opt.loft, type, swing),
        brand = brand.name, model = model, loft = opt.loft, type = type, estimated = type != ClubType.PUTTER,
    )
}

/** How hard the player swings. Scales every estimated carry; typed-in distances are never touched. */
enum class SwingProfile(val label: String, val detail: String, val factor: Double) {
    SLOW("Slower", "driver about 80 mph", 0.88),
    AVERAGE("Average", "driver about 95 mph", 1.00),
    FAST("Faster", "driver about 105 mph", 1.10),
    VERY_FAST("Very fast", "driver about 115 mph", 1.20);

    companion object { fun fromName(s: String?) = entries.firstOrNull { it.name == s } ?: AVERAGE }
}

/**
 * Carry distance from loft. Manufacturers publish lofts, not carry distances, so this is an ESTIMATE: a curve through
 * typical carry yards for an average male amateur (about 95 mph driver), scaled by [SwingProfile]. Stronger lofts
 * therefore go further, which is why a modern 28 degree "7 iron" outcarries a classic 34 degree one.
 */
object DistanceModel {
    // loft (deg) -> carry (yd), average amateur
    private val CURVE = listOf(
        8.0 to 218.0, 10.5 to 212.0, 13.0 to 203.0, 15.0 to 195.0, 18.0 to 181.0, 21.0 to 170.0, 24.0 to 160.0,
        27.0 to 150.0, 30.0 to 142.0, 33.0 to 133.0, 36.0 to 124.0, 40.0 to 114.0, 44.0 to 104.0, 48.0 to 95.0,
        52.0 to 85.0, 56.0 to 75.0, 60.0 to 65.0, 64.0 to 55.0,
    )

    fun estimate(loft: Double, type: ClubType, swing: SwingProfile): Int {
        if (type == ClubType.PUTTER || loft <= 0.0) return 0
        val l = loft.coerceIn(CURVE.first().first, CURVE.last().first)
        val i = CURVE.indexOfLast { it.first <= l }.coerceAtMost(CURVE.size - 2)
        val (x0, y0) = CURVE[i]; val (x1, y1) = CURVE[i + 1]
        val yd = y0 + (y1 - y0) * (l - x0) / (x1 - x0)
        return Math.round(yd * swing.factor).toInt()
    }

    /** Re-estimate the clubs whose distance was never typed by hand (used after the swing setting or a loft changes). */
    fun reestimate(bag: List<Club>, swing: SwingProfile) = bag.map {
        if (it.estimated && it.loft > 0.0) it.copy(carryYd = estimate(it.loft, it.type, swing)) else it
    }
}

object Catalog {
    // Neutral colours, one per brand. Not brand artwork.
    val brands = listOf(
        Brand("taylormade", "TaylorMade", "TM", 0xFF5C6BC0), Brand("callaway", "Callaway", "CW", 0xFF26A69A),
        Brand("titleist", "Titleist", "TL", 0xFF8D6E63), Brand("ping", "Ping", "PG", 0xFFEF5350),
        Brand("cobra", "Cobra", "CB", 0xFFFFA726), Brand("mizuno", "Mizuno", "MZ", 0xFF42A5F5),
        Brand("srixon", "Srixon", "SX", 0xFF66BB6A), Brand("cleveland", "Cleveland", "CV", 0xFFAB47BC),
        Brand("pxg", "PXG", "PXG", 0xFF78909C), Brand("wilson", "Wilson", "WL", 0xFFEC407A),
        Brand("scotty", "Scotty Cameron", "SC", 0xFFBDBDBD), Brand("odyssey", "Odyssey", "OD", 0xFF29B6F6),
        Brand("bettinardi", "Bettinardi", "BT", 0xFFD4E157), Brand("lab", "L.A.B. Golf", "LAB", 0xFFFF7043),
        Brand("kirkland", "Kirkland Signature", "KS", 0xFF9575CD),
    )

    fun brand(id: String) = brands.firstOrNull { it.id == id } ?: Brand(id, id, id.take(2).uppercase(), 0xFF78909C)
    fun brandByName(name: String) = brands.firstOrNull { it.name == name }

    // ---- shared loft sets. Real lofts differ by model and year: these are typical for the model's FAMILY and the
    // ---- player can edit the loft on their own club in the bag. Order: 4,5,6,7,8,9,PW.
    private val IRON_NAMES = listOf("4 Iron", "5 Iron", "6 Iron", "7 Iron", "8 Iron", "9 Iron", "PW")
    private val PLAYERS = listOf(24.0, 27.0, 30.0, 34.0, 38.0, 42.0, 46.0)               // blades / compact cavity backs
    private val PLAYERS_DISTANCE = listOf(21.0, 24.0, 27.0, 31.0, 35.0, 39.0, 43.0)       // forged distance irons
    private val GAME_IMPROVEMENT = listOf(19.0, 22.0, 25.0, 28.0, 32.0, 36.0, 41.0)       // cavity-back game improvement
    private val SUPER_GI = listOf(17.0, 20.0, 23.0, 26.0, 30.0, 34.0, 39.0)               // max game improvement / strong lofts

    private fun drivers(vararg lofts: Double) = lofts.map { ClubOption("Driver", it) }
    private val WOODS = listOf(ClubOption("3 Wood", 15.0), ClubOption("5 Wood", 18.0), ClubOption("7 Wood", 21.0))
    private val HYBRIDS = listOf(ClubOption("3 Hybrid", 19.0), ClubOption("4 Hybrid", 22.0), ClubOption("5 Hybrid", 25.0), ClubOption("6 Hybrid", 28.0))
    private fun irons(lofts: List<Double>) = IRON_NAMES.zip(lofts) { n, l -> ClubOption(n, l) }
    private fun wedges(vararg lofts: Int) = lofts.map { ClubOption("$it Wedge", it.toDouble()) }
    private val PUTTER = listOf(ClubOption("Putter", 3.0))

    private fun d(b: String, m: String, vararg l: Double) = ClubModel(b, m, ClubType.DRIVER, drivers(*l))
    private fun w(b: String, m: String) = ClubModel(b, m, ClubType.WOOD, WOODS)
    private fun h(b: String, m: String) = ClubModel(b, m, ClubType.HYBRID, HYBRIDS)
    private fun i(b: String, m: String, lofts: List<Double>) = ClubModel(b, m, ClubType.IRON, irons(lofts))
    // TaylorMade Qi: 5 iron - SW with its own lofts (21 24 28 32 37 43 49 54), including the AW
    private fun qi() = ClubModel(
        "taylormade", "Qi", ClubType.IRON,
        listOf("5 Iron" to 21.0, "6 Iron" to 24.0, "7 Iron" to 28.0, "8 Iron" to 32.0, "9 Iron" to 37.0, "PW" to 43.0, "AW" to 49.0, "SW" to 54.0)
            .map { ClubOption(it.first, it.second) },
    )
    private fun wg(b: String, m: String, vararg l: Int) = ClubModel(b, m, ClubType.WEDGE, wedges(*l))
    private fun p(b: String, m: String) = ClubModel(b, m, ClubType.PUTTER, PUTTER)

    val models: List<ClubModel> = listOf(
        // ---------------------------------------------------------------- drivers
        d("taylormade", "Qi35", 9.0, 10.5, 12.0), d("taylormade", "Qi10", 9.0, 10.5, 12.0),
        d("taylormade", "Qi10 Max", 9.0, 10.5, 12.0), d("taylormade", "Stealth 2", 9.0, 10.5, 12.0),
        d("callaway", "Elyte", 9.0, 10.5, 12.0), d("callaway", "Paradym Ai Smoke", 9.0, 10.5, 12.0),
        d("callaway", "Paradym", 9.0, 10.5, 12.0), d("callaway", "Rogue ST Max", 9.0, 10.5, 12.0),
        d("titleist", "GT2", 9.0, 10.0, 12.0), d("titleist", "GT3", 8.0, 9.0, 10.0),
        d("titleist", "TSR2", 8.0, 9.0, 10.0, 11.0), d("titleist", "TSR3", 8.0, 9.0, 10.0),
        d("ping", "G440 Max", 9.0, 10.5, 12.0), d("ping", "G430 Max 10K", 9.0, 10.5, 12.0),
        d("ping", "G430 Max", 9.0, 10.5, 12.0), d("ping", "G425 Max", 9.0, 10.5, 12.0),
        d("cobra", "Darkspeed", 9.0, 10.5, 12.0), d("cobra", "Aerojet", 9.0, 10.5, 12.0), d("cobra", "LTDx", 9.0, 10.5, 12.0),
        d("mizuno", "ST-Z 230", 9.5, 10.5, 12.0), d("mizuno", "ST-X 230", 10.5, 12.0),
        d("srixon", "ZX5 Mk II", 9.5, 10.5, 12.0), d("srixon", "ZX7 Mk II", 8.5, 9.5, 10.5),
        d("cleveland", "Launcher XL2", 9.0, 10.5, 12.0), d("pxg", "0811 GEN6", 9.0, 10.5, 12.0),
        d("wilson", "Dynapower", 9.0, 10.5, 12.0),
        // ---------------------------------------------------------------- fairway woods
        w("taylormade", "Qi35"), w("taylormade", "Qi10"), w("taylormade", "Stealth 2"),
        w("callaway", "Elyte"), w("callaway", "Paradym Ai Smoke"), w("callaway", "Paradym"),
        w("titleist", "GT2"), w("titleist", "TSR2"), w("titleist", "TSR3"),
        w("ping", "G440"), w("ping", "G430 Max"), w("cobra", "Darkspeed"), w("cobra", "Aerojet"),
        w("mizuno", "ST-Z 230"), w("srixon", "ZX Mk II"), w("cleveland", "Launcher XL Halo"), w("pxg", "0211"),
        // ---------------------------------------------------------------- hybrids
        h("taylormade", "Qi10 Rescue"), h("taylormade", "Stealth 2 Rescue"),
        h("callaway", "Paradym Ai Smoke Hybrid"), h("callaway", "Apex UW"),
        h("titleist", "GT2 Hybrid"), h("titleist", "TSR2 Hybrid"), h("titleist", "TSR3 Hybrid"),
        h("ping", "G430 Hybrid"), h("ping", "G440 Hybrid"), h("cobra", "Darkspeed Hybrid"),
        h("mizuno", "CLK Hybrid"), h("srixon", "ZX Mk II Hybrid"), h("cleveland", "Launcher XL Halo Hybrid"), h("pxg", "0317 Hybrid"),
        // ---------------------------------------------------------------- irons (4 iron - PW)
        i("titleist", "T100", PLAYERS), i("titleist", "T150", PLAYERS_DISTANCE), i("titleist", "T200", PLAYERS_DISTANCE),
        i("titleist", "T350", GAME_IMPROVEMENT),
        i("taylormade", "P7MC", PLAYERS), i("taylormade", "P790", PLAYERS_DISTANCE), qi(),
        i("taylormade", "Stealth HD", SUPER_GI),
        i("callaway", "Apex MB", PLAYERS), i("callaway", "Apex Pro", PLAYERS_DISTANCE), i("callaway", "Paradym Ai Smoke", GAME_IMPROVEMENT),
        i("callaway", "Paradym Max Fast", SUPER_GI),
        i("ping", "Blueprint S", PLAYERS), i("ping", "i230", PLAYERS_DISTANCE), i("ping", "G430", GAME_IMPROVEMENT),
        i("ping", "G440", GAME_IMPROVEMENT), i("ping", "G430 HL", SUPER_GI),
        i("cobra", "King Forged Tec", PLAYERS_DISTANCE), i("cobra", "Darkspeed", GAME_IMPROVEMENT), i("cobra", "Aerojet", GAME_IMPROVEMENT),
        i("cobra", "Air-X", SUPER_GI),
        i("mizuno", "Pro 225", PLAYERS), i("mizuno", "Pro 245", PLAYERS_DISTANCE), i("mizuno", "JPX925 Hot Metal", GAME_IMPROVEMENT),
        i("srixon", "Z-Forged II", PLAYERS), i("srixon", "ZX7 Mk II", PLAYERS_DISTANCE), i("srixon", "ZX4 Mk II", GAME_IMPROVEMENT),
        i("cleveland", "Halo XL Full-Face", SUPER_GI),
        i("pxg", "0311 P GEN6", PLAYERS_DISTANCE), i("pxg", "0311 XP GEN6", GAME_IMPROVEMENT),
        i("wilson", "Staff Model CB", PLAYERS), i("wilson", "D9", GAME_IMPROVEMENT),
        // ---------------------------------------------------------------- wedges
        wg("titleist", "Vokey SM10", 46, 48, 50, 52, 54, 56, 58, 60, 62),
        wg("cleveland", "RTX 6 ZipCore", 46, 48, 50, 52, 54, 56, 58, 60),
        wg("cleveland", "CBX 4 ZipCore", 48, 50, 52, 54, 56, 58, 60),
        wg("callaway", "Opus", 46, 48, 50, 52, 54, 56, 58, 60), wg("callaway", "Jaws Raw", 48, 50, 52, 54, 56, 58, 60),
        wg("taylormade", "Milled Grind 4", 50, 52, 54, 56, 58, 60), wg("ping", "s159", 50, 52, 54, 56, 58, 60),
        wg("ping", "Glide 4.0", 50, 52, 54, 56, 58, 60), wg("cobra", "Snakebite", 50, 52, 54, 56, 58, 60),
        wg("mizuno", "T24", 46, 48, 50, 52, 54, 56, 58, 60), wg("pxg", "0311 Sugar Daddy II", 50, 52, 54, 56, 58, 60),
        wg("wilson", "Staff Model", 48, 50, 52, 54, 56, 58, 60),
        wg("kirkland", "Gen 3 Forged", 52, 56, 60), wg("kirkland", "Signature (Gen 1-2)", 52, 56, 60),
        // ---------------------------------------------------------------- putters
        p("scotty", "Phantom 11"), p("scotty", "Super Select Newport 2"), p("scotty", "Studio Style Newport 2"),
        p("odyssey", "White Hot OG #7"), p("odyssey", "Ai-ONE Square 2 Square"), p("odyssey", "Tri-Hot 5K Double Wide"),
        p("taylormade", "Spider GT"), p("taylormade", "TP Reserve"),
        p("ping", "PLD Anser"), p("ping", "PLD Milled"), p("ping", "Heppler Tomcat 14"),
        p("bettinardi", "Studio Stock 28"), p("bettinardi", "BB8"),
        // L.A.B. Golf: the ten models listed on labgolf.com/pages/our-putters, plus the OZ.1i
        p("lab", "DF3"), p("lab", "DF2.1"), p("lab", "OZ.1"), p("lab", "OZ.1i"), p("lab", "OZ.1i HS"),
        p("lab", "MEZZ.1"), p("lab", "MEZZ.1 Max"), p("lab", "LINK"), p("lab", "LINK.2.1"), p("lab", "LINK.2.2"), p("lab", "VZN.1i"),
    )

    /** Models of [type], optionally narrowed to one brand, in a stable order (brand list order, then as listed). */
    fun models(type: ClubType, brandId: String? = null): List<ClubModel> =
        models.filter { it.type == type && (brandId == null || it.brandId == brandId) }
            .sortedBy { m -> brands.indexOfFirst { it.id == m.brandId } }

    /** Brands that actually have a model of [type] (a brand with no wedges shouldn't show in the wedge filter). */
    fun brandsFor(type: ClubType) = brands.filter { b -> models.any { it.brandId == b.id && it.type == type } }

    /** True if [club] (same brand, model and name) is already in [bag]. */
    fun inBag(bag: List<Club>, model: ClubModel, opt: ClubOption) =
        bag.any { it.brand == model.brand.name && it.model == model.model && it.name == opt.name }
}
