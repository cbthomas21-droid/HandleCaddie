package com.handlecaddie.controller.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.handlecaddie.controller.ble.BleLink
import com.handlecaddie.controller.core.BenchScenario
import com.handlecaddie.controller.core.CartMode
import com.handlecaddie.controller.core.CartUnits
import com.handlecaddie.controller.service.CaddieHub
import com.handlecaddie.controller.service.Command
import java.text.SimpleDateFormat
import java.util.Locale

private val BenchRed = Color(0xFFFF6B6B)

/**
 * Bench test + decision log, on the Cart page. The test feeds the hazard guard a made-up walk, so the guard,
 * the phone-to-cart link and the cart's own response can all be tried with the cart's wheels off the ground. The decision
 * log is always on, also on the course: it answers "why did the cart stop?".
 */
@Composable
internal fun BenchCard(send: (Command) -> Unit) {
    val b by CaddieHub.bench.collectAsState()
    val guard by CaddieHub.guard.collectAsState()
    val log by CaddieHub.decisionLog.collectAsState()
    val cartMode by CaddieHub.cartMode.collectAsState()
    val demo by CaddieHub.cartDemo.collectAsState()
    val link by CaddieHub.cartLink.collectAsState()
    val auth by CaddieHub.cartAuth.collectAsState()
    val clipboard = LocalClipboardManager.current
    val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    val cartLive = demo || (link is BleLink.LinkState.Connected && auth.state == com.handlecaddie.controller.core.CartAuthState.AUTHED)
    fun yd(m: Double) = Math.round(CartUnits.metresToYards(m)).toInt()

    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("BENCH TEST", color = Cyan, fontWeight = FontWeight.Bold)
            Text(
                "Try the hazard guard without walking anywhere. Lift the cart so the wheels are off the ground, switch it to Follow, then run a test. The phone's real GPS is ignored while a test runs, and your scores and stats are not touched.",
                color = Dim, fontSize = 12.sp,
            )
            when {
                !cartLive -> Text("No cart connected: only the phone side will be checked.", color = Gold, fontSize = 12.sp)
                cartMode != CartMode.FOLLOW -> Text("The cart is in ${cartMode.label}. Switch it to Follow to test how it responds.", color = Gold, fontSize = 12.sp)
                else -> Text("The cart is in Follow: its response is checked too.", color = Green, fontSize = 12.sp)
            }
            if (!guard.hasHazards) Text("Pick a course with mapped greens, water or bunkers first.", color = Gold, fontSize = 12.sp)
            else if (!guard.cfg.enabled) Text("The hazard guard is switched off above. Turn it on to test it.", color = Gold, fontSize = 12.sp)

            BenchScenario.entries.forEach { sc ->
                OutlinedButton(
                    onClick = { send(Command.StartBench(sc)) },
                    enabled = !b.running && guard.hasHazards && guard.cfg.enabled,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(Modifier.fillMaxWidth()) {
                        Text(sc.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(sc.blurb, color = Dim, fontSize = 11.sp)
                    }
                }
            }

            if (b.running) {
                val frac = if (b.total == 0) 0f else (b.second.toFloat() / b.total).coerceIn(0f, 1f)
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF16293B))) {
                    Box(Modifier.fillMaxWidth(frac).height(6.dp).background(Cyan))
                }
                Text("${b.scenario?.label}: second ${b.second} of ${b.total}", color = Color.White, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                Text(
                    "${b.note}  ·  ${b.hazardM?.let { "${yd(it)} yd from the nearest hazard" } ?: "no hazard"}  ·  GPS ${b.accuracyM?.let { "+/-${yd(it)} yd" } ?: "no fix"}",
                    color = Dim, fontSize = 12.sp,
                )
                Text("Guard: ${guard.state.name.lowercase()}${guard.hazard?.let { " (${it.label})" } ?: ""}", color = if (guard.state.name == "HOLDING") Gold else Green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Button(onClick = { send(Command.StopBench) }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = BenchRed)) {
                    Text("Stop the test", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            if (b.message.isNotBlank()) Text(b.message, color = Gold, fontSize = 12.sp)

            b.summary?.let { sum ->
                Spacer(Modifier.height(2.dp))
                Text(
                    if (sum.allPassed) "ALL ${sum.checks.size} CHECKS PASSED" else "${sum.failures} OF ${sum.checks.size} CHECKS FAILED",
                    color = if (sum.allPassed) Green else BenchRed, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                )
                sum.checks.forEach { c ->
                    Text(
                        (if (c.passed) "✓  " else "✗  ") + c.name + (if (c.passed) "" else " - ${c.detail}"),
                        color = if (c.passed) Color.White else BenchRed, fontSize = 12.sp,
                    )
                }
                if (!sum.allPassed) Text("A failed check means the cart would have done the wrong thing. Copy the log below and send it to me.", color = Dim, fontSize = 11.sp)
            }

            // ---- decision log
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("DECISION LOG", color = Cyan, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        clipboard.setText(AnnotatedString(log.joinToString("\n") { fmt.format(it.timeMs) + "  " + it.text }))
                    }, enabled = log.isNotEmpty()) { Text("Copy", fontSize = 12.sp) }
                    OutlinedButton(onClick = { send(Command.ClearLog) }, enabled = log.isNotEmpty()) { Text("Clear", fontSize = 12.sp) }
                }
            }
            if (log.isEmpty()) Text("Nothing yet. When the cart holds, resumes or the switch is used, the reason shows up here, on the course too.", color = Dim, fontSize = 12.sp)
            else log.takeLast(40).asReversed().forEach {
                Text(fmt.format(it.timeMs) + "  " + it.text, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
