package com.handlecaddie.controller.core

import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * What the shot log says about each club: how far it really goes, how consistent it is, whether it has changed lately.
 * Distances are the same ball-to-ball readings [Learning] uses (so they include roll), cleaned the same way.
 */
data class ClubStat(
    val club: Club,
    val n: Int,
    val avgYd: Int,
    /** Typical shot-to-shot variation (standard deviation) in yards; null until there are enough shots to say. */
    val spreadYd: Int?,
    /** The last few shots minus the ones before, in yards; null until there are enough shots to compare. */
    val trendYd: Int?,
    /** What the bag says (typed or estimated), for comparison. */
    val bagYd: Int,
) {
    val name get() = club.name
}

/** [stats] longest club first; [lines] are up to three things worth saying, in the caddie's voice. */
data class ClubReport(val stats: List<ClubStat>, val lines: List<String>)

object ClubInsights {
    const val TREND_MIN_SHOTS = 8
    const val TREND_RECENT = 4
    const val TREND_MIN_YD = 5
    const val SPREAD_MIN_SHOTS = 5
    const val LOOSE_SPREAD_YD = 10
    const val TIGHT_GAP_YD = 4
    const val BIG_GAP_YD = 25

    fun build(bag: List<Club>, shots: List<ShotRecord>): ClubReport {
        val stats = bag.filter { !it.isPutter }.mapNotNull { c ->
            val key = Clubs.key(c)
            val kept = Learning.robust(
                shots.filter { it.club == key && it.accuracyM <= Learning.MAX_ACCURACY_M }.takeLast(Learning.MAX_SHOTS).map { it.distanceYd },
            )
            if (kept.size < Learning.MIN_SHOTS) return@mapNotNull null
            val mean = kept.average()
            val spread = if (kept.size >= 4) sqrt(kept.sumOf { (it - mean) * (it - mean) } / (kept.size - 1)).roundToInt() else null
            val trend = if (kept.size >= TREND_MIN_SHOTS) (kept.takeLast(TREND_RECENT).average() - kept.dropLast(TREND_RECENT).average()).roundToInt() else null
            ClubStat(c, kept.size, mean.roundToInt(), spread, trend, c.carryYd)
        }.sortedByDescending { it.avgYd }

        val lines = ArrayList<String>()

        // 1. the club that has changed the most lately
        stats.filter { it.trendYd != null && abs(it.trendYd) >= TREND_MIN_YD }.maxByOrNull { abs(it.trendYd!!) }?.let {
            val t = it.trendYd!!
            lines += if (t < 0) "Your ${it.name} has been ${-t} yd shorter lately. Worth a look at contact, or the conditions."
            else "Your ${it.name} has been $t yd longer lately. The caddie is using the new number."
        }

        // 2. consistency (needs at least two clubs to compare)
        val withSpread = stats.filter { it.spreadYd != null && it.n >= SPREAD_MIN_SHOTS }
        if (withSpread.size >= 2) {
            val loose = withSpread.maxByOrNull { it.spreadYd!! }!!
            val tight = withSpread.minByOrNull { it.spreadYd!! }!!
            if (loose.spreadYd!! >= LOOSE_SPREAD_YD) lines += "Your ${loose.name} is your loosest club: shots vary by about ${loose.spreadYd} yd either way. A range session would tighten it."
            else if (tight !== loose) lines += "Your ${tight.name} is your most reliable club, within about ${tight.spreadYd} yd."
        }

        // 3. gapping between neighbouring clubs: a big hole is more useful to know about than a tight pair
        var big: Triple<ClubStat, ClubStat, Int>? = null
        var tightPair: Triple<ClubStat, ClubStat, Int>? = null
        for (i in 0 until stats.size - 1) {
            val gap = stats[i].avgYd - stats[i + 1].avgYd
            if (gap >= BIG_GAP_YD && (big == null || gap > big.third)) big = Triple(stats[i], stats[i + 1], gap)
            if (gap <= TIGHT_GAP_YD && (tightPair == null || gap < tightPair.third)) tightPair = Triple(stats[i], stats[i + 1], gap)
        }
        if (big != null) lines += "There's a ${big.third} yd hole between your ${big.first.name} and ${big.second.name}."
        else if (tightPair != null) lines += "Your ${tightPair.first.name} and ${tightPair.second.name} only differ by ${tightPair.third} yd, so one of them isn't doing much."

        return ClubReport(stats, lines.take(3))
    }
}
