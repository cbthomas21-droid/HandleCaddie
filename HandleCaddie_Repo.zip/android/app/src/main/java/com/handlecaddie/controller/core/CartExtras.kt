package com.handlecaddie.controller.core

import kotlin.math.max

/**
 * Will the battery last the round? Learns how much charge a metre of driving costs from the cart's own trip counter and charge
 * reading, then compares with the holes still to play. Honest about not knowing: until it has seen enough driving it says so.
 */
class BatteryForecast(private val reservePct: Int = 15) {
    private var firstTrip = Double.NaN; private var firstSoc = 0
    private var lastTrip = 0.0; private var lastSoc = 0

    data class Out(val holesOnBattery: Double?, val warn: Boolean, val text: String)

    fun reset() { firstTrip = Double.NaN }

    /** Feed every telemetry frame. A trip counter that goes backwards (trip reset) starts the learning again. */
    fun add(tripM: Double, socPct: Int) {
        if (firstTrip.isNaN() || tripM < lastTrip - 1.0) { firstTrip = tripM; firstSoc = socPct }
        lastTrip = tripM; lastSoc = socPct
    }

    /** % of charge per km, or null until the cart has driven 400 m and the reading has fallen by at least 2 points. */
    fun pctPerKm(): Double? {
        if (firstTrip.isNaN()) return null
        val km = (lastTrip - firstTrip) / 1000.0
        val used = firstSoc - lastSoc
        return if (km >= 0.4 && used >= 2) used / km else null
    }

    /**
     * @param holesLeft holes still to play including the current one
     * @param tripPerHoleM observed average driving per hole so far, or null to assume [assumedHoleM]
     */
    fun forecast(socPct: Int, holesLeft: Int, tripPerHoleM: Double?, assumedHoleM: Double = 450.0): Out {
        val rate = pctPerKm() ?: return Out(null, false, "Battery $socPct%. Learning how far a hole costs; a forecast appears after a few holes.")
        val perHoleKm = (tripPerHoleM ?: assumedHoleM) / 1000.0
        val usable = max(0, socPct - reservePct)
        val holes = usable / (rate * perHoleKm)
        val warn = holes < holesLeft
        val text = if (holesLeft <= 0) "Battery $socPct%."
        else if (warn) "Battery $socPct%: enough for about ${holes.toInt()} more holes, ${holesLeft} to play. Plan to carry or recharge."
        else "Battery $socPct%: enough for the rest of the round (about ${holes.toInt()} holes)."
        return Out(holes, warn, text)
    }
}

/**
 * Remembers where the cart was left. While the cart link is up your position is the cart's position (it follows you).
 * When the link drops, that spot is frozen; walking away from it raises the alert.
 */
class CartLocator(private val nearAlertM: Double = 60.0, private val farAlertM: Double = 150.0, private val sustainMs: Long = 8_000L) {
    enum class Alert { NONE, LEFT_BEHIND, FAR_BEHIND }
    data class Out(val lastSeen: XY?, val awayM: Double?, val bearingDeg: Double?, val alert: Alert, val newAlert: Boolean)

    private var lastSeen: XY? = null
    private var armed = false
    private var upMs = 0L; private var lastUpdate = 0L
    private var overSince = -1L
    private var level = Alert.NONE

    /** The user pressed Disconnect, or ended the round: stop watching. */
    fun disarm() { armed = false; level = Alert.NONE; overSince = -1L; lastSeen = null }

    /** Call about once a second (every GPS fix is fine). [player] null = no position. */
    fun update(linkUp: Boolean, player: XY?, nowMs: Long): Out {
        val dt = if (lastUpdate == 0L) 0L else (nowMs - lastUpdate).coerceIn(0L, 5_000L); lastUpdate = nowMs
        if (linkUp) {
            if (player != null) lastSeen = player
            upMs += dt
            if (upMs >= 30_000L) armed = true          // it has really been with us; a quick scan-and-drop is not "a cart"
            level = Alert.NONE; overSince = -1L
            return Out(lastSeen, null, null, Alert.NONE, false)
        }
        val spot = lastSeen
        if (!armed || spot == null || player == null) return Out(if (armed) spot else null, null, null, level, false)
        val away = Geo.dist(player, spot)
        val bearing = Geo.compassDeg(player, spot)
        var fresh = false
        if (away >= nearAlertM) {
            if (overSince < 0) overSince = nowMs
            if (nowMs - overSince >= sustainMs) {
                val want = if (away >= farAlertM) Alert.FAR_BEHIND else Alert.LEFT_BEHIND
                if (want.ordinal > level.ordinal) { level = want; fresh = true }
            }
        } else if (away < nearAlertM * 0.5) { overSince = -1L; level = Alert.NONE }
        return Out(spot, away, bearing, level, fresh)
    }
}
