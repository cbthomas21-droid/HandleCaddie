package com.handlecaddie.controller.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.handlecaddie.controller.ble.BleLink.LinkState
import com.handlecaddie.controller.core.CartAuthState
import com.handlecaddie.controller.core.CartConfig
import com.handlecaddie.controller.core.ManualDrive
import com.handlecaddie.controller.core.CartFault
import com.handlecaddie.controller.core.CartFlag
import com.handlecaddie.controller.core.CartMode
import com.handlecaddie.controller.core.CartUnits
import com.handlecaddie.controller.core.GuardState
import com.handlecaddie.controller.core.CartLocator
import com.handlecaddie.controller.core.NavPhase
import com.handlecaddie.controller.service.CaddieHub
import com.handlecaddie.controller.service.CartCommand
import com.handlecaddie.controller.service.Command
import com.handlecaddie.controller.service.Joy
import kotlin.math.abs
import kotlin.math.hypot

private val Red = Color(0xFFFF6B6B)
private const val TIP_ROLL_DEG = 25.0      // the cart's tip-over limits (SupCfg in cart_logic.h)
private const val TIP_PITCH_DEG = 32.0

/** Motor-control page: link, mode, joystick, follow settings and live readouts. */
@Composable
internal fun CartTab(send: (Command) -> Unit) {
    val link by CaddieHub.cartLink.collectAsStateWithLifecycle()
    val t by CaddieHub.cart.collectAsStateWithLifecycle()
    val cfg by CaddieHub.cartConfig.collectAsStateWithLifecycle()
    val mode by CaddieHub.cartMode.collectAsStateWithLifecycle()
    val fresh by CaddieHub.cartFresh.collectAsStateWithLifecycle()
    val demo by CaddieHub.cartDemo.collectAsStateWithLifecycle()
    val guard by CaddieHub.guard.collectAsStateWithLifecycle()
    val auth by CaddieHub.cartAuth.collectAsStateWithLifecycle()

    val connected = link is LinkState.Connected
    val authed = auth.state == CartAuthState.AUTHED
    val live = (connected && authed) || demo
    val showing = live && fresh          // numbers on screen are current

    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LinkCard(link, demo, connected, authed, send)
        if (connected && !demo && !authed) PairCard(auth.state, auth.message, send)

        if (demo) Banner("DEMO MODE  -  these numbers are simulated. No cart is being controlled.", Gold)
        else if (connected && authed && !fresh) Banner("Connected, waiting for the cart's data…", Gold)

        // ---- faults and what the cart is doing
        if (showing && t.faults != 0) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF4A1F24))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    CartFault.names(t.faults).forEach { Text("⚠  $it", color = Red, fontWeight = FontWeight.Bold) }
                    Text("The cart will not drive until this is cleared.", color = Color.White, fontSize = 13.sp)
                    if (t.faults and (CartFault.TIP or CartFault.IMU) != 0) {
                        OutlinedButton(onClick = { send(CartCommand.Do("clear")) }) { Text("Clear fault") }
                        Text("Works only when the cart is upright and the tilt sensor is reading normally.", color = Dim, fontSize = 12.sp)
                    }
                }
            }
        }
        if (showing && t.flags != 0) {
            Text(CartFlag.names(t.flags).joinToString("   ·   "), color = Gold, fontSize = 13.sp)
        }

        // ---- mode + stop
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("MODE", color = Cyan, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CartMode.entries.filter { it != CartMode.NAV }.forEach { m -> Pill(m.label, selected = mode == m, enabled = live) { send(CartCommand.SetMode(m)) } }
                }
                Text(
                    when (mode) {
                        CartMode.PARK -> "Parked: not driving. Holds its brake on a slope."
                        CartMode.FOLLOW -> "Following your fob at the distance set below."
                        CartMode.MANUAL -> "Drive with the joystick. The cart stops the moment you let go."
                        CartMode.NAV -> "Driving itself round a hazard to you. Tap Park to stop it."
                    },
                    color = Dim, fontSize = 13.sp,
                )
                Button(
                    onClick = { send(CartCommand.Do("stop")) }, Modifier.fillMaxWidth().height(52.dp), enabled = live,
                    colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Color(0xFF3A2A2E)),
                ) { Text("STOP", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                Text("This is a software stop. The red button on the cart is the real emergency stop.", color = Dim, fontSize = 11.sp)
            }
        }

        // ---- battery forecast and "where did I leave it"
        val batt by CaddieHub.battery.collectAsStateWithLifecycle()
        val loc by CaddieHub.locator.collectAsStateWithLifecycle()
        if (showing && batt.text.isNotEmpty()) Text(batt.text, color = if (batt.warn) Gold else Color.White, fontSize = 13.sp, fontWeight = if (batt.warn) FontWeight.Bold else FontWeight.Normal)
        if (loc.awayYd != null && loc.alert != CartLocator.Alert.NONE) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("CART LEFT BEHIND?", color = Gold, fontWeight = FontWeight.Bold)
                    val dir = loc.bearingDeg?.let { listOf("north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west")[(((it + 22.5) % 360.0) / 45.0).toInt()] } ?: ""
                    Text("The cart is not connected. It was last with you ${loc.awayYd} yd away, to the $dir.", color = Color.White, fontSize = 14.sp)
                    Text("This clears by itself when the cart reconnects. Tap Disconnect on the Cart page if you meant to leave it.", color = Dim, fontSize = 11.sp)
                }
            }
        }

        // ---- watch
        val watchOn by CaddieHub.watchConnected.collectAsStateWithLifecycle()
        val posWatch by CaddieHub.positionFromWatch.collectAsStateWithLifecycle()
        val gpsAge by CaddieHub.watchGpsAgeS.collectAsStateWithLifecycle()
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("WATCH", color = Cyan, fontWeight = FontWeight.Bold)
                        Text(if (watchOn) "Watch connected." else "No watch connected. Install the Handle Caddie watch app (see WEAR_SETUP.md).", color = if (watchOn) Green else Dim, fontSize = 12.sp)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Use my watch for my position", color = Color.White, fontSize = 14.sp)
                        Text("Turn this on to leave the phone on the cart (mounted with a clear view of the sky). Your position then comes from the watch, and the phone's own GPS becomes the CART's position: the hazard guard and the go-around use the cart's real position instead of a guess.", color = Dim, fontSize = 11.sp)
                    }
                    Switch(checked = posWatch, onCheckedChange = { send(CartCommand.SetWatchPosition(it)) })
                }
                if (posWatch) {
                    val gpsFollow by CaddieHub.gpsFollowEnabled.collectAsStateWithLifecycle()
                    val cartAge by CaddieHub.cartGpsAgeS.collectAsStateWithLifecycle()
                    Text(cartAge?.let { if (it > 5) "Cart GPS (phone) is $it s old." else "Cart GPS (phone) OK." } ?: "Waiting for the phone's GPS (the cart's position)…", color = if (cartAge == null || cartAge!! > 5) Gold else Color.White, fontSize = 13.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("GPS follow when the fob is lost (experimental)", color = Color.White, fontSize = 14.sp)
                            Text("If the fob goes out of reach or dies, the cart drives after your watch's GPS position and stops about 10 yd short of you. Slower and less precise than the fob; it needs the wheel speed sensor. The switch on the cart always stops it.", color = Dim, fontSize = 11.sp)
                        }
                        Switch(checked = gpsFollow, onCheckedChange = { send(CartCommand.SetGpsFollow(it)) })
                    }
                    val age = gpsAge
                    Text(
                        when { !watchOn -> "Watch not connected - no position, so the cart will hold."; age == null -> "Waiting for the watch's first GPS position…"; age > 5 -> "Watch GPS is $age s old - the cart holds until it recovers."; else -> "Position from the watch ($age s ago)." },
                        color = if (!watchOn || age == null || age > 5) Gold else Color.White, fontSize = 13.sp,
                    )
                }
            }
        }

        // ---- hazard guard
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val cfg = guard.cfg
                fun send3(en: Boolean = cfg.enabled, g: Double = cfg.baseMarginM, w: Double = cfg.waterMarginM, b: Double = cfg.bunkerMarginM) = send(Command.SetGuard(en, g, w, b))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("HAZARD GUARD", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("Stops the cart before it follows you into a green, water or a bunker.", color = Dim, fontSize = 12.sp)
                    }
                    Switch(checked = cfg.enabled, onCheckedChange = { send3(en = it) })
                }
                val yd = guard.cartToHazardM?.let { String.format("%.0f yd", CartUnits.metresToYards(it)) }
                val what = guard.hazard?.label ?: "hazard"
                Text(
                    when (guard.state) {
                        GuardState.OFF -> "Off. Use the switch on the cart to pause it at hazards."
                        GuardState.NO_DATA -> if (!guard.hasHazards) "This course has no green, water or bunker outlines in the map, so the guard can't help here. Use the switch on the cart." else "Waiting for GPS…"
                        GuardState.FREE -> "Watching." + (yd?.let { " Cart is about $it from the nearest $what." } ?: "")
                        GuardState.HOLDING ->
                            if (guard.lostGps) "HOLDING - the phone has lost its GPS position. The cart resumes when GPS recovers."
                            else if (guard.pathBlocked) "HOLDING - you are clear of the $what, but the cart's straight path to you would cross it. It will not cross. Walk back around, or use the switch on the cart."
                            else "HOLDING - $what ahead. The cart resumes when you are well clear of it." + (yd?.let { " (cart $it away)" } ?: "")
                        GuardState.OVERRIDDEN -> "You overrode the hold with the switch. It re-arms once the cart is well clear of the hazard."
                    },
                    color = if (guard.state == GuardState.HOLDING) Gold else Color.White, fontSize = 13.sp,
                    fontWeight = if (guard.state == GuardState.HOLDING) FontWeight.Bold else FontWeight.Normal,
                )
                fun yds(m: Double) = String.format("%.0f", CartUnits.metresToYards(m + 3.0))
                SettingSlider(
                    "Greens", cfg.baseMarginM, 6.0, 20.0, enabled = cfg.enabled,
                    show = { String.format("%.0f yd", CartUnits.metresToYards(it)) },
                    hint = "The cart stops about ${yds(cfg.baseMarginM)} yd short of a green's edge. Greens are easily damaged, so keep this the largest.",
                    unitScale = { CartUnits.metresToYards(it) }, fromUnit = { CartUnits.yardsToMetres(it) },
                    onDone = { send3(g = it) },
                )
                SettingSlider(
                    "Water", cfg.waterMarginM, 6.0, 20.0, enabled = cfg.enabled,
                    show = { String.format("%.0f yd", CartUnits.metresToYards(it)) },
                    hint = "The cart stops about ${yds(cfg.waterMarginM)} yd short of water. Rolling in is the worst outcome, so don't go small.",
                    unitScale = { CartUnits.metresToYards(it) }, fromUnit = { CartUnits.yardsToMetres(it) },
                    onDone = { send3(w = it) },
                )
                SettingSlider(
                    "Bunkers", cfg.bunkerMarginM, 3.0, 15.0, enabled = cfg.enabled,
                    show = { String.format("%.0f yd", CartUnits.metresToYards(it)) },
                    hint = "The cart stops about ${yds(cfg.bunkerMarginM)} yd short of a bunker. Smaller lets it hug the fairway; larger holds more often.",
                    unitScale = { CartUnits.metresToYards(it) }, fromUnit = { CartUnits.yardsToMetres(it) },
                    onDone = { send3(b = it) },
                )
                Text("Poor GPS widens every distance automatically; if the phone loses GPS the cart holds. Works while the cart is connected and in Follow. It relies on phone GPS and the map, which can be off by several yards - the switch on the cart always works.", color = Dim, fontSize = 11.sp)
            }
        }

        // ---- go round hazards (phase 2)
        val navOn by CaddieHub.navEnabled.collectAsStateWithLifecycle()
        val nav by CaddieHub.nav.collectAsStateWithLifecycle()
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("GO AROUND HAZARDS (EXPERIMENTAL)", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("If you walk across a green and leave on the far side, the cart drives round it to you instead of waiting.", color = Dim, fontSize = 12.sp)
                    }
                    Switch(checked = navOn, onCheckedChange = { send(CartCommand.SetNav(it)) })
                }
                if (navOn) {
                    val supported = demo || cfg.navSupported
                    val ready = demo || t.navReady
                    Text(
                        when {
                            nav.phase == NavPhase.WAIT_ACK || nav.phase == NavPhase.STARTING || nav.phase == NavPhase.RUNNING -> nav.text + " - tap Park to stop it."
                            nav.text.isNotEmpty() -> nav.text
                            !live -> "Connect the cart first."
                            !supported -> "This cart's software cannot drive routes yet."
                            !ready -> "Waiting for the cart's wheel speed sensor and turn sensor to be ready."
                            else -> "Ready. It only starts when the cart is holding for a hazard and you are clear of it."
                        },
                        color = if (nav.phase == NavPhase.FAILED) Gold else Color.White, fontSize = 13.sp,
                    )
                    Text("It plans the route from the phone's GPS and the course map and the cart follows it by counting wheel turns, with no GPS of its own, so it can end up several yards off. It keeps well away from the hazard, stops itself if anything looks wrong, and the switch on the cart always cancels it. Needs the wheel speed sensor wired and the wheel size set correctly.", color = Dim, fontSize = 11.sp)
                }
            }
        }

        // ---- drive to the next tee
        val teeOn by CaddieHub.teeDriveEnabled.collectAsStateWithLifecycle()
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("DRIVE TO THE NEXT TEE (EXPERIMENTAL)", color = Cyan, fontWeight = FontWeight.Bold)
                        Text("When you hole out and press Go on the watch, the cart drives itself to the next tee and parks there, instead of following you across the green.", color = Dim, fontSize = 12.sp)
                    }
                    Switch(checked = teeOn, onCheckedChange = { send(CartCommand.SetTeeDrive(it)) })
                }
                if (teeOn) {
                    val navT by CaddieHub.nav.collectAsStateWithLifecycle()
                    val busy = navT.phase == NavPhase.WAIT_ACK || navT.phase == NavPhase.STARTING || navT.phase == NavPhase.RUNNING
                    OutlinedButton(onClick = { send(CartCommand.DriveToTee) }, enabled = live && !busy, modifier = Modifier.fillMaxWidth()) { Text("Send the cart to the next tee now") }
                    Text(
                        when {
                            busy -> navT.text + " - tap Park to stop it."
                            navT.text.isNotEmpty() -> navT.text
                            !live -> "Connect the cart first."
                            else -> "Ready. Hole out, then press Go on the watch (or the button above)."
                        },
                        color = if (navT.phase == NavPhase.FAILED) Gold else Color.White, fontSize = 13.sp,
                    )
                    Text("It uses the same route driving as the go-around: dead reckoning from wheel turns, corrected by the fob or the cart's GPS when they are in reach. It can end up a few yards off the tee, it has no way to see people or carts in its path, and it stops if anything looks wrong. Watch the cart the whole way; the switch on the cart always stops it. Up to about 230 m with the phone riding on the cart (its GPS keeps the route honest), 100 m without; and only to a tee the map knows.", color = Dim, fontSize = 11.sp)
                }
            }
        }

        // ---- bench test + decision log
        BenchCard(send)

        // ---- joystick
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("MANUAL DRIVE", color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
                val canDrive = live && mode == CartMode.MANUAL && (!showing || t.faults == 0)
                Joystick(enabled = canDrive)
                Text(
                    if (canDrive) "Up = go, left / right = steer. Pulling down just stops (the cart only drives forward)."
                    else if (!live) "Connect to the cart to drive it."
                    else "Switch the mode to Manual to use the joystick.",
                    color = Dim, fontSize = 12.sp,
                )
                // speed cap: applies to the joystick, the watch buttons and creep
                val cap by CaddieHub.manualCap.collectAsStateWithLifecycle()
                val mph = cap * CartConfig.MANUAL_MAX_MS * 2.23694
                Column(Modifier.fillMaxWidth()) {
                    Text("Top speed in manual: ${String.format("%.1f", mph)} mph (${String.format("%.2f", cap * CartConfig.MANUAL_MAX_MS)} m/s)", color = Color.White, fontSize = 13.sp)
                    Slider(value = cap.toFloat(), onValueChange = { send(CartCommand.SetManualCap(it.toDouble())) }, valueRange = ManualDrive.CAP_MIN.toFloat()..ManualDrive.CAP_MAX.toFloat())
                    Text("Starts at half speed every time. Keep it low for the first tests.", color = Dim, fontSize = 11.sp)
                }
                // creep: one slow nudge, for lining the cart up at a tee
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { send(CartCommand.Creep(-ManualDrive.STEER)) }, enabled = canDrive, modifier = Modifier.weight(1f)) { Text("Creep left") }
                    OutlinedButton(onClick = { send(CartCommand.Creep(0.0)) }, enabled = canDrive, modifier = Modifier.weight(1f)) { Text("Creep") }
                    OutlinedButton(onClick = { send(CartCommand.Creep(ManualDrive.STEER)) }, enabled = canDrive, modifier = Modifier.weight(1f)) { Text("Creep right") }
                }
                Text("A creep moves the cart about half a metre at a crawl, then stops by itself.", color = Dim, fontSize = 11.sp)
                // watch driving
                val wd by CaddieHub.watchDriveEnabled.collectAsStateWithLifecycle()
                val wConn by CaddieHub.watchConnected.collectAsStateWithLifecycle()
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Drive from the watch", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(if (wConn) "Hold a button on the watch to drive; let go and the cart stops within a second. Off at every start." else "No watch connected (WEAR_SETUP.md).", color = Dim, fontSize = 11.sp)
                    }
                    Switch(checked = wd, onCheckedChange = { send(CartCommand.SetWatchDrive(it)) })
                }
            }
        }

        // ---- readouts
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("LIVE", color = Cyan, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Readout("BATTERY", if (showing) String.format("%.1f V", t.packV) else "--", Modifier.weight(1f),
                        sub = if (showing) "${t.socPct}%" else "", color = if (!showing) Dim else if (t.socPct < 15 || t.faults and CartFault.LOWBATT != 0) Red else if (t.socPct < 30) Gold else Green)
                    Readout("SPEED", if (showing) String.format("%.1f mph", t.speedMph) else "--", Modifier.weight(1f),
                        sub = if (showing) String.format("%.1f m/s", t.speedMs) else "")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    TiltGauge("PITCH", t.pitchDeg, TIP_PITCH_DEG, showing, side = true, Modifier.weight(1f),
                        note = if (!showing) "" else if (t.pitchDeg > 1) "uphill" else if (t.pitchDeg < -1) "downhill" else "level")
                    TiltGauge("ROLL", t.rollDeg, TIP_ROLL_DEG, showing, side = false, Modifier.weight(1f),
                        note = if (!showing) "" else if (t.rollDeg > 1) "left side high" else if (t.rollDeg < -1) "right side high" else "level")
                }
                if (showing) Text(String.format("Slope %.0f%%   ·   tip-over limit: pitch %.0f°, roll %.0f°", t.slopePct, TIP_PITCH_DEG, TIP_ROLL_DEG), color = Dim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Readout("YOU ARE", if (showing && t.rangeM != null) String.format("%.0f ft", CartUnits.metresToFeet(t.rangeM!!)) else "--", Modifier.weight(1f),
                        sub = if (showing) t.bearingDeg?.let { b -> if (abs(b) < 3) "dead ahead" else if (b > 0) String.format("%.0f° left", b) else String.format("%.0f° right", -b) } ?: "direction unknown" else "")
                    Readout("OBSTACLE", if (showing) t.obstacleM?.let { String.format("%.0f ft", CartUnits.metresToFeet(it)) } ?: "clear" else "--", Modifier.weight(1f),
                        color = if (showing && t.flags and CartFlag.OBSTACLE != 0) Red else Color.White)
                }
                Text("MOTORS", color = Dim, fontSize = 11.sp)
                Bar("Left", if (showing) t.motorLPct else 0, showing)
                Bar("Right", if (showing) t.motorRPct else 0, showing)
                Bar("Brake", if (showing) t.brakePct else 0, showing)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Readout("TRIP", if (showing) String.format("%.2f mi", t.tripMiles) else "--", Modifier.weight(1f))
                    Readout("ALL TIME", if (showing) String.format("%.1f mi", t.totalMiles) else "--", Modifier.weight(1f))
                }
                OutlinedButton(onClick = { send(CartCommand.Do("trip0")) }, enabled = live, modifier = Modifier.fillMaxWidth()) { Text("Reset trip") }
            }
        }

        // ---- settings
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("SETTINGS", color = Cyan, fontWeight = FontWeight.Bold)
                SettingSlider(
                    "Follow distance", cfg.followM, CartConfig.FOLLOW_MIN_M, CartConfig.FOLLOW_MAX_M, enabled = live,
                    show = { String.format("%.0f ft", CartUnits.metresToFeet(it)) }, hint = "How far behind you the cart stays.",
                    unitScale = { CartUnits.metresToFeet(it) }, fromUnit = { CartUnits.feetToMetres(it) },
                    onDone = { send(CartCommand.SetFollow(it)) },
                )
                SettingSlider(
                    "Top speed (follow)", cfg.maxSpeedMs, CartConfig.SPEED_MIN_MS, CartConfig.SPEED_MAX_MS, enabled = live,
                    show = { String.format("%.1f mph", CartUnits.msToMph(it)) }, hint = "A brisk walk is about 3 mph.",
                    unitScale = { CartUnits.msToMph(it) }, fromUnit = { CartUnits.mphToMs(it) },
                    onDone = { send(CartCommand.SetMaxSpeed(it)) },
                )
                SettingSlider(
                    "Downhill speed limit", cfg.descentMs, CartConfig.DESCENT_MIN_MS, CartConfig.DESCENT_MAX_MS, enabled = live,
                    show = { String.format("%.1f mph", CartUnits.msToMph(it)) }, hint = "Hill descent control holds the cart to this on slopes.",
                    unitScale = { CartUnits.msToMph(it) }, fromUnit = { CartUnits.mphToMs(it) },
                    onDone = { send(CartCommand.SetDescent(it)) },
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Hold brake on slopes", color = Color.White)
                        Text("When parked on a hill the cart won't roll away.", color = Dim, fontSize = 12.sp)
                    }
                    Switch(checked = cfg.hillHold, onCheckedChange = { send(CartCommand.SetHillHold(it)) }, enabled = live)
                }
                Spacer(Modifier.height(4.dp))
                OutlinedButton(onClick = { send(CartCommand.Do("level")) }, enabled = live, modifier = Modifier.fillMaxWidth()) { Text("Set level (zero the tilt sensor)") }
                Text("Park the cart on flat ground first. Do this if Pitch or Roll doesn't read about 0° on level ground.", color = Dim, fontSize = 12.sp)
                if (cfg.firmware.isNotEmpty()) Text("Cart firmware ${cfg.firmware}", color = Dim, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ------------------------------------------------------------------------------------------ pieces
@Composable
private fun LinkCard(link: LinkState, demo: Boolean, connected: Boolean, authed: Boolean, send: (Command) -> Unit) {
    val (text, color) = when (link) {
        LinkState.Idle -> "Cart: not connected" to Gold
        LinkState.Scanning -> "Cart: searching… (switch it on and stay close)" to Gold
        LinkState.Connecting -> "Cart: connecting…" to Gold
        LinkState.Pairing -> "Cart: pairing - type the PIN from the cart's screen into Android's dialog" to Gold
        is LinkState.Connected -> "Cart: connected" to Green
        is LinkState.Reconnecting -> "Cart: reconnecting (${link.attempt})" to Gold
        is LinkState.Failed -> "Cart: ${link.reason}" to Red
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (demo) "Cart: demo" else text, color = if (demo) Gold else color, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                if (!demo) {
                    if (connected || link is LinkState.Reconnecting || link == LinkState.Scanning || link == LinkState.Connecting) {
                        OutlinedButton(onClick = { send(CartCommand.Disconnect) }) { Text("Disconnect") }
                    } else OutlinedButton(onClick = { send(CartCommand.Connect) }) { Text("Connect") }
                }
            }
            if (link is LinkState.Reconnecting && link.attempt >= 3 && !demo)
                Text("Can't connect? If the cart was reset or paired with another phone, press Forget (once connected) or remove \"HandleCaddie_Cart\" in Android's Bluetooth settings, then pair again.", color = Dim, fontSize = 12.sp)
            if (connected && authed && !demo) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Paired and encrypted. Only this phone can drive the cart.", color = Dim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { send(CartCommand.ForgetKey) }) { Text("Forget") }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Demo mode", color = Color.White)
                    Text("Try this page with no cart (simulated numbers).", color = Dim, fontSize = 12.sp)
                }
                Switch(checked = demo, onCheckedChange = { send(CartCommand.Demo(it)) }, enabled = demo || !connected)
            }
        }
    }
}

/** Shown while connected but not yet accepted: explains why, and takes the PIN from the cart's screen. */
@Composable
private fun PairCard(state: CartAuthState, message: String, send: (Command) -> Unit) {
    var pin by remember { mutableStateOf("") }
    val canType = state == CartAuthState.PAIRING_OPEN
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                when (state) {
                    CartAuthState.CHECKING, CartAuthState.UNKNOWN -> "Checking this phone…"
                    CartAuthState.LOCKED -> "Cart is not listening"
                    CartAuthState.PAIRING_OPEN -> "Pair with the cart"
                    else -> "This phone isn't accepted yet"
                },
                color = Gold, fontWeight = FontWeight.Bold,
            )
            if (message.isNotBlank()) Text(message, color = Color.White, fontSize = 13.sp)
            Text("Until the cart accepts this phone, the controls below stay off and the cart ignores every command.", color = Dim, fontSize = 12.sp)
            if (state == CartAuthState.UNKNOWN || state == CartAuthState.CHECKING)
                Text("The first time, Android asks for a pairing code: type the 6-digit PIN shown on the cart's screen. The link is then encrypted.", color = Dim, fontSize = 12.sp)
            if (canType) {
                OutlinedTextField(
                    value = pin, onValueChange = { v -> pin = v.filter { it.isDigit() }.take(6) }, singleLine = true,
                    label = { Text("6-digit PIN from the cart") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(onClick = { send(CartCommand.Pair(pin)) }, enabled = pin.length == 6, modifier = Modifier.fillMaxWidth()) { Text("Pair") }
            }
        }
    }
}

@Composable
private fun Banner(text: String, color: Color) {
    Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Panel).padding(10.dp))
}

@Composable
private fun Readout(label: String, value: String, modifier: Modifier = Modifier, sub: String = "", color: Color = Color.White) {
    Column(modifier) {
        Text(label, color = Dim, fontSize = 11.sp)
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        if (sub.isNotEmpty()) Text(sub, color = Dim, fontSize = 12.sp)
    }
}

@Composable
private fun Bar(label: String, pct: Int, active: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Dim, fontSize = 12.sp, modifier = Modifier.width(44.dp))
        Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF1C3D5A))) {
            Box(Modifier.fillMaxWidth(pct.coerceIn(0, 100) / 100f).height(10.dp).background(if (active) Cyan else Dim))
        }
        Text(if (active) "$pct%" else "--", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(44.dp).padding(start = 8.dp))
    }
}

/** A small side view (pitch) or rear view (roll) of the cart body tilting, with the angle underneath. */
@Composable
private fun TiltGauge(label: String, deg: Double, limit: Double, active: Boolean, side: Boolean, modifier: Modifier, note: String) {
    val frac = if (active) abs(deg) / limit else 0.0
    val col = if (!active) Dim else if (frac >= 0.85) Red else if (frac >= 0.6) Gold else Color.White
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Dim, fontSize = 11.sp)
        Canvas(Modifier.size(96.dp, 56.dp)) {
            val w = size.width; val h = size.height
            // ground reference
            drawLine(Color(0xFF3A5671), Offset(0f, h * 0.9f), Offset(w, h * 0.9f), strokeWidth = 2f)
            // pitch: front of the cart is on the right, nose up = counter-clockwise. roll: left side up = clockwise.
            val angle = (if (active) (if (side) -deg else deg) else 0.0).toFloat()
            rotate(angle, Offset(w / 2, h * 0.62f)) {
                drawRoundRect(col, Offset(w * 0.12f, h * 0.45f), Size(w * 0.76f, h * 0.22f), CornerRadius(8f))
                if (side) drawRoundRect(col, Offset(w * 0.62f, h * 0.18f), Size(w * 0.06f, h * 0.30f), CornerRadius(3f))   // windscreen post marks the front
                else drawRoundRect(col, Offset(w * 0.44f, h * 0.16f), Size(w * 0.12f, h * 0.30f), CornerRadius(3f))      // rear view: a post in the middle
                drawCircle(col, h * 0.13f, Offset(w * 0.28f, h * 0.76f)); drawCircle(col, h * 0.13f, Offset(w * 0.72f, h * 0.76f))
            }
        }
        Text(if (active) String.format("%+.1f°", deg) else "--", color = col, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        if (note.isNotEmpty()) Text(note, color = Dim, fontSize = 12.sp)
    }
}

/** A slider that shows the value in the units the player thinks in, and only sends when the finger lifts. */
@Composable
private fun SettingSlider(
    title: String, valueSi: Double, minSi: Double, maxSi: Double, enabled: Boolean,
    show: (Double) -> String, hint: String, unitScale: (Double) -> Double, fromUnit: (Double) -> Double, onDone: (Double) -> Unit,
) {
    var local by remember(valueSi) { mutableFloatStateOf(unitScale(valueSi).toFloat()) }
    val lo = unitScale(minSi).toFloat(); val hi = unitScale(maxSi).toFloat()
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = Color.White)
            Text(show(fromUnit(local.toDouble())), color = Cyan, fontWeight = FontWeight.Bold)
        }
        Slider(value = local.coerceIn(lo, hi), onValueChange = { local = it }, onValueChangeFinished = { onDone(fromUnit(local.toDouble())) }, valueRange = lo..hi, enabled = enabled)
        Text(hint, color = Dim, fontSize = 12.sp)
    }
}

/**
 * Virtual joystick. Forward-only: the vertical axis is clamped to 0..1 (the cart cannot reverse), the horizontal axis
 * steers. It publishes straight to [CaddieHub.joystick]; lifting the finger, leaving the page, or the app going to
 * the background all release it, and the service then sends zeros.
 */
@Composable
private fun Joystick(enabled: Boolean) {
    var knob by remember { mutableStateOf(Offset.Zero) }       // each axis -1..1, y up
    val owner = LocalLifecycleOwner.current

    fun release() { knob = Offset.Zero; CaddieHub.joystick.value = Joy() }

    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_PAUSE) release() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); CaddieHub.joystick.value = Joy() }
    }
    LaunchedEffect(enabled) { if (!enabled) release() }

    Canvas(
        Modifier.size(280.dp).pointerInput(enabled) {
            if (!enabled) return@pointerInput
            val r = size.width / 2f
            val travel = r * 0.78f
            fun update(p: Offset) {
                var dx = (p.x - r) / travel; var dy = -(p.y - r) / travel
                val len = hypot(dx, dy)
                if (len > 1f) { dx /= len; dy /= len }
                knob = Offset(dx, dy)
                val live = len > 0.08f
                CaddieHub.joystick.value = if (live) Joy(dx.toDouble(), dy.toDouble().coerceAtLeast(0.0), true) else Joy(0.0, 0.0, true)
            }
            awaitEachGesture {
                val down = awaitFirstDown()
                update(down.position)
                var pressed = true
                while (pressed) {
                    val ev = awaitPointerEvent()
                    val c = ev.changes.firstOrNull { it.id == down.id }
                    if (c == null || !c.pressed) pressed = false else { update(c.position); c.consume() }
                }
                release()
            }
        },
    ) {
        val r = size.width / 2f
        val c = Offset(r, r)
        val travel = r * 0.78f
        drawCircle(if (enabled) Color(0xFF1C3D5A) else Color(0xFF16293B), r, c)
        drawCircle(Color(0xFF3A5671), r, c, style = Stroke(3f))
        // the forward half is the only half that does anything
        drawArc(Color(0x2203EEEF), 180f, 180f, useCenter = true, topLeft = Offset(0f, 0f), size = Size(size.width, size.height))
        drawLine(Color(0xFF3A5671), Offset(0f, r), Offset(size.width, r), strokeWidth = 2f)
        drawLine(Color(0xFF3A5671), Offset(r, 0f), Offset(r, size.height), strokeWidth = 1f)
        val kc = Offset(c.x + knob.x * travel, c.y - knob.y * travel)
        drawCircle(if (enabled) Cyan else Color(0xFF55708A), r * 0.22f, kc)
    }
}
