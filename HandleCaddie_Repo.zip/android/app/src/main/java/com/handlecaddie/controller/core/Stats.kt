package com.handlecaddie.controller.core

import kotlin.math.abs
import kotlin.math.roundToInt

/** What happened on one finished hole. [swings] excludes putts. [fairway] is null on par 3s or when the tee shot wasn't tracked. */
data class HoleStat(
    val hole: Int,
    val par: Int,
    val swings: Int,
    val putts: Int,
    val fairway: Boolean? = null,
    val driveYd: Int? = null,
) {
    val total get() = swings + putts
    val toPar get() = total - par

    /** Putts are only known if they were entered (on the unit or in the app), so GIR can only be judged then (or for an ace). */
    val girKnown get() = putts >= 1 || total == 1

    /** Green in regulation: on the green with two strokes to spare for a putt (par 3 = 1 swing, par 4 = 2, par 5 = 3). */
    val gir get() = girKnown && (total == 1 || swings <= par - 2)
}

/** The numbers behind the Caddie Report, worked out from the finished holes of one round. */
class RoundStats(holes: List<HoleStat>) {
    val holes = holes.sortedBy { it.hole }
    val played get() = holes.size
    val score get() = holes.sumOf { it.total }
    val par get() = holes.sumOf { it.par }
    val toPar get() = score - par

    val eaglesOrBetter get() = holes.count { it.toPar <= -2 }
    val birdies get() = holes.count { it.toPar == -1 }
    val pars get() = holes.count { it.toPar == 0 }
    val bogeys get() = holes.count { it.toPar == 1 }
    val doublesOrWorse get() = holes.count { it.toPar >= 2 }

    val fairwayChances get() = holes.count { it.fairway != null }
    val fairwaysHit get() = holes.count { it.fairway == true }

    val girHoles get() = holes.count { it.girKnown }
    val girs get() = holes.count { it.gir }

    val puttHoles get() = girHoles
    val putts get() = holes.filter { it.girKnown }.sumOf { it.putts }
    val onePutts get() = holes.count { it.putts == 1 }
    val threePutts get() = holes.count { it.putts >= 3 }
    val puttsPerHole get() = if (puttHoles == 0) 0.0 else putts.toDouble() / puttHoles

    private val drives get() = holes.mapNotNull { it.driveYd }
    val longestDrive get() = drives.maxOrNull() ?: 0
    val averageDrive get() = if (drives.isEmpty()) 0 else drives.average().roundToInt()
}

/** One finished (or saved) round, kept in the history. */
data class RoundSummary(
    val dateMs: Long,
    val course: String,
    val holes: Int,
    val score: Int,
    val par: Int,
    val fairHit: Int,
    val fairChances: Int,
    val gir: Int,
    val girHoles: Int,
    val putts: Int,
    val puttHoles: Int,
    val longestDrive: Int,
) {
    val toPar get() = score - par
    val fairwayPct get() = if (fairChances == 0) null else 100.0 * fairHit / fairChances
    val girPct get() = if (girHoles == 0) null else 100.0 * gir / girHoles
    val puttsPerHole get() = if (puttHoles == 0) null else putts.toDouble() / puttHoles

    companion object {
        fun from(s: RoundStats, course: String, dateMs: Long) = RoundSummary(
            dateMs, course, s.played, s.score, s.par, s.fairwaysHit, s.fairwayChances, s.girs, s.girHoles, s.putts, s.puttHoles, s.longestDrive,
        )
    }
}

/** Compact text formats for storing hole stats and the round history. */
object StatsCodec {
    fun encodeHoles(l: List<HoleStat>): String =
        l.joinToString(";") { "${it.hole},${it.par},${it.swings},${it.putts},${when (it.fairway) { true -> 1; false -> 0; null -> -1 }},${it.driveYd ?: 0}" }

    fun decodeHoles(s: String?): List<HoleStat> {
        if (s.isNullOrBlank()) return emptyList()
        return s.split(";").mapNotNull { r ->
            val p = r.split(",")
            if (p.size < 6) return@mapNotNull null
            val n = p.map { it.toIntOrNull() ?: return@mapNotNull null }
            if (n[0] !in 1..18) return@mapNotNull null
            HoleStat(n[0], n[1], n[2].coerceAtLeast(0), n[3].coerceAtLeast(0), when (n[4]) { 1 -> true; 0 -> false; else -> null }, n[5].takeIf { it > 0 })
        }
    }

    fun encodeHistory(l: List<RoundSummary>): String = l.joinToString("\n") {
        listOf(it.dateMs, it.course.replace('\t', ' ').replace('\n', ' '), it.holes, it.score, it.par, it.fairHit, it.fairChances, it.gir, it.girHoles, it.putts, it.puttHoles, it.longestDrive)
            .joinToString("\t")
    }

    fun decodeHistory(s: String?): List<RoundSummary> {
        if (s.isNullOrBlank()) return emptyList()
        return s.split("\n").mapNotNull { line ->
            val p = line.split("\t")
            if (p.size < 12) return@mapNotNull null
            val d = p[0].toLongOrNull() ?: return@mapNotNull null
            val n = (2..11).map { i -> p[i].toIntOrNull() ?: return@mapNotNull null }
            RoundSummary(d, p[1], n[0], n[1], n[2], n[3], n[4], n[5], n[6], n[7], n[8], n[9])
        }
    }
}

/** What the caddie says about a round. [lines] are the highlights; [focus] is the one thing to work on, or null. */
data class Report(val headline: String, val lines: List<String>, val focus: String?)

/** Writes the Caddie Report in a friendly caddie voice. Pure text, so it can be tested. */
object CaddieReport {
    // rough amateur benchmarks, used to find the area that costs the most
    private const val FAIRWAY_PCT = 55.0
    private const val GIR_PCT = 35.0
    private const val PUTTS_PER_HOLE = 1.95

    fun signed(n: Int) = if (n > 0) "+$n" else if (n == 0) "E" else "$n"

    fun build(s: RoundStats, course: String?, history: List<RoundSummary>, complete: Boolean): Report {
        if (s.played == 0) return Report("No holes finished yet. Play a few and I'll tell you how it's going.", emptyList(), null)
        val at = course?.takeIf { it.isNotBlank() }?.let { " at $it" } ?: ""
        val head = if (complete) "You shot ${s.score} (${signed(s.toPar)})$at."
        else "Through ${s.played} ${if (s.played == 1) "hole" else "holes"}: ${s.score} (${signed(s.toPar)})$at."

        val lines = ArrayList<String>()
        fun plural(n: Int, one: String, many: String) = "$n ${if (n == 1) one else many}"
        val mix = listOfNotNull(
            s.eaglesOrBetter.takeIf { it > 0 }?.let { plural(it, "eagle or better", "eagles or better") },
            s.birdies.takeIf { it > 0 }?.let { plural(it, "birdie", "birdies") },
            s.pars.takeIf { it > 0 }?.let { plural(it, "par", "pars") },
            s.bogeys.takeIf { it > 0 }?.let { plural(it, "bogey", "bogeys") },
            s.doublesOrWorse.takeIf { it > 0 }?.let { plural(it, "double bogey or worse", "doubles or worse") },
        )
        if (mix.isNotEmpty()) lines += mix.joinToString(", ") + "."

        val hist = history.filter { it.holes >= 9 }
        if (s.fairwayChances >= 3) {
            val pct = 100.0 * s.fairwaysHit / s.fairwayChances
            lines += "You hit ${s.fairwaysHit} of ${s.fairwayChances} fairways (${pct.roundToInt()}%)." + vsUsual(pct, hist.mapNotNull { it.fairwayPct }, 8.0, "%", true)
        }
        if (s.girHoles >= 3) {
            val pct = 100.0 * s.girs / s.girHoles
            lines += "Greens in regulation: ${s.girs} of ${s.girHoles} (${pct.roundToInt()}%)." + vsUsual(pct, hist.mapNotNull { it.girPct }, 8.0, "%", true)
        }
        if (s.puttHoles >= 3) {
            val pph = s.puttsPerHole
            val three = when (s.threePutts) { 0 -> "no 3-putts"; 1 -> "one 3-putt"; 2 -> "two 3-putts"; 3 -> "three 3-putts"; else -> "${s.threePutts} three-putts" }
            lines += "You took ${s.putts} putts, ${"%.1f".format(pph)} a hole, with $three." + vsUsual(pph, hist.mapNotNull { it.puttsPerHole }, 0.2, "", false)
        }
        if (s.longestDrive > 0) lines += "Longest drive: ${s.longestDrive} yd (average ${s.averageDrive})."

        val last = history.lastOrNull { it.holes == s.played }
        if (complete && last != null) {
            val d = s.score - last.score
            lines += when {
                d < 0 -> "That's ${-d} ${if (d == -1) "stroke" else "strokes"} better than your last ${s.played}-hole round."
                d > 0 -> "That's $d ${if (d == 1) "stroke" else "strokes"} higher than your last ${s.played}-hole round."
                else -> "Same score as your last ${s.played}-hole round."
            }
        }
        return Report(head, lines, focus(s))
    }

    /** " That's above your usual 52%." when this round differs from the average of earlier rounds by more than [margin]. */
    private fun vsUsual(now: Double, before: List<Double>, margin: Double, unit: String, higherIsBetter: Boolean): String {
        if (before.size < 2) return ""
        val avg = before.average()
        val diff = now - avg
        if (abs(diff) < margin) return " Right around your usual."
        val better = (diff > 0) == higherIsBetter
        val usual = if (unit == "%") "${avg.roundToInt()}%" else "%.1f".format(avg)
        return if (better) " Better than your usual $usual." else " Down from your usual $usual."
    }

    /** The area furthest below the benchmark, with enough holes behind it to mean something. */
    private fun focus(s: RoundStats): String? {
        data class Gap(val size: Double, val text: String)
        val gaps = ArrayList<Gap>()
        if (s.fairwayChances >= 4) {
            val g = (FAIRWAY_PCT - 100.0 * s.fairwaysHit / s.fairwayChances) / FAIRWAY_PCT
            if (g > 0.0) gaps += Gap(g, "Tee shots. Finding more fairways would save you the most strokes. Try the club you trust off the tee on tight holes.")
        }
        if (s.girHoles >= 4) {
            val g = (GIR_PCT - 100.0 * s.girs / s.girHoles) / GIR_PCT
            if (g > 0.0) gaps += Gap(g, "Approach shots. Getting on the green sooner is your biggest chance. Aim for the middle of the green and take the extra club.")
        }
        if (s.puttHoles >= 4) {
            val g = (s.puttsPerHole - PUTTS_PER_HOLE) / PUTTS_PER_HOLE
            if (g > 0.0) gaps += Gap(g, "Putting. Lag putts closer and you'll cut the 3-putts. Spend ten minutes on the practice green before you play.")
        }
        val worst = gaps.maxByOrNull { it.size } ?: return if (s.played >= 6 && (s.fairwayChances >= 4 || s.girHoles >= 4 || s.puttHoles >= 4)) "Nice all-round game. Keep doing what you're doing." else null
        return "Focus for next time: ${worst.text}"
    }
}
