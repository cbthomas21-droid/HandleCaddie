package com.handlecaddie.controller.data

import java.net.HttpURLConnection
import java.net.URL

/** Plain GET for the two small web lookups (weather, height above sea level). Returns null on any failure; callers carry on without. */
object ConditionsClient {
    fun get(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8_000; c.readTimeout = 8_000
        c.setRequestProperty("User-Agent", "HandleCaddie/1.0")
        try { if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null } finally { c.disconnect() }
    } catch (e: Exception) { null }
}
