package com.handlecaddie.controller.core

import org.json.JSONObject
import java.util.PriorityQueue
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/*
 * Phase 2: the cart drives itself round a hazard to meet you when you leave a green on a different side from where you went in.
 *
 * Who does what:
 *   - The cart has no GPS. It can only dead-reckon (wheel speed + gyro) from where it stood when the route began.
 *   - The phone knows where the hazards are and where YOU are. It plans the route, sends it, watches the cart's reported
 *     progress, and stops it the moment anything looks wrong. The cart also stops by itself (see NavController in cart_logic.h).
 *
 * Everything here is pure logic with no clock and no Android classes, so it is tested on the desktop (tools/CoreSelfTest.kt).
 */

/** Wrap an angle into (-pi, pi]. */
fun wrapPi(a: Double): Double { var x = a % (2 * PI); if (x > PI) x -= 2 * PI; if (x <= -PI) x += 2 * PI; return x }

/**
 * The cart's own frame for one route: origin = where the cart stood when the route began, +X = the way it faced, +Y = its left.
 * [theta] is that facing in the world frame (radians, east = 0, counter-clockwise).
 */
class NavFrame(val origin: XY, val theta: Double) {
    private val c = cos(theta); private val s = sin(theta)
    fun toWorld(x: Double, y: Double) = XY(origin.x + x * c - y * s, origin.y + x * s + y * c)
    fun toWorld(p: XY) = toWorld(p.x, p.y)
    fun toLocal(w: XY): XY { val dx = w.x - origin.x; val dy = w.y - origin.y; return XY(dx * c + dy * s, -dx * s + dy * c) }
}

/** Which way the cart faces in the world, and how sure we are. */
data class HeadingEstimate(val thetaRad: Double, val sigmaDeg: Double, val source: String)

object Heading {
    /** Combine independent estimates, weighting each by 1 / sigma^2. */
    fun fuse(parts: List<HeadingEstimate>): HeadingEstimate? {
        if (parts.isEmpty()) return null
        var sx = 0.0; var sy = 0.0; var sw = 0.0
        for (p in parts) { val sg = Math.toRadians(max(1.0, p.sigmaDeg)); val w = 1.0 / (sg * sg); sx += w * cos(p.thetaRad); sy += w * sin(p.thetaRad); sw += w }
        return HeadingEstimate(atan2(sy, sx), Math.toDegrees(sqrt(1.0 / sw)), parts.joinToString("+") { it.source })
    }

    /** From the fob bearing: the cart sees you at [bearingDeg] (+ = left), so it faces (direction to you) - bearing. Only trusted while you are close. */
    fun fromUwb(cart: XY, player: XY, bearingDeg: Double, rangeM: Double): HeadingEstimate? {
        val d = Geo.dist(cart, player)
        if (rangeM > 12.0 || d < 2.0) return null
        val dir = atan2(player.y - cart.y, player.x - cart.x)
        val posErrDeg = Math.toDegrees(atan2(3.0, d))                    // the cart's own position is only known to a few metres
        return HeadingEstimate(wrapPi(dir - Math.toRadians(bearingDeg)), sqrt(8.0 * 8.0 + posErrDeg * posErrDeg), "uwb")
    }

    /** From the guard: the way your trail was pointing where the cart was told to wait. */
    fun fromTrail(holdDir: Double): HeadingEstimate = HeadingEstimate(holdDir, 15.0, "trail")
}

/**
 * Learns which way the cart faces in the world while it is following you. The cart reports its gyro heading since power-up
 * (relative, with an unknown constant offset); while it follows, it moves the way you walked, so
 * (the direction you walked) - (gyro heading) is that unknown offset. Averaged over many samples it is good to a few degrees,
 * far better than any single GPS direction.
 */
class HeadingEstimator(private val windowS: Double = 90.0, private val lagS: Double = 2.0) {
    private class P(val t: Double, val p: XY)
    private class S(val t: Double, val sx: Double, val sy: Double, val w: Double)
    private val players = ArrayList<P>()
    private val samples = ArrayList<S>()
    private var lastSampleT = -1e9
    private var lastGoodT = -1e9
    private var lastYawT = Double.NaN; private var lastYaw = 0.0

    fun reset() { players.clear(); samples.clear(); lastSampleT = -1e9; lastYawT = Double.NaN }

    fun addPlayer(tS: Double, p: XY) {
        players.add(P(tS, p))
        while (players.isNotEmpty() && players.first().t < tS - 30.0) players.removeAt(0)
    }

    private fun playerAt(t: Double): XY? {
        if (players.size < 2 || t < players.first().t || t > players.last().t) return null
        for (i in players.size - 1 downTo 1) {
            val a = players[i - 1]; val b = players[i]
            if (t >= a.t) { val f = if (b.t > a.t) (t - a.t) / (b.t - a.t) else 0.0; return XY(a.p.x + (b.p.x - a.p.x) * f, a.p.y + (b.p.y - a.p.y) * f) }
        }
        return null
    }

    /** Call with every telemetry frame (the estimator thins them itself). [yawDeg] = the cart's gyro heading, + = counter-clockwise. */
    fun addCart(tS: Double, yawDeg: Double, speedMs: Double) {
        val yawRate = if (lastYawT.isNaN() || tS <= lastYawT) 0.0 else abs(wrapPi(Math.toRadians(yawDeg) - lastYaw)) / (tS - lastYawT)
        lastYawT = tS; lastYaw = Math.toRadians(yawDeg)
        if (tS - lastSampleT < 0.5) return
        lastSampleT = tS
        if (speedMs < 0.4 || yawRate > Math.toRadians(12.0)) return              // only while moving fairly straight
        // the cart is about 2 s behind where you are, so the cart's heading now matches the way you were walking 2-8 s ago
        val a = playerAt(tS - 6.0 - lagS) ?: return; val b = playerAt(tS - lagS) ?: return
        val d = Geo.dist(a, b)
        if (d < 6.0) return
        val off = wrapPi(atan2(b.y - a.y, b.x - a.x) - Math.toRadians(yawDeg))
        val w = min(d, 12.0) / 12.0
        while (samples.isNotEmpty() && samples.first().t < tS - windowS) samples.removeAt(0)       // old samples go only when new ones arrive, so a long wait keeps the last good heading
        samples.add(S(tS, cos(off) * w, sin(off) * w, w)); lastGoodT = tS
    }

    val sampleCount get() = samples.size

    /** The cart's facing now, given its gyro heading now. Null until there are enough good samples. */
    fun estimate(currentYawDeg: Double, nowS: Double = lastGoodT): HeadingEstimate? {
        if (samples.size < 8) return null
        var sx = 0.0; var sy = 0.0; var sw = 0.0
        for (s in samples) { sx += s.sx; sy += s.sy; sw += s.w }
        if (sw <= 0) return null
        val r = (hypot(sx, sy) / sw).coerceIn(1e-6, 1.0)
        val spreadDeg = Math.toDegrees(sqrt(max(0.0, -2.0 * ln(r))))
        // samples a second apart are far from independent, so only about one in four counts; add the gyro's own slow drift
        val sigma = sqrt((spreadDeg / sqrt(max(1.0, samples.size / 4.0))).let { it * it } + 3.0 * 3.0)
        val aged = sqrt(sigma * sigma + (0.03 * max(0.0, nowS - lastGoodT)).let { it * it })         // the gyro drifts a little while we wait
        return HeadingEstimate(wrapPi(atan2(sy, sx) + Math.toRadians(currentYawDeg)), max(4.0, aged), "gyro+trail")
    }
}

data class NavTuning(
    /** The cart must stay at least this far from a hazard's edge, PLUS its allowance for sensor error (below). Smaller than the guard's margins, which are a soft buffer. */
    val dMinGreenM: Double = 4.0, val dMinWaterM: Double = 5.0, val dMinBunkerM: Double = 2.0,
    /** Dead-reckoning error allowance: this much per metre driven, clamped, plus a little for cutting corners. Measured by the cart simulation (see CART_DESIGN.md). */
    val driftPerM: Double = 0.07, val driftMinM: Double = 3.0, val driftMaxM: Double = 12.0, val cornerCutM: Double = 1.5,
    /** A wrong starting direction swings the whole route about its start: allowance = distance from start x tan(k x sigma). */
    val headingK: Double = 2.0,
    val cellM: Double = 2.0, val maxWaypoints: Int = 24, val maxPathM: Double = 240.0, val maxSegM: Double = 60.0,
    /** Within this of the end the requirement relaxes: the fob range (valid within 12 m) tells the truth there. */
    val goalRelaxM: Double = 15.0,
    val cruiseMs: Double = 1.0, val chaseCruiseMs: Double = 1.4,
    val replanMoveM: Double = 6.0, val replanEveryMs: Long = 12_000L, val heartbeatMs: Long = 1_000L,
    val handoverM: Double = 10.0, val maxRestarts: Int = 3, val handoverRangeM: Double = 9.0, val maxFixM: Double = 25.0, val ackTimeoutMs: Long = 5_000L, val startTimeoutMs: Long = 5_000L, val telStaleMs: Long = 3_000L,
    val maxRunMs: Long = 420_000L, val arrivedWaitMs: Long = 300_000L,
    /** How far the cart's reported distance to the fob may differ from the distance we expect before we stop believing its position. */
    val rangeToleranceM: Double = 5.0, val rangeToleranceFrac: Double = 0.35,
    /** With the cart's own GPS the error stops growing with distance: it is capped at about (this x GPS accuracy + a constant). */
    val gpsAidFactor: Double = 1.2, val gpsAidConstM: Double = 5.0, val gpsStaleFailMs: Long = 8_000L, val gpsFixMaxAccM: Double = 15.0,
    val gpsNudge: Double = 0.3, val headingBaselineM: Double = 15.0,
    val minHeadingSigmaDeg: Double = 4.0, val maxHeadingSigmaDeg: Double = 25.0,
)

data class NavPlan(val ok: Boolean, val worldPts: List<XY> = emptyList(), val lengthM: Double = 0.0, val reason: String = "", val tightestM: Double = 0.0)

/** Grid A* round the hazards, then straightened. Plans in the world (GreenMap) frame. */
class HazardPlanner(private val map: GreenMap, private val cfg: GuardCfg, private val t: NavTuning = NavTuning()) {
    private class Ring(val pts: List<XY>, val dMin: Double, val x0: Double, val y0: Double, val x1: Double, val y1: Double)
    private class Ctx(val rings: List<Ring>, val start: XY, val goal: XY, val acc: Double, val sigmaDeg: Double, val cap: Double)

    private fun rings(x0: Double, y0: Double, x1: Double, y1: Double, reach: Double): List<Ring> {
        val out = ArrayList<Ring>()
        fun add(list: List<List<XY>>, dMin: Double) {
            for (r in list) {
                var a = Double.MAX_VALUE; var b = Double.MAX_VALUE; var c = -Double.MAX_VALUE; var d = -Double.MAX_VALUE
                for (p in r) { a = min(a, p.x); b = min(b, p.y); c = max(c, p.x); d = max(d, p.y) }
                if (c >= x0 - reach && a <= x1 + reach && d >= y0 - reach && b <= y1 + reach) out.add(Ring(r, dMin, a, b, c, d))
            }
        }
        add(map.greens, t.dMinGreenM); add(map.water, t.dMinWaterM); add(map.bunkers, t.dMinBunkerM)
        return out
    }

    /** Room left at [p] once each hazard's minimum distance and the GPS error are taken off (capped: far from everything is simply "plenty"). */
    private fun slack(c: Ctx, p: XY): Double {
        var best = REACH
        for (r in c.rings) {
            if (p.x < r.x0 - REACH || p.x > r.x1 + REACH || p.y < r.y0 - REACH || p.y > r.y1 + REACH) continue
            val d = if (Geo.pointInPolygon(p, r.pts)) 0.0 else Geo.distToPolygonEdge(p, r.pts)
            best = min(best, d - r.dMin - c.acc)
        }
        return best
    }

    /** How much room the route needs at [p]: dead-reckoning drift + heading swing, relaxed near the end. */
    private fun need(c: Ctx, p: XY): Double {
        val r = Geo.dist(p, c.start)
        val drift = max(t.driftMinM * min(1.0, r / 10.0), min(t.driftMaxM, t.driftPerM * 1.3 * r)) + t.cornerCutM * min(1.0, r / 5.0)
        val swing = r * tan(Math.toRadians(min(60.0, t.headingK * c.sigmaDeg)))
        val full = min(drift + swing, c.cap)
        return min(full, 1.0 + 0.4 * Geo.dist(p, c.goal)).let { if (Geo.dist(p, c.goal) <= t.goalRelaxM) it else full }
    }

    private fun clear(c: Ctx, a: XY, b: XY): Boolean {
        val len = Geo.dist(a, b)
        val n = max(1, Math.ceil(len / 1.0).toInt())
        for (i in 0..n) {
            val f = i.toDouble() / n
            val p = XY(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)
            if (slack(c, p) < need(c, p)) return false
        }
        return true
    }

    /** @param aidedAccM accuracy of the cart's own GPS when it is available; the required room then stops growing with distance. */
    fun plan(start: XY, goal: XY, accuracyM: Double, sigmaDeg: Double, aidedAccM: Double? = null): NavPlan {
        val straight = Geo.dist(start, goal)
        if (straight < 2.0) return NavPlan(false, reason = "already there")
        val sig = sigmaDeg.coerceIn(t.minHeadingSigmaDeg, t.maxHeadingSigmaDeg)
        val acc = cfg.accuracyFactor * accuracyM.coerceIn(0.0, cfg.maxAccuracyCountedM)
        val pad = max(60.0, straight)                // room to swing wide round whatever is in the way
        val x0 = min(start.x, goal.x) - pad; val y0 = min(start.y, goal.y) - pad
        val x1 = max(start.x, goal.x) + pad; val y1 = max(start.y, goal.y) + pad
        val nx = Math.ceil((x1 - x0) / t.cellM).toInt() + 1; val ny = Math.ceil((y1 - y0) / t.cellM).toInt() + 1
        if (nx.toLong() * ny > 90_000L) return NavPlan(false, reason = "too far to plan")
        val cap = if (aidedAccM == null) Double.MAX_VALUE else t.gpsAidFactor * aidedAccM.coerceIn(2.0, 20.0) + t.gpsAidConstM
        val c = Ctx(rings(x0, y0, x1, y1, REACH), start, goal, acc, sig, cap)

        fun cx(i: Int) = x0 + i * t.cellM
        fun cy(j: Int) = y0 + j * t.cellM
        fun ci(p: XY) = ((p.x - x0) / t.cellM).let { Math.round(it).toInt() }.coerceIn(0, nx - 1)
        fun cj(p: XY) = ((p.y - y0) / t.cellM).let { Math.round(it).toInt() }.coerceIn(0, ny - 1)
        val si = ci(start); val sj = cj(start); val gi = ci(goal); val gj = cj(goal)
        val sIdx = sj * nx + si; val gIdx = gj * nx + gi
        val slackG = DoubleArray(nx * ny) { Double.NaN }
        val blockedG = ByteArray(nx * ny)          // 0 unknown, 1 free, 2 blocked
        fun free(idx: Int): Boolean {
            if (blockedG[idx].toInt() == 0) {
                val p = XY(cx(idx % nx), cy(idx / nx))
                val s = slack(c, p); slackG[idx] = s
                blockedG[idx] = if (idx == sIdx || idx == gIdx || s >= need(c, p)) 1 else 2
            }
            return blockedG[idx].toInt() == 1
        }
        if (!free(sIdx)) return NavPlan(false, reason = "no room to start")
        val g = DoubleArray(nx * ny) { Double.MAX_VALUE }
        val parent = IntArray(nx * ny) { -1 }
        val done = BooleanArray(nx * ny)
        fun h(i: Int, j: Int) = hypot((i - gi) * t.cellM, (j - gj) * t.cellM)
        class N(val idx: Int, val f: Double)
        val open = PriorityQueue<N>(compareBy { it.f })
        g[sIdx] = 0.0; open.add(N(sIdx, h(si, sj)))
        var expanded = 0
        var found = false
        while (open.isNotEmpty()) {
            val cur = open.poll()
            if (done[cur.idx]) continue
            done[cur.idx] = true
            if (cur.idx == gIdx) { found = true; break }
            if (++expanded > 40_000) break
            val ci0 = cur.idx % nx; val cj0 = cur.idx / nx
            for (dj in -1..1) for (di in -1..1) {
                if (di == 0 && dj == 0) continue
                val ni = ci0 + di; val nj = cj0 + dj
                if (ni < 0 || nj < 0 || ni >= nx || nj >= ny) continue
                val nIdx = nj * nx + ni
                if (done[nIdx] || !free(nIdx)) continue
                val step = (if (di != 0 && dj != 0) 1.41421356 else 1.0) * t.cellM
                val p = XY(cx(ni), cy(nj))
                val pen = ((need(c, p) + 6.0 - slackG[nIdx]) / 12.0).coerceIn(0.0, 1.0)   // prefer more room when it costs little
                val ng = g[cur.idx] + step * (1.0 + pen)
                if (ng < g[nIdx]) { g[nIdx] = ng; parent[nIdx] = cur.idx; open.add(N(nIdx, ng + h(ni, nj))) }
            }
        }
        if (!found) return NavPlan(false, reason = "no safe way round")
        val cells = ArrayList<XY>()
        var k = gIdx
        while (k != -1) { cells.add(XY(cx(k % nx), cy(k / nx))); k = parent[k] }
        cells.reverse()
        cells[0] = start; cells[cells.size - 1] = goal

        // string-pulling: keep only the corners that are really needed
        var pts = ArrayList<XY>(); pts.add(cells[0])
        var i = 0
        while (i < cells.size - 1) {
            var j = cells.size - 1
            while (j > i + 1 && !clear(c, cells[i], cells[j])) j--
            pts.add(cells[j]); i = j
        }
        // tidy: no tiny hops, no giant ones
        val tidy = ArrayList<XY>(); tidy.add(pts[0])
        for (q in 1 until pts.size) {
            val last = tidy.last(); val p = pts[q]
            val d = Geo.dist(last, p)
            if (d < 0.5 && q != pts.size - 1) continue
            if (d < 0.5) { tidy[tidy.size - 1] = p; continue }
            val parts = Math.ceil(d / t.maxSegM).toInt()
            for (m in 1..parts) { val f = m.toDouble() / parts; tidy.add(XY(last.x + (p.x - last.x) * f, last.y + (p.y - last.y) * f)) }
        }
        pts = tidy
        if (pts.size < 2) return NavPlan(false, reason = "already there")
        if (pts.size > t.maxWaypoints) return NavPlan(false, reason = "route too complicated")
        val len = Geo.polylineLength(pts)
        if (len > t.maxPathM) return NavPlan(false, reason = "route too long")
        var tight = Double.MAX_VALUE
        for (q in 1 until pts.size) {
            val n = max(1, Math.ceil(Geo.dist(pts[q - 1], pts[q])).toInt())
            for (m in 0..n) { val f = m.toDouble() / n; tight = min(tight, slack(c, XY(pts[q - 1].x + (pts[q].x - pts[q - 1].x) * f, pts[q - 1].y + (pts[q].y - pts[q - 1].y) * f)) + 0.0) }
        }
        return NavPlan(true, pts, len, "", tight)
    }

    companion object { const val REACH = 70.0 }
}

enum class NavPhase { IDLE, WAIT_ACK, STARTING, RUNNING, DONE, FAILED }

sealed interface NavAct {
    data class Send(val line: String) : NavAct
    data class Log(val text: String) : NavAct
    /** The cart reached you: send hold off and Follow, and tell the guard the cart is at [cartWorld]. */
    data class Handover(val cartWorld: XY) : NavAct
    /** Put the cart in Park and keep the hold. */
    data class Stop(val reason: String) : NavAct
    /** Tee-drive finished: the cart is parked at its goal (its best idea of where that is). Not a handover to following. */
    data class Parked(val cartWorld: XY) : NavAct
}

data class NavInput(
    val nowMs: Long, val player: XY, val accuracyM: Double, val gpsOk: Boolean,
    /** Latest cart telemetry and how old it is. Null = none yet. */
    val tel: CartTelemetry?, val telAgeMs: Long,
    /** The cart's own GPS position (phone riding on the cart), if any, in the same frame as [player]. */
    val cartFix: XY? = null, val cartFixAccM: Double = 99.0, val cartFixAgeMs: Long = Long.MAX_VALUE,
)

/**
 * One drive round a hazard, start to finish. Feed it the phone's view every second; it returns what to send and what to tell the
 * guard. It never decides the cart is fine on missing information: no telemetry, no GPS, an unexpected cart reading, or a route
 * that cannot be made safe all end in [NavAct.Stop].
 */
class NavSession(
    private val map: GreenMap, private val cfg: GuardCfg,
    private val pathClear: (XY, XY) -> Boolean,
    private val tune: NavTuning = NavTuning(),
) {
    var phase = NavPhase.IDLE; private set
    var frame: NavFrame? = null; private set
    var route: List<XY> = emptyList(); private set
    var cartWorld: XY? = null; private set          // the cart's position as the cart reports it, placed in the world
    var status = ""; private set
    private val planner = HazardPlanner(map, cfg, tune)
    private var sigmaDeg = 15.0
    private var phaseMs = 0L; private var lastHbMs = 0L; private var lastPlanMs = 0L; private var runStartMs = 0L
    private var lastPlanPlayer: XY? = null
    private var planFails = 0; private var rangeBad = 0; private var fixBad = 0; private var restarts = 0; private var gpsBad = 0
    private var aidedAcc: Double? = null                 // non-null = the cart's own GPS is helping (phone riding on the cart)
    private var lastCartGpsMs = 0L
    private var standoffM = 0.0                          // > 0: "chase" - stop this far short of the player instead of at the player
    private val gpsTrack = ArrayList<Triple<Long, XY, XY>>()   // (time, cart GPS in the world, cart pose in its own frame)
    private var arrivedMs = -1L
    private var fixedGoal: XY? = null                    // non-null = "drive to this spot and park" (next tee), not "go to the player"
    private var pendingKind = 0                          // 1 = first route, 2 = update while running

    val active get() = phase == NavPhase.WAIT_ACK || phase == NavPhase.STARTING || phase == NavPhase.RUNNING

    private fun goalFor(from: XY, player: XY): XY {
        fixedGoal?.let { return it }
        if (standoffM <= 0.0) return player
        val d = Geo.dist(from, player)
        if (d < 1e-6) return player
        val back = min(standoffM, d)
        return XY(player.x + (from.x - player.x) / d * back, player.y + (from.y - player.y) / d * back)
    }

    /**
     * Plan and send the first route. The cart is taken to be at [cartWorld] facing [heading].
     * @param aidedAccM  accuracy of the cart's own GPS when the phone rides on the cart (the route may then be tighter), else null
     * @param standoffM  chase mode: stop this far short of [player]
     */
    fun start(nowMs: Long, cartWorld: XY, heading: HeadingEstimate, player: XY, accuracyM: Double, aidedAccM: Double? = null, standoffM: Double = 0.0, fixedGoal: XY? = null): List<NavAct> {
        val f = NavFrame(cartWorld, heading.thetaRad)
        sigmaDeg = heading.sigmaDeg
        this.standoffM = standoffM; this.fixedGoal = fixedGoal; aidedAcc = aidedAccM; lastCartGpsMs = nowMs; gpsBad = 0; gpsTrack.clear()
        val plan = planner.plan(cartWorld, goalFor(cartWorld, player), accuracyM, sigmaDeg, aidedAcc)
        if (!plan.ok) { phase = NavPhase.FAILED; status = "no route: ${plan.reason}"; return listOf(NavAct.Log("go-around: not attempted (${plan.reason})")) }
        frame = f; route = plan.worldPts; this.cartWorld = cartWorld
        phase = NavPhase.WAIT_ACK; phaseMs = nowMs; lastPlanMs = nowMs; lastPlanPlayer = player; planFails = 0; rangeBad = 0; fixBad = 0; arrivedMs = -1L; pendingKind = 1
        status = "route sent"
        return listOf(NavAct.Log("go-around: heading ${Math.round(Math.toDegrees(heading.thetaRad))} deg (+/-${Math.round(sigmaDeg)}, ${heading.source}); route ${plan.worldPts.size} points, ${Math.round(plan.lengthM)} m, tightest ${"%.1f".format(plan.tightestM)} m spare")) + routeLines(plan.worldPts)
    }

    private fun routeLines(world: List<XY>): List<NavAct> {
        val f = frame!!
        val out = ArrayList<NavAct>()
        for ((i, w) in world.withIndex()) { val l = f.toLocal(w); out.add(NavAct.Send(CartProtocol.navPoint(i, l.x, l.y))) }
        out.add(NavAct.Send(CartProtocol.navCommit(world.size, if (standoffM > 0.0) tune.chaseCruiseMs else tune.cruiseMs)))
        return out
    }

    /** The cart's answer to a commit, or to a refused start. */
    fun onAck(ok: Boolean, nowMs: Long): List<NavAct> {
        when (phase) {
            NavPhase.WAIT_ACK -> {
                if (!ok) return fail("the cart refused the route")
                phase = NavPhase.STARTING; phaseMs = nowMs; lastHbMs = nowMs; status = "starting"
                return listOf(NavAct.Send(CartProtocol.navHeartbeat()), NavAct.Send(CartProtocol.mode(CartMode.NAV)))
            }
            NavPhase.STARTING -> if (!ok) return fail("the cart would not start the route")
            NavPhase.RUNNING -> if (!ok && pendingKind == 2) { pendingKind = 0; return listOf(NavAct.Log("go-around: the cart refused the updated route; carrying on with the old one")) }
            else -> {}
        }
        return emptyList()
    }

    fun cancel(): List<NavAct> = if (active) fail("cancelled") else emptyList()

    private fun fail(why: String): List<NavAct> {
        phase = NavPhase.FAILED; status = why
        return listOf(NavAct.Log("go-around: stopped - $why"), NavAct.Stop(why))
    }

    private fun rangeOk(tel: CartTelemetry, est: XY, player: XY): Boolean {
        val r = tel.rangeM ?: return true               // no reading: nothing to check against
        if (r > 12.0) return true
        val d = Geo.dist(est, player)
        return abs(r - d) <= max(tune.rangeToleranceM, tune.rangeToleranceFrac * r)
    }

    fun tick(i: NavInput): List<NavAct> {
        if (!active) return emptyList()
        val now = i.nowMs
        val out = ArrayList<NavAct>()
        if (phase == NavPhase.WAIT_ACK) { if (now - phaseMs > tune.ackTimeoutMs) return fail("no answer from the cart"); return out }
        val tel = i.tel
        if (tel == null || i.telAgeMs > tune.telStaleMs) return fail("lost contact with the cart")
        if (!i.gpsOk) return fail("phone position lost")
        if (now - lastHbMs >= tune.heartbeatMs) { lastHbMs = now; out.add(NavAct.Send(CartProtocol.navHeartbeat())) }
        if (tel.faults != 0) return out + fail("the cart reports a fault")

        if (phase == NavPhase.STARTING) {
            if (tel.navCode == NavCode.RUN) { phase = NavPhase.RUNNING; runStartMs = now; status = "driving" }
            else if (NavCode.aborted(tel.navCode)) return out + fail(NavCode.describe(tel.navCode))
            else if (now - phaseMs > tune.startTimeoutMs) return out + fail("the cart did not start")
            else return out
        }

        // ---- RUNNING
        if (tel.navCode != NavCode.ARRIVED && NavCode.aborted(tel.navCode)) return out + fail(NavCode.describe(tel.navCode))
        val nx = tel.navX; val ny = tel.navY
        if (nx == null || ny == null) return out + fail("the cart sent no position")
        var f = frame!!
        var est = f.toWorld(nx, ny)
        if (now - runStartMs > tune.maxRunMs) return out + fail("took too long")

        // While the fob is within range, its distance and bearing say where the cart REALLY is (dead reckoning cannot): nudge our
        // idea of where the cart's frame sits in the world towards that. A fix that disagrees wildly is a reason to stop, not to trust either.
        val r = tel.rangeM; val brg = tel.bearingDeg
        val haveFix = r != null && r <= 12.0 && brg != null
        if (haveFix) {
            val th = f.theta + Math.toRadians(tel.navHeadDeg) + Math.toRadians(brg!!)           // world direction from the cart to the fob
            val fix = XY(i.player.x - r!! * cos(th), i.player.y - r * sin(th))
            val dx = fix.x - est.x; val dy = fix.y - est.y; val dm = hypot(dx, dy)
            if (dm > tune.maxFixM) { fixBad++; if (fixBad >= 3) return out + fail("the fob says the cart is ${dm.roundToInt()} m from where it thinks it is") }
            else {
                fixBad = 0
                val k = if (dm > 3.0) 0.7 else 0.4                   // the fob position comes from phone GPS, so never take it as gospel
                f = NavFrame(XY(f.origin.x + k * dx, f.origin.y + k * dy), f.theta); frame = f
                if (dm > 3.0) lastPlanMs = Long.MIN_VALUE / 2
                est = f.toWorld(nx, ny)
            }
        } else if (!rangeOk(tel, est, i.player)) { rangeBad++; if (rangeBad >= 3) return out + fail("the cart's position does not match its distance to you") } else rangeBad = 0

        // The cart's own GPS (phone riding on the cart): pulls the position towards what the satellites say, and the heading towards the
        // direction the cart has really travelled. Unlike dead reckoning, this error does not grow with distance. The fob (above) wins when in range.
        var gpsFresh = false
        val acc0 = aidedAcc
        if (acc0 != null) {
            val gf = i.cartFix
            if (gf != null && i.cartFixAgeMs <= 3_000L && i.cartFixAccM <= tune.gpsFixMaxAccM) {
                gpsFresh = true; lastCartGpsMs = now; aidedAcc = 0.7 * acc0 + 0.3 * i.cartFixAccM
                if (!haveFix) {
                    val dx = gf.x - est.x; val dy = gf.y - est.y; val dm = hypot(dx, dy)
                    if (dm > tune.maxFixM) { gpsBad++; if (gpsBad >= 3) return out + fail("the cart's GPS says it is ${dm.roundToInt()} m from where it thinks it is") }
                    else {
                        gpsBad = 0
                        f = NavFrame(XY(f.origin.x + tune.gpsNudge * dx, f.origin.y + tune.gpsNudge * dy), f.theta); frame = f
                        est = f.toWorld(nx, ny)
                        if (dm > 4.0) lastPlanMs = Long.MIN_VALUE / 2
                        // heading: compare the direction travelled according to GPS with the direction according to the cart's own frame
                        val here = XY(nx, ny)
                        if (gpsTrack.isEmpty() || Geo.dist(gpsTrack.last().third, here) >= 2.0) gpsTrack.add(Triple(now, gf, here))
                        while (gpsTrack.size > 1 && now - gpsTrack.first().first > 60_000L) gpsTrack.removeAt(0)
                        val base = gpsTrack.firstOrNull { Geo.dist(it.third, here) >= tune.headingBaselineM }
                        if (base != null && Geo.dist(base.third, here) >= tune.headingBaselineM) {
                            val gAng = atan2(gf.y - base.second.y, gf.x - base.second.x)
                            val lAng = atan2(here.y - base.third.y, here.x - base.third.x)
                            val meas = gAng - lAng
                            val dth = (0.25 * wrapPi(meas - f.theta)).coerceIn(-0.12, 0.12)
                            val th = f.theta + dth
                            val c = cos(th); val sn = sin(th)
                            f = NavFrame(XY(est.x - (nx * c - ny * sn), est.y - (nx * sn + ny * c)), th); frame = f      // turn about the cart, so it does not jump
                            est = f.toWorld(nx, ny)
                            val keep = gpsTrack.indexOf(base)
                            if (keep > 0) repeat(keep) { gpsTrack.removeAt(0) }
                        }
                    }
                }
            } else if (now - lastCartGpsMs > tune.gpsStaleFailMs) return out + fail("the cart's GPS was lost")
        }
        cartWorld = est

        // inside a hazard's minimum distance by our best idea of the cart's position: something is badly wrong
        val here = rawSlack(est, i.accuracyM)
        if (here < 0.0) return out + fail("cart too close to a hazard (${"%.1f".format(here)} m)")

        // chase mode: close enough to you by GPS - done, even without the fob
        if (standoffM > 0.0 && Geo.dist(est, i.player) <= standoffM + 4.0) {
            phase = NavPhase.DONE; status = "caught up"
            return out + listOf(NavAct.Log("gps-follow: caught up (${Geo.dist(est, i.player).roundToInt()} m)"), NavAct.Handover(est))
        }

        val arrived = tel.navCode == NavCode.ARRIVED
        val goal = fixedGoal
        if (goal != null) {
            // drive-to-tee: finished when the route is over and (if we can check) the cart really is near the goal
            if (arrived) {
                val left = Geo.dist(est, goal)
                if ((haveFix || gpsFresh) && restarts < tune.maxRestarts && left > 6.0) {
                    restarts++
                    val h = HeadingEstimate(wrapPi(f.theta + Math.toRadians(tel.navHeadDeg)), sigmaDeg, "restart")
                    val acts = start(now, est, h, i.player, i.accuracyM, aidedAcc, 0.0, goal)
                    return out + acts + (if (phase == NavPhase.FAILED) listOf(NavAct.Stop(status)) else emptyList())
                }
                phase = NavPhase.DONE; status = "parked"
                return out + listOf(NavAct.Log("tee-drive: parked (${left.roundToInt()} m from the tee by the cart's own estimate${if (haveFix || gpsFresh) "" else ", no fix to check it"})"), NavAct.Parked(est))
            }
        } else {
        // close enough, and the straight way to you is clear: hand back to normal following
        val closeOk = if (haveFix) r!! <= tune.handoverRangeM else (r != null && r <= tune.handoverRangeM && Geo.dist(est, i.player) <= tune.handoverM)
        if (closeOk && pathClear(est, i.player)) {
            phase = NavPhase.DONE; status = "arrived"
            return out + listOf(NavAct.Log("go-around: ${"%.1f".format(r)} m from you; back to following"), NavAct.Handover(est))
        }
        if (arrived) {
            // the route is over but the fob is out of range: the cart stopped where it thinks you are, and it is not. Stay put until you come within range.
            if ((haveFix || gpsFresh) && restarts < tune.maxRestarts && Geo.dist(est, i.player) > (if (standoffM > 0) standoffM + 6.0 else 3.5)) {
                // the fob has shown us where the cart really is: drive the last stretch from there, in a fresh route frame
                restarts++
                val h = HeadingEstimate(wrapPi(f.theta + Math.toRadians(tel.navHeadDeg)), sigmaDeg, "restart")
                val acts = start(now, est, h, i.player, i.accuracyM, aidedAcc, standoffM)
                return out + acts + (if (phase == NavPhase.FAILED) listOf(NavAct.Stop(status)) else emptyList())
            }
            if (arrivedMs < 0) { arrivedMs = now; status = "waiting for you"; out.add(NavAct.Log("go-around: route finished but you are out of the cart's range; it waits for you")) }
            if (now - arrivedMs > tune.arrivedWaitMs) return out + fail("waited too long for you")
            return out
        }
        }

        // keep the plan up to date as you walk
        val moved = if (goal != null) 0.0 else lastPlanPlayer?.let { Geo.dist(it, i.player) } ?: 0.0
        if (moved >= tune.replanMoveM || now - lastPlanMs >= tune.replanEveryMs) {
            lastPlanMs = now; lastPlanPlayer = i.player
            val plan = planner.plan(est, goalFor(est, i.player), i.accuracyM, sigmaDeg, aidedAcc)
            if (plan.ok) {
                planFails = 0; route = plan.worldPts; pendingKind = 2
                out.addAll(routeLines(plan.worldPts))
                out.add(NavAct.Log("go-around: route updated (${plan.worldPts.size} points, ${Math.round(plan.lengthM)} m)"))
            } else if (plan.reason != "already there") {
                planFails++
                if (planFails >= 2) return out + fail("no safe way on (${plan.reason})")
            }
        }
        return out
    }

    /** Room left at [p] with the planner's own minimum distances, for the safety check on the cart's reported position. */
    private fun rawSlack(p: XY, accuracyM: Double): Double {
        val acc = cfg.accuracyFactor * accuracyM.coerceIn(0.0, cfg.maxAccuracyCountedM)
        val c = map.clearance(p, tune.dMinGreenM, tune.dMinWaterM, tune.dMinBunkerM) ?: return 99.0
        return c.slackM - acc
    }
}

/**
 * A stand-in for the real cart's route driving: the same pure-pursuit controller as NavController (cart_logic.h), plus simple
 * physics with the errors a real cart has (wheel-size error, gyro drift, a start heading the phone had to guess).
 * Used by the demo cart and by the closed-loop tests. Not part of the real cart.
 */
class NavSimCart(
    var pos: XY, var heading: Double,
    private val gyroOffsetRad: Double = 1.3,       // the gyro's zero is wherever the cart was switched on
    private val wheelScale: Double = 1.0,           // measured speed / true speed (a wrong wheel diameter)
    private val gyroBiasRadS: Double = 0.0,         // residual gyro bias after the cart has learned it
    private val steerGain: Double = 1.0,            // true turn / commanded turn
) {
    var mode = CartMode.PARK
    var fob: XY? = null                              // where the fob is (to report range and bearing)
    var speed = 0.0; private set
    private var omegaTrue = 0.0
    private var gyroDrift = 0.0

    // --- controller (a port of NavController) ---
    private val px = DoubleArray(24); private val py = DoubleArray(24); private val sx = DoubleArray(24); private val sy = DoubleArray(24)
    private var staged = 0; private var n = 0; private var seg = 0
    private var x = 0.0; private var y = 0.0; private var psi = 0.0; private var t = 0.0; private var link = 0.0
    private var vRoute = 1.0; private var stuckT = 0.0; private var bestS = 0.0; private var xtrack = 0.0; private var lastOmega = 0.0; private var yawBad = 0.0
    var navCode = NavCode.IDLE; private set
    var cartEnabled = true                           // false = the cart's own switch is "paused"

    private val lookahead = 2.5; private val vMin = 0.35; private val vCruise = 1.5; private val omegaMax = 0.8

    fun handle(line: String): List<String> {
        val o = try { JSONObject(line.trim()) } catch (e: Exception) { return emptyList() }
        when (o.optString("k")) {
            "navp" -> {
                val i = o.optInt("i", -1)
                if (i == 0) staged = 0
                if (i == 0 && navCode >= NavCode.ARRIVED) { navCode = NavCode.IDLE; n = 0; x = 0.0; y = 0.0; psi = 0.0 }
                if (i in 0..23) { sx[i] = o.optDouble("x"); sy[i] = o.optDouble("y"); staged = staged or (1 shl i) }
            }
            "navgo" -> return listOf(if (commit(o.optInt("n"), o.optDouble("v"))) "{\"k\":\"nav\",\"ok\":1}" else "{\"k\":\"nav\",\"ok\":0}")
            "navhb" -> link = 0.0
            "mode" -> {
                val m = CartMode.fromWire(o.optString("m"))
                if (m == CartMode.NAV) {
                    if (navCode == NavCode.READY && cartEnabled) { x = 0.0; y = 0.0; psi = 0.0; t = 0.0; link = 0.0; seg = 0; stuckT = 0.0; bestS = 0.0; lastOmega = 0.0; yawBad = 0.0; navCode = NavCode.RUN; mode = CartMode.NAV }
                    else return listOf("{\"k\":\"nav\",\"ok\":0}")
                } else if (m != null) { mode = m; if (navCode != NavCode.IDLE) { navCode = NavCode.IDLE; n = 0; x = 0.0; y = 0.0; psi = 0.0 } }     // like NavController::cancel()
            }
        }
        return emptyList()
    }

    private fun commit(cnt: Int, v: Double): Boolean {
        if (cnt < 2 || cnt > 24 || v.isNaN()) return false
        for (i in 0 until cnt) if (staged and (1 shl i) == 0) return false
        var len = 0.0
        for (i in 1 until cnt) { val d = hypot(sx[i] - sx[i - 1], sy[i] - sy[i - 1]); if (d < 0.2 || d > 100.0) return false; len += d }
        if (len > 250.0) return false
        if (hypot(sx[0] - x, sy[0] - y) > 12.0) return false
        for (i in 0 until cnt) { px[i] = sx[i]; py[i] = sy[i] }
        n = cnt; seg = 0; vRoute = v.coerceIn(vMin, vCruise); stuckT = 0.0; bestS = 0.0
        if (navCode == NavCode.IDLE || navCode >= NavCode.ARRIVED) navCode = NavCode.READY
        staged = 0
        return true
    }

    private fun alongTo(sg: Int, tt: Double): Double { var s = 0.0; for (i in 0 until sg) s += hypot(px[i + 1] - px[i], py[i + 1] - py[i]); return s + tt * hypot(px[sg + 1] - px[sg], py[sg + 1] - py[sg]) }
    private fun pointAt(s0: Double): XY {
        var s = s0
        for (i in 0 until n - 1) {
            val l = hypot(px[i + 1] - px[i], py[i + 1] - py[i])
            if (s <= l || i == n - 2) { val f = if (l > 1e-6) (s / l).coerceIn(0.0, 1.0) else 1.0; return XY(px[i] + f * (px[i + 1] - px[i]), py[i] + f * (py[i + 1] - py[i])) }
            s -= l
        }
        return XY(px[n - 1], py[n - 1])
    }

    /** Advance [dt] seconds (use 0.02-0.1). */
    fun step(dt: Double) {
        var vCmd = 0.0; var wCmd = 0.0
        if (!cartEnabled && navCode == NavCode.RUN) { navCode = NavCode.IDLE; n = 0; mode = CartMode.PARK }
        // gyro and wheels as the controller sees them
        val yawMeas = omegaTrue + gyroBiasRadS
        val vMeas = speed * wheelScale
        gyroDrift += gyroBiasRadS * dt
        if (navCode == NavCode.RUN) {
            if (abs(yawMeas - lastOmega) > 0.35) { yawBad += dt; if (yawBad > 3.0) { navCode = NavCode.ABORT_YAW } } else yawBad = 0.0
        }
        if (navCode == NavCode.RUN) {
            psi = wrapPi(psi + yawMeas * dt)
            x += vMeas * cos(psi) * dt; y += vMeas * sin(psi) * dt
            t += dt; link += dt
            if (link > 2.5) navCode = NavCode.ABORT_LINK
            else if (t > 420.0) navCode = NavCode.ABORT_TIME
            else {
                var bestD = 1e9; var bestSeg = seg; var bestT = 0.0
                var i = seg
                while (i < n - 1 && i <= seg + 3) {
                    val dx = px[i + 1] - px[i]; val dy = py[i + 1] - py[i]; val l2 = dx * dx + dy * dy
                    val tt = if (l2 > 1e-9) (((x - px[i]) * dx + (y - py[i]) * dy) / l2).coerceIn(0.0, 1.0) else 0.0
                    val d = hypot(x - (px[i] + tt * dx), y - (py[i] + tt * dy))
                    if (d < bestD) { bestD = d; bestSeg = i; bestT = tt }
                    i++
                }
                seg = bestSeg; xtrack = bestD
                if (bestD > 5.0) navCode = NavCode.ABORT_OFFPATH
                else {
                    val s = alongTo(seg, bestT)
                    if (s > bestS + 0.5) { bestS = s; stuckT = 0.0 } else { stuckT += dt; if (stuckT > 25.0) navCode = NavCode.ABORT_STUCK }
                    val toEnd = hypot(px[n - 1] - x, py[n - 1] - y)
                    if (navCode == NavCode.RUN) {
                        if (toEnd <= 1.0) navCode = NavCode.ARRIVED
                        else {
                            val tp = pointAt(s + lookahead)
                            val alpha = wrapPi(atan2(tp.y - y, tp.x - x) - psi)
                            var v = vRoute * cos(alpha).coerceIn(0.3, 1.0)
                            if (abs(alpha) > 1.2) v = vMin
                            v = min(v, max(vMin, 0.5 * toEnd)); v = max(v, vMin)
                            vCmd = v; wCmd = (2.0 * v * sin(alpha) / lookahead).coerceIn(-omegaMax, omegaMax)
                            lastOmega = wCmd
                        }
                    }
                }
            }
            if (navCode != NavCode.RUN) { n = if (navCode == NavCode.ARRIVED) n else n; mode = CartMode.PARK }
        }
        // physics
        speed += (vCmd - speed) * min(1.0, dt / 0.4)
        omegaTrue += (wCmd * steerGain - omegaTrue) * min(1.0, dt / 0.2)
        if (vCmd == 0.0 && speed < 0.02) speed = 0.0
        heading = wrapPi(heading + omegaTrue * dt)
        pos = XY(pos.x + speed * cos(heading) * dt, pos.y + speed * sin(heading) * dt)
    }

    fun telemetry(): CartTelemetry {
        val f = fob
        val dist = f?.let { Geo.dist(pos, it) }
        val brg = f?.let { Math.toDegrees(wrapPi(atan2(it.y - pos.y, it.x - pos.x) - heading)) }
        val have = navCode != NavCode.IDLE
        return CartTelemetry(
            mode = mode, speedMs = speed,
            rangeM = dist?.takeIf { it <= 12.0 }, bearingDeg = if (dist != null && dist <= 12.0) brg else null,
            yawDeg = Math.toDegrees(wrapPi(heading - gyroOffsetRad + gyroDrift)), navReady = true,
            navX = if (have) x else null, navY = if (have) y else null, navHeadDeg = Math.toDegrees(psi), navSeg = seg, navCode = navCode,
        )
    }
}
