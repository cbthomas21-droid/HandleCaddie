package com.handlecaddie.controller.core

import java.io.ByteArrayOutputStream
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.round

/** Events the ESP32 sends to the phone (see PROTOCOL.md in the firmware folder). */
sealed interface DeviceEvent {
    data object Pull : DeviceEvent                                   // {"e":"pull"}
    data class Return(val heldMs: Long) : DeviceEvent                // {"e":"ret","ms":23500}
    data class Strokes(val n: Int) : DeviceEvent                     // {"e":"str","n":3}
    data object OnGreen : DeviceEvent                                // {"e":"green"}
    data class Putts(val n: Int) : DeviceEvent                       // {"e":"putt","n":2}
    data class HoleOut(val strokes: Int, val putts: Int) : DeviceEvent  // {"e":"out","s":5,"p":2}
}

/** What the unit was last told, so live messages can carry only what changed. */
data class Wire(
    val dist: Int, val front: Int, val back: Int, val zone: Zone, val strokes: Int,
    val last: Int, val club: String?, val carry: Int, val player: XY?,
)

/**
 * Notifications can arrive split across several packets, and a packet can hold more than one
 * message. Feed raw bytes in; get complete '\n'-terminated lines out. Works on bytes so a
 * multi-byte UTF-8 character split between packets is not corrupted.
 */
class LineBuffer(private val maxBytes: Int = 4096) {
    private val buf = ByteArrayOutputStream()

    fun feed(bytes: ByteArray): List<String> {
        val out = ArrayList<String>(1)
        for (b in bytes) {
            if (b == '\n'.code.toByte()) {
                if (buf.size() > 0) out.add(buf.toByteArray().toString(Charsets.UTF_8).trim())
                buf.reset()
            } else {
                if (buf.size() >= maxBytes) buf.reset()      // runaway garbage: drop it
                buf.write(b.toInt())
            }
        }
        return out
    }

    fun clear() = buf.reset()
}

object Protocol {
    const val MAX_POLY_POINTS = 48          // the firmware keeps at most 48 points per polygon
    private const val PLAYER_MOVE_M = 2.0   // don't resend the blue dot for GPS jitter

    private fun r1(v: Double) = round(v * 10.0) / 10.0
    private fun pt(p: XY) = JSONArray().put(r1(p.x)).put(r1(p.y))

    // ---------------------------------------------------------------- unit -> phone
    fun parse(line: String): DeviceEvent? = try {
        val o = JSONObject(line)
        when (o.optString("e")) {
            "pull" -> DeviceEvent.Pull
            "ret" -> DeviceEvent.Return(o.optLong("ms", 0))
            "str" -> DeviceEvent.Strokes(o.getInt("n"))
            "green" -> DeviceEvent.OnGreen
            "putt" -> DeviceEvent.Putts(o.getInt("n"))
            "out" -> DeviceEvent.HoleOut(o.getInt("s"), o.optInt("p", 0))
            else -> null
        }
    } catch (e: Exception) { null }

    // ---------------------------------------------------------------- phone -> unit
    fun wireOf(s: GameState) = Wire(
        dist = s.toPinYd ?: 0, front = s.frontYd ?: 0, back = s.backYd ?: 0, zone = s.zone,
        strokes = s.strokes, last = s.lastShotYd ?: 0,
        club = s.club?.name, carry = s.club?.carryYd ?: 0, player = s.player,
    )

    const val MAX_TIP_CHARS = 52

    /** A one-line message the unit shows for a few seconds and fades out. The display font is plain ASCII, so tidy the text first. */
    fun tip(text: String): String {
        val clean = buildString {
            for (c in text) append(when (c) { in ' '..'~' -> c; '\u2018', '\u2019' -> '\''; '\u2013', '\u2014' -> '-'; else -> ' ' })
        }.trim().replace(Regex(" +"), " ").take(MAX_TIP_CHARS)
        return JSONObject().put("tip", clean).toString() + "\n"
    }

    private fun polys(list: List<List<XY>>): JSONArray {
        val a = JSONArray()
        for (ring in list) if (ring.size >= 3) {
            val fit = Geo.fitRing(ring, MAX_POLY_POINTS)
            a.put(JSONArray().also { j -> fit.forEach { j.put(pt(it)) } })
        }
        return a
    }

    /** Full message for a hole change: geometry + every live field + scorecard. One line, '\n' terminated. */
    fun holeMessage(h: Hole, s: GameState): Pair<String, Wire> {
        val w = wireOf(s)
        val o = JSONObject()
        o.put("hole", h.number).put("par", s.par).put("len", h.lengthYd)
        o.put("dist", w.dist).put("front", w.front).put("back", w.back)
        s.zone.wire?.let { o.put("zone", it) }
        o.put("strokes", w.strokes).put("last", w.last)
        w.club?.let { o.put("club", it).put("carry", w.carry) }
        o.put("tee", pt(h.tee)).put("pin", pt(h.pin))
        w.player?.let { o.put("player", pt(it)) }
        if (h.fairways.isNotEmpty()) o.put("fairway", polys(h.fairways))
        if (h.greens.isNotEmpty()) o.put("green", polys(h.greens))
        if (h.bunkers.isNotEmpty()) o.put("bunkers", polys(h.bunkers))
        if (h.water.isNotEmpty()) o.put("water", polys(h.water))
        o.put("pars", JSONArray(s.pars)).put("scores", JSONArray(s.scores))
        return (o.toString() + "\n") to w
    }

    /** Only the fields that changed since [prev]; null when there is nothing worth sending. */
    fun liveDiff(prev: Wire?, cur: Wire): Pair<String, Wire>? {
        val o = JSONObject()
        var sentPlayer = prev?.player
        if (prev == null || cur.dist != prev.dist) o.put("dist", cur.dist)
        if (prev == null || cur.front != prev.front) o.put("front", cur.front)
        if (prev == null || cur.back != prev.back) o.put("back", cur.back)
        if ((prev == null || cur.zone != prev.zone) && cur.zone.wire != null) o.put("zone", cur.zone.wire)
        if (prev == null || cur.strokes != prev.strokes) o.put("strokes", cur.strokes)
        if (prev == null || cur.last != prev.last) o.put("last", cur.last)
        if (cur.club != null && (prev == null || cur.club != prev.club)) o.put("club", cur.club).put("carry", cur.carry)
        val p = cur.player
        if (p != null && (prev?.player == null || Geo.dist(p, prev.player) >= PLAYER_MOVE_M)) {
            o.put("player", pt(p)); sentPlayer = p
        }
        if (o.length() == 0) return null
        return (o.toString() + "\n") to cur.copy(player = sentPlayer)
    }

    /** Split one message into BLE-write sized pieces (pass `mtu - 3`). */
    fun chunk(line: String, maxPayload: Int): List<ByteArray> {
        require(maxPayload >= 20)
        val b = line.toByteArray(Charsets.UTF_8)
        val out = ArrayList<ByteArray>((b.size + maxPayload - 1) / maxPayload)
        var i = 0
        while (i < b.size) { out.add(b.copyOfRange(i, minOf(b.size, i + maxPayload))); i += maxPayload }
        return out
    }
}
