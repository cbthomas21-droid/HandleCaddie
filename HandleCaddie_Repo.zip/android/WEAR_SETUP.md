# Handle Caddie on a Wear OS watch

What the watch does
- Shows the hole, distance to the pin, "plays like" distance, the club to take, the cart's mode and battery, and why the cart is waiting.
- Buttons: Next hole, Cart follow / park / STOP.
- After a hole-out it buzzes twice and asks "Move on to hole N?" with Go and Later. Go puts the cart in Follow for the next hole. (It does not yet drive the cart to the next tee by itself; that needs the go-around navigation tested on the real cart first.)
- Buzzes for cart alerts: holding at a hazard, battery may not last, cart left behind, go-around stopped.
- Optional: sends the watch's GPS to the phone, so the phone can stay on the cart.

Set-up (once, needs Android Studio)
1. Phone project: add `implementation("com.google.android.gms:play-services-wearable:18.2.0")` to app/build.gradle.kts and copy the new files from HandleCaddie_Android.zip (WatchBridge.kt, WatchProtocol.kt and the changed service/UI files).
2. File > New > New Module > Wear OS > "Empty Wear App" (Compose). Name it `wear`. Set its applicationId to EXACTLY the phone app's applicationId.
3. Copy the contents of `wear/src/main` from the zip into the new module (AndroidManifest.xml, the `core/WatchProtocol.kt` copy and the `wear` package). Add the dependencies in `wear/build.gradle.kts.snippet`.
4. Pair the watch with the phone (normal Wear OS pairing), then run the `wear` module on the watch (Wi-Fi/USB debugging on the watch, or "Wireless debugging").
5. Open the watch app once. The Cart tab on the phone should say "Watch connected".

Leaving the phone on the cart
1. On the phone, Cart tab > Watch > turn on "Use my watch for my position".
2. Open the Handle Caddie app on the watch and tap Start GPS if it does not start by itself (Android only lets an app that is on screen start the position service). Then you can leave the watch app; the position keeps going in the background.
3. If the watch stops sending (battery, Bluetooth range, app killed) the phone sees no position and the cart HOLDS. That is deliberate: it never falls back to the phone's GPS while the phone is riding on the cart.
4. Check the watch battery before a round; continuous GPS uses roughly 5-8% an hour on recent watches.

Not tested on a real watch. If something does not connect, the usual causes are: different applicationId or signing key on the two apps, the watch app never opened, or Bluetooth off.

Drive to the next tee
If "Drive to the next tee" is switched on in the phone's Cart tab, the watch's Go button (after "Move on to hole N?") sends the cart to that hole's tee instead of just putting it in Follow. Nothing changes on the watch itself; if the cart cannot go (not ready, tee unknown, too far), Go falls back to Follow and the reason is in the phone's log.

Driving the cart from the watch
Turn on Cart tab > Manual drive > "Drive from the watch" on the phone (it is off every time the app starts). The watch then shows "Cart: drive". Hold the arrows to move; let go to stop. Replace the files in your wear module with the ones in this zip (WatchMainActivity.kt, WatchLink.kt, core/WatchProtocol.kt). Not tested on a real watch.
