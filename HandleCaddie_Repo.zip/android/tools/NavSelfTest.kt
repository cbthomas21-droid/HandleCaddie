import com.handlecaddie.controller.core.*
import kotlin.math.*

// Desktop test for phase 2 (driving round a hazard). Run:
//   cd /home/claude/android && tools/kotlinc/bin/kotlinc app/src/main/java/com/handlecaddie/controller/core/*.kt tools/NavSelfTest.kt -cp tools/orgjson.jar -d /tmp/ct/nav.jar
//   java -cp /tmp/ct/nav.jar:tools/orgjson.jar:tools/kotlinc/lib/kotlin-stdlib.jar NavSelfTestKt

var nPass = 0; var nFail = 0
fun ncheck(c: Boolean, m: String) { if (c) { nPass++; println("ok:   $m") } else { nFail++; println("FAIL: $m") } }

fun circle(cx: Double, cy: Double, r: Double, n: Int = 16) = (0 until n).map { XY(cx + r * cos(2 * PI * it / n), cy + r * sin(2 * PI * it / n)) }
val ORIGIN = LatLon(41.7, -111.8)

/** Distance from [p] to the edge of the nearest hazard (0 inside). */
fun edgeDist(m: GreenMap, p: XY) = m.distanceM(p) ?: 999.0

class Rng(seed: Long) { private val r = java.util.Random(seed); fun gauss() = r.nextGaussian(); fun uni(a: Double, b: Double) = a + (b - a) * r.nextDouble() }

class Result(val ok: Boolean, val why: String, val minEdgeM: Double, val endRangeM: Double, val routeSecs: Double, val headingErrDeg: Double, val maxLateral: Double)

/**
 * A full go-around, closed loop: a player walks up to a green, across it, and away on the far side; the guard holds the cart at
 * the near side; the session plans, the simulated cart drives with realistic sensor errors, and the player is only seen through
 * noisy GPS. [cartFault] injects a failure at the given second after the route starts.
 */
fun runScenario(seed: Long, scale: Double = 1.0, gyroBias: Double = 0.0, steer: Double = 1.0, gpsBiasSigma: Double = 1.5, cartFault: String? = null, faultAtS: Double = 30.0, verbose: Boolean = false, aided: Boolean = false): Result {
    val rng = Rng(seed)
    val green = circle(0.0, 0.0, 15.0)
    val map = GreenMap(ORIGIN, listOf(green))
    val cfg = GuardCfg()
    val guard = GreenGuard(cfg); guard.setMap(map)
    val session = NavSession(map, cfg, { a, b -> guard.pathClearFrom(a, b) })
    val est = HeadingEstimator()

    // the player's true path: from the south-west, round a bend, over the green, away to the north
    val path = listOf(XY(-40.0, -95.0), XY(0.0, -55.0), XY(0.0, 48.0))
    val total = Geo.polylineLength(path)
    fun pathAt(s: Double): Pair<XY, Double> {
        var rem = s.coerceIn(0.0, total)
        for (i in 0 until path.size - 1) {
            val l = Geo.dist(path[i], path[i + 1])
            if (rem <= l || i == path.size - 2) { val f = if (l > 0) rem / l else 0.0; return Pair(XY(path[i].x + (path[i + 1].x - path[i].x) * f, path[i].y + (path[i + 1].y - path[i].y) * f), atan2(path[i + 1].y - path[i].y, path[i + 1].x - path[i].x)) }
            rem -= l
        }
        return Pair(path.last(), 0.0)
    }
    val walk = 1.2; val followM = 2.5
    var s = 0.0
    val sim = NavSimCart(pathAt(0.0).first, pathAt(0.0).second, gyroOffsetRad = rng.uni(-3.0, 3.0), wheelScale = scale, gyroBiasRadS = gyroBias, steerGain = steer)
    sim.mode = CartMode.FOLLOW
    var bx = 0.0; var by = 0.0                                   // slowly wandering GPS error
    var cbx = 0.0; var cby = 0.0
    fun cartGps(p: XY): XY { cbx = 0.985 * cbx + rng.gauss() * gpsBiasSigma * 0.17; cby = 0.985 * cby + rng.gauss() * gpsBiasSigma * 0.17; return XY(p.x + cbx + rng.gauss() * 0.6, p.y + cby + rng.gauss() * 0.6) }
    fun gps(p: XY): XY { bx = 0.985 * bx + rng.gauss() * gpsBiasSigma * 0.17; by = 0.985 * by + rng.gauss() * gpsBiasSigma * 0.17; return XY(p.x + bx + rng.gauss() * 0.6, p.y + by + rng.gauss() * 0.6) }

    var t = 0.0; var held = false; var tried = false
    var minEdge = 999.0; var maxLat = 0.0
    var routeStart = -1.0; var navStarted = false; var handedOver = false; var stopWhy: String? = null; var endRange = -1.0
    var headingErr = 0.0
    var linkCut = false
    val acts = ArrayList<NavAct>()
    val player0 = pathAt(0.0).first
    var truePlayer = player0
    var lastTel: CartTelemetry = sim.telemetry()

    fun apply(list: List<NavAct>) {
        for (a in list) when (a) {
            is NavAct.Send -> if (!linkCut || a.line.contains("\"mode\"")) {
                if (linkCut && !a.line.contains("navhb")) {}
                for (r in sim.handle(a.line)) { CartProtocol.parse(r)?.let { m -> if (m is CartMsg.NavAck) apply(session.onAck(m.ok, (t * 1000).toLong())) } }
            }
            is NavAct.Log -> if (verbose) println("   [${"%.0f".format(t)}s] ${a.text}")
            is NavAct.Stop -> { stopWhy = a.reason; sim.handle(CartProtocol.mode(CartMode.PARK)) }
            is NavAct.Parked -> {}
            is NavAct.Handover -> { handedOver = true; endRange = Geo.dist(sim.pos, truePlayer); guard.resumeFrom(a.cartWorld, 4.0); sim.handle(CartProtocol.mode(CartMode.FOLLOW)) }
        }
    }

    val dt = 0.05
    var nextPhone = 0.0
    while (t < 700.0 && !handedOver && stopWhy == null) {
        // ---- the world
        if (!held) {
            s += walk * dt                                    // player walks; the cart follows 2.5 m behind on the same path
            val (cp, ch) = pathAt(s - followM); sim.pos = cp; sim.heading = ch
        } else if (s < total) s += walk * dt
        truePlayer = pathAt(s).first
        sim.fob = truePlayer
        if (!(held && !sim.mode.equals(CartMode.FOLLOW)) && !held) { /* following: nothing else to do */ }
        if (held || sim.mode == CartMode.NAV || sim.navCode != NavCode.IDLE) sim.step(dt)
        minEdge = min(minEdge, edgeDist(map, sim.pos))
        if (navStarted) {
            val f = session.frame
            if (f != null) maxLat = max(maxLat, 0.0)
        }
        t += dt
        if (cartFault == "link" && navStarted && t - routeStart > faultAtS) linkCut = true
        if (cartFault == "switch" && navStarted && t - routeStart > faultAtS) sim.cartEnabled = false

        // ---- the phone, once a second
        if (t >= nextPhone) {
            nextPhone += 1.0
            val rp = gps(truePlayer)
            val nowMs = (t * 1000).toLong()
            lastTel = sim.telemetry()
            val tel = if (linkCut) lastTel else lastTel
            est.addPlayer(t, rp)
            if (!held && lastTel.yawDeg != null) est.addCart(t, lastTel.yawDeg!!, 1.1)
            val cg = cartGps(sim.pos)
            val cgOk = !(cartFault == "cartgps" && navStarted && t - routeStart > faultAtS)
            if (aided && cgOk) guard.cartFix(cg, 4.0, nowMs)
            if (!session.active) {
                val out = guard.step(rp, 4.0, followM, false, nowMs)
                if (out.hold && !held) { held = true; sim.mode = CartMode.PARK }
                if (out.hold && out.pathBlocked && !tried && t > 5.0) {
                    tried = true
                    val hp = guard.holdPosition()!!
                    val parts = ArrayList<HeadingEstimate>()
                    est.estimate(lastTel.yawDeg ?: 0.0)?.let { parts += it }
                    guard.holdDirection()?.let { parts += Heading.fromTrail(it) }
                    val h = Heading.fuse(parts)!!
                    headingErr = abs(Math.toDegrees(wrapPi(h.thetaRad - sim.heading)))
                    if (verbose) println("   hold at (${hp.x.toInt()},${hp.y.toInt()}) true (${sim.pos.x.toInt()},${sim.pos.y.toInt()}); heading err ${"%.1f".format(headingErr)} deg, sigma ${"%.1f".format(h.sigmaDeg)} (${h.source})")
                    val a = session.start(nowMs, hp, h, rp, 4.0, if (aided) 4.0 else null)
                    apply(a)
                    if (session.active) { routeStart = t; navStarted = true }
                }
            } else {
                // while the session drives, the guard still sees the player (so it keeps its trail), but the cart is not following
                guard.step(rp, 4.0, followM, false, nowMs)
                val age = if (linkCut) 400L else 0L
                apply(session.tick(NavInput(nowMs, rp, 4.0, cartFault != "gps" || t - routeStart < faultAtS, lastTel, age, if (aided) cg else null, 4.0, if (cgOk) 0L else 20_000L)))
                if (session.phase == NavPhase.FAILED && stopWhy == null) stopWhy = session.status
            }
        }
    }
    if (verbose) println("   end: cart true (${sim.pos.x.roundToInt()},${sim.pos.y.roundToInt()}) player true (${truePlayer.x.roundToInt()},${truePlayer.y.roundToInt()}) navCode ${sim.navCode} est ${session.cartWorld?.let { "(${it.x.roundToInt()},${it.y.roundToInt()})" }}")
    val routeLen = 0.0
    val why = when { handedOver -> "handed over"; stopWhy != null -> "stopped: $stopWhy"; !tried -> "never tried"; else -> "timed out" }
    return Result(handedOver, why, minEdge, endRange, if (routeStart > 0) t - routeStart else 0.0, headingErr, maxLat)
}


class ChaseResult(val finalDistM: Double, val minDistM: Double, val minEdgeM: Double, val sessions: Int, val caught: Boolean)

/**
 * "GPS follow": the fob is gone, the phone is on the cart, and the player walks away along a fairway (stopping now and then). The cart
 * chases the watch's position with routes, stopping 8 m short, with a green beside the path to keep clear of.
 */
fun runChase(seed: Long, scale: Double = 1.0, gyroBias: Double = 0.0): ChaseResult {
    val rng = Rng(seed)
    val map = GreenMap(ORIGIN, listOf(circle(110.0, -34.0, 15.0)))
    val cfg = GuardCfg()
    val guard = GreenGuard(cfg); guard.setMap(map)
    val sim = NavSimCart(XY(0.0, 0.0), 0.0, gyroOffsetRad = rng.uni(-3.0, 3.0), wheelScale = scale, gyroBiasRadS = gyroBias)
    sim.mode = CartMode.FOLLOW
    val stops = listOf(60.0, 120.0, 180.0, 230.0)
    var px = 0.0; var t = 0.0
    var pauseUntil = 0.0; var nextStop = 0
    var cbx = 0.0; var cby = 0.0; var pbx = 0.0; var pby = 0.0
    var session: NavSession? = null
    var sessions = 0; var minDist = 999.0; var minEdge = 999.0
    var cooldownUntil = 0.0; var nextPhone = 0.0
    var endStill = -1.0
    var caught = false

    fun apply(list: List<NavAct>) {
        for (a in list) when (a) {
            is NavAct.Send -> for (r in sim.handle(a.line)) CartProtocol.parse(r)?.let { m -> if (m is CartMsg.NavAck) apply(session?.onAck(m.ok, (t * 1000).toLong()) ?: emptyList()) }
            is NavAct.Stop -> { if (System.getenv("CHASE_LOG") != null) println("   [${t.roundToInt()}s] stop: ${a.reason}"); sim.handle(CartProtocol.mode(CartMode.PARK)); session = null; cooldownUntil = t + 15.0 }
            is NavAct.Handover -> { sim.handle(CartProtocol.mode(CartMode.FOLLOW)); session = null; cooldownUntil = t + 15.0; if (px >= 229.0) caught = true }
            is NavAct.Parked -> {}
            is NavAct.Log -> if (System.getenv("CHASE_LOG") != null) println("   [${t.roundToInt()}s] ${a.text}")
        }
    }
    val dt = 0.05
    while (t < 700.0) {
        if (t >= pauseUntil) {
            if (px < 230.0) px += 1.2 * dt
            if (nextStop < stops.size && px >= stops[nextStop]) { pauseUntil = t + 25.0; nextStop++ }
        }
        sim.step(dt)
        val player = XY(px, 0.0)
        sim.fob = null                                     // the fob is out of reach
        if (sessions > 0) minDist = min(minDist, Geo.dist(sim.pos, player))
        minEdge = min(minEdge, edgeDist(map, sim.pos))
        t += dt
        if (t >= nextPhone) {
            nextPhone += 1.0
            pbx = 0.985 * pbx + rng.gauss() * 0.4; pby = 0.985 * pby + rng.gauss() * 0.4
            cbx = 0.985 * cbx + rng.gauss() * 0.4; cby = 0.985 * cby + rng.gauss() * 0.4
            val rp = XY(player.x + pbx + rng.gauss() * 0.6, player.y + pby + rng.gauss() * 0.6)
            val cg = XY(sim.pos.x + cbx + rng.gauss() * 0.6, sim.pos.y + cby + rng.gauss() * 0.6)
            val nowMs = (t * 1000).toLong()
            val s = session
            if (s == null) {
                if (t >= cooldownUntil && Geo.dist(cg, rp) > 20.0 && px < 229.0 + 1.0 || t >= cooldownUntil && Geo.dist(cg, rp) > 20.0) {
                    val ns = NavSession(map, cfg, { a, b -> guard.pathClearFrom(a, b) })
                    session = ns; sessions++
                    val h = HeadingEstimate(sim.heading + Math.toRadians(rng.gauss() * 4.0), 8.0, "test")
                    apply(ns.start(nowMs, cg, h, rp, 4.0, 4.0, 10.0))
                    if (!ns.active) { session = null; cooldownUntil = t + 15.0 }
                }
            } else apply(s.tick(NavInput(nowMs, rp, 4.0, true, sim.telemetry(), 0L, cg, 4.0, 0L)))
        }
        if (px >= 230.0 && t >= pauseUntil && session == null && Geo.dist(sim.pos, XY(px, 0.0)) < 20.0) { if (endStill < 0) endStill = t; if (t - endStill > 20.0) break }
        else endStill = -1.0
    }
    return ChaseResult(Geo.dist(sim.pos, XY(px, 0.0)), minDist, minEdge, sessions, caught || Geo.dist(sim.pos, XY(px, 0.0)) < 20.0)
}

class TeeResult(val parked: Boolean, val endErrM: Double, val minEdgeM: Double, val why: String)

/** "Drive to the next tee": the player walks on ahead (fob out of range), the cart is sent to a fixed spot with a green in between. */
fun runTeeDrive(seed: Long, scale: Double = 1.0, gyroBias: Double = 0.0, gpsOk: Boolean = true): TeeResult {
    val rng = Rng(seed)
    val map = GreenMap(ORIGIN, listOf(circle(40.0, 0.0, 15.0)))
    val cfg = GuardCfg()
    val guard = GreenGuard(cfg); guard.setMap(map)
    val sim = NavSimCart(XY(0.0, 0.0), 0.0, gyroOffsetRad = rng.uni(-3.0, 3.0), wheelScale = scale, gyroBiasRadS = gyroBias)
    sim.mode = CartMode.PARK
    val tee = XY(120.0, 30.0)
    val session = NavSession(map, cfg, { a, b -> guard.pathClearFrom(a, b) })
    var parked = false; var stopWhy: String? = null; var t = 0.0; var nextPhone = 0.0
    var minEdge = 999.0; var cbx = 0.0; var cby = 0.0
    fun apply(list: List<NavAct>) {
        for (a in list) when (a) {
            is NavAct.Send -> for (r in sim.handle(a.line)) CartProtocol.parse(r)?.let { m -> if (m is CartMsg.NavAck) apply(session.onAck(m.ok, (t * 1000).toLong())) }
            is NavAct.Stop -> { stopWhy = a.reason; sim.handle(CartProtocol.mode(CartMode.PARK)) }
            is NavAct.Parked -> { parked = true; sim.handle(CartProtocol.mode(CartMode.PARK)) }
            is NavAct.Handover -> stopWhy = "unexpected handover"
            is NavAct.Log -> if (System.getenv("TEE_LOG") != null) println("   [${t.roundToInt()}s] ${a.text}")
        }
    }
    val h = HeadingEstimate(sim.heading + Math.toRadians(rng.gauss() * 4.0), 8.0, "test")
    val player = XY(110.0, 25.0)                          // standing at the tee; the cart is 120 m away
    apply(session.start(0L, XY(0.0, 0.0), h, player, 4.0, if (gpsOk) 4.0 else null, 0.0, tee))
    if (!session.active) return TeeResult(false, 999.0, 999.0, session.status)
    val dt = 0.05
    while (t < 600.0 && !parked && stopWhy == null) {
        sim.step(dt); t += dt
        minEdge = min(minEdge, edgeDist(map, sim.pos))
        if (t >= nextPhone) {
            nextPhone += 1.0
            cbx = 0.985 * cbx + rng.gauss() * 0.4; cby = 0.985 * cby + rng.gauss() * 0.4
            val cg = XY(sim.pos.x + cbx + rng.gauss() * 0.6, sim.pos.y + cby + rng.gauss() * 0.6)
            apply(session.tick(NavInput((t * 1000).toLong(), player, 4.0, true, sim.telemetry(), 0L, if (gpsOk) cg else null, 4.0, 0L)))
            if (session.phase == NavPhase.FAILED && stopWhy == null) stopWhy = session.status
        }
    }
    return TeeResult(parked, Geo.dist(sim.pos, tee), minEdge, stopWhy ?: if (parked) "parked" else "timed out")
}

fun main() {
    // ------------------------------------------------------------ frames
    run {
        val f = NavFrame(XY(10.0, -5.0), 0.7)
        val w = XY(31.0, 14.0)
        val l = f.toLocal(w); val b = f.toWorld(l)
        ncheck(abs(b.x - w.x) < 1e-9 && abs(b.y - w.y) < 1e-9, "frame: world -> local -> world round trip")
        val ahead = f.toLocal(XY(10.0 + cos(0.7) * 5, -5.0 + sin(0.7) * 5))
        ncheck(abs(ahead.x - 5.0) < 1e-9 && abs(ahead.y) < 1e-9, "frame: a point straight ahead is +X")
        val left = f.toLocal(XY(10.0 - sin(0.7) * 3, -5.0 + cos(0.7) * 3))
        ncheck(abs(left.y - 3.0) < 1e-9 && abs(left.x) < 1e-9, "frame: a point to the left is +Y")
        ncheck(abs(wrapPi(3 * PI) - PI) < 1e-9 && abs(wrapPi(-3.5 * PI) - 0.5 * PI) < 1e-9, "wrapPi")
    }

    // ------------------------------------------------------------ protocol
    run {
        ncheck(CartProtocol.navPoint(2, 14.5, -3.25) == "{\"k\":\"navp\",\"i\":2,\"x\":14.50,\"y\":-3.25}\n", "wire: navp")
        ncheck(CartProtocol.navCommit(6, 1.0) == "{\"k\":\"navgo\",\"n\":6,\"v\":1.00}\n", "wire: navgo")
        ncheck(CartProtocol.navHeartbeat() == "{\"k\":\"navhb\"}\n" && CartProtocol.mode(CartMode.NAV) == "{\"k\":\"mode\",\"m\":\"nav\"}\n", "wire: navhb and mode nav")
        val tel = (CartProtocol.parse("{\"k\":\"tel\",\"m\":\"nav\",\"v\":20.1,\"yw\":-12.5,\"nr\":1,\"nx\":3.2,\"ny\":-1.1,\"nh\":14,\"ni\":2,\"ns\":2}") as CartMsg.Tel).t
        ncheck(tel.mode == CartMode.NAV && tel.yawDeg == -12.5 && tel.navReady && tel.navX == 3.2 && tel.navY == -1.1 && tel.navSeg == 2 && tel.navCode == NavCode.RUN, "parse: telemetry with route progress")
        val plain = (CartProtocol.parse("{\"k\":\"tel\",\"m\":\"follow\",\"v\":20.1}") as CartMsg.Tel).t
        ncheck(plain.navX == null && plain.yawDeg == null && !plain.navReady, "parse: telemetry without route fields")
        ncheck((CartProtocol.parse("{\"k\":\"nav\",\"ok\":1}") as CartMsg.NavAck).ok && !(CartProtocol.parse("{\"k\":\"nav\",\"ok\":0}") as CartMsg.NavAck).ok, "parse: nav ack")
        ncheck((CartProtocol.parse("{\"k\":\"cfg\",\"fd\":2.5,\"nav\":1}") as CartMsg.Cfg).c.navSupported, "parse: cfg says the firmware can drive routes")
    }

    // ------------------------------------------------------------ planner
    val green = circle(0.0, 0.0, 15.0)
    val map = GreenMap(ORIGIN, listOf(green))
    val cfg = GuardCfg()
    val planner = HazardPlanner(map, cfg)
    run {
        val open = planner.plan(XY(0.0, -100.0), XY(0.0, -140.0), 4.0, 6.0)
        ncheck(open.ok && open.worldPts.size == 2 && abs(open.lengthM - 40.0) < 0.5, "planner: open ground -> one straight leg")
        val p = planner.plan(XY(0.0, -31.0), XY(0.0, 33.0), 4.0, 6.0)
        ncheck(p.ok, "planner: round a green to the far side finds a route (${p.reason})")
        if (p.ok) {
            println("      route: ${p.worldPts.size} points, ${p.lengthM.roundToInt()} m, tightest spare ${"%.1f".format(p.tightestM)} m; points " + p.worldPts.joinToString(" ") { "(${it.x.roundToInt()},${it.y.roundToInt()})" })
            var minD = 999.0
            for (i in 1 until p.worldPts.size) { val n = 40; for (k in 0..n) { val f = k / n.toDouble(); minD = min(minD, edgeDist(map, XY(p.worldPts[i - 1].x + (p.worldPts[i].x - p.worldPts[i - 1].x) * f, p.worldPts[i - 1].y + (p.worldPts[i].y - p.worldPts[i - 1].y) * f))) } }
            ncheck(minD >= 8.0, "planner: the route stays at least 8 m off the green edge (min ${"%.1f".format(minD)} m)")
            ncheck(p.worldPts.size <= 24 && p.lengthM < 200.0, "planner: within the cart's limits (24 points, 250 m)")
            ncheck(p.worldPts.first() == XY(0.0, -31.0) && p.worldPts.last() == XY(0.0, 33.0), "planner: starts at the cart and ends at you")
            // every leg within the cart's accepted length range
            ncheck((1 until p.worldPts.size).all { Geo.dist(p.worldPts[it - 1], p.worldPts[it]).let { d -> d in 0.2..100.0 } }, "planner: every leg between 0.2 and 100 m")
        }
        val worse = planner.plan(XY(0.0, -31.0), XY(0.0, 33.0), 4.0, 20.0)
        ncheck(!worse.ok || worse.lengthM >= p.lengthM - 0.5, "planner: a less certain heading gives a route at least as wide (${worse.lengthM.roundToInt()} vs ${p.lengthM.roundToInt()} m)")
        ncheck(!planner.plan(XY(0.0, 0.0), XY(0.0, 40.0), 4.0, 6.0).ok, "planner: refuses to start from inside a green")
        // hazards all round: a lake and a green leave no way
        val walled = GreenMap(ORIGIN, listOf(green), listOf(circle(0.0, 60.0, 30.0)))
        val noWay = HazardPlanner(walled, cfg).plan(XY(0.0, -31.0), XY(0.0, 33.0), 4.0, 6.0)
        println("      with a lake in the way: ${noWay.ok} ${noWay.reason}")
        ncheck(noWay.ok || noWay.reason.isNotEmpty(), "planner: a blocked case gives a reason, not a crash")
        val tight = HazardPlanner(GreenMap(ORIGIN, listOf(circle(0.0, 0.0, 15.0), circle(0.0, 55.0, 15.0))), cfg).plan(XY(0.0, -31.0), XY(0.0, 80.0), 4.0, 6.0)
        println("      two greens in line: ${tight.ok} ${tight.reason} ${tight.lengthM.roundToInt()} m")
        ncheck(!tight.ok || tight.worldPts.all { edgeDist(GreenMap(ORIGIN, listOf(circle(0.0, 0.0, 15.0), circle(0.0, 55.0, 15.0))), it) >= 7.0 }, "planner: two greens in line -> a route that stays clear, or none")
    }

    // ------------------------------------------------------------ heading estimator
    run {
        val e = HeadingEstimator()
        val rng = Rng(7)
        val offset = 2.0                                     // gyro zero is 2 rad off the world
        val truth = Math.toRadians(35.0)                     // walking north-east-ish
        var px = 0.0; var py = 0.0
        for (k in 0..120) {
            val t = k * 1.0
            px += cos(truth) * 1.2; py += sin(truth) * 1.2
            e.addPlayer(t, XY(px + rng.gauss() * 1.0, py + rng.gauss() * 1.0))
            e.addCart(t, Math.toDegrees(truth - offset), 1.1)
        }
        val h = e.estimate(Math.toDegrees(truth - offset))!!
        val err = abs(Math.toDegrees(wrapPi(h.thetaRad - truth)))
        println("      heading from gyro+trail: error ${"%.1f".format(err)} deg, sigma ${"%.1f".format(h.sigmaDeg)}, ${e.sampleCount} samples")
        ncheck(err < 5.0, "heading estimator: within 5 degrees on a straight walk with 1 m GPS noise")
        ncheck(HeadingEstimator().estimate(0.0) == null, "heading estimator: no estimate without samples")
        val f = Heading.fuse(listOf(HeadingEstimate(0.0, 4.0, "a"), HeadingEstimate(0.2, 20.0, "b")))!!
        ncheck(f.thetaRad in 0.0..0.2 && f.thetaRad < 0.05 && f.sigmaDeg < 4.0, "heading fusion: the sharper estimate dominates")
        val u = Heading.fromUwb(XY(0.0, 0.0), XY(10.0, 0.0), 30.0, 10.0)!!        // fob 30 deg to the left of the nose and due east -> nose points -30 deg
        ncheck(abs(u.thetaRad + Math.toRadians(30.0)) < 1e-9, "heading from UWB bearing")
        ncheck(Heading.fromUwb(XY(0.0, 0.0), XY(30.0, 0.0), 0.0, 30.0) == null, "heading from UWB: not used beyond 12 m")
    }

    // ------------------------------------------------------------ guard additions
    run {
        val g = GreenGuard(cfg); g.setMap(map)
        var out: GuardOut? = null
        var tt = 0L
        for (i in 0..60) { out = g.step(XY(0.0, -80.0 + i * 1.0), 4.0, 2.5, false, tt); tt += 1000 }
        ncheck(out!!.hold && g.holdPosition() != null, "guard: holdPosition is set while holding")
        val d = g.holdDirection()
        ncheck(d != null && abs(wrapPi(d - PI / 2)) < 0.2, "guard: holdDirection points the way the player was walking")
        g.resumeFrom(XY(0.0, 30.0), 4.0)
        ncheck(g.holdPosition() == null && g.step(XY(0.0, 36.0), 4.0, 2.5, false, tt + 1000).hold == false, "guard: resumeFrom -> following again")
    }

    // ------------------------------------------------------------ session safety rules
    fun mkSession(): Pair<NavSession, GreenGuard> { val g = GreenGuard(cfg); g.setMap(map); return Pair(NavSession(map, cfg, { a, b -> g.pathClearFrom(a, b) }), g) }
    run {
        val (s, _) = mkSession()
        val a = s.start(0, XY(0.0, -31.0), HeadingEstimate(PI / 2, 6.0, "test"), XY(0.0, 33.0), 4.0)
        val sends = a.filterIsInstance<NavAct.Send>().map { it.line }
        ncheck(s.phase == NavPhase.WAIT_ACK && sends.isNotEmpty() && sends.last().contains("navgo") && sends.dropLast(1).all { it.contains("navp") }, "session: sends the points, then the commit")
        ncheck(sends.first().contains("\"x\":0.00,\"y\":0.00"), "session: the first point is the cart's own origin")
        val r = s.onAck(true, 100)
        ncheck(s.phase == NavPhase.STARTING && r.filterIsInstance<NavAct.Send>().any { it.line.contains("\"m\":\"nav\"") }, "session: after the commit is accepted it starts the route")
    }
    run {
        val (s, _) = mkSession()
        s.start(0, XY(0.0, -31.0), HeadingEstimate(PI / 2, 6.0, "test"), XY(0.0, 33.0), 4.0)
        val r = s.onAck(false, 100)
        ncheck(s.phase == NavPhase.FAILED && r.any { it is NavAct.Stop }, "session: the cart refuses the route -> stop, no drive")
    }
    run {
        val (s, _) = mkSession()
        val a = s.start(0, XY(0.0, 0.0), HeadingEstimate(0.0, 6.0, "test"), XY(0.0, 40.0), 4.0)
        ncheck(s.phase == NavPhase.FAILED && a.none { it is NavAct.Send }, "session: no route possible -> nothing is sent")
    }
    run {
        val (s, _) = mkSession()
        s.start(0, XY(0.0, -31.0), HeadingEstimate(PI / 2, 6.0, "test"), XY(0.0, 33.0), 4.0)
        val r = s.tick(NavInput(6000, XY(0.0, 33.0), 4.0, true, null, 0))
        ncheck(s.phase == NavPhase.FAILED && r.any { it is NavAct.Stop }, "session: no answer to the commit for 5 s -> give up")
    }
    fun running(): Pair<NavSession, NavSimCart> {
        val (s, _) = mkSession()
        val sim = NavSimCart(XY(0.0, -31.0), PI / 2)
        sim.fob = XY(0.0, 33.0)
        val acts = s.start(0, XY(0.0, -31.0), HeadingEstimate(PI / 2, 6.0, "test"), XY(0.0, 33.0), 4.0)
        fun feed(list: List<NavAct>) { for (a in list) if (a is NavAct.Send) for (r in sim.handle(a.line)) (CartProtocol.parse(r) as? CartMsg.NavAck)?.let { feed(s.onAck(it.ok, 100)) } }
        feed(acts)
        for (k in 0..20) sim.step(0.05)
        s.tick(NavInput(1000, XY(0.0, 33.0), 4.0, true, sim.telemetry(), 0))
        return Pair(s, sim)
    }
    run {
        val (s, sim) = running()
        ncheck(s.phase == NavPhase.RUNNING && sim.navCode == NavCode.RUN, "session: running once the cart says it is driving")
        for (k in 0..40) sim.step(0.05)
        val r = s.tick(NavInput(3000, XY(0.0, 33.0), 4.0, true, sim.telemetry(), 3500))
        ncheck(s.phase == NavPhase.FAILED && r.any { it is NavAct.Stop }, "session: telemetry older than 3 s -> stop")
    }
    run {
        val (s, sim) = running()
        val r = s.tick(NavInput(3000, XY(0.0, 33.0), 4.0, false, sim.telemetry(), 0))
        ncheck(s.phase == NavPhase.FAILED && r.any { it is NavAct.Stop }, "session: phone position lost -> stop")
    }
    run {
        val (s, sim) = running()
        // the cart claims it is 3 m from you while the dead-reckoned position says ~60 m
        var stopped = false
        for (k in 0..4) { sim.fob = XY(sim.pos.x + 3.0, sim.pos.y); val r = s.tick(NavInput(3000L + k * 1000, XY(0.0, 33.0), 4.0, true, sim.telemetry(), 0)); if (r.any { it is NavAct.Stop }) stopped = true }
        ncheck(stopped && s.phase == NavPhase.FAILED, "session: the fob range contradicts the cart's own position -> stop")
    }
    run {
        val (s, sim) = running()
        val t = sim.telemetry().copy(faults = 1)
        val r = s.tick(NavInput(3000, XY(0.0, 33.0), 4.0, true, t, 0))
        ncheck(s.phase == NavPhase.FAILED && r.any { it is NavAct.Stop }, "session: a cart fault -> stop")
    }
    run {
        val (s, sim) = running()
        val t = sim.telemetry().copy(navCode = NavCode.ABORT_OFFPATH)
        val r = s.tick(NavInput(3000, XY(0.0, 33.0), 4.0, true, t, 0))
        ncheck(s.phase == NavPhase.FAILED && r.any { it is NavAct.Stop }, "session: the cart aborts by itself -> the session ends")
    }

    // ------------------------------------------------------------ closed loop
    println("\n-- closed loop: player crosses the green, the cart goes round --")
    val perfect = runScenario(1, verbose = true)
    println("   result: ${perfect.why}; closest to the green ${"%.1f".format(perfect.minEdgeM)} m; ended ${"%.1f".format(perfect.endRangeM)} m from the player after ${perfect.routeSecs.roundToInt()} s; heading error ${"%.1f".format(perfect.headingErrDeg)} deg")
    ncheck(perfect.ok, "closed loop: good sensors -> the cart reaches you and hands back to Follow (${perfect.why})")
    ncheck(perfect.minEdgeM > 4.0, "closed loop: good sensors -> never closer than 4 m to the green (${"%.1f".format(perfect.minEdgeM)} m)")

    data class Case(val name: String, val scale: (Rng) -> Double, val bias: (Rng) -> Double, val steer: (Rng) -> Double, val gps: Double)
    val cases = listOf(
        Case("typical sensors", { it.uni(0.97, 1.03) }, { it.uni(-0.002, 0.002) }, { it.uni(0.97, 1.03) }, 1.5),
        Case("poor sensors (6% wheel error, double the gyro bias)", { it.uni(0.94, 1.06) }, { it.uni(-0.004, 0.004) }, { it.uni(0.94, 1.06) }, 2.5),
    )
    val verboseSeed = (System.getenv("NAV_SEED") ?: "-1").toInt(); val verboseCase = System.getenv("NAV_CASE") ?: ""
    println("\n-- same, with the phone riding on the cart (cart GPS) --")
    val aidedCases = cases.map { it.copy(name = it.name + ", GPS-aided") }
    for (c in aidedCases) {
        var ok = 0; var stopped = 0; var worst = 999.0; var mean = 0.0; var secs = 0.0; var errSum = 0.0
        val n = 25
        for (k in 0 until n) {
            val rr = Rng(5000L + k); val r = runScenario(1000L + k, c.scale(rr), c.bias(rr), c.steer(rr), c.gps, aided = true)
            if (r.ok) { ok++; secs += r.routeSecs } else if (r.why.startsWith("stopped")) stopped++
            if (!r.ok) println("      seed ${1000 + k}: ${r.why}; closest ${"%.1f".format(r.minEdgeM)} m")
            worst = min(worst, r.minEdgeM); mean += r.minEdgeM / n
        }
        println("   ${c.name}: $ok of $n reached the player, $stopped stopped themselves; closest approach to the green mean ${"%.1f".format(mean)} m, worst ${"%.1f".format(worst)} m; mean drive ${if (ok > 0) (secs / ok).roundToInt() else 0} s")
        ncheck(worst > 2.0, "closed loop, ${c.name}: in every one of $n runs the cart stayed off the green (worst ${"%.1f".format(worst)} m)")
        ncheck(ok >= n * 0.9, "closed loop, ${c.name}: at least 90% reach the player ($ok of $n)")
    }
    // the cart's GPS dying mid-route must end the route
    run {
        var allStopped = true; var worst = 999.0
        for (k in 0 until 8) { val r = runScenario(3000L + k, cartFault = "cartgps", faultAtS = 25.0, aided = true); if (r.ok) allStopped = false; worst = min(worst, r.minEdgeM) }
        ncheck(allStopped && worst > 2.0, "failure: the cart's GPS drops mid-route -> the route ends, cart stays off the green (${"%.1f".format(worst)} m)")
    }

    println("\n-- unaided, for comparison --")
    for (c in cases) {
        var ok = 0; var stopped = 0; var worst = 999.0; var mean = 0.0; var worstEnd = 0.0
        val n = 25
        for (k in 0 until n) {
            val rr = Rng(5000L + k); val r = runScenario(1000L + k, c.scale(rr), c.bias(rr), c.steer(rr), c.gps, verbose = verboseSeed == k && verboseCase == c.name)
            if (r.ok) ok++ else if (r.why.startsWith("stopped")) stopped++
            if (!r.ok || r.minEdgeM < 4.0) println("      seed ${1000 + k}: ${r.why}; closest ${"%.1f".format(r.minEdgeM)} m; heading err ${"%.1f".format(r.headingErrDeg)} deg")
            worst = min(worst, r.minEdgeM); mean += r.minEdgeM / n; worstEnd = max(worstEnd, r.endRangeM)
        }
        println("   ${c.name}: $ok of $n got to the player, $stopped stopped themselves, the rest never tried or timed out; closest approach to the green: mean ${"%.1f".format(mean)} m, worst ${"%.1f".format(worst)} m")
        ncheck(worst > 2.0, "closed loop, ${c.name}: in every one of $n runs the cart stayed off the green (worst ${"%.1f".format(worst)} m from the edge)")
        if (c.name.startsWith("typical")) ncheck(ok >= n * 0.8, "closed loop, ${c.name}: at least 80% reach the player ($ok of $n)")
        else ncheck(ok + stopped == n, "closed loop, ${c.name}: every run either reaches the player or stops itself ($ok + $stopped of $n)")
    }

    // ------------------------------------------------------------ failure injection
    println("\n-- failures during the route --")
    for ((fault, label) in listOf("link" to "the phone link drops", "switch" to "someone pauses the cart with its switch", "gps" to "the phone loses GPS")) {
        var worst = 999.0; var allStopped = true
        for (k in 0 until 8) {
            val r = runScenario(2000L + k, cartFault = fault, faultAtS = 25.0)
            worst = min(worst, r.minEdgeM)
            if (r.ok) allStopped = false
        }
        println("   $label: closest approach to the green over 8 runs ${"%.1f".format(worst)} m")
        ncheck(allStopped, "failure: $label -> the go-around never completes (the cart stops)")
        ncheck(worst > 2.0, "failure: $label -> the cart still stays off the green (${"%.1f".format(worst)} m)")
    }

    println("\n-- GPS follow: the fob is gone, the cart chases the watch's position --")
    run {
        var good = 0; var worstMin = 999.0; var worstEdge = 999.0; var worstFinal = 0.0; var sess = 0
        val n = 12
        for (k in 0 until n) {
            val only = System.getenv("CHASE_ONLY")?.toInt(); if (only != null && only != k) continue
            val rr = Rng(7000L + k)
            val r = runChase(8000L + k, rr.uni(0.97, 1.03), rr.uni(-0.002, 0.002))
            if (r.caught) good++
            worstMin = min(worstMin, r.minDistM); worstEdge = min(worstEdge, r.minEdgeM); worstFinal = max(worstFinal, r.finalDistM); sess += r.sessions
            if (!r.caught) println("      seed ${8000 + k}: final ${"%.0f".format(r.finalDistM)} m, closest to you ${"%.1f".format(r.minDistM)} m")
        }
        println("   $good of $n ended near the player (worst final gap ${"%.0f".format(worstFinal)} m); closest to the player ${"%.1f".format(worstMin)} m; closest to the green ${"%.1f".format(worstEdge)} m; ${"%.1f".format(sess / n.toDouble())} routes per run")
        ncheck(worstMin > 4.0, "gps-follow: the cart never came within 4 m of the player (closest ${"%.1f".format(worstMin)} m)")
        ncheck(worstEdge > 3.0, "gps-follow: the cart stayed off the green (closest ${"%.1f".format(worstEdge)} m)")
        ncheck(good >= n - 1, "gps-follow: it caught up with the player at the end ($good of $n)")
    }

    println("\n-- Drive to the next tee: a fixed spot, the player is elsewhere --")
    run {
        var ok = 0; var worstErr = 0.0; var worstEdge = 999.0; val n = 10
        for (k in 0 until n) {
            val rr = Rng(9100L + k)
            val r = runTeeDrive(9200L + k, rr.uni(0.97, 1.03), rr.uni(-0.002, 0.002))
            if (r.parked && r.endErrM < 8.0) ok++
            worstErr = max(worstErr, r.endErrM); worstEdge = min(worstEdge, r.minEdgeM)
            if (!r.parked) println("      seed ${9200 + k}: ${r.why}, ${"%.0f".format(r.endErrM)} m from the tee")
        }
        println("   $ok of $n parked within 8 m of the tee (worst ${"%.1f".format(worstErr)} m); closest to the green ${"%.1f".format(worstEdge)} m")
        var okNoGps = 0; var worstNoGps = 0.0
        for (k in 0 until n) { val rr = Rng(9400L + k); val r = runTeeDrive(9500L + k, rr.uni(0.97, 1.03), rr.uni(-0.002, 0.002), gpsOk = false); if (r.parked && r.endErrM < 25.0) okNoGps++; worstNoGps = max(worstNoGps, r.endErrM) }
        println("   without the cart's own GPS (dead reckoning only): $okNoGps of $n parked within 25 m of the tee (worst ${"%.1f".format(worstNoGps)} m)")
        ncheck(okNoGps >= n - 1, "tee-drive: by dead reckoning alone (130 m) it still parks within 25 m of the tee - drift is real, so the app limits unaided drives to 100 m ($okNoGps of $n)")
        ncheck(ok >= n - 1, "tee-drive: it parks at the tee ($ok of $n)")
        ncheck(worstEdge > 3.0, "tee-drive: it stays off the green on the way (closest ${"%.1f".format(worstEdge)} m)")
        // the session must never hand over to following when the goal is a fixed spot
        val r2 = runTeeDrive(9301L)
        ncheck(r2.why != "unexpected handover", "tee-drive: never hands over to following")
        // an unreachable tee (inside the green) is refused, not attempted
        val sess = NavSession(map, cfg, { a, b -> true })
        val acts = sess.start(0L, XY(0.0, -40.0), HeadingEstimate(0.0, 5.0, "test"), XY(0.0, 0.0), 4.0, null, 0.0, XY(0.0, 0.0))
        ncheck(!sess.active && acts.none { it is NavAct.Send }, "tee-drive: a goal inside a hazard is refused and nothing is sent to the cart")
    }

    // ------------------------------------------------------------ guard working from a measured cart position
    run {
        val green = circle(0.0, 0.0, 15.0)
        val map2 = GreenMap(ORIGIN, listOf(green)); val cfg2 = GuardCfg()
        fun walk(cartBehind: Double?): Triple<Boolean, XY?, Double> {
            val g = GreenGuard(cfg2); g.setMap(map2)
            var hold = false; var pos: XY? = null; var t = 0L; var playerY = 0.0
            var y = -80.0
            while (y < 0.0) {
                if (cartBehind != null) g.cartFix(XY(0.0, y - cartBehind), 4.0, t)
                val o = g.step(XY(0.0, y), 4.0, 2.5, false, t)
                if (o.hold && !hold) { hold = true; pos = g.holdPosition(); playerY = y }
                y += 1.2; t += 1000
            }
            return Triple(hold, pos, playerY)
        }
        val est = walk(null); val near = walk(2.5); val far = walk(14.0)
        ncheck(est.first && near.first && abs(near.second!!.y - est.second!!.y) < 3.0, "guard: a measured cart 2.5 m behind you holds where the estimate does")
        ncheck(far.first && far.third > est.third + 8.0 && abs(far.second!!.y - est.second!!.y) < 3.0, "guard: a cart that has really fallen 14 m behind is held at the same spot, but later (player at y=${far.third.roundToInt()} vs ${est.third.roundToInt()})")
        val g = GreenGuard(cfg2); g.setMap(map2)
        g.cartFix(XY(0.0, -60.0), 4.0, 0L); g.step(XY(0.0, -40.0), 4.0, 2.5, false, 1000L)
        ncheck(g.cartMeasured(), "guard: reports it is working from a measured cart")
        g.step(XY(0.0, -39.0), 4.0, 2.5, false, 9000L)
        ncheck(!g.cartMeasured(), "guard: a measured position older than 3 s is ignored")
    }

    println("\n$nPass passed, $nFail failed")
    if (nFail > 0) System.exit(1)
}
