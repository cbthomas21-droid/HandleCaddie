import com.handlecaddie.controller.core.*
import kotlin.math.*

var xPass = 0; var xFail = 0
fun xc(c: Boolean, m: String) { if (c) { xPass++; println("ok:   $m") } else { xFail++; println("FAIL: $m") } }

fun main() {
    val o = LatLon(41.7, -111.8)
    // ---- geo helpers
    val p = XY(120.0, -80.0)                       // 120 m east, 80 m NORTH (y is south)
    val ll = Geo.toLatLon(o, p); val back = Geo.toLocal(o, ll)
    xc(abs(back.x - p.x) < 0.01 && abs(back.y - p.y) < 0.01, "geo: toLatLon is the inverse of toLocal")
    xc(abs(Geo.compassDeg(XY(0.0, 0.0), XY(0.0, -10.0)) - 0.0) < 1e-6 && abs(Geo.compassDeg(XY(0.0, 0.0), XY(10.0, 0.0)) - 90.0) < 1e-6 && abs(Geo.compassDeg(XY(0.0, 0.0), XY(0.0, 10.0)) - 180.0) < 1e-6, "geo: compass bearings (north = -y)")

    // ---- plays like
    val calm = PlaysLikeCalc.compute(150, 0.0, null, null, null, true)
    xc(calm.playsYd == 150 && !calm.changed && calm.summary == "", "plays-like: no data -> same number, no message")
    val head = PlaysLikeCalc.compute(150, 0.0, Conditions(21.0, 5.0, 0.0), null, null, false)      // 5 m/s from the north while hitting north
    xc(head.playsYd > 150 && head.headwindMph!! > 10.0, "plays-like: wind from the target is a headwind and plays longer (${head.playsYd})")
    val tail = PlaysLikeCalc.compute(150, 0.0, Conditions(21.0, 5.0, 180.0), null, null, false)
    xc(tail.playsYd < 150 && (150 - tail.playsYd) < (head.playsYd - 150), "plays-like: a tailwind helps, but less than a headwind hurts (${tail.playsYd})")
    val cross = PlaysLikeCalc.compute(150, 0.0, Conditions(21.0, 5.0, 90.0), null, null, false)
    xc(cross.playsYd == 150, "plays-like: a pure crosswind does not change the distance")
    xc(PlaysLikeCalc.compute(150, 270.0, Conditions(21.0, 5.0, 270.0), null, null, false).playsYd == head.playsYd, "plays-like: depends only on wind relative to the shot")
    val up = PlaysLikeCalc.compute(150, 0.0, null, 10.0, null, false)
    xc(up.elevYd in 10..12 && up.playsYd > 150, "plays-like: 10 m uphill is about +11 yd (${up.elevYd})")
    xc(PlaysLikeCalc.compute(150, 0.0, null, -10.0, null, false).playsYd < 150, "plays-like: downhill plays shorter")
    xc(PlaysLikeCalc.compute(150, 0.0, null, 500.0, null, false).playsYd == 150 + 38, "plays-like: elevation is capped at 25% (a bad reading cannot move it far)")
    xc(PlaysLikeCalc.compute(150, 0.0, Conditions(5.0, 0.0, 0.0), null, null, false).tempYd > 0 && PlaysLikeCalc.compute(150, 0.0, Conditions(35.0, 0.0, 0.0), null, null, false).tempYd < 0, "plays-like: cold plays longer, heat plays shorter")
    val alt = PlaysLikeCalc.compute(150, 0.0, null, null, 1400.0, true)
    xc(alt.altYd in -10..-6, "plays-like: 1400 m (Cache Valley) plays about 5% shorter (${alt.altYd})")
    xc(PlaysLikeCalc.compute(150, 0.0, null, null, 1400.0, false).altYd == 0, "plays-like: altitude left out when the club distances were measured on a course")
    val s = PlaysLikeCalc.compute(150, 0.0, Conditions(21.0, 5.0, 0.0), 4.0, null, false).summary
    xc(s.startsWith("Plays 1") && s.contains("headwind") && s.contains("uphill"), "plays-like: summary reads like a caddie ($s)")

    // ---- parsing
    val w = ConditionsParse.weather("""{"latitude":41.7,"current":{"time":"x","temperature_2m":12.3,"wind_speed_10m":4.1,"wind_direction_10m":250}}""", 5L)!!
    xc(w.tempC == 12.3 && w.windMs == 4.1 && w.windFromDeg == 250.0 && w.fetchedMs == 5L, "parse: weather")
    xc(ConditionsParse.weather("not json", 0) == null && ConditionsParse.weather("""{"current":{}}""", 0)!!.tempC == null, "parse: bad weather -> null / unknown parts")
    xc(ConditionsParse.elevationM("""{"location":{"x":-111.8,"y":41.7},"value":1362.55,"units":"Meters"}""") == 1362.55, "parse: elevation")
    xc(ConditionsParse.elevationM("""{"value":-1000000}""") == null && ConditionsParse.elevationM("junk") == null, "parse: no-data elevation -> null")

    // ---- hole profile
    val tee = XY(0.0, 0.0); val pin = XY(0.0, -150.0)
    xc(abs(HoleProfile.elevDelta(tee, pin, tee, 1000.0, 1010.0)!! - 10.0) < 1e-9, "hole profile: from the tee the pin is the full rise")
    xc(abs(HoleProfile.elevDelta(tee, pin, XY(0.0, -75.0), 1000.0, 1010.0)!! - 5.0) < 1e-9, "hole profile: halfway, half the rise is left")
    xc(HoleProfile.elevDelta(tee, pin, tee, null, 1010.0) == null, "hole profile: unknown height -> unknown")

    // ---- battery
    run {
        val b = BatteryForecast()
        xc(b.forecast(80, 10, null).holesOnBattery == null, "battery: no driving yet -> says it is still learning")
        b.add(0.0, 90); b.add(300.0, 89); b.add(800.0, 86)
        xc(abs(b.pctPerKm()!! - 5.0) < 1e-9, "battery: 4 points over 800 m = 5% per km (${b.pctPerKm()})")
        val f = b.forecast(86, 12, 450.0)                       // 5 %/km x 0.45 km = 2.25 % per hole; (86-15)/2.25 = 31 holes
        xc(!f.warn && f.holesOnBattery!! > 30.0, "battery: plenty -> no warning (${f.text})")
        val g = b.forecast(30, 12, 450.0)                       // (30-15)/2.25 = 6.7 holes
        xc(g.warn && g.holesOnBattery!! in 6.0..7.0 && g.text.contains("6 more holes"), "battery: not enough -> warns (${g.text})")
        b.add(5.0, 80)                                         // trip counter reset
        xc(b.pctPerKm() == null, "battery: a trip reset starts the learning again")
    }

    // ---- cart locator
    run {
        val l = CartLocator()
        var t = 0L
        fun at(x: Double, up: Boolean) = l.update(up, XY(x, 0.0), t).also { t += 1000 }
        for (i in 0 until 40) at(i * 1.0, true)                // together for 40 s, ending at x=39
        xc(l.update(true, XY(40.0, 0.0), t).alert == CartLocator.Alert.NONE, "locator: with the cart connected there is no alert")
        t += 1000
        var fresh = 0; var last = at(41.0, false)
        for (x in 42..130) { last = at(x.toDouble(), false); if (last.newAlert) fresh++ }
        xc(fresh >= 1 && last.alert == CartLocator.Alert.LEFT_BEHIND, "locator: walking 60+ m from where the link dropped -> left-behind alert (${last.alert}, away ${last.awayM?.roundToInt()} m)")
        xc(abs(last.bearingDeg!! - 270.0) < 1.0, "locator: the cart is to the west of you (${last.bearingDeg})")
        var far = false
        for (x in 131..260) { val r = at(x.toDouble(), false); if (r.newAlert && r.alert == CartLocator.Alert.FAR_BEHIND) far = true }
        xc(far, "locator: a second, stronger alert at 150 m")
        val back = at(60.0, true)
        xc(back.alert == CartLocator.Alert.NONE, "locator: reconnecting clears it")
    }
    run {
        val l = CartLocator(); var t = 0L
        for (i in 0 until 10) { l.update(true, XY(i.toDouble(), 0.0), t); t += 1000 }       // only 10 s connected: not really a cart in use
        var any = false
        for (x in 10..300) { if (l.update(false, XY(x.toDouble(), 0.0), t).newAlert) any = true; t += 1000 }
        xc(!any, "locator: a link that was only up for 10 s never raises an alert")
        val m = CartLocator(); t = 0L
        for (i in 0 until 40) { m.update(true, XY(0.0, 0.0), t); t += 1000 }
        m.disarm()
        var any2 = false
        for (x in 1..300) { if (m.update(false, XY(x.toDouble(), 0.0), t).newAlert) any2 = true; t += 1000 }
        xc(!any2, "locator: after Disconnect (disarm) it stays quiet")
        val q = CartLocator(); t = 0L
        for (i in 0 until 40) { q.update(true, XY(0.0, 0.0), t); t += 1000 }
        var wob = false
        for (i in 0 until 60) { if (q.update(false, XY(if (i % 2 == 0) 62.0 else 20.0, 0.0), t).newAlert) wob = true; t += 1000 }
        xc(!wob, "locator: a brief GPS jump past 60 m does not alert")
    }

    WatchTests.run()
    ManualDriveTests.run()
    println("\n$xPass passed, $xFail failed")
    if (xFail > 0) System.exit(1)
}

object WatchTests {
    fun run() {
        val s = WatchState(4, 4, 152, 160, "7 Iron", "follow", 78, "Green ahead", "Cart holding", 5, true)
        val back = WatchProtocol.decodeState(WatchProtocol.encodeState(s))
        xc(back == s, "watch: state survives encode/decode")
        val min = WatchProtocol.decodeState(WatchProtocol.encodeState(WatchState(1, 3)))!!
        xc(min.toPinYd == null && min.cartMode == null && min.advanceTo == null && !min.posFromWatch, "watch: absent fields stay null")
        xc(WatchProtocol.decodeState("garbage") == null, "watch: garbage state -> null")
        val g = WatchProtocol.decodeGps(WatchProtocol.encodeGps(41.7085, -111.8479, 6.5f))!!
        xc(abs(g.first - 41.7085) < 1e-9 && abs(g.second + 111.8479) < 1e-9 && g.third == 6.5f, "watch: gps round trip")
        xc(WatchProtocol.decodeGps("""{"la":0,"lo":0,"ac":5}""") == null && WatchProtocol.decodeGps("""{"la":95,"lo":0}""") == null && WatchProtocol.decodeGps("{}") == null, "watch: nonsense positions are refused")
        xc(WatchCmd.entries.all { WatchCmd.fromWire(it.wire) == it } && WatchCmd.fromWire("x") == null, "watch: command names round trip")
        val o = AdvanceOffer(60_000L)
        xc(o.current(4, 0) == null, "advance: no offer to begin with")
        o.onHoleOut(5, 1_000L)
        xc(o.current(5, 2_000L) == 5, "advance: offered after a hole-out")
        xc(o.current(6, 3_000L) == null, "advance: gone once the app is already past it")
        o.onHoleOut(5, 10_000L); o.dismiss()
        xc(o.current(5, 11_000L) == null, "advance: dismissed")
        o.onHoleOut(5, 10_000L)
        xc(o.current(5, 80_000L) == null, "advance: times out")
        o.onHoleOut(null, 0L)
        xc(o.current(18, 1L) == null, "advance: nothing offered after the last hole")
    }
}

object ManualDriveTests {
    fun run() {
        println("\n-- Manual driving from the watch and creep --")
        xc(WatchProtocol.decodeState(WatchProtocol.encodeState(WatchState(1, 3, drive = true)))!!.drive && !WatchProtocol.decodeState(WatchProtocol.encodeState(WatchState(1, 3)))!!.drive, "drive: the watch is told whether driving is allowed")
        xc(ManualDrive.decodeWatch("f") == (0.0 to 1.0) && ManualDrive.decodeWatch("l")!!.first < 0 && ManualDrive.decodeWatch("r")!!.first > 0 && ManualDrive.decodeWatch("0") == (0.0 to 0.0), "drive: codes f / l / r / 0")
        xc(ManualDrive.decodeWatch("") == null && ManualDrive.decodeWatch("b") == null && ManualDrive.decodeWatch("ff") == null && ManualDrive.decodeWatch("1") == null, "drive: unknown codes are ignored (there is no reverse code)")
        xc(ManualDrive.decodeWatch("l")!!.second >= 0 && ManualDrive.decodeWatch("r")!!.second >= 0, "drive: no code asks for backwards")
        // the pulse lapses by itself
        val t = TimedDrive()
        xc(t.current(0) == null, "drive: nothing pending to start with")
        t.pulse(1_000, 0.0, 1.0, ManualDrive.WATCH_PULSE_MS)
        xc(t.current(1_200) == (0.0 to 1.0), "drive: a frame keeps the cart driving for its pulse")
        xc(t.current(1_000 + ManualDrive.WATCH_PULSE_MS) == null && !t.pending, "drive: with no further frame it lapses by itself")
        // a burst of late frames cannot pile up time
        val b = TimedDrive()
        for (i in 0 until 50) b.pulse(5_000, 0.0, 1.0, ManualDrive.WATCH_PULSE_MS)
        xc(b.current(5_000 + ManualDrive.WATCH_PULSE_MS) == null, "drive: 50 queued frames arriving together still end 0.35 s after they land")
        t.pulse(0, 0.0, 1.0, 1000); t.pulse(10, 0.0, 0.0, 1000)
        xc(t.current(20) == null, "drive: letting go ('0') stops it at once")
        t.pulse(0, 0.0, 1.0, 1000); t.clear()
        xc(t.current(1) == null, "drive: clear (STOP, mode change) stops it at once")
        xc(TimedDrive().also { it.pulse(0, 2.0, 5.0, 1000) }.current(1) == (1.0 to 1.0), "drive: out-of-range values are clamped")
        // speed cap
        xc(ManualDrive.scale(1.0, 0.5) == 0.5 && ManualDrive.scale(1.0, 5.0) == 1.0 && ManualDrive.scale(1.0, 0.0) == ManualDrive.CAP_MIN && ManualDrive.scale(-1.0, 0.5) == 0.0, "drive: the speed cap scales forward, never goes below its minimum, never reverses")
        xc(abs(ManualDrive.scale(1.0, ManualDrive.CAP_DEFAULT) * CartConfig.MANUAL_MAX_MS - 0.6) < 1e-9, "drive: default cap is 0.6 m/s (a slow walk)")
        for (cap in listOf(0.2, 0.5, 1.0)) {
            val v = ManualDrive.scale(ManualDrive.creepFraction(cap), cap) * CartConfig.MANUAL_MAX_MS
            xc(v <= ManualDrive.CREEP_SPEED_MS + 0.011 && v >= 0.2, "drive: creep never exceeds ~${ManualDrive.CREEP_SPEED_MS} m/s (cap $cap gives ${"%.2f".format(v)}; a very low cap just makes it slower)")
        }
        val dist = ManualDrive.CREEP_SPEED_MS * ManualDrive.CREEP_MS / 1000.0
        xc(dist in 0.3..0.6, "drive: one creep is about ${"%.2f".format(dist)} m")
    }
}
