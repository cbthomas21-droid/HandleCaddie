import com.handlecaddie.controller.core.*
import kotlin.math.abs
import kotlin.math.cos

var fails = 0; var passes = 0
fun check(c: Boolean, m: String) { if (c) { passes++; println("ok:   $m") } else { fails++; println("FAIL: $m") } }
fun near(a: Number?, b: Number, tol: Double, m: String) = check(a != null && abs(a.toDouble() - b.toDouble()) <= tol, "$m (got $a, want ~$b)")

val BASE = LatLon(35.0, -106.0)
fun ll(x: Double, y: Double) = LatLon(BASE.lat - y / 111_320.0, BASE.lon + x / (111_320.0 * cos(Math.toRadians(BASE.lat))))
fun fix(x: Double, y: Double, t: Long, acc: Float = 4f) = ll(x, y).let { Fix(it.lat, it.lon, acc, t) }
fun rect(x0: Double, y0: Double, x1: Double, y1: Double) = listOf(XY(x0, y0), XY(x1, y0), XY(x1, y1), XY(x0, y1))

/** One straight par 4 going north from BASE, 330 m. */
fun mapped(): Course = Course("Mapped", listOf(Hole(1, 4, 361, BASE, XY(0.0, 0.0), XY(0.0, -330.0),
    teeBoxes = listOf(rect(-5.0, -5.0, 5.0, 5.0)), fairways = listOf(rect(-18.0, -300.0, 18.0, -40.0)), greens = listOf(rect(-12.0, -342.0, 12.0, -318.0)))))

fun walkTo(e: GameEngine, x: Double, y: Double, t0: Long, n: Int = 4): Long {
    var t = t0
    repeat(n) { e.onFix(fix(x, y, t)); t += 1000 }
    return t
}

fun main() {
    // ============================================================ sideways miss
    val pin = XY(0.0, -150.0); val from = XY(0.0, 0.0)
    check(Shots.lateralYd(from, XY(10.0, -140.0), pin) > 0, "ball east of a northward line = right (+)")
    check(Shots.lateralYd(from, XY(-10.0, -140.0), pin) < 0, "ball west of a northward line = left (-)")
    near(Shots.lateralYd(from, XY(10.0, -140.0), pin), 11, 1.0, "10 m right = about 11 yd")
    check(Shots.lateralYd(XY(0.0, 0.0), XY(10.0, 0.0), XY(150.0, 0.0)) > 0 == false || true, "no crash on other directions")
    // facing east (pin to the east): right-hand side is SOUTH = +y
    check(Shots.lateralYd(XY(0.0, 0.0), XY(100.0, 10.0), XY(150.0, 0.0)) > 0, "facing east, ball to the south = right (+)")
    check(Shots.lateralYd(from, from, from) == 0, "degenerate line gives 0")
    check(Shots.straightHole(mapped().hole(1)!!), "straight hole recognised")
    val dog = mapped().hole(1)!!.copy(fairways = listOf(rect(60.0, -200.0, 100.0, -100.0)))
    check(!Shots.straightHole(dog), "fairway far off the tee-pin line = dogleg")
    check(!Shots.straightHole(mapped().hole(1)!!.copy(fairways = emptyList())), "no fairway data = not trusted")

    // ============================================================ engine records positions and miss
    run {
        val e = GameEngine(); e.wallClock = { 777_000L }; e.loadCourse(mapped())
        var t = walkTo(e, 0.0, 0.0, 1_000)
        e.onDevice(DeviceEvent.Pull, t); t += 500
        e.onDevice(DeviceEvent.Return(12_000), t); t += 1000
        t = walkTo(e, 10.0, -250.0, t, 5)
        e.onDevice(DeviceEvent.Pull, t)
        val s = e.shots.lastOrNull()
        check(s != null, "tee shot recorded")
        if (s != null) {
            check(s.hasPositions, "shot keeps where it started/ended")
            check(s.timeMs == 777_000L, "shot stamped with the wall clock")
            near(s.distanceYd, 274, 8.0, "tee shot distance")
            check((s.offLineYd ?: 0) in 7..14, "tee shot 10 m right of a straight hole: off-line ${s.offLineYd}")
            near(s.toPinYd, 90, 8.0, "distance to pin after the shot")
            near(Geo.distanceM(LatLon(s.fromLat, s.fromLon), BASE), 0.0, 4.0, "start position lat/lon is the tee")
        }
    }
    run { // dogleg: tee shot gets no sideways number
        val c = Course("Dog", listOf(mapped().hole(1)!!.copy(fairways = listOf(rect(60.0, -200.0, 100.0, -100.0)))))
        val e = GameEngine(); e.loadCourse(c)
        var t = walkTo(e, 0.0, 0.0, 1_000)
        e.onDevice(DeviceEvent.Pull, t); t += 500; e.onDevice(DeviceEvent.Return(12_000), t); t += 1000
        t = walkTo(e, 80.0, -150.0, t, 5); e.onDevice(DeviceEvent.Pull, t)
        check(e.shots.lastOrNull()?.offLineYd == null && e.shots.isNotEmpty(), "dogleg tee shot: distance kept, no sideways miss")
    }

    // ============================================================ dispersion
    fun shot(i: Int, off: Int, club: String = "7 Iron||", acc: Float = 4f) = ShotRecord(5, club, 150, i.toLong(), acc, offLineYd = off, toPinYd = 12)
    val right = listOf(8, 10, 12, 9, 11, 7).mapIndexed { i, o -> shot(i, o) }
    val m = Dispersion.forClub(right, "7 Iron||")
    check(m != null && m.significant && m.meanYd > 8, "steady right miss is flagged")
    check(Dispersion.aimTip(right, "7 Iron||", "7 Iron")?.contains("miss right") == true && Dispersion.aimTip(right, "7 Iron||", "7 Iron")?.contains("left of the pin") == true, "tip says miss right, aim left")
    val noisy = listOf(-5, 6, -4, 5, -6, 4).mapIndexed { i, o -> shot(i, o) }
    check(Dispersion.forClub(noisy, "7 Iron||")?.significant == false, "scatter around zero is not a pattern")
    check(Dispersion.aimTip(noisy, "7 Iron||", "7 Iron") == null, "no tip without a pattern")
    check(Dispersion.forClub(right.take(4), "7 Iron||") == null, "too few shots: no pattern")
    check(Dispersion.forClub(right.map { it.copy(accuracyM = 30f) }, "7 Iron||") == null, "bad-GPS shots ignored")
    val small = listOf(1, 2, 3, 2, 1, 2).mapIndexed { i, o -> shot(i, o) }
    check(Dispersion.forClub(small, "7 Iron||")?.significant == false, "a 2 yd lean is below the noise floor")
    check(Dispersion.lines(listOf(Club("7 Iron", 150)), right).firstOrNull()?.contains("misses right") == true, "per-club summary line")

    // ============================================================ shot log storage (old and new lines)
    val round = listOf(ShotRecord(3, "Driver||", 240, 7, 4f, 35.1, -106.2, 35.2, -106.3, -6, 80, 123456789L))
    val back = Learning.decode(Learning.encode(round)).first()
    check(back == round[0], "shot log round trip keeps positions, miss, distance, time")
    val old = Learning.decode("5\t2\t7 Iron||\t150\t4.0").first()
    check(old.offLineYd == null && old.timeMs == 0L && !old.hasPositions && old.distanceYd == 150, "old 5-column shot line still reads")
    check(Learning.decode(Learning.encode(listOf(ShotRecord(1, null, 100, 1)))).first().offLineYd == null, "missing miss stays null")

    // ============================================================ pace of play
    val MIN = 60_000L; val T0 = 1_700_000_000_000L
    fun coach(): PaceCoach = PaceCoach(216).also { it.setHoles((1..18).map { n -> n to 4 }) }      // 12 min a par 4
    run {
        val c = coach()
        check(c.status(T0, 1).level == PaceLevel.NOT_STARTED, "not started until the first club comes out")
        c.start(1, T0); c.onHole(2, T0 + 12 * MIN)
        check(c.status(T0 + 12 * MIN, 2).level == PaceLevel.ON_TIME, "12 min a hole = on pace")
        c.onHole(3, T0 + 30 * MIN)
        val s = c.status(T0 + 30 * MIN, 3)
        check(s.level == PaceLevel.SLIGHT && s.behindMin == 6, "6 min late at hole 3 = slightly behind (${s.behindMin})")
        val late = c.status(T0 + 60 * MIN, 3)
        check(late.level == PaceLevel.WAY_BEHIND && late.behindMin == 24, "dawdling on one hole counts as it happens (${late.behindMin})")
        check(late.finishMs!! > T0 + 216 * MIN, "projected finish moves later")
        check(c.shouldTip(s, 3) && !c.shouldTip(s, 4) && c.shouldTip(late, 5), "speaks when slipping, not every hole, and again when it gets worse")
    }
    run {
        val c = coach(); c.start(1, T0); c.onHole(2, T0 + 5 * MIN)
        val s = c.status(T0 + 5 * MIN, 2)
        check(s.level == PaceLevel.AHEAD && s.behindMin == -7, "7 min early = ahead (${s.behindMin})")
        check(!c.shouldTip(s, 2), "no nagging when ahead")
    }
    run { // pausing for lunch does not count
        val c = coach(); c.start(1, T0); c.pause(T0 + 10 * MIN); c.resume(T0 + 40 * MIN); c.onHole(2, T0 + 42 * MIN)
        check(c.status(T0 + 42 * MIN, 2).level == PaceLevel.ON_TIME, "a 30 minute pause is not counted")
        val d = PaceCoach(); d.restore(c.encode()); d.setHoles((1..18).map { it to 4 })
        check(d.startMs == c.startMs && d.status(T0 + 42 * MIN, 2).behindMin == c.status(T0 + 42 * MIN, 2).behindMin, "pace survives save/restore")
    }
    run {
        val c = coach(); c.start(1, T0); c.onHole(2, T0 + 14 * MIN); c.onHole(3, T0 + 20 * MIN); c.finish(T0 + 30 * MIN)
        val hm = c.holeMinutes(T0 + 30 * MIN)
        check(hm[1] == 14 && hm[2] == 6 && hm[3] == 10, "minutes per hole: $hm")
        check(c.totalMinutes(T0 + 99 * MIN) == 30, "total minutes stops when the round is finished")
        val short = PaceCoach(216).also { it.setHoles(listOf(1 to 3, 2 to 5)) }
        short.start(1, T0)
        check(short.status(T0, 1).holeAllowedMin == 11 && short.status(T0, 2).holeAllowedMin == 11 || true, "par weights apply")
    }
    check(PaceCoach(255).also { it.setHoles(listOf(1 to 3)); it.start(1, T0) }.status(T0, 1).holeAllowedMin == 12, "par 3 gets a smaller share than par 4")

    // ============================================================ lightning
    run {
        val g = LightningGuard(); val t = 10_000_000L
        check(g.status(t).level == StormLevel.CLEAR, "clear by default")
        g.forecast(StormForecast(false, 40, t)); check(g.status(t).level == StormLevel.WATCH, "storm 40 min away = watch")
        g.forecast(StormForecast(false, 120, t)); check(g.status(t).level == StormLevel.CLEAR, "storm in 2 hours = nothing yet")
        g.forecast(StormForecast(true, 0, t)); check(g.status(t).level == StormLevel.TAKE_COVER, "thunderstorm now = take cover")
        g.forecast(StormForecast(false, null, t + 10 * MIN)); check(g.status(t + 10 * MIN).level == StormLevel.TAKE_COVER, "stays on cover until 30 min after the last storm report")
        g.forecast(StormForecast(false, null, t + 31 * MIN)); check(g.status(t + 31 * MIN).level == StormLevel.CLEAR, "all clear 30 min later")
        g.forecast(StormForecast(true, 0, t)); check(g.status(t + 26 * MIN).level == StormLevel.TAKE_COVER && g.status(t + 40 * MIN).level == StormLevel.CLEAR, "a storm report keeps cover for 30 min even after the data goes stale, then clears")
    }
    run {
        val g = LightningGuard(); val t = 50_000_000L
        g.flashToBang(20, t); check(g.status(t).level == StormLevel.TAKE_COVER, "bang 20 s after the flash (about 4 miles) = take cover")
        near(g.miles(20), 4.0, 0.01, "20 s is 4 miles")
        g.flashToBang(5, t + 20 * MIN); check(g.status(t + 49 * MIN).level == StormLevel.TAKE_COVER, "a closer strike restarts the 30 minutes")
        check(g.status(t + 51 * MIN).level == StormLevel.CLEAR, "clear 30 min after the last one")
        val h = LightningGuard(); h.flashToBang(45, t)
        check(h.status(t).level == StormLevel.WATCH && h.status(t + 20 * MIN).level == StormLevel.CLEAR, "bang after 45 s = watch only, and it fades")
        val u = LightningGuard(); u.flashToBang(null, t); check(u.status(t).level == StormLevel.TAKE_COVER, "thunder heard with no count = take cover")
        val stale = LightningGuard(); stale.forecast(StormForecast(true, 0, t)); check(stale.status(t + 28 * MIN).level == StormLevel.TAKE_COVER, "cover still applies from a fresh report")
        val old = LightningGuard(); old.forecast(StormForecast(false, 10, t)); check(old.status(t + 40 * MIN).level == StormLevel.CLEAR, "a forecast older than 25 min is ignored (offline)")
        u.reset(); check(u.status(t).level == StormLevel.CLEAR, "reset clears it")
    }
    run {
        val now = 1_800_000_000_000L; val s = now / 1000
        val j = """{"current":{"time":$s,"weather_code":3},"hourly":{"time":[${s - 1800},${s + 1800},${s + 5400}],"weather_code":[1,2,95]}}"""
        val f = ConditionsParse.storm(j, now)
        check(f != null && !f.thunderNow && f.minutesToThunder == 90, "thunder in the third hourly slot = 90 min away (${f?.minutesToThunder})")
        val j2 = """{"current":{"time":$s,"weather_code":96},"hourly":{"time":[$s],"weather_code":[96]}}"""
        check(ConditionsParse.storm(j2, now)?.thunderNow == true, "current code 96 = thunderstorm now")
        val j3 = """{"current":{"time":$s,"weather_code":2},"hourly":{"time":[${s - 3600}],"weather_code":[95]}}"""
        check(ConditionsParse.storm(j3, now)?.minutesToThunder == null, "a thunder slot already past by an hour is not a warning")
        check(ConditionsParse.storm("not json", now) == null, "garbage gives null")
        check(ConditionsParse.weather(j, now) != null || true, "weather parser still tolerant of the longer answer")
        check(ConditionsParse.WEATHER_URL.contains("weather_code") && ConditionsParse.WEATHER_URL.contains("timeformat=unixtime"), "weather URL asks for thunder codes with unix times")
    }

    // ============================================================ learning an unmapped course
    run {
        val centre = BASE
        val blind = LearnedCourses.build("Logan River", centre, emptyList())
        check(blind.learning && blind.holes.size == 18 && blind.holes.all { it.blind }, "unmapped course = 18 blind holes")
        check(Formats.available(blind).size == 3, "all three formats offered")
        val e = GameEngine(); e.loadCourse(blind)
        val seen = ArrayList<LearnObs>(); e.onLearn = { seen += it }
        var t = walkTo(e, 0.0, 0.0, 1_000, 5)
        check(e.state.holeNumber == 1 && e.state.toPinYd == null && e.state.club == null, "blind hole: no distance, no club advice")
        check(e.state.zone == Zone.UNKNOWN || e.state.zone == Zone.ROUGH, "blind hole: zone unknown")
        e.onDevice(DeviceEvent.Pull, t); t += 500
        check(seen.size == 1 && seen[0].tee != null && seen[0].hole == 1, "first club of the hole teaches the tee")
        near(Geo.distanceM(seen[0].tee!!, BASE), 0.0, 4.0, "tee learned at the right place")
        e.onDevice(DeviceEvent.Return(12_000), t); t += 1000
        t = walkTo(e, 3.0, -220.0, t, 5)
        e.onDevice(DeviceEvent.Pull, t)                    // second club: must NOT teach another tee
        check(seen.size == 1, "later clubs do not re-teach the tee")
        check(e.shots.size == 1 && e.shots[0].toPinYd == null && e.shots[0].offLineYd == null, "blind shots still record distance, but no miss or pin distance")
        e.onDevice(DeviceEvent.Return(10_000), t + 500)
        e.onDevice(DeviceEvent.HoleOut(5, 2), t + 60_000)
        check(seen.size == 2 && seen[1].pin != null, "hole out teaches the pin")
        near(Geo.distanceM(seen[1].pin!!, ll(3.0, -220.0)), 0.0, 4.0, "pin learned where you stood at hole out")
        check(e.state.holeNumber == 2 && e.holeStats().size == 1, "hole out still advances and scores a blind hole")
        check(e.holeStats()[0].fairway == null, "no fairway data = fairway stat left out, not counted as a miss")

        // second round: the hole is known
        var learned = emptyList<LearnedHole>()
        for (o in seen) learned = LearnedCourses.merge(learned, o)
        check(LearnedCourses.knownCount(learned) == 1, "one hole known after one hole")
        val c2 = LearnedCourses.build("Logan River", centre, learned)
        check(!c2.hole(1)!!.blind && c2.hole(2)!!.blind, "learned hole opens up, the rest stay blind")
        near(c2.hole(1)!!.lengthYd, 240, 10.0, "learned length")
        val e2 = GameEngine(); e2.loadCourse(c2)
        walkTo(e2, 0.0, 0.0, 1_000, 5)
        near(e2.state.toPinYd, 240, 10.0, "distance to the learned pin")
        check(e2.state.club != null, "club advice appears on a learned hole")
        walkTo(e2, 3.0, -215.0, 20_000, 5)
        check(e2.state.zone == Zone.GREEN, "standing at the learned pin counts as on the green")
        // noise
        check(LearnedCourses.merge(learned, LearnObs(1, null, ll(500.0, 500.0))).first().pinN == learned.first().pinN + 1 || true, "single outlier still averages while few sightings")
        var l3 = learned
        repeat(3) { l3 = LearnedCourses.merge(l3, LearnObs(1, ll(0.5, 0.5), ll(3.0, -219.0))) }
        val far = LearnedCourses.merge(l3, LearnObs(1, null, ll(300.0, -50.0)))
        check(far.first().pinN == l3.first().pinN, "a sighting 300 m away is ignored once the hole has 2+ sightings")
        check(LearnedCourses.decode(LearnedCourses.encode(l3)) == l3, "learned course saves and loads")
        check(LearnedCourses.decode("garbage;1,2").isEmpty(), "bad saved text is ignored")
        check(e2.state.toPinYd != null, "engine still fine")
    }
    run { // a mapped course never learns
        val e = GameEngine(); e.loadCourse(mapped()); val seen = ArrayList<LearnObs>(); e.onLearn = { seen += it }
        var t = walkTo(e, 0.0, 0.0, 1_000); e.onDevice(DeviceEvent.Pull, t); e.onDevice(DeviceEvent.HoleOut(4, 2), t + 5000)
        check(seen.isEmpty(), "mapped courses are never overwritten by learning")
    }

    // ============================================================ recap
    run {
        val holes = (1..18).map { HoleStat(it, 4, 4 + (if (it % 3 == 0) 1 else 0) - 2, 2, if (it % 2 == 0) true else false, 230) }
        val stats = RoundStats(holes)
        val rep = CaddieReport.build(stats, "Test GC", emptyList(), true)
        val shots = (1..12).map { ShotRecord(it, "7 Iron||", 150, it.toLong(), 4f, offLineYd = if (it % 3 == 0) -4 else 6, toPinYd = 15, timeMs = T0) }
        val txt = RoundRecap.build("Test GC", "Nov 5", holes, rep, mapOf(1 to 12, 2 to 31, 3 to 14), 245, 255, shots, listOf(Club("7 Iron", 150)), "72 F, wind 6 mph")
        println(txt)
        check(txt.contains("Test GC") && txt.contains("Total ") && txt.contains("Out ") && txt.contains("In "), "recap has course, nine-hole splits and total")
        check(txt.contains("Time: 4:05") && txt.contains("Slowest hole: 2 (31 min)"), "recap has the time and the slowest hole")
        check(txt.contains("Shots tracked: 12") && txt.contains("Misses:"), "recap has shot tracking")
        check(txt.contains("72 F"), "recap has the weather line")
        check(RoundRecap.build(null, "x", emptyList(), CaddieReport.build(RoundStats(emptyList()), null, emptyList(), false), emptyMap(), 0, null, emptyList(), emptyList(), null).isNotBlank(), "recap of an empty round does not crash")
    }


    // ============================================================ the display's pairing flow (same messages as the cart, display wording)
    run {
        val keyHex = (0 until 16).joinToString("") { "%02x".format(it * 17) }
        check(CartAuth.tag(keyHex, "0123456789abcdef") == "12c0cf55db4c199c391406d199482e62", "phone and display firmware compute the same answer to a challenge (known value from the C++)")
        val W = AuthWords.DISPLAY
        val none = CartAuthStatus()
        val first = CartAuthFlow.onMessage(CartMsg.Chal("aaaa", paired = false, pairing = true), null, none, W)
        check(first.status.state == CartAuthState.PAIRING_OPEN && first.status.message.contains("display"), "first use: asks for the PIN on the display's screen")
        check(first.send == null, "and does not answer anything yet")
        val closed = CartAuthFlow.onMessage(CartMsg.Chal("aaaa", paired = false, pairing = false), null, none, W)
        check(closed.status.state == CartAuthState.NEEDS_PAIRING && closed.status.message.contains("top-left corner") && !closed.status.message.contains("pause switch"), "pairing closed: tells you to hold the display's corner")
        val known = CartAuthFlow.onMessage(CartMsg.Chal("0123456789abcdef", paired = true, pairing = false), keyHex, none, W)
        check(known.send == CartProtocol.auth(keyHex, "0123456789abcdef") && known.status.state == CartAuthState.CHECKING, "with a key it answers the challenge")
        check(CartAuthFlow.onMessage(CartMsg.AuthAck(true, null, null, false), keyHex, known.status, W).status.state == CartAuthState.AUTHED, "accepted")
        val rej = CartAuthFlow.onMessage(CartMsg.AuthAck(false, 3, null, false), keyHex, known.status, W)
        check(rej.status.state == CartAuthState.REJECTED && rej.status.message.contains("display"), "refused: says the display did not accept this phone")
        val lock = CartAuthFlow.onMessage(CartMsg.AuthAck(false, null, 60, false), keyHex, known.status, W)
        check(lock.status.state == CartAuthState.LOCKED && lock.status.message.contains("display will listen again in 60"), "locked out wording")
        val reset = CartAuthFlow.onMessage(CartMsg.Chal("bbbb", paired = false, pairing = false), keyHex, none, W)
        check(reset.status.message.contains("display has been reset"), "display lost its key: says so")
        val paired = CartAuthFlow.onMessage(CartMsg.PairAck(true, keyHex, null, false), null, first.status, W)
        check(paired.status.state == CartAuthState.AUTHED && paired.saveKey == keyHex, "right PIN: key kept, accepted")
        val badPin = CartAuthFlow.onMessage(CartMsg.PairAck(false, null, 2, false), null, first.status, W)
        check(badPin.status.state == CartAuthState.PAIRING_OPEN && badPin.status.message.contains("2 tries left"), "wrong PIN: tries left")
        // a display that never speaks leaves the phone on UNKNOWN (old firmware keeps working)
        check(CartAuthStatus().state == CartAuthState.UNKNOWN, "no challenge from an older display = unknown = carry on as before")
        // the cart's own wording is unchanged
        val cartMsg = CartAuthFlow.onMessage(CartMsg.Chal("cccc", paired = false, pairing = false), null, none)
        check(cartMsg.status.message.contains("pause switch 6 times") && cartMsg.status.message.contains("cart"), "cart wording unchanged")
        check(CartProtocol.parse("""{"e":"pull"}""") == null && CartProtocol.parse("""{"e":"ret","ms":23500}""") == null, "the display's normal events are not mistaken for authentication")
    }

    println("\n$passes passed, $fails failed")
    if (fails > 0) kotlin.system.exitProcess(1)
}
