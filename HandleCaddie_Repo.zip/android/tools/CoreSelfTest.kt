import com.handlecaddie.controller.core.*
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.cos

var fails = 0; var passes = 0
fun check(c: Boolean, m: String) { if (c) { passes++; println("ok:   $m") } else { fails++; println("FAIL: $m") } }
fun near(a: Number?, b: Number, tol: Double, m: String) = check(a != null && abs(a.toDouble() - b.toDouble()) <= tol, "$m (got $a, want ~$b)")

// ---- synthetic course: metres east/south of a base point -> lat/lon -------------------------
val BASE = LatLon(35.0, -106.0)
fun ll(x: Double, y: Double) = LatLon(BASE.lat - y / 111_320.0, BASE.lon + x / (111_320.0 * cos(Math.toRadians(BASE.lat))))
fun geom(pts: List<Pair<Double, Double>>) = pts.joinToString(",", "[", "]") { val p = ll(it.first, it.second); """{"lat":${p.lat},"lon":${p.lon}}""" }
fun rect(x0: Double, y0: Double, x1: Double, y1: Double) = listOf(x0 to y0, x1 to y0, x1 to y1, x0 to y1, x0 to y0)
fun way(tags: String, pts: List<Pair<Double, Double>>) = """{"type":"way","tags":{$tags},"geometry":${geom(pts)}}"""

fun overpass(): String {
    val e = ArrayList<String>()
    // hole 1: tee (0,0) north to green (0,-330); par 4
    e += way(""""golf":"hole","ref":"1","par":"4"""", listOf(0.0 to 0.0, 0.0 to -330.0))
    e += way(""""golf":"tee"""", rect(-5.0, -5.0, 5.0, 5.0))
    e += way(""""golf":"fairway"""", rect(-18.0, -300.0, 18.0, -40.0))
    e += way(""""golf":"green"""", rect(-12.0, -342.0, 12.0, -318.0))
    e += way(""""golf":"bunker"""", rect(15.0, -325.0, 25.0, -315.0))
    e += way(""""golf":"water_hazard"""", rect(-60.0, -200.0, -40.0, -100.0))
    // hole 2: tee (40,-350) north to green (40,-600); par 3
    e += way(""""golf":"hole","ref":"2","par":"3"""", listOf(40.0 to -350.0, 40.0 to -600.0))
    e += way(""""golf":"tee"""", rect(35.0, -355.0, 45.0, -345.0))
    e += way(""""golf":"green"""", rect(28.0, -612.0, 52.0, -588.0))
    return """{"elements":[${e.joinToString(",")}]}"""
}
fun fix(x: Double, y: Double, t: Long, acc: Float = 4f) = ll(x, y).let { Fix(it.lat, it.lon, acc, t) }
fun JSONObject.keysList() = keys().asSequence().toList()

fun main() {
    // ============================================================ course parser
    val course = CourseParser.parse(overpass(), "Test GC")
    check(course.holes.size == 2, "parser finds 2 holes")
    val h1 = course.hole(1)!!; val h2 = course.hole(2)!!
    check(h1.par == 4 && h2.par == 3, "par read from tags")
    near(h1.lengthYd, 361, 3.0, "hole 1 length in yards")
    check(h1.greens.size == 1 && h1.fairways.size == 1 && h1.bunkers.size == 1 && h1.water.size == 1 && h1.teeBoxes.size == 1, "hole 1 gets its own green/fairway/bunker/water/tee")
    check(h2.greens.size == 1 && h2.fairways.isEmpty() && h2.bunkers.isEmpty(), "hole 2 does not steal hole 1's features")
    near(h1.pin.y, -330.0, 1.0, "pin defaults to green centroid (y)")
    check(CourseParser.overpassQuery(BASE).contains("around:1800,35.0,-106.0"), "overpass query contains centre")
    check(CourseParser.parse("""{"elements":[]}""", "x").holes.isEmpty(), "empty data -> empty course")

    // ============================================================ protocol codec
    val lb = LineBuffer()
    val bytes = "{\"e\":\"pull\"}\n{\"e\":\"ret\",\"ms\":23500}\n{\"e\":\"out\",\"s\":5,\"p\":2}\n".toByteArray()
    val got = ArrayList<String>()
    for (i in bytes.indices step 7) got += lb.feed(bytes.copyOfRange(i, minOf(bytes.size, i + 7)))
    check(got.size == 3, "LineBuffer reassembles 3 messages from 7-byte packets")
    check(Protocol.parse(got[0]) == DeviceEvent.Pull, "parse pull")
    check(Protocol.parse(got[1]) == DeviceEvent.Return(23500), "parse ret")
    check(Protocol.parse(got[2]) == DeviceEvent.HoleOut(5, 2), "parse out")
    check(Protocol.parse("""{"e":"str","n":3}""") == DeviceEvent.Strokes(3), "parse str")
    check(Protocol.parse("""{"e":"green"}""") == DeviceEvent.OnGreen, "parse green")
    check(Protocol.parse("""{"e":"putt","n":2}""") == DeviceEvent.Putts(2), "parse putt")
    check(Protocol.parse("garbage") == null && Protocol.parse("""{"e":"zzz"}""") == null, "garbage / unknown events -> null")
    val utf = "{\"club\":\"Wedge é\"}\n".toByteArray(); val lb2 = LineBuffer()
    val r = lb2.feed(utf.copyOfRange(0, 17)) + lb2.feed(utf.copyOfRange(17, utf.size))
    check(r == listOf("{\"club\":\"Wedge é\"}"), "multi-byte UTF-8 split across packets survives")
    val ch = Protocol.chunk("x".repeat(500) + "\n", 244)
    check(ch.size == 3 && ch.all { it.size <= 244 } && ch.sumOf { it.size } == 501, "chunking at MTU-3")

    // ============================================================ ball location when the club comes out
    run {
        fun after(offset: Double): Int? {
            val e = GameEngine(); e.loadCourse(course); e.ballOffsetM = offset
            var tt = 1_000L
            e.selectNearest(fix(0.0, 0.5, tt))
            for (i in 0 until 5) { tt += 1_000; e.onFix(fix(0.0, -100.0 + (if (i == 2) -4.0 else 0.0), tt)) }   // one noisy fix in the middle
            e.onDevice(DeviceEvent.Pull, tt + 500)
            return e.state.toPinYd
        }
        val plain = after(0.0); val withCart = after(2.5)
        check(plain != null && withCart != null, "ball estimate: pull produces a distance")
        near(plain!! - withCart!!, 2.7, 1.0, "ball estimate: 2.5 m follow distance moves the ball ~2.7 yd toward the pin")
        val big = after(30.0)
        near(plain - big!!, 6.6, 1.0, "ball estimate: correction capped at 6 m")
    }

    // ============================================================ engine: scripted round
    val eng = GameEngine()
    eng.loadCourse(course)
    val sentAll = ArrayList<String>()           // everything we would send to the unit
    fun send(l: List<String>) { sentAll += l }
    var t = 1_000L

    val start = eng.selectNearest(fix(0.0, 0.5, t)); send(start)
    check(start.size == 1 && eng.state.holeNumber == 1, "nearest tee -> hole 1, one hole message")
    val hm = JSONObject(start[0])
    check(hm.getInt("hole") == 1 && hm.getInt("par") == 4 && hm.has("fairway") && hm.has("green") && hm.has("bunkers") && hm.has("water"), "hole message has hole/par/shapes")
    check(hm.getJSONArray("pars").length() == 18 && hm.getJSONArray("scores").length() == 18, "hole message carries scorecard")
    println("      hole message size: ${start[0].length} bytes")
    check(eng.state.zone == Zone.TEE, "standing in tee box -> TEE")
    near(eng.state.toPinYd, 361, 3.0, "distance to pin from tee")
    check(eng.state.club?.name == "Driver", "far shot recommends the longest club")

    // tee shot: pull, hold 20 s, return
    t += 5_000; send(eng.onDevice(DeviceEvent.Pull, t))
    check(eng.state.clubOut, "pull -> clubOut")
    t += 20_000; send(eng.onDevice(DeviceEvent.Return(20_000), t))
    check(eng.state.strokes == 1 && !eng.state.clubOut, "20 s hold counts as a stroke")

    // walk up the fairway; zone needs 2 fixes to switch
    t += 60_000; send(eng.onFix(fix(0.0, -100.0, t)))
    check(eng.state.zone == Zone.TEE, "one fix in a new zone is not enough")
    t += 1_000; send(eng.onFix(fix(0.0, -150.0, t)))
    check(eng.state.zone == Zone.FAIRWAY, "second fix confirms FAIRWAY")
    t += 1_000; send(eng.onFix(fix(0.0, -210.0, t)))
    check(eng.onFix(fix(0.0, -210.0, t + 1)).isEmpty(), "no change -> nothing sent")
    check(eng.onFix(fix(0.0, -214.0, t + 2, acc = 80f)).isEmpty(), "poor GPS accuracy ignored")

    // second club out: distance of the first shot = pull-to-pull
    t += 2_000; send(eng.onDevice(DeviceEvent.Pull, t))
    near(eng.state.lastShotYd, 230, 2.0, "tee shot length (0,0)->(0,-210)")
    check(eng.state.club?.name == "8 Iron", "131 yd out -> 8 Iron (140 carry)")
    t += 3_000; send(eng.onDevice(DeviceEvent.Return(3_000), t))
    check(eng.state.strokes == 1, "3 s pull/return (club swap) is not a stroke")
    t += 5_000; send(eng.onDevice(DeviceEvent.Pull, t))
    t += 15_000; send(eng.onDevice(DeviceEvent.Return(15_000), t))
    check(eng.state.strokes == 2, "second real swing counted")

    // front / back of green from 80 m out
    val fx = eng.onFix(fix(0.0, -250.0, t + 30_000)); send(fx)
    t += 31_000; send(eng.onFix(fix(0.0, -250.0, t)))
    near(eng.state.toPinYd, 87, 1.5, "to pin from (0,-250)")
    near(eng.state.frontYd, 74, 1.5, "front of green (68 m)")
    near(eng.state.backYd, 101, 1.5, "back of green")

    // approach to the green edge, then user taps ON GREEN?
    t += 20_000; send(eng.onFix(fix(0.0, -312.0, t))); t += 1_000; send(eng.onFix(fix(0.0, -312.0, t)))
    check(eng.state.zone == Zone.ROUGH, "6 m short of the green -> ROUGH")
    t += 1_000; val og = eng.onDevice(DeviceEvent.OnGreen, t); send(og)
    check(eng.state.zone == Zone.GREEN && eng.state.club == null, "ON GREEN -> GREEN, no club recommendation")
    near(eng.state.lastShotYd, 112, 2.5, "approach shot length finalised when reaching the green")
    check(og.isNotEmpty() && JSONObject(og[0]).optString("zone") == "green", "zone=green sent to unit")
    t += 10_000; send(eng.onDevice(DeviceEvent.Pull, t)); t += 4_000
    send(eng.onDevice(DeviceEvent.Return(30_000), t))
    check(eng.state.strokes == 2, "club pulls on the green don't add strokes")
    send(eng.onDevice(DeviceEvent.Putts(1), t)); send(eng.onDevice(DeviceEvent.Putts(2), t))
    check(eng.state.putts == 2, "putts mirrored from unit")
    val out = eng.onDevice(DeviceEvent.HoleOut(4, 2), t + 1000); send(out)
    check(eng.state.scores[0] == 4, "score recorded")
    check(eng.state.holeNumber == 2 && eng.state.strokes == 0 && eng.state.putts == 0, "advanced to hole 2, counters reset")
    val hs1 = eng.holeStats().firstOrNull { it.hole == 1 }
    check(hs1 != null && hs1.swings == 2 && hs1.putts == 2 && hs1.par == 4, "hole 1 recorded: 2 swings + 2 putts, par 4 (got $hs1)")
    check(hs1?.fairway == true, "tee shot that finished in the fairway counts as a fairway hit")
    check(hs1?.driveYd != null && hs1.driveYd in 228..232, "drive distance recorded (~230 yd)")
    check(hs1 != null && hs1.gir && hs1.total == 4 && hs1.toPar == 0, "2 swings on a par 4 = green in regulation; 4 strokes = par")
    val m2 = JSONObject(out.first { JSONObject(it).has("hole") })
    check(JSONObject(out.last()).optString("tip") == "Par. Solid." && out.indexOfFirst { JSONObject(it).has("tip") } == out.size - 1, "a caddie tip follows the new hole's data (par 4 in 4 = 'Par. Solid.')")
    check(m2.getInt("hole") == 2 && m2.getJSONArray("scores").getInt(0) == 4, "hole 2 message carries hole-1 score")
    check(eng.shots.size >= 2 && eng.shots[0].distanceYd in 228..232, "shot history recorded")

    // strokes corrected on the unit
    send(eng.onDevice(DeviceEvent.Strokes(3), t + 5000))
    check(eng.state.strokes == 3, "str event sets absolute strokes")

    // throttle: two moving fixes 200 ms apart -> second is held back
    val e2 = GameEngine(); e2.loadCourse(course); e2.selectNearest(fix(0.0, 0.0, 0))
    e2.onFix(fix(0.0, -20.0, 10_000)); e2.onFix(fix(0.0, -20.0, 10_100)); e2.onFix(fix(0.0, -60.0, 20_000))
    val a = e2.onFix(fix(0.0, -90.0, 21_000)); val b = e2.onFix(fix(0.0, -120.0, 21_200))
    check(a.isNotEmpty() && b.isEmpty(), "live updates limited to ~1 per second")

    // auto-advance to the next tee
    val e3 = GameEngine(); e3.loadCourse(course); e3.selectNearest(fix(0.0, 0.0, 0))
    e3.onDevice(DeviceEvent.Putts(2), 1); e3.onDevice(DeviceEvent.Strokes(3), 2)
    for (i in 0 until 3) e3.onFix(fix(40.0, -350.0, 5_000L + i * 1_000))
    check(e3.state.holeNumber == 2 && e3.state.scores[0] == 5, "reaching tee 2 advances the hole and saves 3+2=5")

    // polygon limits: 200-point circle must be reduced to <= 48
    val circle = (0 until 200).map { val a2 = it * 2 * Math.PI / 200; XY(30 * Math.cos(a2), 30 * Math.sin(a2)) }
    val big = h1.copy(fairways = listOf(circle))
    val bigMsg = Protocol.holeMessage(big, eng.state.copy()).first
    val fw = JSONObject(bigMsg).getJSONArray("fairway").getJSONArray(0)
    check(fw.length() in 3..48, "200-point polygon fitted to ${fw.length()} points (max 48)")

    // ============================================================ nearby courses
    fun nearbyEl(type: String, id: Long, name: String?, lat: Double, lon: Double, center: Boolean = true): String {
        val t = if (name == null) "" else """"name":"$name","leisure":"golf_course""""
        return if (center) """{"type":"$type","id":$id,"center":{"lat":$lat,"lon":$lon},"tags":{$t}}"""
        else """{"type":"$type","id":$id,"lat":$lat,"lon":$lon,"tags":{$t}}"""
    }
    val me = LatLon(35.0, -106.0)
    val nj = """{"elements":[
        ${nearbyEl("way", 11, "Far Hills GC", 35.20, -106.0)},
        ${nearbyEl("relation", 12, "Close Creek CC", 35.02, -106.0)},
        ${nearbyEl("way", 13, null, 35.01, -106.0)},
        ${nearbyEl("way", 14, "Close Creek CC", 35.0205, -106.0)},
        ${nearbyEl("node", 15, "Node Links", 35.05, -106.0, center = false)}]}"""
    val near = CourseParser.parseNearby(nj, me)
    check(near.map { it.name } == listOf("Close Creek CC", "Node Links", "Far Hills GC"), "nearby: nearest first, unnamed dropped, duplicate name merged (${near.map { it.name }})")
    near(near.first().miles, 1.38, 0.05, "nearby: 0.02 deg latitude is about 1.4 miles")
    check(near.first().osmType == "relation" && near.first().key == "relation_12", "nearby: type and key kept")
    check(CourseParser.nearbyQuery(me).contains("leisure") && CourseParser.nearbyQuery(me).contains("around:30000,35.0,-106.0"), "nearby query")
    check(CourseParser.holesInCourseQuery(near[0])!!.contains("rel(12);map_to_area"), "relation -> rel(id) area query")
    check(CourseParser.holesInCourseQuery(near[1]) == null, "node has no boundary -> radius fallback")
    check(CourseParser.holesInCourseQuery(CourseChoice("way", 99, "x", 0.0, 0.0))!!.contains("way(99);map_to_area"), "way -> way(id) area query")
    check(CourseParser.parseNearby("""{"elements":[]}""", me).isEmpty(), "nearby: empty result")

    // ============================================================ round format
    val full = Course("Full", listOf(h1, h2, h1.copy(number = 10), h2.copy(number = 11)))
    check(Formats.available(full) == listOf(RoundFormat.ALL_18, RoundFormat.FRONT_9, RoundFormat.BACK_9), "all three formats on a full course")
    check(Formats.available(course) == listOf(RoundFormat.FRONT_9), "front-only course offers only 9 holes")
    check(Formats.label(RoundFormat.FRONT_9, course) == "9 holes" && Formats.label(RoundFormat.FRONT_9, full) == "Front 9", "9-hole label")
    check(Formats.available(Course("Back", listOf(h1.copy(number = 12)))) == listOf(RoundFormat.BACK_9), "back-only course")
    check(RoundFormat.BACK_9.contains(10) && !RoundFormat.BACK_9.contains(9) && RoundFormat.FRONT_9.contains(9) && !RoundFormat.FRONT_9.contains(10), "format ranges")

    val ef = GameEngine(); ef.loadCourse(full)
    ef.setFormat(RoundFormat.BACK_9)
    check(ef.state.holeNumber == 10 && ef.state.firstHole == 10 && ef.state.lastHole == 18, "back 9 starts on hole 10")
    ef.nextHole(); check(ef.state.holeNumber == 11, "next hole -> 11")
    ef.nextHole(); check(ef.state.holeNumber == 10, "next hole wraps inside the back 9")
    ef.prevHole(); check(ef.state.holeNumber == 11, "prev hole wraps inside the back 9")
    ef.onDevice(DeviceEvent.HoleOut(4, 2), 1)
    check(ef.state.roundComplete && ef.state.scores[10] == 4, "holing out on the last back-9 hole completes the round")
    ef.setFormat(RoundFormat.FRONT_9)
    check(ef.state.holeNumber == 1 && !ef.state.roundComplete && ef.state.scores[10] == 4, "switching to front 9 jumps to hole 1 and keeps scores")
    ef.setFormat(RoundFormat.ALL_18); ef.selectHole(2); ef.onDevice(DeviceEvent.HoleOut(5, 2), 2)
    check(ef.state.holeNumber == 10 && !ef.state.roundComplete, "18 holes: after hole 2 comes hole 10 (holes 3-9 not mapped)")
    val eg = GameEngine(); eg.loadCourse(full); eg.setFormat(RoundFormat.FRONT_9)
    eg.selectNearest(fix(40.0, -350.0, 0))
    check(eg.state.holeNumber == 2, "front 9: nearest hole is chosen among front-9 holes")
    val eh = GameEngine(); eh.loadCourse(full); eh.setFormat(RoundFormat.BACK_9); eh.onFix(fix(0.0, 0.0, 0))
    check(eh.state.holeNumber in 10..11, "back 9: GPS never selects a front-9 hole (got ${eh.state.holeNumber})")
    val ei = GameEngine(); ei.loadCourse(course)
    ei.setFormat(RoundFormat.BACK_9)
    check(ei.nextHole().isEmpty(), "format with no mapped holes does nothing")

    // ============================================================ cart protocol + demo simulator
    val tel = CartProtocol.parse("""{"k":"tel","m":"follow","v":20.4,"soc":78,"pit":-3.2,"rol":1.1,"spd":1.2,"rng":2.7,"brg":-8,"ml":35,"mr":38,"bk":0,"obs":-1,"trip":1234.5,"tot":98000,"ft":0,"fg":8}""")
    check(tel is CartMsg.Tel, "telemetry parses")
    (tel as CartMsg.Tel).t.let {
        check(it.mode == CartMode.FOLLOW && it.socPct == 78 && it.packV == 20.4 && it.pitchDeg == -3.2 && it.rollDeg == 1.1, "telemetry: mode, battery, pitch, roll")
        check(it.rangeM == 2.7 && it.bearingDeg == -8.0 && it.obstacleM == null && it.motorLPct == 35 && it.motorRPct == 38, "telemetry: range, bearing, clear obstacle, motors")
        near(it.speedMph, 2.68, 0.01, "1.2 m/s in mph"); near(it.tripMiles, 0.767, 0.002, "trip miles"); near(it.totalMiles, 60.9, 0.1, "total miles")
        check(CartFlag.names(it.flags) == listOf("Hill descent control") && CartFault.names(it.faults).isEmpty(), "flag bit 8 = descent")
        near(it.slopePct, -5.6, 0.1, "slope % from pitch")
    }
    val noFob = (CartProtocol.parse("""{"k":"tel","rng":-1,"brg":null,"obs":0.8}""") as CartMsg.Tel).t
    check(noFob.rangeM == null && noFob.bearingDeg == null && noFob.obstacleM == 0.8 && noFob.mode == CartMode.PARK, "negative range = no fob, null bearing, defaults to park")
    check(CartFault.names(CartFault.TIP or CartFault.ESTOP) == listOf("Tip-over detected", "E-stop pressed"), "fault names")
    check(CartFlag.names(CartFlag.FOB_LOST or CartFlag.SLOWED).size == 2, "flag names")
    val cfg = (CartProtocol.parse("""{"k":"cfg","fd":9,"vm":0.1,"dc":1.0,"hh":0,"fw":"1.2"}""") as CartMsg.Cfg).c
    check(cfg.followM == 6.0 && cfg.maxSpeedMs == 0.5 && cfg.descentMs == 1.0 && !cfg.hillHold && cfg.firmware == "1.2", "config parses and is clamped to the allowed ranges")
    check(CartProtocol.parse("garbage") == null && CartProtocol.parse("""{"k":"zzz"}""") == null && CartProtocol.parse("") == null, "bad cart lines -> null")
    check(CartProtocol.mode(CartMode.MANUAL) == "{\"k\":\"mode\",\"m\":\"manual\"}\n", "mode message")
    check(CartProtocol.joy(-2.0, -1.0) == "{\"k\":\"joy\",\"x\":-1.00,\"y\":0.00}\n" && CartProtocol.joy(0.5, 5.0).contains("\"y\":1.00"), "joystick is clamped: steer -1..1, forward 0..1 (no reverse)")
    check(CartProtocol.setFollow(99.0).contains("6.00") && CartProtocol.setFollow(0.1).contains("1.50") && CartProtocol.setMaxSpeed(5.0).contains("1.60"), "settings clamped before sending")
    check(CartProtocol.setHillHold(true).contains("\"hh\":1") && CartProtocol.cmd("stop") == "{\"k\":\"cmd\",\"c\":\"stop\"}\n" && CartProtocol.hello().endsWith("\n"), "other messages")
    for (line in listOf(CartProtocol.mode(CartMode.PARK), CartProtocol.joy(0.3, 0.7), CartProtocol.setFollow(3.0), CartProtocol.cmd("clear")))
        check(JSONObject(line).has("k") && line.length < 60, "cart message is valid JSON and short: ${line.trim()}")
    near(CartUnits.metresToFeet(2.5), 8.2, 0.05, "2.5 m in feet"); near(CartUnits.feetToMetres(8.2), 2.5, 0.01, "feet back to metres")

    val sim = CartSimulator()
    var last = sim.step(0.2)
    check(last.speedMs == 0.0 && last.mode == CartMode.PARK, "sim: starts parked")
    sim.mode = CartMode.MANUAL; sim.joyY = 1.0
    repeat(50) { last = sim.step(0.1) }
    check(last.speedMs > 0.9 && last.speedMs <= CartConfig.MANUAL_MAX_MS + 1e-9, "sim: manual full stick -> about 1.2 m/s, never above (${last.speedMs})")
    check(last.tripM > 3.0, "sim: trip distance grows")
    sim.joyY = 0.0; repeat(30) { last = sim.step(0.1) }
    check(last.speedMs == 0.0, "sim: stick released -> stops")
    sim.mode = CartMode.PARK; repeat(20) { last = sim.step(0.1) }
    check(last.speedMs == 0.0 && last.motorLPct == 0, "sim: park holds still")
    val sim2 = CartSimulator(); sim2.mode = CartMode.FOLLOW; sim2.config = CartConfig(followM = 3.0)
    var worst = 0.0; var minRange = 99.0; var maxSpeed = 0.0
    repeat(2000) { val x = sim2.step(0.05); minRange = minOf(minRange, x.rangeM!!); maxSpeed = maxOf(maxSpeed, x.speedMs); if (it > 400) worst = maxOf(worst, x.rangeM!!) }
    check(minRange > 1.5 && worst < 8.0 && maxSpeed <= 1.6 + 1e-9, "sim: follow keeps a sensible distance (min $minRange, max after settling $worst) and the speed limit")
    val sim3 = CartSimulator(); sim3.mode = CartMode.MANUAL; sim3.joyY = 1.0; sim3.config = CartConfig(descentMs = 0.6)
    var downhillMax = 0.0; var sawDescent = false; var run = 0
    repeat(1500) {
        val x = sim3.step(0.05)
        if (x.flags and CartFlag.DESCENT != 0) { sawDescent = true; run++; if (run > 20) downhillMax = maxOf(downhillMax, x.speedMs) } else run = 0   // 1 s to slow down first
    }
    check(sawDescent && downhillMax <= 0.6 + 1e-9, "sim: descent flag set and, after braking for a second, speed is held at the descent limit ($downhillMax)")

    // ============================================================ club learning
    check(eng.shots.all { it.id > 0 } && eng.shots.map { it.id }.toSet().size == eng.shots.size, "recorded shots get unique ids")
    val firstShot = eng.shots[0]
    check(eng.setShotClub(firstShot.id, "7 Iron||") && eng.shots[0].club == "7 Iron||" && !eng.setShotClub(9999, "x"), "player can correct which club was hit")
    val nBefore = eng.shots.size
    check(eng.deleteShot(firstShot.id) && eng.shots.size == nBefore - 1 && !eng.deleteShot(firstShot.id), "player can delete a shot")
    val eL = GameEngine(); eL.loadShots(listOf(ShotRecord(1, "a", 100, 7), ShotRecord(2, "b", 120, 3)))
    check(eL.shots.size == 2, "history restored")

    val i7 = Club("7 Iron", 140, "Titleist", "T150", 31.0, ClubType.IRON, estimated = true)
    val k7 = Clubs.key(i7)
    check(k7 == "7 Iron|Titleist|T150", "club key")
    fun sh(vararg d: Int) = d.mapIndexed { i, yd -> ShotRecord(1, k7, yd, i + 1L, 5f) }
    val l5 = Learning.apply(listOf(i7), sh(142, 145, 139, 150, 141), true)[0]
    check(l5.learnedN == 5 && l5.learnedYd in 141..143 && l5.useYd == l5.learnedYd, "5 shots: learned ~142 (blended with the 140 estimate), used for recommendations (${l5.learnedYd})")
    check(Learning.apply(listOf(i7), sh(142, 145), true)[0].let { it.learnedN == 2 && it.useYd == 140 }, "2 shots: not enough yet, estimate still used")
    check(Learning.apply(listOf(i7), sh(142, 145, 139, 60, 141), true)[0].learnedN == 4, "a 60 yd chunk is thrown out as an outlier")
    check(Learning.apply(listOf(i7), sh(142, 145, 139), false)[0].let { it.learnedN == 0 && it.useYd == 140 }, "learning switched off -> estimate")
    val bad = (1..5).map { ShotRecord(1, k7, 100, it.toLong(), 30f) }
    check(Learning.apply(listOf(i7), bad, true)[0].learnedN == 0, "shots measured with bad GPS are ignored")
    val other = i7.copy(brand = "Ping", model = "G430")
    check(Learning.apply(listOf(other), sh(142, 145, 139, 150, 141), true)[0].learnedN == 0, "another set's 7 iron does not inherit these shots")
    val typedClub = i7.copy(estimated = false, carryYd = 120)
    check(Learning.apply(listOf(typedClub), sh(160, 160, 160), true)[0].learnedYd < Learning.apply(listOf(i7.copy(carryYd = 120)), sh(160, 160, 160), true)[0].learnedYd, "a number you typed is trusted more than an estimate")
    val old = (1..30).map { ShotRecord(1, k7, if (it <= 10) 100 else 150, it.toLong(), 5f) }
    check(Learning.apply(listOf(i7), old, true)[0].learnedYd > 140, "only the 20 most recent shots count")
    val bagL = Learning.apply(listOf(i7, i7.copy(name = "8 Iron", carryYd = 130)), sh(160, 161, 159), true)
    check(Clubs.recommend(bagL, 150)?.name == "7 Iron" && Clubs.recommend(bagL, 150)!!.useYd >= 150, "recommendation uses the learned distance (7 iron now reaches 150)")
    check(Learning.strip(bagL).all { it.learnedN == 0 && it.learnedYd == 0 }, "strip removes learned numbers")
    val enc2 = Learning.encode(sh(142, 145) + ShotRecord(3, null, 90, 9, 4.5f))
    val dec2 = Learning.decode(enc2)
    check(dec2.size == 3 && dec2[0].id == 1L && dec2[0].club == k7 && dec2[2].club == null && dec2[2].accuracyM == 4.5f, "shot log encode/decode")
    check(Learning.decode("junk").isEmpty() && Learning.decode(null).isEmpty(), "bad shot log -> empty")
    check(Clubs.decode(Clubs.encode(bagL)).all { it.learnedN == 0 }, "learned numbers are not stored with the bag")

    // ============================================================ green guard
    val gO = LatLon(35.0, -106.0)
    fun rectXY(x0: Double, y0: Double, x1: Double, y1: Double) = listOf(XY(x0, y0), XY(x1, y0), XY(x1, y1), XY(x0, y1))
    val greenRect = rectXY(-10.0, 90.0, 10.0, 110.0)        // true green: 20 x 20 m, its near edge at y = 90
    val gm = GreenMap(gO, listOf(greenRect))
    near(gm.distanceM(XY(0.0, 80.0)), 10.0, 1e-6, "distance to green edge")
    check(gm.distanceM(XY(0.0, 100.0)) == 0.0 && GreenMap(gO, emptyList()).distanceM(XY(0.0, 0.0)) == null, "inside a green = 0; no greens = null")
    val twoHoles = Course("Two", listOf(
        h1.copy(origin = ll(0.0, 0.0), greens = listOf(rectXY(-5.0, -10.0, 5.0, 0.0))),
        h2.copy(number = 2, origin = ll(100.0, 0.0), greens = listOf(rectXY(-5.0, -10.0, 5.0, 0.0)))))
    val gmc = GreenMap.build(twoHoles)!!
    check(gmc.greens.size == 2, "course map has both greens in one frame")
    near(gmc.distanceM(XY(100.0, 5.0)), 5.0, 0.3, "second hole's green is shifted into the shared frame (100 m east)")
    check(GreenMap.build(Course("none", emptyList())) == null, "no holes -> no map")

    // cart position estimate follows the walked path, also round a corner
    val gg0 = GreenGuard(); gg0.setMap(gm)
    for (y in 0..10) gg0.step(XY(0.0, y.toDouble()), 3.0, 2.5, false)
    near(gg0.estimateCart(XY(0.0, 10.0), 2.5).y, 7.5, 0.01, "cart is 2.5 m behind on a straight path")
    for (x in 1..5) gg0.step(XY(x.toDouble(), 10.0), 3.0, 2.5, false)
    near(gg0.estimateCart(XY(5.0, 10.0), 2.5).x, 2.5, 0.01, "cart estimate follows the path round a corner")
    near(GreenGuard().estimateCart(XY(3.0, 3.0), 2.5).x, 3.0, 1e-9, "no trail yet: cart assumed at the player")

    // walk straight at the green, onto it, across and away: hold, stay held, resume only well clear
    val gg = GreenGuard(); gg.setMap(gm)
    var holdAtY = -1.0; var resumedAtY = -1.0; var heldOnGreen = true
    for (i in 0..1300) {
        val y = i * 0.1
        val o = gg.step(XY(0.0, y), 3.0, 2.5, false)
        if (o.hold && holdAtY < 0) holdAtY = y
        if (y in 90.0..110.0 && !o.hold) heldOnGreen = false
        if (holdAtY >= 0 && !o.hold && resumedAtY < 0 && y > 111) resumedAtY = y
    }
    check(holdAtY in 70.0..82.0, "holds before the cart reaches the green (player at y=$holdAtY, margin 12+3=15 m, cart 2.5 m behind)")
    check(heldOnGreen, "stays held the whole time you are on the green")
    check(resumedAtY < 0, "walking straight across the green and away: the cart does NOT follow across it (never resumed, y=$resumedAtY)")
    check(gg.step(XY(0.0, 130.0), 3.0, 2.5, false).let { it.hold && it.pathBlocked }, "...and says why: you are clear but its path to you is blocked")
    // the same walk, but coming back out the way you went in: resumes once clear
    val ggb = GreenGuard(); ggb.setMap(gm)
    var backResumedAtY = -1.0; var wasHeld = false
    for (i in 0..800) { val y = i * 0.1; val o = ggb.step(XY(0.0, y), 3.0, 2.5, false); if (o.hold) wasHeld = true }
    for (i in 800 downTo 0) { val y = i * 0.1; val o = ggb.step(XY(0.0, y), 3.0, 2.5, false); if (wasHeld && !o.hold && backResumedAtY < 0) backResumedAtY = y }
    check(wasHeld && backResumedAtY in 55.0..75.0, "walking back out the way you came: resumes once clear (at y=$backResumedAtY)")
    check(GreenGuard(GuardCfg(enabled = false)).also { it.setMap(gm) }.step(XY(0.0, 100.0), 3.0, 2.5, false).state == GuardState.OFF, "guard off -> never holds")
    check(GreenGuard().step(XY(0.0, 100.0), 3.0, 2.5, false).state == GuardState.NO_DATA, "no map -> NO_DATA, no hold")
    val ggn = GreenGuard(); ggn.setMap(GreenMap(gO, emptyList()))
    check(!ggn.step(XY(0.0, 0.0), 3.0, 2.5, false).hold, "course without green data -> no hold (cannot help)")
    val ggp = GreenGuard(); ggp.setMap(gm)
    check(ggp.step(XY(0.0, 60.0), 40.0, 2.5, false).hold, "bad GPS (40 m) 30 m from a green -> hold, we cannot trust the position")
    check(!GreenGuard().also { it.setMap(gm) }.step(XY(0.0, 0.0), 40.0, 2.5, false).hold, "bad GPS but far from any green -> free")

    // ---- water and bunkers: each kind has its own buffer; the tightest one wins
    val featRect = rectXY(-10.0, 100.0, 10.0, 110.0)         // true edge at y = 100
    fun holdY(map: GreenMap, cfg: GuardCfg = GuardCfg()): Double {
        val g = GreenGuard(cfg); g.setMap(map)
        for (i in 0..1200) { val y = i * 0.1; if (g.step(XY(0.0, y), 3.0, 2.5, false).hold) return y }
        return -1.0
    }
    val yWater = holdY(GreenMap(gO, emptyList(), water = listOf(featRect)))
    val yBunker = holdY(GreenMap(gO, emptyList(), bunkers = listOf(featRect)))
    val yGreen = holdY(GreenMap(gO, listOf(featRect)))
    check(yWater in 84.0..90.0, "water: holds about 12+3 m short, cart 2.5 m behind (player y=$yWater)")
    check(yBunker in 89.0..95.0, "bunker: holds about 7+3 m short (player y=$yBunker)")
    check(yBunker > yWater && Math.abs(yWater - yGreen) < 0.3, "bunker buffer is the tighter one; water and green match by default")
    check(holdY(GreenMap(gO, emptyList(), bunkers = listOf(featRect)), GuardCfg(bunkerMarginM = 15.0)) < yBunker - 6.0, "a bigger bunker buffer holds earlier")
    val mixed = GreenMap(gO, listOf(rectXY(-10.0, 300.0, 10.0, 310.0)), bunkers = listOf(featRect))
    val gmix = GreenGuard(); gmix.setMap(mixed)
    var mo = gmix.step(XY(0.0, 0.0), 3.0, 2.5, false)
    for (y in 1..95) mo = gmix.step(XY(0.0, y.toDouble()), 3.0, 2.5, false)
    check(mo.hold && mo.hazard == Hazard.BUNKER && !mo.lostGps, "the hold names the hazard that caused it (bunker, not the far green)")
    check(GreenMap.build(Course("W", listOf(h1.copy(origin = ll(0.0, 0.0), greens = emptyList(), water = listOf(rectXY(0.0, 0.0, 5.0, 5.0)), bunkers = listOf(rectXY(9.0, 9.0, 12.0, 12.0))))))!!.let { !it.isEmpty && it.water.size == 1 && it.bunkers.size == 1 },
        "a course with only water and bunkers still gets a map")
    check(GreenGuard().also { it.setMap(GreenMap(gO, emptyList(), bunkers = listOf(featRect))) }.step(XY(0.0, 0.0), 3.0, 2.5, false).let { it.state == GuardState.FREE && !it.hold }, "far from a bunker -> free")

    // GPS lost: hold wherever you are, resume only once it has recovered
    val gl = GreenGuard(); gl.setMap(gm)
    var lo = gl.step(XY(0.0, 0.0), 60.0, 2.5, false)
    check(lo.hold && lo.lostGps, "GPS worse than 50 m, nowhere near a hazard -> hold, flagged as lost GPS")
    lo = gl.step(XY(0.0, 0.0), 60.0, 2.5, false)
    check(lo.hold, "stays held while GPS stays lost")
    for (i in 1..2) lo = gl.step(XY(0.0, 0.0), 4.0, 2.5, false)
    check(lo.hold, "not released on the first good fixes")
    lo = gl.step(XY(0.0, 0.0), 4.0, 2.5, false)
    check(!lo.hold && lo.state == GuardState.FREE, "released after 3 good fixes in a row")
    check(!GreenGuard().also { it.setMap(gm) }.step(XY(0.0, 0.0), 49.0, 2.5, false).hold, "49 m is poor but not lost: far from hazards -> still free")
    val dflt = GuardCfg()
    check(dflt.baseMarginM == 12.0 && dflt.waterMarginM == 12.0 && dflt.bunkerMarginM == 7.0, "default buffers: green 12, water 12, bunker 7 m")

    // ---- caddie voice and display tips
    check(CaddieVoice.holeResult(3, 4) == "Birdie. Nicely played." && CaddieVoice.holeResult(4, 4) == "Par. Solid.", "hole result wording: birdie, par")
    check(CaddieVoice.holeResult(1, 3).startsWith("Hole in one") && CaddieVoice.holeResult(3, 5).startsWith("Eagle"), "hole in one and eagle")
    check(CaddieVoice.holeResult(9, 4).startsWith("Tough") && CaddieVoice.holeResult(0, 4).startsWith("Hole done"), "big numbers and no strokes are handled kindly")
    check(listOf(1, 2, 3, 4, 5, 6, 7, 8).all { CaddieVoice.holeResult(it, 4).length <= Protocol.MAX_TIP_CHARS }, "every hole-result line fits the display")
    check(CaddieVoice.cartHolding("bunker", false) == "Cart holding: bunker ahead." && CaddieVoice.cartHolding(null, true).contains("GPS"), "cart-holding wording")
    val tipJson = JSONObject(Protocol.tip("Nice \u2013 it\u2019s a par \u00e9 \u263a   ok"))
    check(tipJson.getString("tip") == "Nice - it's a par ok", "tip text: dashes and quotes mapped, other symbols dropped, spaces tidied (got '${tipJson.getString("tip")}')")
    check(JSONObject(Protocol.tip("x".repeat(200))).getString("tip").length == Protocol.MAX_TIP_CHARS, "tip text is cut to the display's limit")
    check(Protocol.tip("hi").endsWith("\n") && !Protocol.tip("hi").dropLast(1).contains('\n'), "tip is one newline-terminated line")

    // ============================================================ round stats, history and the Caddie Report
    fun hs(h: Int, par: Int, sw: Int, pu: Int, fw: Boolean? = null, dr: Int? = null) = HoleStat(h, par, sw, pu, fw, dr)
    check(hs(1, 4, 2, 2).gir && !hs(1, 4, 3, 2).gir && hs(1, 3, 1, 2).gir && hs(1, 5, 3, 3).gir && !hs(1, 5, 4, 2).gir, "GIR: par4 in 2 swings, par3 in 1, par5 in 3 (and not par5 in 4)")
    check(!hs(1, 4, 4, 0).girKnown && !hs(1, 4, 4, 0).gir, "no putts entered -> GIR unknown (not counted as a miss)")
    check(hs(1, 3, 1, 0).gir && hs(1, 3, 1, 0).girKnown, "a hole in one counts as GIR even with no putts")
    val rs = RoundStats(listOf(
        hs(1, 4, 2, 2, true, 240), hs(2, 3, 2, 2), hs(3, 5, 3, 2, false, 255), hs(4, 4, 3, 3, true, 220),
        hs(5, 4, 4, 2, false, 200), hs(6, 4, 2, 1, true, 235),
    ))
    check(rs.played == 6 && rs.score == 4 + 4 + 5 + 6 + 6 + 3 && rs.par == 24, "score ${rs.score} on par ${rs.par}")
    check(rs.birdies == 1 && rs.pars == 2 && rs.bogeys == 1 && rs.doublesOrWorse == 2 && rs.eaglesOrBetter == 0, "score mix counted (b=${rs.birdies} p=${rs.pars} bo=${rs.bogeys} d=${rs.doublesOrWorse})")
    check(rs.fairwayChances == 5 && rs.fairwaysHit == 3, "fairways: 3 of 5 (par 3 excluded)")
    check(rs.girHoles == 6 && rs.girs == 3, "GIR: 3 of 6 (got ${rs.girs} of ${rs.girHoles})")
    check(rs.putts == 12 && rs.threePutts == 1 && rs.onePutts == 1, "putts 12, one 3-putt, one 1-putt")
    near(rs.puttsPerHole, 2.0, 1e-9, "putts per hole")
    check(rs.longestDrive == 255 && rs.averageDrive == 230, "longest drive 255, average 230 (got ${rs.averageDrive})")
    check(RoundStats(emptyList()).played == 0 && RoundStats(emptyList()).puttsPerHole == 0.0, "empty round is safe")

    val sum = RoundSummary.from(rs, "Pine\tValley", 1_700_000_000_000L)
    val back = StatsCodec.decodeHistory(StatsCodec.encodeHistory(listOf(sum, sum.copy(dateMs = 1L, score = 90))))
    check(back.size == 2 && back[0].score == sum.score && back[1].score == 90 && back[0].course == "Pine Valley" && back[0].fairHit == 3, "history round trip (tab in a course name is cleaned)")
    check(StatsCodec.decodeHistory("junk\nmore junk").isEmpty() && StatsCodec.decodeHistory(null).isEmpty(), "bad history -> empty")
    val hrt = StatsCodec.decodeHoles(StatsCodec.encodeHoles(rs.holes))
    check(hrt == rs.holes, "hole stats round trip incl. null fairway and drive")
    check(StatsCodec.decodeHoles("1,4,2,2,1,240;bad;99,4,2,2,1,0").size == 1, "bad hole-stat entries are skipped")

    val rep0 = CaddieReport.build(RoundStats(emptyList()), "X", emptyList(), false)
    check(rep0.lines.isEmpty() && rep0.focus == null && rep0.headline.contains("No holes"), "empty round -> friendly nothing-yet message")
    val rep = CaddieReport.build(rs, "Pine Valley", emptyList(), false)
    check(rep.headline == "Through 6 holes: 28 (+4) at Pine Valley.", "headline mid-round (got '${rep.headline}')")
    check(rep.lines.any { it.startsWith("You hit 3 of 5 fairways (60%)") } && rep.lines.any { it.startsWith("Greens in regulation: 3 of 6 (50%)") } && rep.lines.any { it.contains("12 putts, 2.0 a hole") }, "report lines for fairways, greens and putts: ${rep.lines}")
    check(rep.focus != null && rep.focus!!.startsWith("Focus for next time:"), "something is below benchmark -> name it (got ${rep.focus})")
    val allGood = RoundStats((1..6).map { hs(it, 4, 2, 2, true, 240) }.map { it.copy(putts = 1) })
    check(CaddieReport.build(allGood, null, emptyList(), false).focus == "Nice all-round game. Keep doing what you're doing.", "everything at or above benchmark -> encouragement")
    check(rep.lines.first() == "1 birdie, 2 pars, 1 bogey, 2 doubles or worse.", "score mix line (got '${rep.lines.first()}')")
    val threePuttRound = RoundStats((1..6).map { hs(it, 4, 2, 3, true, 240) })
    check(CaddieReport.build(threePuttRound, null, emptyList(), false).focus!!.contains("Putting"), "lots of putts -> focus on putting")
    val missFairways = RoundStats((1..6).map { hs(it, 4, 2, 2, false, 240) })
    check(CaddieReport.build(missFairways, null, emptyList(), false).focus!!.contains("Tee shots"), "no fairways -> focus on tee shots")
    val missGreens = RoundStats((1..6).map { hs(it, 4, 4, 2, true, 240) })
    check(CaddieReport.build(missGreens, null, emptyList(), false).focus!!.contains("Approach"), "no greens in regulation -> focus on approach shots")
    check(CaddieReport.build(rs, null, emptyList(), true).headline == "You shot 28 (+4).", "complete round headline, no course name")
    fun past(score: Int, fw: Int, gir: Int, putts: Int) = RoundSummary(1L, "P", 18, score, 72, fw, 14, gir, 18, putts, 18, 250)
    val hist = listOf(past(90, 7, 5, 36), past(88, 7, 6, 35))
    val repH = CaddieReport.build(rs, "Pine Valley", hist, false)
    check(repH.lines.any { it.contains("Better than your usual 50%") }, "compares fairways with your usual (60% vs 50%): ${repH.lines}")
    val fullRound = RoundStats((1..18).map { hs(it, 4, 3, 2, if (it % 2 == 0) true else false, 230) })
    val repF = CaddieReport.build(fullRound, "P", listOf(past(85, 7, 5, 36)), true)
    check(repF.lines.any { it.contains("better than your last 18-hole round") } || repF.lines.any { it.contains("higher than your last 18-hole round") } || repF.lines.any { it.contains("Same score") }, "compares with the last round of the same length")
    check(CaddieReport.signed(3) == "+3" && CaddieReport.signed(0) == "E" && CaddieReport.signed(-2) == "-2", "to-par formatting")
    check(CaddieReport.build(RoundStats(listOf(hs(1, 4, 2, 1))), null, emptyList(), false).focus == null, "one hole is too little to give advice")

    // override with the switch
    val ggo = GreenGuard(); ggo.setMap(gm)
    var o = ggo.step(XY(0.0, 0.0), 3.0, 2.5, false)
    for (y in 1..85) o = ggo.step(XY(0.0, y.toDouble()), 3.0, 2.5, false)
    check(o.hold, "held near the green")
    o = ggo.step(XY(0.0, 85.0), 3.0, 2.5, true)
    check(!o.hold && o.state == GuardState.OVERRIDDEN, "switch overrides the hold")
    o = ggo.step(XY(0.0, 86.0), 3.0, 2.5, false)
    check(!o.hold, "does not grab the cart again while still next to the green")
    o = ggo.step(XY(0.0, 20.0), 3.0, 2.5, false); o = ggo.step(XY(0.0, 5.0), 3.0, 2.5, false)
    check(o.state == GuardState.FREE, "re-armed once the cart is well clear")

    // How often does the cart still reach the collar? Monte-Carlo, with the error sizes ASSUMED (not measured):
    //  GPS: slowly wandering error (AR1, sigma 3.5 m), reported accuracy 4 m; 10% of runs have an 8 m multipath bias for 15 s;
    //  map: the whole green drawn 3 m (sigma) off; latency from decision to a stopped cart ~1.3 m of extra roll.
    fun approach(seed: Long, baseM: Double): Pair<Boolean, Double> {   // (miss, final cart distance to the REAL edge)
        val rng = java.util.Random(seed)
        val mapOff = XY(rng.nextGaussian() * 3.0, rng.nextGaussian() * 3.0)
        val g = GreenGuard(GuardCfg(baseMarginM = baseM)); g.setMap(GreenMap(gO, listOf(greenRect.map { XY(it.x + mapOff.x, it.y + mapOff.y) })))
        var ex = 0.0; var ey = 0.0
        val bias = rng.nextDouble() < 0.10; val bAng = rng.nextDouble() * 2 * Math.PI; val bStart = 40 + rng.nextInt(40)
        for (t in 0..150) {
            val py = t * 1.2
            ex = 0.9 * ex + Math.sqrt(1 - 0.81) * 3.5 * rng.nextGaussian(); ey = 0.9 * ey + Math.sqrt(1 - 0.81) * 3.5 * rng.nextGaussian()
            var bx = 0.0; var by = 0.0
            if (bias && t in bStart..bStart + 15) { bx = 8 * Math.cos(bAng); by = 8 * Math.sin(bAng) }
            val out = g.step(XY(ex + bx, py + ey + by), 4.0, 2.5, false)
            if (out.hold) { val cartY = py - 2.5 + 1.2 * 1.0 + 0.3; return (cartY > 87.0) to (90.0 - cartY) }
        }
        return true to -99.0
    }
    for (base in listOf(4.0, 9.0, 12.0, 14.0)) {
        val res = (1L..2000L).map { approach(it, base) }
        val miss = res.count { it.first } / 20.0
        val short = res.filter { !it.first }.map { it.second }.sorted()
        println("      green guard, base margin ${base.toInt()} m: collar reached in ${"%.1f".format(miss)}% of 2000 simulated approaches; when it holds, it stops ${"%.0f".format(short[short.size / 2])} m (median) short of the real edge")
    }
    val missAt9 = (1L..2000L).count { approach(it, 9.0).first } / 20.0
    val missAt14 = (1L..2000L).count { approach(it, 14.0).first } / 20.0
    check(missAt14 < missAt9 && missAt9 < (1L..2000L).count { approach(it, 4.0).first } / 20.0, "bigger margin -> fewer misses")

    // ============================================================ par: source + corrections
    val noPar = CourseParser.parse("""{"elements":[${way(""""golf":"hole","ref":"1"""", listOf(0.0 to 0.0, 0.0 to -330.0))},
        ${way(""""golf":"hole","ref":"2","par":"3"""", listOf(40.0 to -350.0, 40.0 to -500.0))},
        ${way(""""golf":"hole","ref":"3","par":"seven"""", listOf(80.0 to 0.0, 80.0 to -600.0))}]}""", "NoPar")
    check(!noPar.hole(1)!!.parMapped && noPar.hole(1)!!.par == 4, "no par tag -> guessed from length (par 4) and flagged")
    check(noPar.hole(2)!!.parMapped && noPar.hole(2)!!.par == 3, "par tag used as is")
    check(!noPar.hole(3)!!.parMapped, "unreadable par tag counts as missing")
    check(h1.parMapped && h2.parMapped, "tagged test holes are marked as from the map")

    val ep = GameEngine(); ep.loadCourse(noPar)
    check(ep.state.parSources.take(3) == listOf(ParSource.ESTIMATED, ParSource.MAP, ParSource.ESTIMATED), "scorecard knows which pars are guesses")
    ep.selectHole(1)
    val msg1 = ep.setPar(1, 5)
    check(ep.state.par == 5 && ep.state.pars[0] == 5 && ep.state.parSources[0] == ParSource.EDITED, "editing the current hole updates par + source")
    check(msg1.size == 1 && JSONObject(msg1[0]).getInt("par") == 5 && JSONObject(msg1[0]).getJSONArray("pars").getInt(0) == 5, "display gets the edited par (hole message)")
    check(ep.setPar(2, 4).isEmpty() && ep.state.pars[1] == 4 && ep.state.par == 5, "editing another hole changes the card, sends nothing")
    check(ep.parEditList().take(2) == listOf(5, 4), "edits listed for saving")
    ep.setPar(1, 0)
    check(ep.state.par == 4 && ep.state.parSources[0] == ParSource.ESTIMATED, "reset goes back to the guessed value")
    ep.setPar(1, 9); check(ep.state.pars[0] == 4, "out-of-range par ignored (treated as reset)")
    check(ep.setPar(0, 4).isEmpty() && ep.setPar(19, 4).isEmpty(), "bad hole numbers ignored")
    val eq = GameEngine(); eq.loadCourse(noPar); eq.setParEdits(listOf(3, 0, 6, 2, 9))
    check(eq.state.pars.take(3) == listOf(3, 3, 6) && eq.state.pars[3] == 4, "saved edits restored; junk values dropped")
    eq.selectHole(1); eq.onDevice(DeviceEvent.HoleOut(5, 2), 1)
    check(eq.state.toPar == 2, "score vs par uses the corrected par (5 on a par 3 = +2)")
    eq.loadCourse(noPar)
    check(eq.state.pars[0] == 4, "loading a course clears the previous course's edits")

    // ============================================================ club catalog
    check(Catalog.models.isNotEmpty() && Catalog.models.all { m -> Catalog.brands.any { it.id == m.brandId } }, "every model has a known brand")
    for (t in ClubType.entries.filter { it != ClubType.OTHER })
        check(Catalog.models(t).isNotEmpty(), "catalog has ${t.label} (${Catalog.models(t).size})")
    check(Catalog.models.all { it.options.isNotEmpty() && it.options.all { o -> o.loft in 1.0..70.0 } }, "all lofts are sane")
    check(Catalog.models.filter { it.type == ClubType.IRON }.all { it.options.map { o -> o.loft }.zipWithNext().all { (a, b) -> b > a } }, "iron lofts rise from 4 iron to PW")
    check(Catalog.models.filter { it.type == ClubType.WEDGE }.all { it.options.map { o -> o.loft }.zipWithNext().all { (a, b) -> b > a } }, "wedge lofts ascend")
    check(Catalog.models.map { "${it.brandId}|${it.model}|${it.type}" }.toSet().size == Catalog.models.size, "no duplicate catalog entries")
    check(Catalog.brandsFor(ClubType.WEDGE).none { it.id == "scotty" } && Catalog.brandsFor(ClubType.PUTTER).any { it.id == "scotty" }, "brand filter per club type")
    val lab = Catalog.models(ClubType.PUTTER, "lab").map { it.model }
    check(lab.size == 11 && listOf("LINK.2.2", "LINK.2.1", "LINK", "DF3", "MEZZ.1 Max").all { it in lab }, "L.A.B. line incl. Link.2.2 (${lab.size} models)")
    val kw = Catalog.models(ClubType.WEDGE, "kirkland")
    check(kw.isNotEmpty() && kw.all { m -> m.options.map { it.loft } == listOf(52.0, 56.0, 60.0) } && Catalog.brand("kirkland").name == "Kirkland Signature", "Kirkland wedges 52/56/60")
    val qi = Catalog.models.first { it.brandId == "taylormade" && it.model == "Qi" && it.type == ClubType.IRON }
    check(qi.options.map { it.name } == listOf("5 Iron", "6 Iron", "7 Iron", "8 Iron", "9 Iron", "PW", "AW", "SW") && qi.options.first { it.name == "AW" }.loft == 49.0, "TaylorMade Qi irons include the AW (49) and SW")
    check(Catalog.brand("nope").initials == "NO", "unknown brand falls back to a badge")

    val avg = SwingProfile.AVERAGE
    val est = { loft: Double, t: ClubType, p: SwingProfile -> DistanceModel.estimate(loft, t, p) }
    near(est(10.5, ClubType.DRIVER, avg), 212, 0.5, "average driver carry")
    near(est(34.0, ClubType.IRON, avg), 130, 1.5, "34 degree iron")
    check(est(28.0, ClubType.IRON, avg) > est(34.0, ClubType.IRON, avg), "stronger loft goes further")
    check((8..64).map { est(it.toDouble(), ClubType.IRON, avg) }.zipWithNext().all { (a, b) -> b <= a }, "carry never increases with loft")
    check(est(52.0, ClubType.WEDGE, SwingProfile.FAST) > est(52.0, ClubType.WEDGE, avg) && est(52.0, ClubType.WEDGE, SwingProfile.SLOW) < est(52.0, ClubType.WEDGE, avg), "swing profile scales distance")
    check(est(3.0, ClubType.PUTTER, avg) == 0 && est(0.0, ClubType.IRON, avg) == 0, "putter / no loft -> 0")
    check(est(2.0, ClubType.DRIVER, avg) == est(8.0, ClubType.DRIVER, avg) && est(90.0, ClubType.WEDGE, avg) == est(64.0, ClubType.WEDGE, avg), "extreme lofts are clamped")

    val ti = Catalog.models.first { it.brandId == "titleist" && it.model == "T150" }
    val c7 = ti.toClub(ti.options[3], avg)
    check(c7.name == "7 Iron" && c7.brand == "Titleist" && c7.model == "T150" && c7.loft == 31.0 && c7.estimated && c7.type == ClubType.IRON, "toClub fills brand/model/loft")
    check(Catalog.inBag(listOf(c7), ti, ti.options[3]) && !Catalog.inBag(listOf(c7), ti, ti.options[2]), "inBag matches brand+model+name")
    val putter = Catalog.models.first { it.type == ClubType.PUTTER }.let { it.toClub(it.options[0], avg) }
    check(putter.carryYd == 0 && !putter.estimated && putter.isPutter, "putter has no carry")

    // recommendation uses the real clubs, never a putter
    val bag = listOf(putter) + ti.options.map { ti.toClub(it, avg) }
    check(Clubs.recommend(bag, 5)?.isPutter == false, "putter is never recommended, even at 5 yards")
    val rec = Clubs.recommend(bag, 140)!!
    check(rec.carryYd >= 140 && bag.filter { !it.isPutter && it.carryYd >= 140 }.all { it.carryYd >= rec.carryYd }, "recommends the shortest club that reaches (${rec.name} ${rec.carryYd})")
    check(Clubs.recommend(listOf(putter), 100) == null && Clubs.recommend(emptyList(), 100) == null, "putter-only / empty bag -> no recommendation")
    check(Clubs.sorted(bag).last().isPutter && Clubs.sorted(bag).first().carryYd == bag.maxOf { it.carryYd }, "bag sorted longest first, putter last")

    // swing change re-estimates only clubs the player never typed in
    val typed = c7.copy(name = "8 Iron", carryYd = 123, estimated = false)
    val re = DistanceModel.reestimate(listOf(c7, typed), SwingProfile.FAST)
    check(re[0].carryYd > c7.carryYd && re[1].carryYd == 123, "swing change leaves typed distances alone")

    // storage round trip + the old format
    val enc = Clubs.encode(listOf(c7, typed, putter, Club("Odd\tName", 99)))
    val dec = Clubs.decode(enc)
    check(dec.size == 4 && dec[0] == c7 && dec[1] == typed && dec[2] == putter && dec[3].name == "Odd Name", "bag encode/decode round trip")
    check(Clubs.decode("Driver:230;7 Iron:150") == listOf(Club("Driver", 230), Club("7 Iron", 150)), "old bag format still reads")
    check(Clubs.decode(null).isEmpty() && Clubs.decode("").isEmpty() && Clubs.decode("garbage\tx").isEmpty(), "bad bag data -> empty")

    // ============================================================ cart pairing (phone side; the cart side is tested in tests/test_auth.cpp)
    run {
        val fixKey = "000102030405060708090a0b0c0d0e0f"
        check(CartAuth.tag(fixKey, "0123456789abcdef") == "30019ba06197c0ed181d45d34500c0b6", "pairing: HMAC answer matches the cart's test value (same fixture as the cart's C++ test)")
        check(CartAuth.tag(fixKey.uppercase(), "0123456789abcdef") == "30019ba06197c0ed181d45d34500c0b6", "pairing: key letters can be upper or lower case")
        check(CartAuth.tag(fixKey, "0123456789abcdee") != CartAuth.tag(fixKey, "0123456789abcdef"), "pairing: a different challenge gives a different answer")
        check(CartAuth.validPin("012345") && !CartAuth.validPin("12345") && !CartAuth.validPin("12345a") && !CartAuth.validPin(null), "pairing: PIN is exactly six digits")
        check(CartAuth.validKeyHex(fixKey) && !CartAuth.validKeyHex("zz") && !CartAuth.validKeyHex(fixKey + "0") && !CartAuth.validKeyHex(null), "pairing: key is exactly 32 hex characters")

        // the lines
        check(CartProtocol.auth(fixKey, "0123456789abcdef") == "{\"k\":\"auth\",\"h\":\"30019ba06197c0ed181d45d34500c0b6\"}\n", "pairing: auth line format")
        check(CartProtocol.pair("004217") == "{\"k\":\"pair\",\"pin\":\"004217\"}\n", "pairing: pair line keeps leading zeros")
        check(CartProtocol.parse("{\"k\":\"chal\",\"n\":\"abcd\",\"paired\":1,\"pairing\":0}") == CartMsg.Chal("abcd", true, false), "pairing: parse challenge")
        check(CartProtocol.parse("{\"k\":\"chal\",\"paired\":1}") == null, "pairing: a challenge without a nonce is ignored")
        check(CartProtocol.parse("{\"k\":\"auth\",\"ok\":0,\"left\":4}") == CartMsg.AuthAck(false, 4, null, false), "pairing: parse refusal with tries left")
        check(CartProtocol.parse("{\"k\":\"auth\",\"ok\":0,\"wait\":60}") == CartMsg.AuthAck(false, null, 60, false), "pairing: parse lockout")
        check(CartProtocol.parse("{\"k\":\"auth\",\"ok\":1}") == CartMsg.AuthAck(true, null, null, false), "pairing: parse success")
        check(CartProtocol.parse("{\"k\":\"paired\",\"ok\":1,\"key\":\"$fixKey\"}") == CartMsg.PairAck(true, fixKey, null, false), "pairing: parse paired + key")
        check(CartProtocol.parse("{\"k\":\"paired\",\"ok\":0,\"closed\":1}") == CartMsg.PairAck(false, null, null, true), "pairing: parse window closed")

        // the decisions
        val unk = CartAuthStatus()
        val flow = CartAuthFlow
        flow.onMessage(CartMsg.Chal("n1", paired = false, pairing = true), null, unk).let {
            check(it.status.state == CartAuthState.PAIRING_OPEN && it.send == null, "pairing: no key + window open -> ask for the PIN")
        }
        flow.onMessage(CartMsg.Chal("n1", paired = false, pairing = false), null, unk).let {
            check(it.status.state == CartAuthState.NEEDS_PAIRING && it.status.message.contains("6 times") && it.send == null, "pairing: no key + window closed -> tell how to open it")
        }
        flow.onMessage(CartMsg.Chal("n1", paired = true, pairing = false), fixKey, unk).let {
            check(it.status.state == CartAuthState.CHECKING && it.send == CartProtocol.auth(fixKey, "n1"), "pairing: key + cart has a key -> answer the challenge")
        }
        // the encrypted link (Bluetooth passkey = the PIN): pairing finishes without typing the PIN a second time
        check(CartProtocol.parse("{\"k\":\"chal\",\"n\":\"abcd\",\"paired\":0,\"pairing\":1,\"sec\":1,\"fresh\":1}") == CartMsg.Chal("abcd", false, true, true, true), "encrypted: parse sec + fresh")
        check((CartProtocol.parse("{\"k\":\"chal\",\"n\":\"abcd\",\"paired\":1,\"pairing\":0}") as CartMsg.Chal).let { !it.secure && !it.fresh }, "encrypted: older cart (no sec/fresh) parses as unprotected")
        check(CartProtocol.pair(null) == "{\"k\":\"pair\"}\n" && CartProtocol.pair("123456").contains("\"pin\":\"123456\""), "encrypted: pair line with and without a PIN")
        flow.onMessage(CartMsg.Chal("n1", paired = false, pairing = true, secure = true, fresh = true), null, unk).let {
            check(it.status.state == CartAuthState.CHECKING && it.send == CartProtocol.pair(null), "encrypted: fresh passkey pairing -> finish without asking for the PIN")
        }
        flow.onMessage(CartMsg.Chal("n1", paired = true, pairing = true, secure = true, fresh = true), fixKey, unk).let {
            check(it.send == CartProtocol.pair(null), "encrypted: fresh pairing replaces an old key (the person opened pairing on purpose)")
        }
        flow.onMessage(CartMsg.Chal("n1", paired = true, pairing = true, secure = true, fresh = false), null, unk).let {
            check(it.status.state == CartAuthState.PAIRING_OPEN && it.send == null, "encrypted: old Android pairing + window open -> the PIN is still typed")
        }
        flow.onMessage(CartMsg.Chal("n2", paired = false, pairing = true, secure = true, fresh = true), null, CartAuthStatus(CartAuthState.CHECKING, "")).let {
            check(it.send == null, "encrypted: the finishing line is not sent twice")
        }
        flow.onMessage(CartMsg.Chal("n1", paired = false, pairing = false), fixKey, unk).let {
            check(it.status.state == CartAuthState.NEEDS_PAIRING && it.status.message.contains("reset") && it.send == null, "pairing: our key but the cart has none -> it was reset, pair again")
        }
        flow.onMessage(CartMsg.Chal("n1", paired = true, pairing = false), "garbage", unk).let {
            check(it.send == null && it.status.state == CartAuthState.NEEDS_PAIRING, "pairing: a damaged stored key is not used")
        }
        flow.onMessage(CartMsg.AuthAck(true, null, null, false), fixKey, CartAuthStatus(CartAuthState.CHECKING)).let { check(it.status.state == CartAuthState.AUTHED, "pairing: accepted -> authenticated") }
        val rej = flow.onMessage(CartMsg.AuthAck(false, 4, null, false), fixKey, CartAuthStatus(CartAuthState.CHECKING))
        check(rej.status.state == CartAuthState.REJECTED && rej.status.message.contains("6 times"), "pairing: refused -> says to pair again")
        flow.onMessage(CartMsg.Chal("n2", paired = true, pairing = false), fixKey, rej.status).let {
            check(it.send == null && it.status.state == CartAuthState.REJECTED, "pairing: the cart's fresh challenge after a refusal is NOT answered again (would burn its few tries)")
        }
        flow.onMessage(CartMsg.Chal("n2", paired = true, pairing = true), fixKey, rej.status).let {
            check(it.send == null && it.status.state == CartAuthState.PAIRING_OPEN, "pairing: after a refusal, if the owner opens pairing at the cart, offer the PIN")
        }
        flow.onMessage(CartMsg.AuthAck(false, null, 60, false), fixKey, CartAuthStatus(CartAuthState.CHECKING)).let {
            check(it.status.state == CartAuthState.LOCKED && it.status.message.contains("60"), "pairing: locked out -> says for how long")
        }
        flow.onMessage(CartMsg.Chal("n3", paired = true, pairing = false), fixKey, CartAuthStatus(CartAuthState.LOCKED)).let { check(it.send == null, "pairing: nothing is sent while locked out") }
        flow.onMessage(CartMsg.AuthAck(false, null, null, true), fixKey, CartAuthStatus(CartAuthState.CHECKING)).let { check(it.status.state == CartAuthState.NEEDS_PAIRING, "pairing: cart says it has no paired phone") }
        flow.onMessage(CartMsg.PairAck(true, fixKey.uppercase(), null, false), null, CartAuthStatus(CartAuthState.PAIRING_OPEN)).let {
            check(it.status.state == CartAuthState.AUTHED && it.saveKey == fixKey, "pairing: right PIN -> authenticated and the key is saved (lowercase)")
        }
        flow.onMessage(CartMsg.PairAck(true, "short", null, false), null, CartAuthStatus(CartAuthState.PAIRING_OPEN)).let {
            check(it.saveKey == null && it.status.state == CartAuthState.REJECTED, "pairing: a malformed key from the cart is never saved")
        }
        flow.onMessage(CartMsg.PairAck(false, null, 4, false), null, CartAuthStatus(CartAuthState.PAIRING_OPEN)).let { check(it.status.message.contains("4 tries left") && it.status.state == CartAuthState.PAIRING_OPEN, "pairing: wrong PIN -> tries left") }
        flow.onMessage(CartMsg.PairAck(false, null, 1, false), null, CartAuthStatus(CartAuthState.PAIRING_OPEN)).let { check(it.status.message.contains("1 try left"), "pairing: '1 try left' singular") }
        flow.onMessage(CartMsg.PairAck(false, null, null, true), null, CartAuthStatus(CartAuthState.PAIRING_OPEN)).let { check(it.status.state == CartAuthState.NEEDS_PAIRING, "pairing: window closed after too many wrong PINs") }
        flow.onMessage(CartMsg.Tel(CartTelemetry()), null, unk).let { check(it.status.state == CartAuthState.AUTHED, "pairing: an older cart without this check (it just sends data) still works") }
        flow.onMessage(CartMsg.Tel(CartTelemetry()), null, CartAuthStatus(CartAuthState.NEEDS_PAIRING, "x")).let { check(it.status.state == CartAuthState.NEEDS_PAIRING, "pairing: stray data never upgrades a cart that asked for pairing") }
    }

    // ============================================================ per-club insights
    run {
        fun cl(name: String, carry: Int, t: ClubType = ClubType.IRON) = Club(name, carry, type = t)
        fun shotsOf(c: Club, ds: List<Int>, start: Long = 1, acc: Float = 5f) = ds.mapIndexed { i, d -> ShotRecord(1, Clubs.key(c), d, start + i, acc) }
        val a = cl("7 Iron", 150); val b = cl("9 Iron", 130); val pu = Club("Putter", 0, type = ClubType.PUTTER)

        check(ClubInsights.build(listOf(a), shotsOf(a, listOf(150, 148))).stats.isEmpty(), "insights: two shots are not enough to say anything")
        val three = ClubInsights.build(listOf(a), shotsOf(a, listOf(140, 150, 160))).stats.single()
        check(three.n == 3 && three.avgYd == 150 && three.spreadYd == null && three.trendYd == null && three.bagYd == 150, "insights: 3 shots -> average, no spread or trend yet")
        val five = ClubInsights.build(listOf(a), shotsOf(a, listOf(140, 150, 160, 150, 150))).stats.single()
        check(five.avgYd == 150 && five.spreadYd == 7, "insights: spread is the standard deviation (about 7 yd, got ${five.spreadYd})")
        check(ClubInsights.build(listOf(a), shotsOf(a, listOf(150, 150, 150, 60, 150)) ).stats.single().let { it.n == 4 && it.avgYd == 150 }, "insights: a mis-hit (60 yd) is ignored like the caddie does")
        check(ClubInsights.build(listOf(a), shotsOf(a, listOf(150, 150, 150), acc = 30f)).stats.isEmpty(), "insights: shots with bad GPS are ignored")
        check(ClubInsights.build(listOf(pu), shotsOf(pu, listOf(5, 6, 7, 8))).stats.isEmpty(), "insights: putter is never listed")

        // trend: last four vs the ones before
        val trendShort = ClubInsights.build(listOf(a), shotsOf(a, listOf(150, 152, 148, 150, 140, 141, 139, 140)))
        check(trendShort.stats.single().trendYd == -10 && trendShort.lines.any { it.contains("7 Iron") && it.contains("10 yd shorter") }, "insights: 7 iron 10 yd shorter lately is called out")
        val trendLong = ClubInsights.build(listOf(a), shotsOf(a, listOf(150, 150, 150, 150, 158, 158, 158, 158)))
        check(trendLong.lines.any { it.contains("8 yd longer") }, "insights: longer lately is called out too")
        check(ClubInsights.build(listOf(a), shotsOf(a, listOf(150, 150, 150, 150, 152, 152, 152, 152))).lines.none { it.contains("lately") }, "insights: a 2 yd change is just noise")
        check(ClubInsights.build(listOf(a), shotsOf(a, listOf(150, 140, 150, 145))).stats.single().trendYd == null, "insights: no trend with fewer than 8 shots")

        // consistency
        val tightA = shotsOf(a, listOf(149, 151, 150, 150, 152, 148))
        val looseB = shotsOf(b, listOf(110, 150, 120, 145, 105, 150), start = 100)
        val cons = ClubInsights.build(listOf(a, b), tightA + looseB)
        check(cons.lines.any { it.contains("9 Iron") && it.contains("loosest") }, "insights: the loose club is named (${cons.lines})")
        val bothTight = ClubInsights.build(listOf(a, b), tightA + shotsOf(b, listOf(127, 133, 130, 130, 134, 126), start = 100))
        check(bothTight.lines.any { it.contains("most reliable") } && bothTight.lines.none { it.contains("loosest") }, "insights: all steady -> the steadiest club is praised, nobody is blamed")
        check(ClubInsights.build(listOf(a), tightA).lines.none { it.contains("loosest") || it.contains("reliable") }, "insights: one club alone is not 'the most' of anything")

        // gapping
        val c4 = cl("4 Hybrid", 190, ClubType.HYBRID)
        val gapBig = ClubInsights.build(listOf(c4, a), shotsOf(c4, listOf(185, 185, 185)) + shotsOf(a, listOf(150, 150, 150), start = 50))
        check(gapBig.lines.any { it.contains("35 yd hole between your 4 Hybrid and 7 Iron") }, "insights: a 35 yd hole is reported (${gapBig.lines})")
        val a6 = cl("6 Iron", 155)
        val gapTight = ClubInsights.build(listOf(a6, a), shotsOf(a6, listOf(152, 152, 152)) + shotsOf(a, listOf(150, 150, 150), start = 50))
        check(gapTight.lines.any { it.contains("6 Iron and 7 Iron only differ by 2 yd") }, "insights: two clubs 2 yd apart are reported (${gapTight.lines})")
        check(gapBig.stats.map { it.name } == listOf("4 Hybrid", "7 Iron"), "insights: longest club first")

        // never more than three lines, and none with an empty log
        val many = (1..6).map { cl("$it Test", 250 - it * 20) }
        val manyShots = many.flatMapIndexed { i, c -> shotsOf(c, listOf(150, 152, 148, 150, 140, 141, 139, 140).map { it + 0 }, start = 1000L * (i + 1)) }
        check(ClubInsights.build(many, manyShots).lines.size <= 3, "insights: at most three lines")
        check(ClubInsights.build(Clubs.DEFAULT, emptyList()).let { it.stats.isEmpty() && it.lines.isEmpty() }, "insights: no shots -> nothing to say")
    }

    // ============================================================ GPS watchdog + bench simulator
    run {
        val wg = GreenGuard(); wg.setMap(gm)
        check(wg.staleOut(10_000, 2.5, false) == null, "watchdog: never had a fix -> nothing to do")
        wg.step(XY(0.0, 0.0), 5.0, 2.5, false, 1_000)
        check(wg.staleOut(5_900, 2.5, false) == null, "watchdog: fixes only 4.9 s old -> quiet")
        val st = wg.staleOut(6_500, 2.5, false)
        check(st != null && st.hold && st.lostGps, "watchdog: 5.5 s without a fix -> hold (GPS lost)")
        check(wg.step(XY(0.0, 0.0), 5.0, 2.5, false, 7_000).hold && wg.step(XY(0.0, 0.0), 5.0, 2.5, false, 8_000).hold, "after a stale hold, the first good fixes do not release it yet")
        check(!wg.step(XY(0.0, 0.0), 5.0, 2.5, false, 9_000).hold, "three good fixes release it")
        val off = GreenGuard(GuardCfg(enabled = false)); off.setMap(gm); off.step(XY(0.0, 0.0), 5.0, 2.5, false, 0)
        check(off.staleOut(60_000, 2.5, false) == null, "watchdog: guard switched off -> never holds")
        val nodata = GreenGuard(); nodata.setMap(GreenMap(gO, emptyList())); nodata.step(XY(0.0, 0.0), 5.0, 2.5, false, 0)
        check(nodata.staleOut(60_000, 2.5, false) == null, "watchdog: no hazard data -> never holds (cannot help)")
        check(GreenGuard().also { it.setMap(gm); it.step(XY(0.0, 0.0), 5.0, 2.5, false, 0); it.reset() }.staleOut(60_000, 2.5, false) == null, "watchdog: reset forgets the last fix")

        // ---- scenarios on different maps, cfgs and follow distances: every check must pass
        val mapGreen = gm
        val mapWater = GreenMap(gO, emptyList(), water = listOf(featRect))
        val mapBunker = GreenMap(gO, emptyList(), bunkers = listOf(featRect))
        val mapMixed = GreenMap(gO, listOf(rectXY(-10.0, 300.0, 10.0, 310.0)), water = listOf(rectXY(40.0, 100.0, 60.0, 120.0)), bunkers = listOf(rectXY(-60.0, 80.0, -45.0, 95.0)))
        val maps = listOf("green" to mapGreen, "water" to mapWater, "bunker" to mapBunker, "mixed" to mapMixed)
        val cfgs = listOf("default" to GuardCfg(), "wide" to GuardCfg(baseMarginM = 18.0, waterMarginM = 16.0, bunkerMarginM = 10.0), "tight" to GuardCfg(baseMarginM = 7.0, waterMarginM = 7.0, bunkerMarginM = 4.0))
        var allOk = true; var ran = 0
        for ((mn, m) in maps) for ((cn, cfg) in cfgs) for (follow in listOf(2.5, 5.0)) for (sc in BenchScenario.entries) {
            val plan = BenchScenarios.build(sc, m, XY(0.0, 0.0), cfg, follow)
            if (plan == null) { allOk = false; println("  no plan: $mn $cn follow=$follow ${sc.name}"); continue }
            val g = GreenGuard(cfg); g.setMap(m)
            val sum = BenchHarness.run(plan, g, follow); ran++
            if (!sum.allPassed) { allOk = false; println("  FAILED: $mn/$cn/follow=$follow/${sc.name}: " + sum.checks.filter { !it.passed }.joinToString { it.name + " - " + it.detail }) }
        }
        check(allOk && ran == maps.size * cfgs.size * 2 * BenchScenario.entries.size, "bench: all ${BenchScenario.entries.size} scenarios pass on 4 maps x 3 settings x 2 follow distances ($ran runs)")

        // the checks must be able to FAIL, otherwise they prove nothing
        val planA = BenchScenarios.build(BenchScenario.APPROACH, mapGreen, XY(0.0, 0.0), GuardCfg(), 2.5)!!
        val planD = BenchScenarios.build(BenchScenario.DROPOUT, mapGreen, XY(0.0, 0.0), GuardCfg(), 2.5)!!
        val planW = BenchScenarios.build(BenchScenario.WEAK_GPS, mapGreen, XY(0.0, 0.0), GuardCfg(), 2.5)!!
        val sloppy = GreenGuard(GuardCfg(baseMarginM = 2.0)); sloppy.setMap(mapGreen)
        check(BenchHarness.run(planA, sloppy, 2.5).checks.any { it.name.startsWith("Held in time") && !it.passed }, "bench catches a guard that holds too late (margin 2 m instead of 12 m)")
        val deaf = GreenGuard(GuardCfg(staleFixMs = 3_600_000L)); deaf.setMap(mapGreen)
        check(BenchHarness.run(planD, deaf, 2.5).checks.any { it.name.startsWith("Held once fixes stopped") && !it.passed }, "bench catches a guard with no GPS watchdog")
        val trusting = GreenGuard(GuardCfg(lostAccuracyM = 1000.0)); trusting.setMap(mapGreen)
        check(BenchHarness.run(planW, trusting, 2.5).checks.any { it.name.startsWith("Held while GPS is lost") && !it.passed }, "bench catches a guard that ignores lost GPS")
        val stubborn = GreenGuard(GuardCfg(resumeClearM = 80.0)); stubborn.setMap(mapGreen)
        check(BenchHarness.run(planA, stubborn, 2.5).checks.any { it.name.startsWith("Went again") && !it.passed }, "bench catches a guard that never lets the cart go again")

        // the old behaviour (letting go as soon as YOU are clear) must be caught by the new far-side scenario
        val planX = BenchScenarios.build(BenchScenario.CROSS, mapGreen, XY(0.0, 0.0), GuardCfg(), 2.5)!!
        val oldRule = GreenGuard(GuardCfg(pursuitSpeedMs = 1.6)); oldRule.setMap(mapGreen)
        val bareHold = BenchHarness.run(planX, oldRule, 2.5)
        check(bareHold.allPassed, "bench: the new guard passes the far-side scenario")
        val leaky = object { fun run(): BenchSummary {                       // a guard that releases the moment you are clear, as before
            val r = BenchRunner(planX, withCart = false); val g2 = GreenGuard(); g2.setMap(mapGreen); var hold = false
            while (!r.done) {
                val s = r.current!!; val o = g2.step(s.pos, s.accuracyM ?: 5.0, 2.5, false, r.tick * 1000L)
                // ignore "path blocked": release as soon as the player alone is clear
                hold = o.hold && !o.pathBlocked
                r.record(hold, null)
            }
            return r.summary()
        } }.run()
        check(leaky.checks.any { it.name.startsWith("Did not follow you across") && !it.passed }, "bench catches a guard that lets the cart follow you across the hazard")

        check(Protocol.tip(CaddieVoice.pathBlocked()).contains(CaddieVoice.pathBlocked()) && CaddieVoice.pathBlocked().length <= Protocol.MAX_TIP_CHARS, "path-blocked tip fits the display line")

        // plan shape
        check(planA.seconds in 40..160 && planD.seconds == 38 && planW.seconds == 44, "scenario lengths are sensible (approach ${planA.seconds} s, dropout ${planD.seconds} s, weak GPS ${planW.seconds} s)")
        println("      bench lengths: approach ${planA.seconds} s, cross ${planX.seconds} s, weak GPS ${planW.seconds} s, dropout ${planD.seconds} s")
        check(planA.startDistM > 20.0, "approach starts well away from the hazard (${planA.startDistM.toInt()} m)")
        check(BenchScenarios.build(BenchScenario.APPROACH, GreenMap(gO, emptyList()), XY(0.0, 0.0), GuardCfg(), 2.5) == null, "no hazards on the map -> no bench plan")

        // cart agreement: a cart that never raises its flag fails; a cart that follows within 2 s passes
        fun cartRun(lag: Int, never: Boolean): BenchSummary {
            val r = BenchRunner(BenchScenarios.build(BenchScenario.DROPOUT, mapGreen, XY(0.0, 0.0), GuardCfg(), 2.5)!!, withCart = true)
            val g = GreenGuard(); g.setMap(mapGreen); var hold = false; val hist = ArrayList<Boolean>()
            while (!r.done) {
                val s = r.current!!; val now = r.tick * 1000L
                val out = if (s.accuracyM != null) g.step(s.pos, s.accuracyM, 2.5, false, now) else g.staleOut(now, 2.5, false)
                if (out != null) hold = out.hold
                hist += hold
                val cartHold = if (never) false else hist[(hist.size - 1 - lag).coerceAtLeast(0)]
                r.record(hold, cartHold)
            }
            return r.summary()
        }
        check(cartRun(1, false).let { it.allPassed && it.checks.any { c -> c.name.startsWith("The cart agreed") } }, "bench: cart that follows the phone within a second -> PASS")
        check(cartRun(0, true).checks.any { it.name.startsWith("The cart agreed") && !it.passed }, "bench: cart that never holds -> FAIL")
    }

    // ============================================================ hand off to the firmware test
    File("out/app_messages.hex").printWriter().use { w ->
        val msgs = listOf(start[0]) + sentAll.filter { it.contains("\"zone\"") && !it.contains("\"hole\"") }.take(2) + out.last()
        for (m in msgs) { for (c in Protocol.chunk(m, 244)) w.println(c.joinToString("") { "%02x".format(it) }); w.println("=") }
    }
    println("\n$passes passed, $fails failed")
    if (fails > 0) System.exit(1)
}
