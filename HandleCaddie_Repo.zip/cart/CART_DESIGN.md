# Handle Caddie cart controller - design notes and status (read this first)

## 1. Plan: 3 BU03-Kits. Two "base stations" on the cart, one "tag" fob on you.
One distance can't tell left from right; two distances from units 0.6-0.8 m apart can (the difference gives your direction).
The cart also uses its own gyro to carry that direction through its own turns, so the distance readings only have to nudge it.

Simulation with the REAL controller code (sim/sim_follow.cpp; 12 random runs per row; "lost" = more than 8 m away for over 3 s):

| Walk / conditions                    | 0.8 m spacing                            | 0.6 m spacing        |
|--------------------------------------|------------------------------------------|----------------------|
| All 5 routes, ideal and typical noise | 0 of 12 lost, every route                | 0 of 12 lost         |
| Same, plus body shadowing (one unit reads 0.3 m long in 2 s bursts, ~8% of the time) | 0 of 12 lost, every route | 1 of 12 on the sharp corner |
| Bad ranging (+-20 cm noise, 15% dropouts, 8% big spikes, 4 Hz) | 0-4 of 12 lost depending on route (worst: sharp corner) | 1-8 of 12 |

Routes: straight + stop, gentle S-bends, starting 30 degrees off to the side, stop-and-go, sharp 90 degree corner.
"Typical" = +-10 cm noise, 5 readings/s per unit, 5% dropouts, 3% spikes. I do NOT yet know what your units really do.
The bench test in section 4 measures it, and then the numbers above can be re-run with your real values.
Limits: forward-only differential steering (no pivot turns); the cart can't lead you; the simulation has no
terrain, wheel slip or antenna-pattern effects.

## 2. Tested (tests/test_safety.cpp, 43 checks pass)
Two-anchor geometry (left/right sign, gyro shift, impossible readings, one unit lost), tip-over latch (ignores a short bump),
IMU-failure stop, lost-signal stop, max-range stop, never reverses, obstacle slow/stop (an echo at your own distance is you),
park-brake on slopes, downhill speed cap and braking, battery percent / low-battery latch, tilt maths, spike rejection.
Everything is in cart_logic.h (plain C++, no Arduino calls). Nothing here has run on hardware.

## 3. Mounting
- Cart units: left and right sides of the cart, as far apart as practical (0.8 m is simulated; do not go under 0.6 m), same
  height, antennas pointing up and clear of metal, motor boards and the battery. Measure the exact spacing - the code needs it.
- Fob: wear it on the BACK of your belt or the back of a shoulder strap, OUTSIDE your clothing, because the cart is behind you
  and your body blocks the signal. Antenna end up, 1-2 cm off your body, no metal behind it.
- Fob power: the kit needs 5 V on its USB-C port and (factory firmware) draws about 318 mW as a tag, 487 mW as a base station.
  Use a protected 1S LiPo (1500-2000 mAh) with a charge-and-boost board, a slide switch and a plastic case: roughly 14-19 hours.
  If you use a USB power bank instead, test it - many switch off when the load is under 50-100 mA, which is where a tag sits.
- Cart units: 5 V from the cart's regulated rail, about 0.1 A each. Each connects to the ESP32 over its UART2 pins
  (PA2 = TX, PA3 = RX, 3.3 V logic, per the Hackaday page) - cross TX/RX. The ESP32 has two spare UARTs for this.

## 4. Bench test to do when the third kit arrives (send me what it prints)
1. On a PC, open each kit's USB-C serial port in a terminal (try 115200 baud first).
2. Set roles: `AT+SETCFG=ID,role,channel,datarate`  role 0 = tag, 1 = base; give the two bases IDs 0 and 1, the tag ID 0, and
   the same channel and data rate on all three. (This is the only command I found; check it against the Ai-Thinker AT manual.)
3. Put the tag exactly 1.0 m, 2.0 m, 3.0 m, 5.0 m from the base(s) in the open, antennas up. Capture 30 s of the raw serial
   lines at each distance from BOTH bases at once. Check that both bases report distances at the same time (the vendor
   documentation I found only shows one tag with one base).
4. Repeat with the tag worn on your back belt and the bases mounted on the cart, walking away and toward them.
Send me ~20 raw lines per case. From them I'll match the parser (the output format is not documented where I could read it),
measure real noise and update rate, and re-run the simulation with your numbers.

## 5. Hardware findings you should act on (from the product pages I could read)
- Motor boards take an ANALOG speed voltage 0.1-5 V, not PWM. Safest build (CORRECTED - an earlier version of this note was wrong):
  ESP32 PWM pin -> 1 k resistor -> node; 10 uF from the node to GND (your 10 uF cap); node -> board VR input. Put a 10 k resistor from the
  ESP32 PIN itself to GND (before the 1 k), NOT on the VR side. If the ESP32 crashes or resets its pin floats, the 10 k pulls it low, and
  the speed is zero. A pull-down on the VR side would instead divide the signal and lose full scale.
  This gives at most 3.3 V = about 66% of the board's range. For the full 5 V, use a 74AHCT125 buffer powered from 5 V in front of the 1 k
  (input pull-down, output enable tied low) and set SPEED_FULLSCALE_V 5.0. Do NOT use a single MOSFET with a 5 V pull-up: it inverts, and
  a crashed ESP32 then commands FULL speed.
  Before connecting a board, measure the voltage at the node with the VR input connected: if it sits below 3.3 V at 100% duty, the input
  loads the signal - lower the 1 k resistor and raise the capacitor.
- Direction: the cart only goes forward, so do not use an ESP32 pin. Hard-wire each board's DIR input to GND or to 5 V. The two motors are
  mirrored, so one board gets GND and the other 5 V, or swap whichever wheel spins backward. This removes a failure mode.
- The pages don't name the brake / enable / hall-output pins. Check the silkscreen. Hill descent control needs BOTH a brake input
  and a wheel-speed signal (hall output through a voltage divider). Without them: speed limit and park-hold only.
- Two Dewalt 20 V packs are 5S (about 21 V full). Wire them in PARALLEL. In series they reach ~42 V, above the boards' 36 V limit.
  Fuse each pack and use a diode / ideal-diode module so a fuller pack can't dump into an emptier one.
- 10 uF is far too small for the motor bus: add 470 uF or more, 35 V, across each board's supply.
- HC-SR04 ECHO is 5 V: use a divider (or 3.3 V-tolerant modules) into the ESP32.
- Emergency stop: in series with the MOTOR board supply only, so the ESP32 and OLED stay alive to show "E-STOP".
- The GY-521 mounts flat with its X axis toward the front of the cart.

## 6. Suggested OLED content (does not repeat the HandleCaddie screen: no hole, yards, club, score, strokes)
Main page: battery % and volts, estimated miles left, mode (PARK / FOLLOW / FREE), speed in mph, slope %.
Second page (auto-rotate): distance to you and link quality of each base, nearest obstacle, trip miles, lifetime miles.
Alerts take over the screen: TIPPED, LOW BATTERY, E-STOP, SIGNAL LOST, TOO FAR, HILL HOLD.
Cheap additions: a current sensor (INA219) for amps and a real range estimate; a buzzer for alerts.

## 7. ESP32 pin map (classic ESP32, used by BringUp/BringUp.ino)
| Function | Pin | Notes |
|---|---|---|
| I2C SDA / SCL | 21 / 22 | MPU6050 (0x68) and OLED (0x3C) share the bus |
| Speed PWM left / right | 25 / 26 | RC filter described above |
| Brake left / right | 32 / 33 | via a transistor, only if your board has a brake input |
| Hall pulses left / right | 34 / 35 | input-only pins; through a divider |
| Battery sense | 36 | divider about 120 k / 18 k (ratio 7.67) into this pin |
| E-stop sense | 39 | input-only pin |
| Ultrasonic trigger (both tied) / echo left / echo right | 18 / 19 / 23 | echo pins through a divider (5 V to 3.3 V) |
| UWB kit A (Serial2) RX / TX | 16 / 17 | ESP32 RX <- kit PA2, ESP32 TX -> kit PA3 |
| UWB kit B (Serial1) RX / TX | 4 / 14 | |
| Mode button | 0 | the board's own BOOT button |
Not used (strapping or flash pins): 0 (after boot only), 2, 5, 6-11, 12, 15.

## 8. Controller firmware (Cart/Cart.ino) - status
Written and syntax-checked against stub Arduino headers; the logic it calls is tested on a PC (tests/: test_safety 43, test_manual 38, test_proto 42 checks).
**It has not been compiled with the real ESP32 core and has not run on hardware.** Expect to fix small compile errors (BLE class signatures differ a little
between arduino-esp32 versions; this targets core 3.x).

Arduino IDE: board "ESP32 Dev Module", Partition Scheme "Huge APP (3MB No OTA/1MB SPIFFS)", library U8g2. Open Cart/Cart.ino (keep cart_logic.h and
cart_proto.h next to it).

### Things the firmware CANNOT know yet - set them before the first drive (all #defines at the top of Cart.ino)
| setting | why |
|---|---|
| UWB_BAUD, UWB_NO_UNIT_SCALE, `parseUwbLine()` in cart_proto.h | the BU03 line format is undocumented where I could read it. Until a line parses, the cart sees NO fob and will not move in FOLLOW. Type `uwb` in the Serial Monitor to see every raw line and what was understood; compare with a tape measure |
| SPEED_AT_FULL_MS | cart speed at full motor-board input. Calibrate: wheels on the ground, MANUAL, 50% stick, time 10 m, scale |
| MIN_RUN_V | the motor boards may ignore small voltages (dead band) |
| SPEED_TRIM_L/R | if it drifts to one side |
| BASELINE_M, UWB_A_IS_LEFT | measure the base spacing; swap if left/right is mirrored |
| ESTOP_PRESSED_LEVEL / HAS_ESTOP_SENSE | how your e-stop sense divider reads |
| HAS_BRAKE, HAS_HALL, WHEEL_DIAM_M, HALL_PULSES_PER_REV | only if wired; enables hill braking |
| PACK_WH, WH_PER_MILE | "miles left" on the OLED is a guess until you measure |

### Pause switch and LED (new pins)
| pin | function |
|---|---|
| 27 | switch contact to GND when pushed in (internal pull-up) |
| 13 / 15 | green / red LED, each through a transistor or logic-level MOSFET from the battery rail. Your switch LED is rated 12-24 V, so NEVER connect it to an ESP32 pin. I assumed a 3-wire bicolor LED (two anodes, common); if yours is 2-wire reverse-polarity it needs an H-bridge/two transistors - tell me |
LED: steady green = following/manual, brief flash every 2 s = parked, steady red = you paused, blinking amber = waiting at a green, fast red blink = fault.
Press while the cart is waiting at a green = "go anyway"; the position you pressed to becomes "run", so the next press pauses.

### Known limits
- Open-loop speed: without hall wiring the cart does not measure its own speed, so hill descent is only a speed cap.
- Pairing: the cart ignores all commands until a phone proves it holds the key (HMAC-SHA256 challenge, 5 tries then 60 s lockout). The key is made by typing the PIN shown on the cart's OLED. The link itself is encrypted with BLE Secure Connections (passkey = the same PIN, MITM-protected, bonded; one bond at a time), so the key cannot be sniffed during pairing. Untested on hardware: if the Bluetooth security code gives trouble, set CART_BLE_ENCRYPT to 0 in Cart.ino to fall back to the app-level check. See CART_PROTOCOL.md.
- FOLLOW/MANUAL always need to be requested again after power-up, a fault, or a new phone connection (by design).
- millis()-based float timestamps are fine for a round of golf; reboot the cart after about a day of continuous power.

## 9. Route driving (phase 2) - status

Code: `NavController` and `YawBias` in `cart_logic.h`; messages in `cart_proto.h`; wiring in `Cart.ino`; tests in `tests/test_nav.cpp` (85 checks, including a 120-run Monte Carlo). NOT yet run on hardware.

Needs: `HAS_HALL 1` (wheel speed pulses wired) and `WHEEL_DIAM_M` measured. A wheel diameter 6% wrong adds roughly 9 m of error on a 150 m route. The gyro bias is learned while the cart sits still (about 20 s after power-up); route driving is refused until then.

Measured with the host simulation (148 m route, half circle): good sensors mean 1.5 m / worst 4.3 m off the plan; typical 2.7 / 8.0 m; 6% wheel error 15.8 m worst. The phone adds a clearance allowance of 0.07 m per metre of route (3 to 12 m) plus its heading uncertainty, and refuses routes it cannot make that safe.

The phone side (`HazardNav.kt`, tests in `tools/NavSelfTest.kt`) simulates the whole loop with noisy GPS: with typical sensors the cart never got closer than 8.9 m to the green in 25 runs and 21 reached the player; the other 4 stopped themselves out of fob range.
