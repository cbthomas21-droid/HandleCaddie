// Closed-loop simulation using the REAL controller classes (TwoAnchorTracker + Supervisor).
// Two UWB base stations on the cart (left/right), one tag on the walker. Usage: sim_follow [scenario]  (prints a trace)
#include "../cart_logic.h"
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>
#include <algorithm>
using namespace cart;

struct Res { float lostT, rms, minR; };

static Res run(unsigned seed, int sc, float sigma, float spike, float drop, float hz, float d, float shadow, bool trace) {
  std::mt19937 rng(seed); std::normal_distribution<float> N(0, 1); std::uniform_real_distribution<float> U(0, 1);
  float cx = 0, cy = 0, psi = 0, px = 3, py = 0, ppsi = 0, wl = 0, wr = 0, nextL = 0, nextR = 0.5f / hz, lostT = 0, sq = 0, minR = 99; int n = 0;
  float shadowUntil = -1; int shadowSide = 0;
  Supervisor sup; TwoAnchorTracker trk(d);
  const float dt = 0.02f; SupOut out;
  for (float t = 0; t < 150; t += dt) {
    float u = 0, turn = 0;
    if (sc == 0) u = (t < 50) ? 1.3f : (t < 62 ? 0.0f : 1.3f);
    else if (sc == 1) { u = 1.3f; turn = 0.05f * sinf(2 * 3.14159f * t / 40.0f); }
    else if (sc == 2) { u = (t < 3) ? 0.0f : 1.4f; turn = (t > 60 && t < 70) ? 0.15f : 0.0f; if (t < 0.02f) { px = 2.6f; py = 1.5f; } }
    else if (sc == 3) { u = fmodf(t, 30.0f) < 18 ? 1.2f : 0.0f; turn = 0.04f * sinf(t / 9.0f); }
    else { u = 1.3f; turn = (t > 30 && t < 36.3f) ? 0.25f : 0.0f; }
    ppsi += turn * dt; px += u * cosf(ppsi) * dt; py += u * sinf(ppsi) * dt;

    // body shadowing: for ~2 s bursts, one anchor's distance reads long by 0.3 m
    if (shadow > 0 && t > shadowUntil && U(rng) < shadow * dt) { shadowUntil = t + 2.0f; shadowSide = (U(rng) < 0.5f) ? 1 : 2; }
    bool sh = t < shadowUntil;
    for (int a = 0; a < 2; a++) {
      float& next = a == 0 ? nextL : nextR;
      if (t >= next) {
        next += 1.0f / hz;
        if (U(rng) > drop) {
          float s = a == 0 ? 1.0f : -1.0f;
          float ax = cx - s * (d / 2) * sinf(psi), ay = cy + s * (d / 2) * cosf(psi);
          float r = hypotf(px - ax, py - ay) + sigma * N(rng);
          if (sh && shadowSide == a + 1) r += 0.3f;
          if (U(rng) < spike) r += 1.0f + 2.0f * U(rng);
          if (a == 0) trk.pushLeft(t, r); else trk.pushRight(t, r);
        }
      }
    }
    float gz = (wr - wl) / sup.cfg().trackWidthM + 0.003f + 0.01f * N(rng);   // gyro: true yaw rate + small bias + noise
    trk.predict(dt, gz);
    trk.update(t);
    SupIn in; in.dt = dt; in.req = Mode::FOLLOW;
    in.rangeValid = trk.rangeOk(); in.rangeAgeS = trk.ageS(t); in.range = trk.range(); in.rangeRate = trk.rate();
    in.bearing = trk.bearing(); in.bearingOk = trk.bearingOk(); in.yawRate = gz;
    out = sup.update(in);
    wl += (out.vL - wl) * dt / 0.3f; wr += (out.vR - wr) * dt / 0.3f;
    float v = 0.5f * (wl + wr), om = (wr - wl) / sup.cfg().trackWidthM;
    psi += om * dt; cx += v * cosf(psi) * dt; cy += v * sinf(psi) * dt;
    float r = hypotf(px - cx, py - cy); minR = fminf(minR, r); if (r > 8.0f) lostT += dt;
    if (t > 20) { sq += (r - 2.5f) * (r - 2.5f); n++; }
    if (trace && fmodf(t, 3.1f) < dt && t < 80)
      printf("t=%5.1f person=(%6.1f,%6.1f) cart=(%6.1f,%6.1f) r=%5.2f v=%4.2f true_brg=%6.1f est=%6.1f\n", t, px, py, cx, cy, r, v,
             (atan2f(py - cy, px - cx) - psi) * RAD2DEG, out.bearingDeg);
  }
  return {lostT, sqrtf(sq / n), minR};
}

int main(int argc, char** argv) {
  const char* names[] = {"straight + stop", "gentle S-bends", "start 30deg off-axis", "stop-and-go", "sharp 90deg corner"};
  if (argc > 1) {   // trace: sim_follow <scenario> [condition 0-3]
    struct T { float sg, sp, dr, hz, sh; } tc[] = {{0.05f, 0, 0, 10, 0}, {0.10f, 0.03f, 0.05f, 5, 0}, {0.20f, 0.08f, 0.15f, 4, 0}, {0.10f, 0.03f, 0.05f, 5, 0.08f}};
    int ci = argc > 2 ? atoi(argv[2]) : 1; run(100, atoi(argv[1]), tc[ci].sg, tc[ci].sp, tc[ci].dr, tc[ci].hz, 0.8f, tc[ci].sh, true); return 0; }
  struct C { float sg, sp, dr, hz, sh; const char* n; } cs[] = {
    {0.05f, 0.00f, 0.00f, 10, 0.0f, "ideal 10Hz"}, {0.10f, 0.03f, 0.05f, 5, 0.0f, "typical 5Hz"},
    {0.20f, 0.08f, 0.15f, 4, 0.0f, "bad 4Hz"}, {0.10f, 0.03f, 0.05f, 5, 0.08f, "typical + shadowing"}};
  for (float d : {0.6f, 0.8f}) {
    printf("\n== baseline %.1f m (12 random runs per row; lost = more than 8 m away for over 3 s) ==\n", d);
    printf("%-22s %-20s %-10s %-10s %-9s %s\n", "scenario", "conditions", "lost runs", "median rms", "<0.9 m", "worst lost-time");
    for (int s = 0; s < 5; s++) for (auto& c : cs) {
      int lost = 0, close = 0; float worst = 0; std::vector<float> rm;
      for (int k = 0; k < 12; k++) { Res r = run(100 + k, s, c.sg, c.sp, c.dr, c.hz, d, c.sh, false); if (r.lostT > 3) lost++; if (r.minR < 0.9f) close++; worst = fmaxf(worst, r.lostT); rm.push_back(r.rms); }
      std::sort(rm.begin(), rm.end());
      printf("%-22s %-20s %2d / 12    %-10.2f %-9d %.1fs\n", names[s], c.n, lost, rm[6], close, worst);
    }
  }
}
