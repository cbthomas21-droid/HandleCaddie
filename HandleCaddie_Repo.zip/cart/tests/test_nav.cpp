#include <stdio.h>
#include <vector>
#include <algorithm>
#include "../cart_proto.h"
using namespace cart;
static int fails = 0, total = 0;
#define CHECK(c) do { total++; if (!(c)) { fails++; printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)

static uint32_t seed = 777;
static float rnd01() { seed = seed * 1664525u + 1013904223u; return ((seed >> 8) & 0xFFFF) / 65535.0f; }
static float rndSym(float a) { return (rnd01() * 2 - 1) * a; }

struct P2 { float x, y; };
static bool stage(NavController& n, const std::vector<P2>& pts, float v) {
  n.stageClear();
  for (size_t i = 0; i < pts.size(); i++) if (!n.stagePoint((int)i, pts[i].x, pts[i].y)) return false;
  return n.commit((int)pts.size(), v);
}
static float distToRoute(const std::vector<P2>& r, float x, float y) {
  float best = 1e9f;
  for (size_t i = 0; i + 1 < r.size(); i++) {
    float dx = r[i + 1].x - r[i].x, dy = r[i + 1].y - r[i].y, l2 = dx * dx + dy * dy;
    float t = l2 > 1e-9f ? clampv(((x - r[i].x) * dx + (y - r[i].y) * dy) / l2, 0.0f, 1.0f) : 0.0f;
    best = fminf(best, hypotf(x - (r[i].x + t * dx), y - (r[i].y + t * dy)));
  }
  return best;
}

// A cart in the loop: real Supervisor + the NavController inside it, a simple physical cart, and imperfect sensors.
struct World {
  Supervisor sup; float x = 0, y = 0, psi = 0, v = 0, omega = 0;       // truth
  float gyroBias, speedScale, slip, turnSlip, gyroNoise;
  float t = 0;
  explicit World(float bias = 0, float scale = 1, float slipv = 1, float tslip = 1, float noise = 0.0f) : gyroBias(bias), speedScale(scale), slip(slipv), turnSlip(tslip), gyroNoise(noise) {
    sup.cfg().hasSpeedSense = true; sup.cfg().trackWidthM = 0.45f;
  }
  SupOut step(float dt, Mode req, bool paused = false, float obs = -1, bool imuOk = true) {
    SupIn in; in.dt = dt; in.req = req; in.paused = paused; in.obsL = in.obsR = obs; in.imuOk = imuOk;
    in.vMeas = v * speedScale;                                          // hall sensors read the TRUE speed with a scale error
    in.yawRate = omega + gyroBias + rndSym(gyroNoise);                  // gyro reads the true turn rate plus drift and noise
    SupOut o = sup.update(in);
    float vc = 0.5f * (o.vL + o.vR), wc = (o.vR - o.vL) / sup.cfg().trackWidthM;
    v += (vc * slip - v) * clampv(dt / 0.3f, 0.0f, 1.0f);               // the wheels follow with some lag, and slip a little
    omega += (wc * turnSlip - omega) * clampv(dt / 0.2f, 0.0f, 1.0f);
    psi += omega * dt; x += v * cosf(psi) * dt; y += v * sinf(psi) * dt; t += dt;
    return o;
  }
};

static void settle(World& w, float seconds = 40) { for (int i = 0; i < (int)(seconds / 0.04f); i++) w.step(0.04f, Mode::PARK); }

int main() {
  // ---------------------------------------------------------------- the messages
  Msg m;
  CHECK(parseMsg("{\"k\":\"mode\",\"m\":\"nav\"}", m) && m.kind == MsgKind::MODE && m.mode == Mode::NAV);
  CHECK(parseMsg("{\"k\":\"navp\",\"i\":3,\"x\":12.5,\"y\":-4.25}", m) && m.kind == MsgKind::NAVP && m.navI == 3 && m.navX == 12.5f && m.navY == -4.25f);
  CHECK(!parseMsg("{\"k\":\"navp\",\"i\":99,\"x\":1,\"y\":1}", m));
  CHECK(!parseMsg("{\"k\":\"navp\",\"i\":-1,\"x\":1,\"y\":1}", m));
  CHECK(!parseMsg("{\"k\":\"navp\",\"i\":1,\"x\":1}", m));
  CHECK(parseMsg("{\"k\":\"navgo\",\"n\":6,\"v\":0.9}", m) && m.kind == MsgKind::NAVGO && m.navN == 6 && fabsf(m.navV - 0.9f) < 1e-6f);
  CHECK(!parseMsg("{\"k\":\"navgo\",\"n\":1,\"v\":0.9}", m) && !parseMsg("{\"k\":\"navgo\",\"n\":40,\"v\":0.9}", m));
  CHECK(parseMsg("{\"k\":\"navhb\"}", m) && m.kind == MsgKind::NAVHB);
  { TelData t{}; t.yawDeg = -12.5f; t.navOk = true; t.mode = Mode::NAV; t.navShow = true; t.navX = 3.14f; t.navY = -2.0f; t.navHeadDeg = 90; t.navSeg = 2; t.navState = 2;
    char b[400]; int n = formatTel(b, sizeof(b), t);
    CHECK(n > 0 && b[n - 1] == '\n' && strstr(b, "\"nr\":1") && strstr(b, "\"yw\":-12.5") && strstr(b, "\"m\":\"nav\"") && strstr(b, "\"nx\":3.1") && strstr(b, "\"ns\":2") && strstr(b, "}\n"));
    t.navShow = false; n = formatTel(b, sizeof(b), t); CHECK(!strstr(b, "\"nx\"") && b[n - 2] == '}');
    char c[200]; formatCfg(c, sizeof(c), 2.5f, 1.6f, 1.2f, true, "0.3", true); CHECK(strstr(c, "\"nav\":1"));
    formatCfg(c, sizeof(c), 2.5f, 1.6f, 1.2f, true, "0.3"); CHECK(strstr(c, "\"nav\":0")); }

  // ---------------------------------------------------------------- committing a route
  {
    NavController n;
    CHECK(!n.commit(2, 1.0f));                                           // nothing staged
    n.stageClear(); n.stagePoint(0, 0, 0); CHECK(!n.commit(2, 1.0f));    // point 1 missing
    CHECK(!n.stagePoint(24, 0, 0) && !n.stagePoint(0, NAN, 0) && !n.stagePoint(0, 1e6f, 0));
    CHECK(stage(n, {{0, 0}, {10, 0}}, 1.0f) && n.ready() && !n.running());
    CHECK(!stage(n, {{0, 0}, {0.05f, 0}}, 1.0f));                        // a segment shorter than 0.2 m
    CHECK(!stage(n, {{0, 0}, {150, 0}}, 1.0f));                          // one leg longer than 100 m
    { std::vector<P2> big; for (int i = 0; i < 12; i++) big.push_back({i * 30.0f, 0}); CHECK(!stage(n, big, 1.0f)); }   // 330 m total
    CHECK(!stage(n, {{30, 0}, {40, 0}}, 1.0f));                          // does not start where the cart is
    CHECK(n.begin() && n.running() && !n.begin());                       // begin once
    n.cancel(); CHECK(n.state() == NavState::IDLE && !n.begin());
  }

  // ---------------------------------------------------------------- perfect world: straight, L-shape, arc
  {
    std::vector<P2> straight = {{0, 0}, {20, 0}, {40, 0}};
    std::vector<P2> ell = {{0, 0}, {20, 0}, {20, 20}, {20, 40}};
    std::vector<P2> arc; { int N = 9; for (int i = 0; i <= N; i++) { float a = -1.5708f + 3.14159f * i / N; arc.push_back({28 * cosf(a), 28 * sinf(a) + 28}); } }
    std::vector<std::vector<P2>> routes = {straight, ell, arc};
    for (auto& r : routes) {
      World w; settle(w); CHECK(w.sup.navOk()); CHECK(stage(w.sup.nav(), r, 1.0f)); CHECK(w.sup.nav().begin());
      float worst = 0; bool arrived = false; float maxV = 0, minVL = 9;
      for (int i = 0; i < 25 * 400 && !arrived; i++) {
        SupOut o = w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat();
        maxV = fmaxf(maxV, w.v); minVL = fminf(minVL, fminf(o.vL, o.vR));
        worst = fmaxf(worst, distToRoute(r, w.x, w.y));
        arrived = w.sup.nav().state() == NavState::ARRIVED;
      }
      CHECK(arrived && worst < 1.6f && maxV <= 1.01f && minVL >= 0.0f);
      printf("  route: arrived=%d  worst deviation %.2f m  top speed %.2f  time %.0f s\n", arrived, worst, maxV, w.t);
      w.step(0.04f, Mode::NAV); CHECK(w.sup.nav().state() == NavState::ARRIVED);
      for (int i = 0; i < 100; i++) w.step(0.04f, Mode::NAV);
      CHECK(w.v < 0.05f);                                                // and it comes to rest
    }
  }

  // ---------------------------------------------------------------- safety stops
  {
    std::vector<P2> r = {{0, 0}, {30, 0}, {60, 0}};
    auto fresh = [&](World& w) { settle(w); CHECK(stage(w.sup.nav(), r, 1.0f)); CHECK(w.sup.nav().begin()); };
    { World w; fresh(w); bool st = false; for (int i = 0; i < 25 * 10; i++) { w.step(0.04f, Mode::NAV); if (i < 50) w.sup.nav().heartbeat(); }   // heartbeat stops after 2 s
      st = w.sup.nav().state() == NavState::ABORT_LINK; CHECK(st); for (int i = 0; i < 100; i++) w.step(0.04f, Mode::NAV); CHECK(w.v < 0.05f); }
    { World w; fresh(w); for (int i = 0; i < 25 * 30; i++) { w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); if (w.sup.nav().finished()) break; }
      CHECK(w.sup.nav().state() == NavState::IDLE || w.sup.nav().running() || w.sup.nav().finished()); }
    { World w(0.5f /* rad/s of gyro drift: absurd */); settle(w, 60); CHECK(!w.sup.navOk()); }       // a gyro that is far from zero at rest is never trusted
    { World w; fresh(w); w.gyroBias = 0.5f; bool bad = false; for (int i = 0; i < 25 * 60 && !bad; i++) { w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); bad = w.sup.nav().state() == NavState::ABORT_YAW; }
      CHECK(bad); }                                                                                  // one that goes wrong while driving is caught by the wheels disagreeing
    { Supervisor s; s.cfg().hasSpeedSense = true; SupIn in; in.dt = 0.04f; in.req = Mode::NAV; for (int i = 0; i < 100; i++) s.update(in);   // only 4 s at rest so far
      CHECK(!s.navOk()); NavController& n = s.nav(); CHECK(stage(n, r, 1.0f) && n.begin()); SupOut o = s.update(in); CHECK(o.mode == Mode::PARK && o.vL == 0); }
    { World w; fresh(w); w.slip = 0.0f; bool stuck = false; for (int i = 0; i < 25 * 60 && !stuck; i++) { w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); stuck = w.sup.nav().state() == NavState::ABORT_STUCK; }
      CHECK(stuck); }                                                     // wheels turn, cart does not move
    { World w; fresh(w); for (int i = 0; i < 100; i++) { w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); }
      SupOut o = w.step(0.04f, Mode::NAV, true); CHECK(o.mode == Mode::PARK && w.sup.nav().state() == NavState::IDLE); }   // the switch cancels
    { World w; fresh(w); for (int i = 0; i < 100; i++) { w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); }
      SupOut o = w.step(0.04f, Mode::PARK); CHECK(o.mode == Mode::PARK && w.sup.nav().state() == NavState::IDLE); }          // asking for park ends it
    { World w; fresh(w); for (int i = 0; i < 100; i++) { w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); }
      w.step(0.04f, Mode::NAV, false, -1, false); SupOut o = w.step(0.04f, Mode::NAV, false, -1, false);
      CHECK(o.mode == Mode::PARK && (o.faults & F_IMU)); }                // a dead tilt sensor stops it
    { World w; fresh(w); for (int i = 0; i < 100; i++) { w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); }
      float vFree = w.v; for (int i = 0; i < 100; i++) { w.step(0.04f, Mode::NAV, false, 1.0f); w.sup.nav().heartbeat(); }
      CHECK(w.v < vFree * 0.6f);                                          // something close ahead slows the cart
      for (int i = 0; i < 100; i++) { w.step(0.04f, Mode::NAV, false, 0.4f); w.sup.nav().heartbeat(); }
      CHECK(w.v < 0.05f); }                                               // and an obstacle stops it
    { Supervisor s; s.cfg().hasSpeedSense = false; NavController& n = s.nav(); CHECK(stage(n, r, 1.0f) && n.begin());
      SupIn in; in.dt = 0.04f; in.req = Mode::NAV; SupOut o = s.update(in); CHECK(o.mode == Mode::PARK && o.vL == 0 && o.vR == 0); }   // no wheel-speed sensing: no routes
    { Supervisor s; s.cfg().hasSpeedSense = true; SupIn in; in.dt = 0.04f; in.req = Mode::NAV; SupOut o = s.update(in); CHECK(o.mode == Mode::PARK); }   // no route: nothing to drive
  }

  // ---------------------------------------------------------------- swapping the route while driving
  {
    World w; settle(w); std::vector<P2> r1 = {{0, 0}, {40, 0}};
    CHECK(stage(w.sup.nav(), r1, 1.0f) && w.sup.nav().begin());
    for (int i = 0; i < 25 * 8; i++) { w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); }
    float px = w.sup.nav().x(), py = w.sup.nav().y();
    std::vector<P2> r2 = {{px, py}, {px + 10, 12}, {px + 10, 30}};
    CHECK(stage(w.sup.nav(), r2, 1.0f) && w.sup.nav().running());        // swapped without stopping
    CHECK(fabsf(w.sup.nav().x() - px) < 1e-4f);                           // position was kept
    std::vector<P2> far = {{px + 30, py}, {px + 40, py}};
    CHECK(!stage(w.sup.nav(), far, 1.0f) && w.sup.nav().running());      // a route that does not start here is refused; the old one keeps going
  }

  // ---------------------------------------------------------------- gyro drift tracking
  {
    YawBias yb; for (int i = 0; i < 25 * 90; i++) yb.update(0.04f, 0.01f + rndSym(0.002f), true);
    CHECK(fabsf(yb.bias() - 0.01f) < 0.002f);                             // learned the drift while standing still
    YawBias mv; for (int i = 0; i < 25 * 90; i++) mv.update(0.04f, 0.4f, true); CHECK(fabsf(mv.bias()) < 1e-6f);        // someone turning the cart is not drift
    YawBias dr; for (int i = 0; i < 25 * 90; i++) dr.update(0.04f, 0.01f, false); CHECK(fabsf(dr.bias()) < 1e-6f);     // not learned while driving
  }

  // ---------------------------------------------------------------- many imperfect carts on a route like the planner makes
  {
    // 20 m out, a half circle of radius 28 m, 20 m out again: about 128 m
    std::vector<P2> r; r.push_back({0, 0}); r.push_back({20, 0});
    { int N = 10; for (int i = 1; i < N; i++) { float a = -1.5708f + 3.14159f * i / N; r.push_back({20 + 28 * cosf(a), 28 + 28 * sinf(a)}); } }
    r.push_back({20, 56}); r.push_back({0, 56}); r.push_back({-20, 56});
    float len = 0; for (size_t i = 1; i < r.size(); i++) len += hypotf(r[i].x - r[i - 1].x, r[i].y - r[i - 1].y);
    struct Case { const char* name; float bias, scale, slip, tslip, noise, limit; };
    Case cases[] = {
      {"good sensors", 0.002f, 1.02f, 1.00f, 1.00f, 0.01f, 6.5f},
      {"typical     ", 0.004f, 1.03f, 0.97f, 0.95f, 0.02f, 9.5f},
      {"poor        ", 0.009f, 1.06f, 0.92f, 0.88f, 0.03f, 0.0f},
    };
    for (auto& c : cases) {
      int arrived = 0, runs = 120; float worst = 0, sum = 0, worstEnd = 0;
      for (int k = 0; k < runs; k++) {
        World w(rndSym(c.bias), 1 + rndSym(c.scale - 1), 1 - rnd01() * (1 - c.slip), 1 - rnd01() * (1 - c.tslip), c.noise);
        settle(w, 40);
        stage(w.sup.nav(), r, 1.0f); w.sup.nav().begin();
        float dev = 0; bool fin = false;
        for (int i = 0; i < 25 * 300 && !fin; i++) {
          w.step(0.04f, Mode::NAV); w.sup.nav().heartbeat(); dev = fmaxf(dev, distToRoute(r, w.x, w.y));
          fin = w.sup.nav().finished();
        }
        bool ok = w.sup.nav().state() == NavState::ARRIVED;
        arrived += ok; worst = fmaxf(worst, dev); sum += dev;
        if (ok) worstEnd = fmaxf(worstEnd, hypotf(w.x - r.back().x, w.y - r.back().y));
      }
      printf("  %s  route %.0f m: arrived %d/%d, true path off the plan: mean %.2f m, worst %.2f m, worst end error %.1f m\n", c.name, len, arrived, runs, sum / runs, worst, worstEnd);
      CHECK(arrived >= runs * 95 / 100);
      // The phone plans with a safety allowance of 0.07 m per metre of route (see HazardNav.kt). These are the numbers that choice rests on:
      if (c.limit > 0) CHECK(worst < c.limit);                           // "typical" must stay inside 0.07 x 148 m = 10.4 m
      // "poor" (6 % wheel-size error) is printed, not required: calibrate the wheel diameter
    }
  }

  printf("%d checks, %d failed\n", total, fails);
  return fails ? 1 : 0;
}
