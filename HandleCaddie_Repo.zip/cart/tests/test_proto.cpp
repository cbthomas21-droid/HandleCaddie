#include <stdio.h>
#include "../cart_proto.h"
using namespace cart;
static int fails = 0, total = 0;
#define CHECK(c) do { total++; if (!(c)) { fails++; printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static bool near(float a, float b, float e = 1e-3f) { return fabsf(a - b) <= e; }

int main() {
  Msg m;
  CHECK(parseMsg("{\"k\":\"hello\"}", m) && m.kind == MsgKind::HELLO);
  CHECK(parseMsg("{\"k\":\"mode\",\"m\":\"follow\"}", m) && m.mode == Mode::FOLLOW);
  CHECK(parseMsg("{\"k\":\"mode\",\"m\":\"manual\"}", m) && m.mode == Mode::MANUAL);
  CHECK(parseMsg("{\"k\":\"mode\",\"m\":\"park\"}", m) && m.mode == Mode::PARK);
  CHECK(!parseMsg("{\"k\":\"mode\",\"m\":\"turbo\"}", m));              // unknown mode ignored
  CHECK(!parseMsg("{\"k\":\"mode\"}", m));
  CHECK(parseMsg("{\"k\":\"joy\",\"x\":-0.50,\"y\":0.75}", m) && near(m.joyX, -0.5f) && near(m.joyY, 0.75f));
  CHECK(parseMsg("{\"k\":\"joy\",\"x\":5,\"y\":-3}", m) && m.joyX == 1.0f && m.joyY == 0.0f);   // clamped, never reverse
  CHECK(!parseMsg("{\"k\":\"joy\",\"x\":0.1}", m));
  CHECK(parseMsg("{\"k\":\"set\",\"fd\":2.5}", m) && m.hasFd && near(m.fd, 2.5f) && !m.hasVm);
  CHECK(parseMsg("{\"k\":\"set\",\"fd\":99}", m) && near(m.fd, FD_MAX));
  CHECK(parseMsg("{\"k\":\"set\",\"fd\":0.1,\"vm\":9,\"dc\":0}", m) && near(m.fd, FD_MIN) && near(m.vm, VM_MAX) && near(m.dc, DC_MIN));
  CHECK(parseMsg("{\"k\":\"set\",\"hh\":0}", m) && m.hasHh && !m.hh);
  CHECK(!parseMsg("{\"k\":\"set\",\"zz\":1}", m));
  CHECK(parseMsg("{\"k\":\"hold\",\"on\":1}", m) && m.hold);
  CHECK(parseMsg("{\"k\":\"hold\",\"on\":0}", m) && !m.hold);
  CHECK(parseMsg("{\"k\":\"cmd\",\"c\":\"stop\"}", m) && m.cmd == CmdKind::STOP);
  CHECK(parseMsg("{\"k\":\"cmd\",\"c\":\"clear\"}", m) && m.cmd == CmdKind::CLEAR);
  CHECK(parseMsg("{\"k\":\"cmd\",\"c\":\"level\"}", m) && m.cmd == CmdKind::LEVEL);
  CHECK(parseMsg("{\"k\":\"cmd\",\"c\":\"trip0\"}", m) && m.cmd == CmdKind::TRIP0);
  CHECK(!parseMsg("{\"k\":\"cmd\",\"c\":\"selfdestruct\"}", m));
  CHECK(!parseMsg("", m) && !parseMsg("garbage", m) && !parseMsg("{", m) && !parseMsg("{\"k\":", m) && !parseMsg(nullptr, m));
  CHECK(!parseMsg("{\"k\":\"unknown\"}", m));
  CHECK(!parseMsg("{\"k\":\"joy\",\"x\":nan,\"y\":0.5}", m));
  CHECK(parseMsg("{ \"k\" : \"hello\" }", m));                              // whitespace tolerated

  // line buffer
  LineBuffer lb; const char* in = "{\"k\":\"hello\"}\n{\"k\":\"hold\",\"on\":1}\r\n"; int lines = 0; char last[64] = {0};
  for (const char* p = in; *p; p++) if (lb.push(*p)) { lines++; strncpy(last, lb.line(), 63); }
  CHECK(lines == 2 && strstr(last, "hold"));
  LineBuffer lb2; int got = 0; for (int i = 0; i < 400; i++) lb2.push('a'); if (lb2.push('\n')) got++;   // overlong line dropped
  for (const char* p = "{\"k\":\"hello\"}\n"; *p; p++) if (lb2.push(*p)) got += 10;
  CHECK(got == 10);

  // output formats
  char b[300];
  TelData t{Mode::FOLLOW, 20.44f, 78.4f, -3.24f, 1.1f, 1.2f, 2.7f, -8.0f, true, 35, 38, 0, -1.0f, 1234.5f, 98000.0f, 0, 8};
  int n = formatTel(b, sizeof(b), t);
  CHECK(n > 0 && n < 240 && b[n - 1] == '\n');
  CHECK(strstr(b, "\"m\":\"follow\"") && strstr(b, "\"brg\":-8") && strstr(b, "\"fg\":8") && strstr(b, "\"soc\":78"));
  t.bearingOk = false; t.mode = Mode::FREE; n = formatTel(b, sizeof(b), t);
  CHECK(strstr(b, "\"brg\":null") && strstr(b, "\"m\":\"park\""));
  n = formatCfg(b, sizeof(b), 2.5f, 1.6f, 1.2f, true, "0.1"); CHECK(strstr(b, "\"fd\":2.50") && strstr(b, "\"hh\":1") && b[n - 1] == '\n');
  // worst-case telemetry still fits one notification
  TelData w{Mode::MANUAL, 99.9f, 100, -89.9f, -89.9f, 9.99f, 59.99f, -179.0f, true, 100, 100, 100, 9.99f, 99999.9f, 9999999.0f, 15, 511};
  n = formatTel(b, sizeof(b), w); CHECK(n < 240);

  // UWB lines (guessed formats)
  float d;
  CHECK(parseUwbLine("distance:2.35m", &d) && near(d, 2.35f));
  CHECK(parseUwbLine("Distance = 235 cm", &d) && near(d, 2.35f));
  CHECK(parseUwbLine("dist: 2350 mm", &d) && near(d, 2.35f));
  CHECK(parseUwbLine("+RANGE:0,1,2.35", &d) == false || true);               // unknown layout: allowed to refuse, must not crash
  CHECK(parseUwbLine("tag 0 range 3.10", &d) && near(d, 3.10f));
  CHECK(parseUwbLine("dis:450", &d, 0.01f) && near(d, 4.5f));               // no unit -> noScale
  CHECK(!parseUwbLine("hello world", &d));
  CHECK(!parseUwbLine("distance:0.00m", &d) && !parseUwbLine("distance:900m", &d) && !parseUwbLine("distance:-3m", &d));
  CHECK(!parseUwbLine("distance:abc", &d) && !parseUwbLine("", &d));
  CHECK(!parseUwbLine("distance", &d));
  printf("%d checks, %d failed\n", total, fails);
  return fails ? 1 : 0;
}
