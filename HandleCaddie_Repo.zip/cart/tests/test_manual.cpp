#include <stdio.h>
#include "../cart_logic.h"
using namespace cart;
static int fails = 0, total = 0;
#define CHECK(c) do { total++; if (!(c)) { fails++; printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)

static SupOut run(Supervisor& s, SupIn in, float secs) { SupOut o; for (float t = 0; t < secs; t += in.dt) o = s.update(in); return o; }
static SupIn base() { SupIn in; in.dt = 0.02f; return in; }

int main() {
  // ---- MANUAL
  { Supervisor s; SupIn in = base(); in.req = Mode::MANUAL; in.joyX = 0; in.joyY = 1; in.joyAgeS = 0.1f;
    SupOut o = run(s, in, 3.0f);
    CHECK(o.mode == Mode::MANUAL); CHECK(o.vL > 1.1f && o.vL < 1.3f && o.vR > 1.1f && o.vR < 1.3f);          // 1.2 m/s straight
    in.joyX = 1.0f; o = run(s, in, 2.0f); CHECK(o.vL > o.vR);                                                  // steer right: left wheel faster
    CHECK(o.vL <= 3.0f && o.vR >= 0.0f);
    in.joyX = -1.0f; o = run(s, in, 2.0f); CHECK(o.vR > o.vL);
    in.joyX = 0; in.joyAgeS = 0.6f; o = run(s, in, 3.0f); CHECK(o.vL == 0 && o.vR == 0);                       // dead-man: stale joystick stops
    in.joyAgeS = 0.1f; in.joyY = -1; o = run(s, in, 1.0f); CHECK(o.vL == 0 && o.vR == 0);                      // never reverse
  }
  // ---- faults beat the joystick
  { Supervisor s; SupIn in = base(); in.req = Mode::MANUAL; in.joyY = 1; in.joyAgeS = 0.0f;
    run(s, in, 2.0f); in.rollDeg = 40; SupOut o = run(s, in, 1.0f);
    CHECK((o.faults & F_TIP) && o.mode == Mode::PARK && o.vL == 0 && o.vR == 0);
    in.rollDeg = 0; o = run(s, in, 1.0f); CHECK(o.vL == 0);                                                    // latched: joystick can't defeat it
    in.estopPressed = true; in.clearFaults = true; o = run(s, in, 1.0f); CHECK(o.vL == 0 && (o.faults & F_ESTOP)); }
  // ---- obstacle in MANUAL (any echo counts: there is no fob to hide behind)
  { Supervisor s; SupIn in = base(); in.req = Mode::MANUAL; in.joyY = 1; in.joyAgeS = 0.0f; in.obsL = 0.5f;
    SupOut o = run(s, in, 4.0f); CHECK(o.vL < 0.05f && o.vR < 0.05f && (o.flags & FL_OBSTACLE));
    in.obsL = -1; o = run(s, in, 3.0f); CHECK(o.vL > 1.0f); }
  // ---- descent cap still applies in MANUAL
  { Supervisor s; SupIn in = base(); in.req = Mode::MANUAL; in.joyY = 1; in.joyAgeS = 0.0f; in.pitchDeg = -8;
    SupOut o = run(s, in, 4.0f); CHECK(o.vL <= 1.21f && o.vL > 0 && (o.flags & FL_DESCENT));
    Supervisor s2; s2.cfg().descentVMax = 0.9f; o = run(s2, in, 4.0f); CHECK(o.vL <= 0.91f); }

  // ---- FOLLOW + hold / pause
  auto follow = [](Supervisor& s, SupIn& in) { in.req = Mode::FOLLOW; in.rangeValid = true; in.rangeAgeS = 0.1f; in.range = 5.0f; in.bearingOk = true; in.bearing = 0; };
  { Supervisor s; SupIn in = base(); follow(s, in);
    SupOut o = run(s, in, 4.0f); CHECK(o.vL > 0.5f);
    in.autoHold = true; o = run(s, in, 3.0f); CHECK(o.vL == 0 && o.vR == 0 && (o.flags & FL_AUTOHOLD) && o.mode == Mode::FOLLOW);
    in.autoHold = false; o = run(s, in, 3.0f); CHECK(o.vL > 0.5f && !(o.flags & FL_AUTOHOLD));                   // resumes
    in.paused = true; o = run(s, in, 3.0f); CHECK(o.vL == 0 && (o.flags & FL_PAUSED));
    in.paused = false; in.overridden = true; o = run(s, in, 1.0f); CHECK(o.flags & FL_OVERRIDE); }
  { Supervisor s; SupIn in = base(); in.req = Mode::MANUAL; in.joyY = 1; in.joyAgeS = 0; in.paused = true;      // the switch pauses MANUAL too
    SupOut o = run(s, in, 2.0f); CHECK(o.vL == 0 && (o.flags & FL_PAUSED));
    in.paused = false; in.autoHold = true; o = run(s, in, 3.0f); CHECK(o.vL > 1.0f); }                          // phone's hold is for FOLLOW only
  { Supervisor s; SupIn in = base(); in.req = Mode::PARK; in.autoHold = true; in.paused = true;
    SupOut o = run(s, in, 1.0f); CHECK(!(o.flags & (FL_AUTOHOLD | FL_PAUSED))); }                                // flags only describe what is happening
  // ---- slope hold while auto-held (cart stays put on a hill)
  { Supervisor s; s.cfg().hasBrake = true; SupIn in = base(); follow(s, in); in.pitchDeg = 6; in.autoHold = true;
    SupOut o = run(s, in, 3.0f); CHECK(o.brake > 0.9f); }

  // ---- HoldLogic: the switch
  { HoldLogic h; h.begin(false);
    CHECK(!h.paused() && !h.autoHold());
    h.onSwitch(true);  CHECK(h.paused());                       // press = pause
    h.onSwitch(false); CHECK(!h.paused());                      // press again = resume
    h.onHold(true);    CHECK(h.autoHold() && !h.paused());
    h.onSwitch(true);  CHECK(!h.autoHold() && h.overridden() && !h.paused());   // override: go anyway, NOT paused
    h.onHold(true);    CHECK(!h.autoHold());                    // phone's repeat hold:1 is ignored until it sees the override
    h.onSwitch(false); CHECK(h.paused());                       // the next press pauses (new "run" position is the latched one)
    h.onHold(false);   CHECK(!h.overridden() && h.paused());
    h.onSwitch(true);  CHECK(!h.paused());
    h.onHold(true);    CHECK(h.autoHold());                     // the guard can arm again
    h.onHold(false);   CHECK(!h.autoHold());
    h.onHold(true); h.onConnect(); CHECK(!h.autoHold() && !h.overridden()); }
  { HoldLogic h; h.begin(true); CHECK(!h.paused());             // booting with the switch already latched is "run"
    h.onSwitch(false); CHECK(h.paused()); }
  { HoldLogic h; h.begin(false); h.onHold(true); h.onSwitch(false); CHECK(h.autoHold()); }   // no change = no override

  printf("%d checks, %d failed\n", total, fails);
  return fails ? 1 : 0;
}
