#include "../cart_logic.h"
#include <cstdio>
using namespace cart;
static int fails = 0, total = 0;
#define CHECK(c, msg) do { total++; if (c) printf("ok:   %s\n", msg); else { printf("FAIL: %s\n", msg); fails++; } } while (0)

static SupIn follow(float r = 3.0f) { SupIn i; i.req = Mode::FOLLOW; i.rangeValid = true; i.rangeAgeS = 0.1f; i.range = r; i.bearingOk = true; return i; }
static SupOut run(Supervisor& s, SupIn in, float secs) { SupOut o; for (float t = 0; t < secs; t += in.dt) o = s.update(in); return o; }

int main() {
  { // tilt latch
    Supervisor s; SupIn in = follow(5); run(s, in, 3);
    in.rollDeg = 30; SupOut o = run(s, in, 0.5f);
    CHECK(o.faults & F_TIP, "30 deg roll latches TIP fault");
    CHECK(o.vL < 0.05f && o.vR < 0.05f && o.mode == Mode::PARK, "TIP fault stops the motors and forces PARK");
    in.rollDeg = 0; o = run(s, in, 1);
    CHECK(o.faults & F_TIP, "fault stays latched after the cart is upright");
    in.clearFaults = true; o = run(s, in, 0.1f); in.clearFaults = false; o = run(s, in, 0.5f);
    CHECK(!(o.faults & F_TIP), "fault clears only on request while upright");
    Supervisor s2; SupIn t = follow(5); t.rollDeg = 30; run(s2, t, 0.5f); t.clearFaults = true; SupOut o2 = run(s2, t, 0.5f);
    CHECK(o2.faults & F_TIP, "cannot clear the fault while still tipped");
  }
  { // brief bump must not trip
    Supervisor s; SupIn in = follow(5); run(s, in, 1); in.rollDeg = 30; run(s, in, 0.08f); in.rollDeg = 0; SupOut o = run(s, in, 0.5f);
    CHECK(!(o.faults & F_TIP), "an 80 ms bump does not trip the tip fault");
  }
  { // IMU failure
    Supervisor s; SupIn in = follow(5); in.imuOk = false; SupOut o = run(s, in, 0.2f);
    CHECK((o.faults & F_IMU) && o.mode == Mode::PARK, "IMU failure forces PARK");
  }
  { // lost UWB
    Supervisor s; SupIn in = follow(6); SupOut o = run(s, in, 4);
    CHECK(o.vL > 0.5f, "cart drives when you are 6 m away");
    in.rangeAgeS = 3.0f; o = run(s, in, 2);
    CHECK(o.vL < 0.02f && (o.flags & FL_UWB_LOST), "stops when the UWB signal is lost for >2 s");
  }
  { // too far
    Supervisor s; SupIn in = follow(12.5f); SupOut o = run(s, in, 3);
    CHECK(o.vL < 0.02f && (o.flags & FL_TOO_FAR), "stops when you are beyond the max range");
  }
  { // two-anchor tracker: geometry
    const float d = 0.8f; auto feed = [&](TwoAnchorTracker& k, float px, float py, int n) {      // person at (px,py); cart at origin facing +x; left anchor y=+d/2
      for (int i = 0; i < n; i++) { float tt = 0.2f * (i + 1); k.pushLeft(tt, hypotf(px, py - d / 2)); k.pushRight(tt, hypotf(px, py + d / 2)); k.predict(0.2f, 0); k.update(tt); } };
    TwoAnchorTracker a(d); feed(a, 3.0f, 1.0f, 30);
    CHECK(a.bearingOk() && fabsf(a.bearing() * RAD2DEG - 18.4f) < 1.5f, "person 1 m to the LEFT at 3 m reads about +18 degrees");
    CHECK(fabsf(a.range() - 3.16f) < 0.1f, "range is the distance to the middle of the cart");
    TwoAnchorTracker b(d); feed(b, 3.0f, -1.0f, 30);
    CHECK(b.bearing() * RAD2DEG < -16.0f, "person to the RIGHT reads negative");
    TwoAnchorTracker c(d); feed(c, 4.0f, 0.0f, 30);
    CHECK(fabsf(c.bearing()) < 0.02f, "person straight ahead reads zero");
    // gyro prediction: cart turns left 20 degrees -> person appears 20 degrees further right
    TwoAnchorTracker g(d); feed(g, 4.0f, 0.0f, 30); float before = g.bearing(); g.predict(1.0f, 20.0f * DEG2RAD);
    CHECK(fabsf((g.bearing() - before) * RAD2DEG + 20.0f) < 0.1f, "turning the cart left 20 degrees shifts the bearing right by 20 degrees");
    // impossible geometry: the two distances differ by more than the baseline -> no bearing
    TwoAnchorTracker h(d); for (int i = 0; i < 20; i++) { float tt = 0.2f * (i + 1); h.pushLeft(tt, 3.0f); h.pushRight(tt, 4.5f); h.update(tt); }
    CHECK(!h.bearingOk() && h.rangeOk(), "distances that cannot be geometrically true give distance only, no bearing");
    // one anchor lost
    TwoAnchorTracker k(d); feed(k, 3.0f, 1.0f, 30); float tt = 6.0f; for (int i = 0; i < 20; i++) { tt += 0.2f; k.pushLeft(tt, 3.1f); k.update(tt); }
    CHECK(k.rangeOk() && !k.bearingOk(), "with one anchor lost the distance survives and the bearing is dropped");
    // all lost
    TwoAnchorTracker m(d); feed(m, 3.0f, 0.0f, 10); m.update(10.0f);
    CHECK(!m.rangeOk(), "no recent data from either anchor means no distance");
    Supervisor s; SupIn in = follow(7.0f); in.bearingOk = false; SupOut o = run(s, in, 10);
    CHECK(0.5f * (o.vL + o.vR) <= 0.81f && o.vL > 0.3f, "without a bearing the cart creeps straight at the reduced speed limit");
    Supervisor s2; SupIn in2 = follow(5.0f); in2.bearing = 30.0f * DEG2RAD; run(s2, in2, 4); SupOut o2 = run(s2, in2, 0.1f);
    CHECK(o2.vR > o2.vL + 0.1f, "person on the left: the right wheel runs faster so the cart turns left");
    Supervisor s3; SupIn in3 = follow(5.0f); in3.bearing = -30.0f * DEG2RAD; run(s3, in3, 4); SupOut o3 = run(s3, in3, 0.1f);
    CHECK(o3.vL > o3.vR + 0.1f, "person on the right: the left wheel runs faster so the cart turns right");
  }
  { // never reverses / never exceeds vMax
    Supervisor s; SupIn in = follow(7.5f); SupOut o = run(s, in, 10);
    CHECK(o.vL >= 0 && o.vR >= 0 && o.vL <= 3.0f && 0.5f * (o.vL + o.vR) <= 1.61f, "wheel commands stay within 0..vMax");
    in = follow(1.0f); o = run(s, in, 5);
    CHECK(o.vL < 0.02f && o.vR < 0.02f, "stops when you are closer than the target distance");
  }
  { // obstacle in front vs the person
    Supervisor s; SupIn in = follow(4.0f); in.obsL = 3.9f;   // echo at your distance = you
    SupOut o = run(s, in, 5);
    CHECK(o.vL > 0.3f && !(o.flags & FL_OBSTACLE), "an echo at your distance is you, not an obstacle");
    in.obsL = 1.0f; o = run(s, in, 3);
    CHECK(o.vL > 0.1f && o.vL < 0.7f, "an echo 1.0 m ahead (nearer than you) slows the cart to roughly a third");
    in.obsL = 0.5f; o = run(s, in, 3);
    CHECK(o.vL < 0.02f && (o.flags & FL_OBSTACLE), "an echo at 0.5 m stops the cart");
  }
  { // hill hold in PARK, FREE releases
    SupCfg c; c.hasBrake = true; Supervisor s(c); SupIn in; in.req = Mode::PARK; in.pitchDeg = 8; SupOut o = run(s, in, 2);
    CHECK(o.brake > 0.95f && (o.flags & FL_HOLD), "PARK on an 8 degree slope holds the brake");
    in.req = Mode::FREE; o = run(s, in, 2);
    CHECK(o.brake < 0.01f, "FREE mode releases the brake");
    in.req = Mode::PARK; in.pitchDeg = 1; o = run(s, in, 2);
    CHECK(o.brake < 0.01f, "no brake on flat ground");
  }
  { // downhill descent control
    SupCfg c; c.hasBrake = true; c.hasSpeedSense = true; Supervisor s(c);
    SupIn in = follow(7.0f); in.pitchDeg = -8; in.vMeas = 0.8f; run(s, in, 6);
    SupOut o = run(s, in, 0.1f);
    CHECK(0.5f * (o.vL + o.vR) <= 1.21f && (o.flags & FL_DESCENT), "downhill caps speed at the descent limit");
    in.vMeas = 2.2f; o = run(s, in, 1);
    CHECK(o.brake > 0.3f && o.brake <= 0.71f, "over-speed downhill applies partial braking (<= brakeMax)");
    in.vMeas = 0.9f; o = run(s, in, 2);
    CHECK(o.brake < 0.05f, "brake releases when the speed is back under control");
  }
  { // low battery
    BatteryGauge b(5); for (int i = 0; i < 500; i++) b.update(0.1f, 21.0f, false);
    CHECK(b.percent() > 95, "5S at 21.0 V reads ~full");
    BatteryGauge b2(5); for (int i = 0; i < 500; i++) b2.update(0.1f, 18.5f, false);
    CHECK(b2.percent() > 25 && b2.percent() < 36, "5S at 18.5 V (3.7 V/cell) reads ~30%");
    BatteryGauge b3(5); for (int i = 0; i < 300; i++) b3.update(0.1f, 16.0f, false);
    CHECK(b3.low(), "low-battery flag after sustained 16.0 V");
    BatteryGauge b4(5); for (int i = 0; i < 50; i++) b4.update(0.1f, 16.0f, true); b4.update(0.1f, 20.5f, true);
    CHECK(!b4.low(), "a brief load sag does not trip low-battery");
    Supervisor s; SupIn in = follow(5); in.batteryLow = true; SupOut o = run(s, in, 1);
    CHECK((o.faults & F_LOWBATT) && o.vL < 0.02f, "low battery stops the cart");
  }
  { // attitude
    Attitude a; for (int i = 0; i < 400; i++) a.update(0.01f, 0.1736f, 0, 0.9848f, 0, 0, 0);
    CHECK(fabsf(a.pitchDeg() - 10.0f) < 0.6f, "10 deg nose-up reads +10 pitch");
    Attitude b; for (int i = 0; i < 400; i++) b.update(0.01f, 0, 0.2588f, 0.9659f, 0, 0, 0);
    CHECK(fabsf(b.rollDeg() - 15.0f) < 0.6f, "15 deg left-side-up reads +15 roll");
    Attitude c; for (int i = 0; i < 300; i++) c.update(0.01f, 0, 0, 1.0f, 0, 0, 0);
    for (int i = 1; i <= 100; i++) {                                   // physically consistent: tip nose-down 10 deg/s for 1 s
      float th = -0.17453f * 0.01f * i;                                // true pitch (rad)
      c.update(0.01f, sinf(th), 0, cosf(th), 0, +0.17453f, 0);         // gravity follows the tilt; gyro +y = nose-down
    }
    CHECK(fabsf(c.pitchDeg() + 10.0f) < 1.0f, "tilting nose-down 10 deg (gyro + accel agree) reads about -10 pitch");
    Attitude d; for (int i = 0; i < 300; i++) d.update(0.01f, 0, 0, 1.0f, 0, 0, 0);
    for (int i = 0; i < 20; i++) d.update(0.01f, 1.5f, 0, 0.3f, 0, 0, 0);   // hard bump: accel magnitude is not 1 g
    CHECK(fabsf(d.pitchDeg()) < 1.0f, "a hard bump (accel not ~1 g) is ignored by the tilt estimate");
  }
  { // range filter spike rejection
    RangeFilter f; float t = 0; for (int i = 0; i < 20; i++) { t += 0.2f; f.push(t, 3.0f); }
    t += 0.2f; f.push(t, 6.1f); t += 0.2f; f.push(t, 3.0f);
    CHECK(fabsf(f.range() - 3.0f) < 0.3f, "a single +3 m body-blocking spike is rejected");
    RangeFilter g; t = 0; for (int i = 0; i < 20; i++) { t += 0.2f; g.push(t, 3.0f + 0.5f * t); }
    CHECK(fabsf(g.rate() - 0.5f) < 0.1f, "range rate measures a 0.5 m/s walk-away");
  }
  printf("\n%d checks, %d failed\n", total, fails);
  return fails ? 1 : 0;
}
