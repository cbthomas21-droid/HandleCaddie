#include <stdio.h>
#include "../cart_auth.h"
using namespace cart;
static int fails = 0, total = 0;
#define CHECK(c) do { total++; if (!(c)) { fails++; printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)

// a repeatable "random" source so the tests are deterministic
static uint32_t seed = 12345;
static uint32_t rnd() { seed = seed * 1664525u + 1013904223u; return seed ^ (seed >> 15); }

static void hexOf(const uint8_t* d, size_t n, char* o) { toHex(d, n, o); }

// ------- helpers that play the phone
struct Phone {
  uint8_t key[16]; bool has = false;
  // answer a challenge line from the cart
  static bool nonceOf(const char* chalLine, char* nonce, size_t cap) { return getStr(chalLine, "n", nonce, cap); }
  void authLine(const char* nonce, char* out, size_t cap) const {
    char tag[Auth::TAG_HEX + 1]; Auth::tagFor(key, nonce, tag);
    snprintf(out, cap, "{\"k\":\"auth\",\"h\":\"%s\"}", tag);
  }
};

int main() {
  // ---------------------------------------------------------------- crypto against published vectors
  uint8_t d[32]; char hx[80];
  sha256((const uint8_t*)"abc", 3, d); hexOf(d, 32, hx);
  CHECK(!strcmp(hx, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"));
  { uint8_t a[1000]; memset(a, 'a', sizeof(a)); sha256(a, sizeof(a), d); hexOf(d, 32, hx);
    CHECK(!strcmp(hx, "41edece42d63e8d9bf515a9ba6932e1c20cbc9f5a5d134645adb5db1b9737ea3")); }          // crosses block edges
  { uint8_t k[20]; memset(k, 0x0b, 20); hmacSha256(k, 20, (const uint8_t*)"Hi There", 8, d); hexOf(d, 32, hx);
    CHECK(!strcmp(hx, "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7")); }          // RFC 4231 case 1
  { hmacSha256((const uint8_t*)"Jefe", 4, (const uint8_t*)"what do ya want for nothing?", 28, d); hexOf(d, 32, hx);
    CHECK(!strcmp(hx, "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843")); }          // case 2
  { uint8_t k[131]; memset(k, 0xaa, 131); const char* m = "Test Using Larger Than Block-Size Key - Hash Key First";
    hmacSha256(k, 131, (const uint8_t*)m, strlen(m), d); hexOf(d, 32, hx);
    CHECK(!strcmp(hx, "60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54")); }          // case 6: key longer than a block
  // the SAME fixture the phone's tests use (tools/CoreSelfTest.kt), so both sides agree
  { uint8_t key[16]; for (int i = 0; i < 16; i++) key[i] = (uint8_t)i; char tag[Auth::TAG_HEX + 1]; Auth::tagFor(key, "0123456789abcdef", tag);
    CHECK(!strcmp(tag, "30019ba06197c0ed181d45d34500c0b6")); }
  { uint8_t b[4]; CHECK(fromHex("00ff10Ab", b, 4) && b[0] == 0 && b[1] == 255 && b[2] == 16 && b[3] == 0xab); CHECK(!fromHex("0g", b, 1)); }
  CHECK(ctEqual("abcd", "abcd", 4) && !ctEqual("abcd", "abce", 4));

  char reply[400], chal[200], nonce[24], line[200];

  // ---------------------------------------------------------------- first boot: no key -> pairing opens by itself
  {
    Auth a(rnd); a.begin(nullptr, 1000);
    CHECK(!a.hasKey() && a.pairingOpen(1000) && strlen(a.pin()) == 6);
    CHECK(a.pairingOpen(1000 + 299000) && !a.pairingOpen(1000 + 300001));                                // 5 minute window
    a.onConnect(1000, chal, sizeof(chal));
    CHECK(strstr(chal, "\"paired\":0") && strstr(chal, "\"pairing\":1") && strstr(chal, "\"k\":\"chal\""));
    // everything else is not for us and not allowed until authed
    Auth::Result r = a.handle("{\"k\":\"mode\",\"m\":\"follow\"}", 1100, reply, sizeof(reply));
    CHECK(!r.consumed && !a.authed());
    // wrong PIN
    char pin[8]; strcpy(pin, a.pin()); pin[0] = (pin[0] == '9') ? '8' : pin[0] + 1;
    snprintf(line, sizeof(line), "{\"k\":\"pair\",\"pin\":\"%s\"}", pin);
    r = a.handle(line, 1200, reply, sizeof(reply));
    CHECK(r.consumed && r.ev == Auth::Event::NONE && strstr(reply, "\"ok\":0") && strstr(reply, "\"left\":4") && !a.authed());
    // right PIN
    snprintf(line, sizeof(line), "{\"k\":\"pair\",\"pin\":\"%s\"}", a.pin());
    r = a.handle(line, 1300, reply, sizeof(reply));
    CHECK(r.consumed && r.ev == Auth::Event::PAIRED && a.authed() && a.hasKey() && strstr(reply, "\"ok\":1"));
    CHECK(!a.pairingOpen(1300) && a.pin()[0] == 0);                                                        // window closes, PIN forgotten
    char keyHex[40]; CHECK(getStr(reply, "key", keyHex, sizeof(keyHex)) && strlen(keyHex) == 32);
    uint8_t stored[16]; bool erase = true; CHECK(a.takeKeyChange(stored, &erase) && !erase);
    char sh[40]; toHex(stored, 16, sh); CHECK(!strcmp(sh, keyHex));                                          // what was stored is what the phone got
    CHECK(!a.takeKeyChange(stored, &erase));                                                              // only once
    // the phone's key now works on a later connection
    a.onDisconnect(); CHECK(!a.authed());
    a.onConnect(5000, chal, sizeof(chal)); CHECK(strstr(chal, "\"paired\":1") && strstr(chal, "\"pairing\":0"));
    Phone p; memcpy(p.key, stored, 16);
    CHECK(Phone::nonceOf(chal, nonce, sizeof(nonce)) && strlen(nonce) == 16);
    p.authLine(nonce, line, sizeof(line));
    r = a.handle(line, 5100, reply, sizeof(reply));
    CHECK(r.consumed && r.ev == Auth::Event::AUTHED && a.authed() && strstr(reply, "\"ok\":1"));
    // once authed, other lines are passed through to the caller
    r = a.handle("{\"k\":\"mode\",\"m\":\"follow\"}", 5200, reply, sizeof(reply)); CHECK(!r.consumed && a.authed());
  }

  // ---------------------------------------------------------------- a cart that already has a key
  uint8_t key[16]; for (int i = 0; i < 16; i++) key[i] = (uint8_t)(0xA0 + i);
  {
    Auth a(rnd); a.begin(key, 0);
    CHECK(a.hasKey() && !a.pairingOpen(0) && !a.pairingOpen(1000000));                                    // no window unless asked
    a.onConnect(0, chal, sizeof(chal)); Phone p; memcpy(p.key, key, 16);
    // a phone that never paired cannot pair while the window is closed
    Auth::Result r = a.handle("{\"k\":\"pair\",\"pin\":\"123456\"}", 10, reply, sizeof(reply));
    CHECK(r.consumed && strstr(reply, "\"closed\":1") && !a.authed());
    // wrong key
    Phone bad; for (int i = 0; i < 16; i++) bad.key[i] = (uint8_t)i;
    Phone::nonceOf(chal, nonce, sizeof(nonce)); bad.authLine(nonce, line, sizeof(line));
    r = a.handle(line, 20, reply, sizeof(reply));
    CHECK(r.consumed && r.ev == Auth::Event::NONE && !a.authed() && strstr(reply, "\"ok\":0") && strstr(reply, "\"left\":4") && strstr(reply, "\"k\":\"chal\""));
    // a NEW challenge came with the refusal; the old one is dead: replaying the right answer to the OLD nonce fails
    char oldNonce[24]; strcpy(oldNonce, nonce);
    char newChal[200]; const char* second = strstr(reply, "{\"k\":\"chal\""); CHECK(second != nullptr);
    strcpy(newChal, second); char nn[24]; Phone::nonceOf(newChal, nn, sizeof(nn)); CHECK(strcmp(nn, oldNonce) != 0);
    p.authLine(oldNonce, line, sizeof(line));
    r = a.handle(line, 30, reply, sizeof(reply)); CHECK(!a.authed() && r.ev == Auth::Event::NONE);
    // answering the fresh challenge correctly works
    Phone::nonceOf(strstr(reply, "{\"k\":\"chal\""), nn, sizeof(nn));
    p.authLine(nn, line, sizeof(line));
    r = a.handle(line, 40, reply, sizeof(reply)); CHECK(r.ev == Auth::Event::AUTHED && a.authed());
  }
  {   // replay: record one good answer, use it on the next connection -> refused (different challenge)
    Auth a(rnd); a.begin(key, 0); Phone p; memcpy(p.key, key, 16);
    a.onConnect(0, chal, sizeof(chal)); Phone::nonceOf(chal, nonce, sizeof(nonce)); p.authLine(nonce, line, sizeof(line));
    char recorded[200]; strcpy(recorded, line);
    CHECK(a.handle(recorded, 10, reply, sizeof(reply)).ev == Auth::Event::AUTHED);
    a.onDisconnect(); a.onConnect(1000, chal, sizeof(chal));
    Auth::Result r = a.handle(recorded, 1010, reply, sizeof(reply));
    CHECK(r.ev == Auth::Event::NONE && !a.authed());
  }
  {   // brute force: five wrong answers -> locked out for a minute, even the right key is refused meanwhile
    Auth a(rnd); a.begin(key, 0); Phone p; memcpy(p.key, key, 16);
    a.onConnect(0, chal, sizeof(chal)); Phone bad; memset(bad.key, 0x55, 16);
    const char* c = chal; char cc[200]; strcpy(cc, chal); (void)c;
    for (int i = 0; i < 5; i++) {
      Phone::nonceOf(cc, nonce, sizeof(nonce)); bad.authLine(nonce, line, sizeof(line));
      a.handle(line, 100 + i, reply, sizeof(reply));
      const char* nx = strstr(reply, "{\"k\":\"chal\""); if (nx) strcpy(cc, nx);
    }
    CHECK(strstr(reply, "\"wait\":60") != nullptr && !a.authed());
    Phone::nonceOf(cc, nonce, sizeof(nonce)); p.authLine(nonce, line, sizeof(line));
    Auth::Result r = a.handle(line, 5000, reply, sizeof(reply));
    CHECK(r.ev == Auth::Event::NONE && !a.authed() && strstr(reply, "\"wait\""));
    // after the minute a fresh connection works again
    a.onDisconnect(); a.onConnect(61000, chal, sizeof(chal)); Phone::nonceOf(chal, nonce, sizeof(nonce)); p.authLine(nonce, line, sizeof(line));
    r = a.handle(line, 61100, reply, sizeof(reply)); CHECK(r.ev == Auth::Event::AUTHED && a.authed());
  }
  {   // malformed / hostile input never authenticates and never crashes
    Auth a(rnd); a.begin(key, 0); a.onConnect(0, chal, sizeof(chal));
    const char* junk[] = {"", "{", "{\"k\":\"auth\"}", "{\"k\":\"auth\",\"h\":\"\"}", "{\"k\":\"auth\",\"h\":\"zz\"}",
                          "{\"k\":\"auth\",\"h\":\"00000000000000000000000000000000\"}", "{\"k\":\"auth\",\"h\":\"30019ba06197c0ed181d45d34500c0b6ffffffff\"}",
                          "{\"k\":\"pair\"}", "{\"k\":\"pair\",\"pin\":\"\"}", "not json", "{\"k\":\"mode\",\"m\":\"follow\"}"};
    for (const char* j : junk) { a.handle(j, 50, reply, sizeof(reply)); CHECK(!a.authed()); }
    CHECK(a.handle(nullptr, 50, reply, sizeof(reply)).consumed == false);
  }
  {   // hello before auth just gets the challenge back (that is how the app asks for it)
    Auth a(rnd); a.begin(key, 0); a.onConnect(0, chal, sizeof(chal));
    Auth::Result r = a.handle("{\"k\":\"hello\"}", 10, reply, sizeof(reply));
    CHECK(r.consumed && strstr(reply, "\"k\":\"chal\"") && !a.authed());
    char n1[24], n2[24]; Phone::nonceOf(chal, n1, sizeof(n1)); Phone::nonceOf(reply, n2, sizeof(n2));
    CHECK(!strcmp(n1, n2));                                                                               // same unused challenge, not a flood of new ones
  }
  {   // the pairing window: gesture opens it, it times out, wrong PINs close it, and re-pairing replaces the key
    Auth a(rnd); a.begin(key, 0);
    a.openPairing(1000); char pin1[8]; strcpy(pin1, a.pin());
    CHECK(a.pairingOpen(1000 + 119000) && !a.pairingOpen(1000 + 120001) && a.pairingLeftS(1000 + 100000) == 20);
    a.onConnect(1000, chal, sizeof(chal));
    for (int i = 0; i < 5; i++) { snprintf(line, sizeof(line), "{\"k\":\"pair\",\"pin\":\"%s\"}", "000000x"); a.handle(line, 2000 + i, reply, sizeof(reply)); }
    CHECK(!a.pairingOpen(2100) && strstr(reply, "\"closed\":1"));                                         // five wrong tries close the window
    a.openPairing(3000);
    snprintf(line, sizeof(line), "{\"k\":\"pair\",\"pin\":\"%s\"}", a.pin());
    Auth::Result r = a.handle(line, 3100, reply, sizeof(reply));
    uint8_t nk[16]; bool er; CHECK(r.ev == Auth::Event::PAIRED && a.takeKeyChange(nk, &er) && memcmp(nk, key, 16) != 0);   // a new key replaced the old one
    // and the old key no longer works
    a.onDisconnect(); a.onConnect(4000, chal, sizeof(chal)); Phone old; memcpy(old.key, key, 16);
    Phone::nonceOf(chal, nonce, sizeof(nonce)); old.authLine(nonce, line, sizeof(line));
    CHECK(a.handle(line, 4100, reply, sizeof(reply)).ev == Auth::Event::NONE && !a.authed());
  }
  {   // serial-console recovery: forget() erases the key and opens the window
    Auth a(rnd); a.begin(key, 0); a.forget(500);
    uint8_t k2[16]; bool er = false;
    CHECK(!a.hasKey() && a.pairingOpen(500) && a.takeKeyChange(k2, &er) && er);
    a.onConnect(600, chal, sizeof(chal)); CHECK(strstr(chal, "\"paired\":0"));
  }
  {   // PIN is always six digits and varies
    Auth a(rnd); bool allSix = true, varies = false; char first[8] = "";
    for (int i = 0; i < 50; i++) { a.openPairing(0); if (strlen(a.pin()) != 6) allSix = false; for (const char* p = a.pin(); *p; p++) if (*p < '0' || *p > '9') allSix = false;
      if (i == 0) strcpy(first, a.pin()); else if (strcmp(first, a.pin())) varies = true; }
    CHECK(allSix && varies);
  }

  // ---------------------------------------------------------------- the switch gesture
  {
    PairGesture g; bool hit = false;
    for (int i = 0; i < 5; i++) hit |= g.onEdge(1000 + i * 400);
    CHECK(!hit);                                                      // five flips is not enough
    CHECK(g.onEdge(1000 + 5 * 400));                                  // the sixth, 2 s after the first
    CHECK(!g.onEdge(3100));                                           // and it starts again from nothing
    PairGesture slow; hit = false; for (int i = 0; i < 10; i++) hit |= slow.onEdge(i * 2000); CHECK(!hit);   // one flip every 2 s never counts
    PairGesture edge; hit = false; for (int i = 0; i < 6; i++) hit = edge.onEdge(i * 1000); CHECK(hit);      // exactly 5 s from first to last still counts
    PairGesture late; hit = false; for (int i = 0; i < 6; i++) hit = late.onEdge(i * 1001); CHECK(!hit);     // 5.005 s does not
  }

  // ---------------------------------------------------------------- the Bluetooth link's own encryption
  {
    // with encryption required, an unprotected link gets silence: not even a challenge answer
    Auth a(rnd); a.begin(nullptr, 0); a.requireSecureLink(true);
    a.onConnect(10, chal, sizeof(chal));
    Auth::Result r = a.handle("{\"k\":\"hello\"}", 20, reply, sizeof(reply));
    CHECK(r.consumed && reply[0] == 0);
    snprintf(line, sizeof(line), "{\"k\":\"pair\",\"pin\":\"%s\"}", a.pin());
    r = a.handle(line, 30, reply, sizeof(reply));
    CHECK(r.consumed && reply[0] == 0 && r.ev == Auth::Event::NONE && !a.authed() && !a.hasKey());     // even the RIGHT pin does nothing
    CHECK(!a.handle("{\"k\":\"mode\",\"m\":\"follow\"}", 40, reply, sizeof(reply)).consumed == false);

    // the link becomes encrypted but NOT with this PIN (an already-bonded phone): the PIN must still be typed
    a.setLink(true, false); a.onConnect(50, chal, sizeof(chal));
    CHECK(strstr(chal, "\"sec\":1") && strstr(chal, "\"fresh\":0"));
    r = a.handle("{\"k\":\"pair\"}", 60, reply, sizeof(reply));
    CHECK(strstr(reply, "\"ok\":0") && !a.authed());
    r = a.handle(line, 70, reply, sizeof(reply));
    CHECK(r.ev == Auth::Event::PAIRED && a.authed());
  }
  {
    // paired just now with the passkey = PIN: the app need not send the PIN again
    Auth a(rnd); a.begin(nullptr, 0); a.requireSecureLink(true);
    a.setLink(true, true); a.onConnect(10, chal, sizeof(chal));
    CHECK(strstr(chal, "\"sec\":1") && strstr(chal, "\"fresh\":1"));
    Auth::Result r = a.handle("{\"k\":\"pair\"}", 20, reply, sizeof(reply));
    CHECK(r.ev == Auth::Event::PAIRED && a.authed() && strstr(reply, "\"ok\":1") && strstr(reply, "\"key\":\""));
    uint8_t k[16]; bool erase = true; CHECK(a.takeKeyChange(k, &erase) && !erase);
    // a WRONG pin sent anyway is still wrong, fresh or not
    Auth b(rnd); b.begin(nullptr, 0); b.requireSecureLink(true); b.setLink(true, true); b.onConnect(10, chal, sizeof(chal));
    char bad[8]; strcpy(bad, b.pin()); bad[0] = bad[0] == '9' ? '8' : bad[0] + 1;
    snprintf(line, sizeof(line), "{\"k\":\"pair\",\"pin\":\"%s\"}", bad);
    r = b.handle(line, 20, reply, sizeof(reply)); CHECK(r.ev == Auth::Event::NONE && !b.authed());
    // the window closing takes the shortcut away
    Auth c(rnd); c.begin(nullptr, 0); c.requireSecureLink(true); c.setLink(true, true); c.onConnect(10, chal, sizeof(chal));
    r = c.handle("{\"k\":\"pair\"}", Auth::FIRST_WINDOW_MS + 5, reply, sizeof(reply));
    CHECK(r.ev == Auth::Event::NONE && strstr(reply, "\"closed\":1"));
    // a disconnect forgets the link state: the next connection starts unprotected again
    a.onDisconnect(); CHECK(!a.linkSecure());
    a.onConnect(500, chal, sizeof(chal)); CHECK(strstr(chal, "\"sec\":0") && strstr(chal, "\"fresh\":0"));
  }
  {
    // protection off (older setup): behaves exactly as before, and the no-PIN shortcut needs the secure+fresh flags
    Auth a(rnd); a.begin(nullptr, 0); a.onConnect(10, chal, sizeof(chal));
    Auth::Result r = a.handle("{\"k\":\"pair\"}", 20, reply, sizeof(reply));
    CHECK(r.ev == Auth::Event::NONE && !a.authed());
    a.setLink(false, true); CHECK(!a.linkSecure());                            // fresh without secure is ignored
    r = a.handle("{\"k\":\"pair\"}", 30, reply, sizeof(reply)); CHECK(r.ev == Auth::Event::NONE);
  }

  printf("%d checks, %d failed\n", total, fails);
  return fails ? 1 : 0;
}
