// Handle Caddie CART - bring-up tool. Test each part on its own BEFORE running the real controller.
// Board: ESP32 Dev Module (classic ESP32, esp32 core 3.x). Serial Monitor: 115200 baud, "Newline" line ending.
// Libraries: U8g2. Type "help" in the Serial Monitor.
//
// SAFETY: motor boards must have the WHEELS OFF THE GROUND for every test. This sketch never drives more than
// MAX_TEST_PERCENT, and every speed command switches itself off after 5 seconds.
#include <Arduino.h>
#include <Wire.h>
#include <U8g2lib.h>
#include "cart_logic.h"

// ----------------------------------------------------------------------------------------------- pin map
// (strapping pins 0 [used only as the button after boot], 2, 5, 12, 15 and flash pins 6-11 are avoided)
#define PIN_SDA        21      // I2C: MPU6050 (0x68) + OLED (0x3C)
#define PIN_SCL        22
#define PIN_SPEED_L    25      // PWM -> RC filter -> motor board VR (speed) input
#define PIN_SPEED_R    26
#define PIN_BRAKE_L    32      // -> transistor -> board BRAKE input (only if your board has one)
#define PIN_BRAKE_R    33
#define PIN_HALL_L     34      // wheel-speed pulses, THROUGH A DIVIDER (input only pin)
#define PIN_HALL_R     35
#define PIN_VBAT       36      // battery through a divider (ADC1)
#define PIN_ESTOP      39      // e-stop sense (input only pin)
#define PIN_US_TRIG    18      // both HC-SR04 trigger pins tied together
#define PIN_US_ECHO_L  19      // echo THROUGH A DIVIDER (HC-SR04 echo is 5 V)
#define PIN_US_ECHO_R  23
#define PIN_UWB_A_RX   16      // UWB kit A  (Serial2): ESP32 RX <- kit PA2 (TX)
#define PIN_UWB_A_TX   17      //                        ESP32 TX -> kit PA3 (RX)
#define PIN_UWB_B_RX   4       // UWB kit B  (Serial1)
#define PIN_UWB_B_TX   14
#define PIN_BUTTON     0       // the board's own BOOT button
// Motor DIRECTION is not an ESP32 pin: the cart only goes forward, so hard-wire each board's DIR input to GND or 5 V.

// ------------------------------------------------------------------------------------------------- settings
#define SPEED_PWM_HZ        20000
#define SPEED_PWM_BITS      10
#define SPEED_FULLSCALE_V   3.3f   // 3.3 = ESP32 pin straight into the RC filter (max ~66% of the board's range).
                                   // 5.0 = you added a 74AHCT125 buffer powered from 5 V.
#define BOARD_FULLSCALE_V   5.0f   // the motor board's speed input range is 0.1 - 5 V
#define MAX_TEST_PERCENT    30     // bring-up never commands more than this % of the board's range
#define BRAKE_ACTIVE_HIGH   1
#define VBAT_RATIO          7.67f  // divider (R1+R2)/R2, e.g. 120k/18k -> 7.67. Calibrate with: vcal <real volts>
#define OLED_SH1106         0      // set 1 if your OLED is a 1.3" SH1106
#define IMU_ADDR            0x68

#if OLED_SH1106
U8G2_SH1106_128X64_NONAME_F_HW_I2C oled(U8G2_R0, U8X8_PIN_NONE);
#else
U8G2_SSD1306_128X64_NONAME_F_HW_I2C oled(U8G2_R0, U8X8_PIN_NONE);
#endif

// ----------------------------------------------------------------------------------------------- state
enum Mode { M_IDLE, M_IMU, M_US, M_SNIFF } mode = M_IDLE;
cart::Attitude att;
float gyroBias[3] = {0, 0, 0};
float vbatCal = 1.0f;
uint32_t lastSpeedCmdMs = 0, lastPrintMs = 0, lastImuUs = 0;
HardwareSerial* sniff = nullptr; char sniffName = 'A';
String sniffLine;
volatile uint32_t echoRise[2], echoWidth[2]; volatile bool echoDone[2];
volatile uint32_t hallCount[2];

// ----------------------------------------------------------------------------------------------- helpers
static void speedPercent(int side, float pct) {                 // side 0 = left, 1 = right
  pct = constrain(pct, 0.0f, (float)MAX_TEST_PERCENT);
  float vout = BOARD_FULLSCALE_V * pct / 100.0f;
  float duty = vout / SPEED_FULLSCALE_V;
  if (duty > 1.0f) { Serial.println("  needs the 5 V buffer (SPEED_FULLSCALE_V = 5.0)"); duty = 0; vout = 0; }
  ledcWrite(side ? PIN_SPEED_R : PIN_SPEED_L, (uint32_t)(duty * ((1 << SPEED_PWM_BITS) - 1)));
  Serial.printf("  %s speed: %.0f%% of range -> expect %.2f V on the filter output\n", side ? "RIGHT" : "LEFT", pct, vout);
  lastSpeedCmdMs = millis();
}
static void allOff() {
  ledcWrite(PIN_SPEED_L, 0); ledcWrite(PIN_SPEED_R, 0);
  digitalWrite(PIN_BRAKE_L, !BRAKE_ACTIVE_HIGH); digitalWrite(PIN_BRAKE_R, !BRAKE_ACTIVE_HIGH);
}
static void i2cScan() {
  Serial.println("I2C scan (expect 0x3C OLED and 0x68 MPU6050):");
  int n = 0;
  for (uint8_t a = 1; a < 127; a++) { Wire.beginTransmission(a); if (Wire.endTransmission() == 0) { Serial.printf("  found 0x%02X\n", a); n++; } }
  if (!n) Serial.println("  nothing found - check SDA/SCL wiring and power");
}
static bool imuRead(float* ax, float* ay, float* az, float* gx, float* gy, float* gz) {
  Wire.beginTransmission(IMU_ADDR); Wire.write(0x3B); if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)IMU_ADDR, 14) != 14) return false;
  int16_t v[7]; for (int i = 0; i < 7; i++) { uint8_t h = Wire.read(), l = Wire.read(); v[i] = (int16_t)((h << 8) | l); }
  // Mount the GY-521 flat with its X arrow pointing to the FRONT of the cart: X forward, Y left, Z up (identity mapping).
  // If your orientation differs, change the signs / swap axes here and re-check with the 'm' test.
  *ax = v[0] / 16384.0f; *ay = v[1] / 16384.0f; *az = v[2] / 16384.0f;
  *gx = v[4] / 131.0f * cart::DEG2RAD; *gy = v[5] / 131.0f * cart::DEG2RAD; *gz = v[6] / 131.0f * cart::DEG2RAD;
  return true;
}
static bool imuStart() {
  Wire.beginTransmission(IMU_ADDR); Wire.write(0x6B); Wire.write(0x00); if (Wire.endTransmission() != 0) return false;   // wake
  delay(100);
  Serial.println("Calibrating gyro: keep the cart STILL for 2 seconds...");
  double s[3] = {0, 0, 0}; int n = 0;
  for (int i = 0; i < 200; i++) { float a, b, c, x, y, z; if (imuRead(&a, &b, &c, &x, &y, &z)) { s[0] += x; s[1] += y; s[2] += z; n++; } delay(10); }
  if (n < 100) return false;
  for (int i = 0; i < 3; i++) gyroBias[i] = s[i] / n;
  att = cart::Attitude(); lastImuUs = micros();
  return true;
}
void IRAM_ATTR isrEchoL() { if (digitalRead(PIN_US_ECHO_L)) echoRise[0] = micros(); else { echoWidth[0] = micros() - echoRise[0]; echoDone[0] = true; } }
void IRAM_ATTR isrEchoR() { if (digitalRead(PIN_US_ECHO_R)) echoRise[1] = micros(); else { echoWidth[1] = micros() - echoRise[1]; echoDone[1] = true; } }
void IRAM_ATTR isrHallL() { hallCount[0]++; }
void IRAM_ATTR isrHallR() { hallCount[1]++; }

static void ultrasonicOnce() {
  echoDone[0] = echoDone[1] = false;
  digitalWrite(PIN_US_TRIG, HIGH); delayMicroseconds(12); digitalWrite(PIN_US_TRIG, LOW);
  uint32_t t0 = millis(); while (millis() - t0 < 35 && !(echoDone[0] && echoDone[1])) delay(1);
  for (int i = 0; i < 2; i++) {
    if (echoDone[i] && echoWidth[i] < 30000) Serial.printf("  %s: %.2f m   ", i ? "RIGHT" : "LEFT ", echoWidth[i] * 0.0001715f);
    else Serial.printf("  %s: no echo   ", i ? "RIGHT" : "LEFT ");
  }
  Serial.println();
}
static void showOled() {
  oled.clearBuffer(); oled.setFont(u8g2_font_6x12_tr);
  oled.drawStr(0, 12, "HANDLE CADDIE CART"); oled.drawStr(0, 28, "OLED test OK");
  oled.drawStr(0, 44, ESP.getChipModel()); oled.drawStr(0, 60, "bring-up v1"); oled.sendBuffer();
  Serial.println("  OLED updated (if blank: check address 0x3C, and try OLED_SH1106 1)");
}
static void startSniff(char which, uint32_t baud) {
  if (which == 'A') { Serial2.end(); Serial2.begin(baud, SERIAL_8N1, PIN_UWB_A_RX, PIN_UWB_A_TX); sniff = &Serial2; }
  else              { Serial1.end(); Serial1.begin(baud, SERIAL_8N1, PIN_UWB_B_RX, PIN_UWB_B_TX); sniff = &Serial1; }
  sniffName = which; sniffLine = ""; mode = M_SNIFF;
  Serial.printf("Listening to UWB kit %c at %lu baud. Text you type is sent to the kit (add AT commands here). Type !q to stop.\n", which, (unsigned long)baud);
}
static void help() {
  Serial.println(
    "\nCommands:\n"
    "  i              I2C scan\n"
    "  o              OLED test\n"
    "  m              tilt/gyro stream (type anything to stop). Tilt NOSE UP -> pitch +, LEFT SIDE UP -> roll +\n"
    "  u              ultrasonic: stream distances (type anything to stop)\n"
    "  s L|R <pct>    speed output, pct of the motor board's range (max 30). Switches off after 5 s\n"
    "  b L|R 1|0      brake output on/off\n"
    "  x              everything off\n"
    "  h              count hall pulses for 5 s (turn a wheel by hand)\n"
    "  v              battery voltage     vcal <volts>  calibrate it against a multimeter\n"
    "  e              e-stop sense input\n"
    "  k A|B [baud]   listen to UWB kit A or B (default 115200); !q to stop\n"
    "  pins           print the pin map");
}
static void handle(String line) {
  line.trim(); if (!line.length()) return;
  if (mode == M_SNIFF) { if (line == "!q") { mode = M_IDLE; Serial.println("sniff stopped"); } else { sniff->print(line); sniff->print("\r\n"); Serial.printf(">> sent to kit %c: %s\n", sniffName, line.c_str()); } return; }
  if (mode != M_IDLE) { mode = M_IDLE; Serial.println("stopped"); return; }
  char c1[8] = {0}, c2[8] = {0}; float f = 0; int n = sscanf(line.c_str(), "%7s %7s %f", c1, c2, &f);
  String c = c1;
  if (c == "help" || c == "?") help();
  else if (c == "i") i2cScan();
  else if (c == "o") showOled();
  else if (c == "m") { if (imuStart()) { mode = M_IMU; Serial.println("streaming... (type anything to stop)"); } else Serial.println("IMU not responding at 0x68"); }
  else if (c == "u") { mode = M_US; Serial.println("streaming... (type anything to stop)"); }
  else if (c == "s" && n >= 3) speedPercent(String(c2) == "R" ? 1 : 0, f);
  else if (c == "b" && n >= 3) { digitalWrite(String(c2) == "R" ? PIN_BRAKE_R : PIN_BRAKE_L, (f > 0.5f) == (bool)BRAKE_ACTIVE_HIGH); Serial.printf("  brake %s %s\n", c2, f > 0.5f ? "ON" : "off"); }
  else if (c == "x") { allOff(); Serial.println("  all outputs off"); }
  else if (c == "h") {
    hallCount[0] = hallCount[1] = 0; Serial.println("Turn a wheel by hand for 5 s...");
    for (int i = 1; i <= 5; i++) { delay(1000); Serial.printf("  t=%ds  left=%lu  right=%lu pulses\n", i, (unsigned long)hallCount[0], (unsigned long)hallCount[1]); }
  }
  else if (c == "v") { float mv = analogReadMilliVolts(PIN_VBAT); Serial.printf("  pin %.0f mV  -> battery %.2f V (ratio %.2f, cal %.3f)\n", mv, mv / 1000.0f * VBAT_RATIO * vbatCal, VBAT_RATIO, vbatCal); }
  else if (c == "vcal" && n >= 2) { float mv = analogReadMilliVolts(PIN_VBAT); float real = atof(c2); if (mv > 50 && real > 5) { vbatCal = real / (mv / 1000.0f * VBAT_RATIO); Serial.printf("  cal factor %.3f  (put VBAT_CAL %.3f in the sketch)\n", vbatCal, vbatCal); } else Serial.println("  usage: vcal 18.50   (battery connected, multimeter reading)"); }
  else if (c == "e") Serial.printf("  e-stop sense pin = %d\n", digitalRead(PIN_ESTOP));
  else if (c == "k" && n >= 2) startSniff(String(c2) == "B" ? 'B' : 'A', n >= 3 && f > 0 ? (uint32_t)f : 115200);
  else if (c == "pins") Serial.println("SDA21 SCL22 | SPEED L25 R26 | BRAKE L32 R33 | HALL L34 R35 | VBAT 36 | ESTOP 39 | US TRIG18 ECHO L19 R23 | UWB A rx16 tx17, B rx4 tx14");
  else Serial.println("?  type help");
}

// -------------------------------------------------------------------------------------------------- Arduino
void setup() {
  // outputs first, and OFF
  pinMode(PIN_BRAKE_L, OUTPUT); pinMode(PIN_BRAKE_R, OUTPUT);
  digitalWrite(PIN_BRAKE_L, !BRAKE_ACTIVE_HIGH); digitalWrite(PIN_BRAKE_R, !BRAKE_ACTIVE_HIGH);
  ledcAttach(PIN_SPEED_L, SPEED_PWM_HZ, SPEED_PWM_BITS); ledcAttach(PIN_SPEED_R, SPEED_PWM_HZ, SPEED_PWM_BITS);
  ledcWrite(PIN_SPEED_L, 0); ledcWrite(PIN_SPEED_R, 0);
  pinMode(PIN_US_TRIG, OUTPUT); digitalWrite(PIN_US_TRIG, LOW);
  pinMode(PIN_US_ECHO_L, INPUT); pinMode(PIN_US_ECHO_R, INPUT);
  attachInterrupt(PIN_US_ECHO_L, isrEchoL, CHANGE); attachInterrupt(PIN_US_ECHO_R, isrEchoR, CHANGE);
  pinMode(PIN_HALL_L, INPUT); pinMode(PIN_HALL_R, INPUT);
  attachInterrupt(PIN_HALL_L, isrHallL, RISING); attachInterrupt(PIN_HALL_R, isrHallR, RISING);
  pinMode(PIN_ESTOP, INPUT); pinMode(PIN_BUTTON, INPUT_PULLUP);
  analogSetPinAttenuation(PIN_VBAT, ADC_11db);

  Serial.begin(115200); delay(1200);
  Wire.begin(PIN_SDA, PIN_SCL); Wire.setClock(400000);
  oled.begin();
  Serial.printf("\nHandle Caddie CART bring-up. Chip %s rev %d, %d cores.\n", ESP.getChipModel(), ESP.getChipRevision(), ESP.getChipCores());
  Serial.println("WHEELS OFF THE GROUND for any motor test.");
  i2cScan(); help();
}

void loop() {
  static String buf;
  while (Serial.available()) { char ch = Serial.read(); if (ch == '\n' || ch == '\r') { handle(buf); buf = ""; } else if (buf.length() < 80) buf += ch; }

  if (millis() - lastSpeedCmdMs > 5000 && lastSpeedCmdMs) { allOff(); lastSpeedCmdMs = 0; Serial.println("  (5 s timeout: speed outputs off)"); }

  if (mode == M_IMU) {
    float ax, ay, az, gx, gy, gz;
    if (imuRead(&ax, &ay, &az, &gx, &gy, &gz)) {
      uint32_t now = micros(); float dt = (now - lastImuUs) * 1e-6f; lastImuUs = now;
      att.update(dt, ax, ay, az, gx - gyroBias[0], gy - gyroBias[1], gz - gyroBias[2]);
    }
    if (millis() - lastPrintMs > 250) { lastPrintMs = millis(); Serial.printf("  pitch %6.1f deg   roll %6.1f deg   accel %.2f %.2f %.2f g\n", att.pitchDeg(), att.rollDeg(), ax, ay, az); }
    delay(5);
  } else if (mode == M_US) {
    if (millis() - lastPrintMs > 150) { lastPrintMs = millis(); ultrasonicOnce(); }
  } else if (mode == M_SNIFF && sniff) {
    while (sniff->available()) {
      char ch = sniff->read();
      if (ch == '\n') { Serial.printf("[%c %lu] %s\n", sniffName, (unsigned long)millis(), sniffLine.c_str()); sniffLine = ""; }
      else if (ch == '\r') {}
      else if (ch >= 32 && ch < 127) sniffLine += ch;
      else { char t[6]; snprintf(t, sizeof(t), "\\x%02X", (uint8_t)ch); sniffLine += t; }
      if (sniffLine.length() > 200) { Serial.printf("[%c %lu] %s...\n", sniffName, (unsigned long)millis(), sniffLine.c_str()); sniffLine = ""; }
    }
  }
}
