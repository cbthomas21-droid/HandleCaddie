// cart_logic.h - pure C++ (no Arduino calls) so it can be simulated and unit-tested on a PC.
//
// Coordinate conventions (body frame): X forward, Y left, Z up.
//   pitch > 0 : nose up (uphill)      roll > 0 : left side up
//   yaw rate > 0 : turning left (counter-clockwise from above)
//   bearing > 0 : the person is to the LEFT of the cart's heading
#pragma once
#include <math.h>
#include <stdint.h>
#include <string.h>

namespace cart {

static const float DEG2RAD = 0.01745329252f;
static const float RAD2DEG = 57.2957795f;
static const float MPS2MPH = 2.23693629f;
static const float M2MILE  = 0.000621371f;

template <class T> inline T clampv(T x, T lo, T hi) { return x < lo ? lo : (x > hi ? hi : x); }

inline float slewTo(float cur, float tgt, float up, float down, float dt) {
  float d = tgt - cur;
  if (d >= 0) { float m = up * dt;   return d > m ? cur + m : tgt; }
  float m = down * dt;               return -d > m ? cur - m : tgt;
}
inline float med3(float a, float b, float c) {
  if (a > b) { float t = a; a = b; b = t; }
  if (b > c) { b = c; }
  return a > b ? a : b;
}

// ---------------------------------------------------------------------------------------- range filter
// Takes raw UWB distances (metres). Removes impossible values and the short +1..3 m spikes that happen when
// your body blocks the signal, then smooths lightly and provides a range-rate (m/s) from a short regression.
class RangeFilter {
 public:
  void reset() { n_ = 0; hn_ = 0; have_ = false; outl_ = 0; }
  bool push(float t, float r, float maxSpeedMps = 6.0f) {
    if (!(r > 0.05f && r < 60.0f)) return false;
    h3_[0] = h3_[1]; h3_[1] = h3_[2]; h3_[2] = r;
    if (n_ < 3) n_++;
    float m = (n_ >= 3) ? med3(h3_[0], h3_[1], h3_[2]) : r;
    if (!have_) { r_ = m; have_ = true; }
    else {
      float dt = t - tLast_;
      if (dt <= 0) return false;
      if (fabsf(m - r_) > maxSpeedMps * dt + 0.3f && ++outl_ < 6) return false;   // reject a spike...
      outl_ = 0;                                                                  // ...but accept a real jump
      r_ += 0.6f * (m - r_);
    }
    tLast_ = t;
    if (hn_ == H) { for (int i = 1; i < H; i++) { ht_[i - 1] = ht_[i]; hr_[i - 1] = hr_[i]; } hn_--; }
    ht_[hn_] = t; hr_[hn_] = r_; hn_++;
    return true;
  }
  bool valid() const { return have_; }
  float range() const { return r_; }
  float lastTime() const { return tLast_; }
  // least-squares slope over the last ~1 s of samples
  float rate() const {
    if (hn_ < 4) return 0;
    float mt = 0, mr = 0;
    for (int i = 0; i < hn_; i++) { mt += ht_[i]; mr += hr_[i]; }
    mt /= hn_; mr /= hn_;
    float num = 0, den = 0;
    for (int i = 0; i < hn_; i++) { num += (ht_[i] - mt) * (hr_[i] - mr); den += (ht_[i] - mt) * (ht_[i] - mt); }
    return den > 1e-6f ? num / den : 0;
  }
 private:
  static const int H = 6;
  float h3_[3] = {0, 0, 0}, ht_[H] = {}, hr_[H] = {};
  int n_ = 0, hn_ = 0, outl_ = 0;
  bool have_ = false;
  float r_ = 0, tLast_ = 0;
};

// ------------------------------------------------------------------------------------- two-anchor tracker
// Two UWB base stations on the cart (left and right, `baseline` metres apart) and one tag on you.
// Each reports its own distance. The DIFFERENCE between the two distances says which side you are on:
//     y = (rR^2 - rL^2) / (2*baseline)   (positive = you are to the LEFT),  bearing = atan2(y, sqrt(r^2 - y^2))
class TwoAnchorTracker {
 public:
  explicit TwoAnchorTracker(float baselineM = 0.8f) : d_(baselineM) {}
  void setBaseline(float d) { d_ = d; }
  void setCorrectionGain(float g) { gain_ = g; }      // per new measurement; smaller = smoother
  void reset() { fL_.reset(); fR_.reset(); fM_.reset(); bearing_ = 0; haveB_ = false; tL_ = tR_ = -99; dirty_ = false; }
  void pushLeft(float t, float r)  { if (fL_.push(t, r)) { tL_ = t; dirty_ = true; } }
  void pushRight(float t, float r) { if (fR_.push(t, r)) { tR_ = t; dirty_ = true; } }

  // Every loop: when the cart turns left by w*dt, you appear w*dt further to the RIGHT. Predicting this with the gyro lets the
  // distance-based correction below be slow and smooth without lagging behind the cart's own turns.
  void predict(float dt, float yawRate) { if (haveB_) bearing_ -= yawRate * dt; }

  // call once per control loop with the current time (s)
  void update(float now, float freshS = 0.8f) {
    bool lOk = (now - tL_) < freshS && fL_.valid(), rOk = (now - tR_) < freshS && fR_.valid();
    rangeOk_ = lOk || rOk; bearingOk_ = false;
    if (!rangeOk_) return;
    float rl = fL_.range(), rr = fR_.range(), r;
    if (lOk && rOk) {
      r = 0.5f * (rl + rr);
      if (fabsf(rl - rr) <= 1.05f * d_) {                        // geometrically possible (difference can't exceed the baseline)
        float y = clampv((rr * rr - rl * rl) / (2.0f * d_), -0.98f * r, 0.98f * r);
        float b = atan2f(y, sqrtf(fmaxf(1e-4f, r * r - y * y)));
        if (dirty_) { if (!haveB_) { bearing_ = b; haveB_ = true; } else bearing_ += gain_ * (b - bearing_); }
        bearingOk_ = haveB_;
      }
    } else {
      r = lOk ? rl : rr;                                         // one anchor lost: keep the distance, fade the direction
      bearing_ *= 0.995f;
    }
    if (dirty_) { fM_.push(now, r); dirty_ = false; }
    range_ = fM_.valid() ? fM_.range() : r;
  }
  bool rangeOk() const { return rangeOk_; }
  bool bearingOk() const { return bearingOk_; }
  float range() const { return range_; }
  float rate() const { return fM_.rate(); }
  float bearing() const { return bearing_; }                    // rad, left +
  float ageS(float now) const { float a = now - tL_, b = now - tR_; return a < b ? a : b; }
 private:
  RangeFilter fL_, fR_, fM_;
  float d_, gain_ = 0.08f, bearing_ = 0, range_ = 0, tL_ = -99, tR_ = -99;
  bool haveB_ = false, rangeOk_ = false, bearingOk_ = false, dirty_ = false;
};

// ----------------------------------------------------------------------------------------- follow control
struct FollowCfg {
  float targetM      = 2.5f;    // distance to keep from you
  float startBandM   = 0.35f;   // you must be this much beyond target before a stopped cart starts
  float vMax         = 1.6f;    // m/s, never exceeded
  float kp           = 0.9f;    // (m/s) per metre of distance error
  float ffGain       = 0.8f;    // how much of your estimated walking speed to add
  float accel        = 0.7f;    // m/s^2
  float decel        = 2.4f;    // m/s^2
  float maxRangeM    = 12.0f;   // further than this the cart stops and waits
  float steerK       = 1.2f;    // rad/s of turn per rad of bearing
  float steerMax     = 0.8f;    // rad/s
  float vNoBearing   = 0.8f;    // speed limit when only one anchor is working (no direction)
};

class FollowController {
 public:
  explicit FollowController(const FollowCfg& c = FollowCfg()) : c_(c) {}
  FollowCfg& cfg() { return c_; }
  void reset() { v_ = 0; moving_ = false; tooFar_ = false; omega_ = 0; }

  struct Out { float v; float omega; };

  Out update(float dt, float r, float rdot, float vMeas, float bearing, bool bearingOk) {
    float e = r - c_.targetM;
    if (r > c_.maxRangeM) tooFar_ = true; else if (r < c_.maxRangeM - 1.0f) tooFar_ = false;
    float vLim = bearingOk ? c_.vMax : c_.vNoBearing;
    float vDes = 0;
    if (!tooFar_) {
      if (!moving_ && e > c_.startBandM) moving_ = true;
      if (moving_ && e <= 0) moving_ = false;
      if (moving_) {
        float ff = (e > -0.3f) ? c_.ffGain * fmaxf(0.0f, rdot + vMeas) : 0.0f;       // match your walking speed
        vDes = clampv(c_.kp * e + ff, 0.0f, vLim);
      }
    } else moving_ = false;
    v_ = slewTo(v_, vDes, c_.accel, c_.decel, dt);

    float wDes = bearingOk ? clampv(c_.steerK * bearing, -c_.steerMax, c_.steerMax) * clampv(v_ / 0.5f, 0.15f, 1.0f) : 0.0f;
    omega_ += (wDes - omega_) * clampv(dt / 0.15f, 0.0f, 1.0f);
    return {v_, omega_};
  }
  bool tooFar() const { return tooFar_; }
  void hardStop() { v_ = 0; moving_ = false; omega_ = 0; }
 private:
  FollowCfg c_;
  float v_ = 0, omega_ = 0;
  bool moving_ = false, tooFar_ = false;
};

// --------------------------------------------------------------------------------------------- attitude
// Complementary filter on a GY-521 (MPU6050). X forward, Y left, Z up. Units: g and rad/s.
class Attitude {
 public:
  void update(float dt, float ax, float ay, float az, float gx, float gy, float gz) {
    float accRoll  = atan2f(ay, az);
    float accPitch = atan2f(ax, sqrtf(ay * ay + az * az));
    float mag = sqrtf(ax * ax + ay * ay + az * az);
    if (!init_) { roll_ = accRoll; pitch_ = accPitch; init_ = true; }
    float k = (mag > 0.85f && mag < 1.2f) ? 0.02f : 0.0f;          // trust gravity only when not accelerating hard
    roll_  = (1 - k) * (roll_  + gx * dt)  + k * accRoll;
    pitch_ = (1 - k) * (pitch_ - gy * dt)  + k * accPitch;           // +gy = nose down
    yawRate_ = gz;
  }
  float rollDeg() const  { return roll_ * RAD2DEG; }
  float pitchDeg() const { return pitch_ * RAD2DEG; }
  float yawRate() const  { return yawRate_; }
 private:
  float roll_ = 0, pitch_ = 0, yawRate_ = 0; bool init_ = false;
};

// ---------------------------------------------------------------------------------------------- battery
// Pack of S Li-ion cells (a Dewalt 20V pack is 5S). Percent is a smoothed estimate from voltage and
// is approximate: voltage sags under load and recovers at rest.
class BatteryGauge {
 public:
  explicit BatteryGauge(int cells = 5) : n_(cells) {}
  void update(float dt, float packV, bool underLoad) {
    float cv = packV / n_;
    float tgt = socFromCell(cv + (underLoad ? 0.06f : 0.0f));     // crude sag allowance
    if (!init_) { soc_ = tgt; v_ = packV; init_ = true; }
    float tau = underLoad ? 40.0f : 6.0f;
    soc_ += clampv(dt / tau, 0.0f, 1.0f) * (tgt - soc_);
    v_   += clampv(dt / 0.5f, 0.0f, 1.0f) * (packV - v_);
    // low-battery latch with hysteresis, debounced
    float lowV = lowCellV_ * n_;
    if (v_ < lowV) lowT_ += dt; else if (v_ > lowV + 0.3f * n_) lowT_ = 0;
    low_ = lowT_ > (underLoad ? 8.0f : 4.0f) ? true : (v_ > lowV + 0.3f * n_ ? false : low_);
  }
  float percent() const { return soc_; }
  float volts() const { return v_; }
  bool low() const { return low_; }
  void setLowCellV(float v) { lowCellV_ = v; }
 private:
  static float socFromCell(float c) {
    static const float V[] = {3.20f, 3.45f, 3.60f, 3.70f, 3.80f, 3.90f, 4.00f, 4.10f, 4.20f};
    static const float P[] = {0, 5, 15, 30, 45, 60, 75, 90, 100};
    if (c <= V[0]) return 0;
    for (int i = 1; i < 9; i++)
      if (c <= V[i]) return P[i - 1] + (P[i] - P[i - 1]) * (c - V[i - 1]) / (V[i] - V[i - 1]);
    return 100;
  }
  int n_; bool init_ = false, low_ = false; float soc_ = 0, v_ = 0, lowT_ = 0, lowCellV_ = 3.30f;
};

// --------------------------------------------------------------------------------------------- gyro drift
// The gyro's zero point wanders with temperature. While the cart is certainly standing still, creep the zero point toward what the
// gyro reads. Heading for a route comes from integrating this, so a few tenths of a degree per second matter after a minute.
class YawBias {
 public:
  void update(float dt, float yawRate, bool stationary) {
    if (!stationary || fabsf(yawRate - bias_) > 0.05f) { still_ = 0; return; }       // moving, or someone is turning the cart by hand
    still_ += dt;
    if (still_ > 2.0f) { bias_ += clampv(dt / 15.0f, 0.0f, 1.0f) * (yawRate - bias_); learnedS_ += dt; }
  }
  float bias() const { return bias_; }
  /** Enough time standing still has been seen to trust the zero point (a gyro that never reads near zero at rest never gets here). */
  bool settled() const { return learnedS_ >= 20.0f; }
 private:
  float bias_ = 0, still_ = 0, learnedS_ = 0;
};

// ----------------------------------------------------------------------------------------------- route driving
// The phone plans a route around a hazard and sends it as waypoints in the cart's own frame: origin = where the cart was when the
// route began, +X = the way it was facing, +Y = left. The cart has no GPS, so it keeps its own position by dead reckoning
// (gyro for heading, wheel speed for distance) and follows the waypoints with pure pursuit. It trusts nothing it cannot check:
// the phone must keep sending a heartbeat, the route has hard limits, and anything odd stops the cart (the phone re-plans or waits).
struct NavCfg {
  float vCruise     = 1.5f;    // m/s along a route (the route's own speed can only lower this; the phone asks for 1.0 round hazards, 1.4 when chasing)
  float vMin        = 0.35f;
  float lookaheadM  = 2.5f;
  float omegaMax    = 0.8f;    // rad/s
  float arriveM     = 1.0f;
  float maxPathM    = 250.0f;
  float maxRunS     = 420.0f;
  float linkTimeoutS = 2.5f;   // no heartbeat from the phone for this long -> stop
  float offPathM    = 5.0f;    // farther than this from the route -> stop (wheel slip, wrong turn)
  float stuckS      = 25.0f;   // no progress along the route for this long -> stop
  float startNearM  = 12.0f;   // a route's first point must be this near where the cart thinks it is
  float yawMismatch = 0.35f;   // rad/s: the gyro and the wheels must roughly agree on how fast the cart is turning...
  float yawMismatchS = 3.0f;   // ...for all but this long, or the gyro cannot be trusted
};
enum class NavState : uint8_t { IDLE = 0, READY = 1, RUN = 2, ARRIVED = 3, ABORT_LINK = 4, ABORT_TIME = 5, ABORT_OFFPATH = 6, ABORT_STUCK = 7, ABORT_YAW = 8 };

class NavController {
 public:
  static const int MAXW = 24;
  explicit NavController(const NavCfg& c = NavCfg()) : c_(c) {}
  NavCfg& cfg() { return c_; }

  void stageClear() { stagedMask_ = 0; }
  bool stagePoint(int i, float x, float y) {
    if (i < 0 || i >= MAXW || !isfinite(x) || !isfinite(y) || fabsf(x) > 500.0f || fabsf(y) > 500.0f) return false;
    sx_[i] = x; sy_[i] = y; stagedMask_ |= (1u << i); return true;
  }
  /** Check the staged points and make them THE route. While running, the cart keeps its position and swaps routes at once. */
  bool commit(int n, float vMps) {
    if (n < 2 || n > MAXW || !isfinite(vMps)) return false;
    for (int i = 0; i < n; i++) if (!(stagedMask_ & (1u << i))) return false;
    float len = 0;
    for (int i = 1; i < n; i++) {
      float d = hypotf(sx_[i] - sx_[i - 1], sy_[i] - sy_[i - 1]);
      if (d < 0.2f || d > 100.0f) return false;
      len += d;
    }
    if (len > c_.maxPathM) return false;
    if (hypotf(sx_[0] - x_, sy_[0] - y_) > c_.startNearM) return false;                 // the route must start where we are
    for (int i = 0; i < n; i++) { px_[i] = sx_[i]; py_[i] = sy_[i]; }
    n_ = n; seg_ = 0; v_ = clampv(vMps, c_.vMin, c_.vCruise); stuckT_ = 0; bestS_ = 0;
    if (state_ == NavState::IDLE || state_ >= NavState::ARRIVED) state_ = NavState::READY;
    stagedMask_ = 0; return true;
  }
  bool ready() const { return state_ == NavState::READY; }
  bool running() const { return state_ == NavState::RUN; }
  bool finished() const { return state_ >= NavState::ARRIVED; }
  NavState state() const { return state_; }

  /** Start driving the committed route. Position and heading restart at zero: that IS the route's frame. */
  bool begin() {
    if (state_ != NavState::READY) return false;
    x_ = y_ = psi_ = 0; t_ = 0; link_ = 0; seg_ = 0; stuckT_ = 0; bestS_ = 0; lastOmega_ = 0; yawBad_ = 0; state_ = NavState::RUN; return true;
  }
  void heartbeat() { link_ = 0; }
  void cancel() { state_ = NavState::IDLE; n_ = 0; stagedMask_ = 0; x_ = y_ = psi_ = 0; }
  void clearFinished() { if (finished()) { state_ = NavState::IDLE; x_ = y_ = psi_ = 0; } }   // a finished route leaves the pose behind; a new one starts from zero again

  struct Out { float v = 0, omega = 0; };
  Out update(float dt, float yawRate, float vMeas) {
    Out o;
    if (state_ != NavState::RUN) return o;
    // where am I (dead reckoning)
    if (fabsf(yawRate - lastOmega_) > c_.yawMismatch) { yawBad_ += dt; if (yawBad_ > c_.yawMismatchS) { state_ = NavState::ABORT_YAW; return o; } } else yawBad_ = 0;
    psi_ = wrap(psi_ + yawRate * dt);
    x_ += vMeas * cosf(psi_) * dt; y_ += vMeas * sinf(psi_) * dt;
    t_ += dt; link_ += dt;
    if (link_ > c_.linkTimeoutS) { state_ = NavState::ABORT_LINK; return o; }
    if (t_ > c_.maxRunS) { state_ = NavState::ABORT_TIME; return o; }

    // closest point on the route, looking only a little ahead of where we were (never back to an earlier leg)
    float bestD = 1e9f, bestSeg = seg_, bestT = 0;
    for (int i = seg_; i < n_ - 1 && i <= seg_ + 3; i++) {
      float ax = px_[i], ay = py_[i], bx = px_[i + 1], by = py_[i + 1];
      float dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
      float tt = l2 > 1e-9f ? clampv(((x_ - ax) * dx + (y_ - ay) * dy) / l2, 0.0f, 1.0f) : 0.0f;
      float d = hypotf(x_ - (ax + tt * dx), y_ - (ay + tt * dy));
      if (d < bestD) { bestD = d; bestSeg = (float)i; bestT = tt; }
    }
    seg_ = (int)bestSeg;
    xtrack_ = bestD;
    if (bestD > c_.offPathM) { state_ = NavState::ABORT_OFFPATH; return o; }
    float s = alongTo(seg_, bestT);
    if (s > bestS_ + 0.5f) { bestS_ = s; stuckT_ = 0; } else { stuckT_ += dt; if (stuckT_ > c_.stuckS) { state_ = NavState::ABORT_STUCK; return o; } }

    float toEnd = hypotf(px_[n_ - 1] - x_, py_[n_ - 1] - y_);
    if (toEnd <= c_.arriveM) { state_ = NavState::ARRIVED; return o; }

    // pure pursuit: aim at the point one lookahead further along the route
    float tx, ty; pointAt(s + c_.lookaheadM, &tx, &ty);
    float alpha = wrap(atan2f(ty - y_, tx - x_) - psi_);
    float v = v_ * clampv(cosf(alpha), 0.3f, 1.0f);
    if (fabsf(alpha) > 1.2f) v = c_.vMin;
    v = fminf(v, fmaxf(c_.vMin, 0.5f * toEnd));
    v = fmaxf(v, c_.vMin);
    o.v = v;
    o.omega = clampv(2.0f * v * sinf(alpha) / c_.lookaheadM, -c_.omegaMax, c_.omegaMax);
    lastOmega_ = o.omega;
    return o;
  }
  float x() const { return x_; } float y() const { return y_; } float psi() const { return psi_; }
  int segment() const { return seg_; } float crossTrack() const { return xtrack_; } float runS() const { return t_; }
  int count() const { return n_; }
 private:
  static float wrap(float a) { while (a > 3.14159265f) a -= 6.2831853f; while (a < -3.14159265f) a += 6.2831853f; return a; }
  float alongTo(int seg, float t) const {
    float s = 0; for (int i = 0; i < seg; i++) s += hypotf(px_[i + 1] - px_[i], py_[i + 1] - py_[i]);
    return s + t * hypotf(px_[seg + 1] - px_[seg], py_[seg + 1] - py_[seg]);
  }
  void pointAt(float s, float* x, float* y) const {
    for (int i = 0; i < n_ - 1; i++) {
      float l = hypotf(px_[i + 1] - px_[i], py_[i + 1] - py_[i]);
      if (s <= l || i == n_ - 2) { float f = l > 1e-6f ? clampv(s / l, 0.0f, 1.0f) : 1.0f; *x = px_[i] + f * (px_[i + 1] - px_[i]); *y = py_[i] + f * (py_[i + 1] - py_[i]); return; }
      s -= l;
    }
    *x = px_[n_ - 1]; *y = py_[n_ - 1];
  }
  NavCfg c_; NavState state_ = NavState::IDLE;
  float sx_[MAXW] = {}, sy_[MAXW] = {}, px_[MAXW] = {}, py_[MAXW] = {}; uint32_t stagedMask_ = 0; int n_ = 0, seg_ = 0;
  float x_ = 0, y_ = 0, psi_ = 0, t_ = 0, link_ = 0, v_ = 1.0f, stuckT_ = 0, bestS_ = 0, xtrack_ = 0, lastOmega_ = 0, yawBad_ = 0;
};

// ------------------------------------------------------------------------------------------- supervisor
enum class Mode : uint8_t { PARK = 0, FOLLOW = 1, FREE = 2, MANUAL = 3, NAV = 4 };   // PARK: brake on slopes, no drive. FREE: coast. MANUAL: phone joystick. NAV: drive the route the phone sent (dead reckoning).
enum Fault : uint16_t { F_NONE = 0, F_TIP = 1, F_IMU = 2, F_LOWBATT = 4, F_ESTOP = 8 };
enum Flag : uint16_t { FL_UWB_LOST = 1, FL_OBSTACLE = 2, FL_TOO_FAR = 4, FL_DESCENT = 8, FL_HOLD = 16, FL_SLOWED = 32,
                       FL_AUTOHOLD = 64,    // waiting because the phone said "green ahead"
                       FL_PAUSED = 128,     // paused with the switch on the cart
                       FL_OVERRIDE = 256,
                       FL_NAV = 512 };      // driving the phone's route around a hazard // switch pressed while auto-held: you said "go anyway"

struct SupCfg {
  float trackWidthM   = 0.45f;   // distance between the two driven wheels
  float tipRollDeg    = 25.0f;
  float tipPitchDeg   = 32.0f;
  float tipHoldS      = 0.15f;
  float rangeStaleS   = 0.8f;    // start slowing
  float rangeLostS    = 2.0f;    // stop completely
  float obsStopM      = 0.55f;
  float obsSlowM      = 2.00f;
  float descentDeg    = 4.0f;    // downhill steeper than this -> descent control
  float descentVMax   = 1.2f;
  float holdDeg       = 3.0f;    // parked on a slope steeper than this -> brake held
  float brakeGain     = 0.9f;    // brake duty per m/s of over-speed
  float brakeMax      = 0.7f;    // while moving (1.0 only when stopped)
  bool  hasSpeedSense = false;   // true only if the wheel speed (hall pulses) is wired
  bool  hasBrake      = false;   // true only if the board's brake input is wired
  float manualVMax    = 1.2f;    // joystick full-forward speed
  float manualOmegaMax = 0.9f;   // joystick full-steer turn rate, rad/s
  float joyTimeoutS   = 0.5f;    // no joystick frame for this long -> stop (dead-man)
};

struct SupIn {
  float dt = 0.02f;
  Mode  req = Mode::PARK;
  bool  rangeValid = false; float rangeAgeS = 99; float range = 0; float rangeRate = 0;
  float bearing = 0; bool bearingOk = false;       // from TwoAnchorTracker (rad, left +)
  float vMeas = 0;                 // measured wheel speed (m/s); ignored unless hasSpeedSense
  float pitchDeg = 0, rollDeg = 0, yawRate = 0;
  bool  imuOk = true;
  bool  batteryLow = false;
  bool  estopPressed = false;
  float obsL = -1, obsR = -1;      // metres, <0 = no echo
  bool  clearFaults = false;
  float joyX = 0, joyY = 0, joyAgeS = 99;   // joystick (x + = right, y 0..1 forward) and the age of the last frame
  bool  autoHold = false;          // phone: green ahead, wait
  bool  paused = false;            // the switch on the cart
  bool  overridden = false;        // report-only: the switch overrode an auto-hold
};

struct SupOut {
  float vL = 0, vR = 0;            // wheel speed commands, m/s, >= 0
  float brake = 0;                 // 0..1
  Mode  mode = Mode::PARK;
  uint16_t faults = 0, flags = 0;
  float bearingDeg = 0, slopePct = 0, vEst = 0; bool seesPerson = false;
  float yawDeg = 0;                                                                   // gyro heading since power-up (drifts slowly; for relative use)
  float navX = 0, navY = 0, navHeadDeg = 0; int navSeg = 0; uint8_t navState = 0;     // dead-reckoned pose in the route's frame
};

class Supervisor {
 public:
  Supervisor(const SupCfg& s = SupCfg(), const FollowCfg& f = FollowCfg()) : c_(s), fc_(f) {}
  SupCfg& cfg() { return c_; }
  FollowController& follow() { return fc_; }
  NavController& nav() { return nav_; }
  /** A route can be started: wheel speed is measured and the gyro's zero point has been checked while standing still. */
  bool navOk() const { return c_.hasSpeedSense && yawBias_.settled(); }

  SupOut update(const SupIn& in) {
    SupOut o; const float dt = in.dt;

    // ---- faults
    bool tipNow = fabsf(in.rollDeg) > c_.tipRollDeg || fabsf(in.pitchDeg) > c_.tipPitchDeg;
    tipT_ = tipNow ? tipT_ + dt : 0;
    if (tipT_ > c_.tipHoldS) faults_ |= F_TIP;
    if (!in.imuOk) faults_ |= F_IMU;
    if (in.estopPressed) faults_ |= F_ESTOP; else faults_ &= ~F_ESTOP;           // not latched: the button is the latch
    if (in.batteryLow) faults_ |= F_LOWBATT; else faults_ &= ~F_LOWBATT;
    if (in.clearFaults && !tipNow && in.imuOk) faults_ &= ~(F_TIP | F_IMU);

    Mode mode = in.req;
    if (faults_) mode = Mode::PARK;                                              // any fault -> no driving
    if (mode == Mode::NAV) {                                                      // a route needs wheel-speed sensing and a running route
      if (!navOk() || !nav_.running()) mode = Mode::PARK;
      else if (in.paused) { nav_.cancel(); mode = Mode::PARK; }                  // the switch on the cart always cancels a route
    }
    if (mode != Mode::NAV && nav_.running()) nav_.cancel();                       // leaving route mode for any reason ends the route
    o.mode = mode; o.faults = faults_;

    // ---- desired motion
    float v = 0, omega = 0;
    float rangeAge = in.rangeValid ? in.rangeAgeS : 99;
    bool holding = (in.paused && (mode == Mode::FOLLOW || mode == Mode::MANUAL)) || (in.autoHold && mode == Mode::FOLLOW);
    if (in.paused && (mode == Mode::FOLLOW || mode == Mode::MANUAL)) o.flags |= FL_PAUSED;
    if (in.autoHold && mode == Mode::FOLLOW) o.flags |= FL_AUTOHOLD;
    if (in.overridden) o.flags |= FL_OVERRIDE;
    if (mode == Mode::MANUAL) {
      fc_.reset();
      bool fresh = in.joyAgeS <= c_.joyTimeoutS;                              // dead-man: a stale joystick means stop
      float y = fresh ? clampv(in.joyY, 0.0f, 1.0f) : 0.0f, x = fresh ? clampv(in.joyX, -1.0f, 1.0f) : 0.0f;
      v = holding ? 0.0f : y * c_.manualVMax;
      float wTgt = -x * c_.manualOmegaMax;                                    // x + = right = turn right = omega negative
      omegaM_ += (wTgt - omegaM_) * clampv(dt / 0.15f, 0.0f, 1.0f);
      omega = omegaM_;
    } else if (mode == Mode::NAV) {
      fc_.reset();
      auto r = nav_.update(dt, in.yawRate - yawBias_.bias(), vEst_);
      v = r.v; omega = r.omega; o.flags |= FL_NAV;
    } else if (mode == Mode::FOLLOW && holding) {
      fc_.hardStop();                                                         // wait: the speed ramp below brings it to rest smoothly
    } else if (mode == Mode::FOLLOW) {
      if (rangeAge > c_.rangeLostS) { fc_.hardStop(); o.flags |= FL_UWB_LOST; }
      else {
        auto r = fc_.update(dt, in.range, in.rangeRate, vEst_, in.bearing, in.bearingOk);
        v = r.v; omega = r.omega;
        if (rangeAge > c_.rangeStaleS) { v *= clampv(1.0f - (rangeAge - c_.rangeStaleS) / (c_.rangeLostS - c_.rangeStaleS), 0.0f, 1.0f); o.flags |= FL_SLOWED; }
        if (fc_.tooFar()) o.flags |= FL_TOO_FAR;
      }
    } else { fc_.reset(); }
    if (mode != Mode::MANUAL) omegaM_ = 0;
    if (mode != Mode::NAV && nav_.finished()) { /* result stays readable until the phone asks again */ }

    // ---- obstacles (two forward ultrasonic sensors). While following, an echo that matches the UWB distance is YOU,
    //      so only echoes nearer than you count; the sensors double as the person finder.
    float obs = 99;
    float cut = (mode == Mode::FOLLOW && in.rangeValid && rangeAge < c_.rangeStaleS) ? (in.range - 0.8f) : 99.0f;
    float e1 = in.obsL, e2 = in.obsR;
    if (e1 > 0 && (e1 < cut || e1 < c_.obsStopM)) obs = fminf(obs, e1);
    if (e2 > 0 && (e2 < cut || e2 < c_.obsStopM)) obs = fminf(obs, e2);
    if (obs < c_.obsSlowM) {
      v *= clampv((obs - c_.obsStopM) / (c_.obsSlowM - c_.obsStopM), 0.0f, 1.0f);
      o.flags |= (obs < c_.obsStopM + 0.05f) ? FL_OBSTACLE : FL_SLOWED;
    }

    // ---- downhill speed cap
    bool down = in.pitchDeg < -c_.descentDeg;
    if (down && (mode == Mode::FOLLOW || mode == Mode::MANUAL || mode == Mode::NAV)) { v = fminf(v, c_.descentVMax); o.flags |= FL_DESCENT; }

    // ---- final speed ramp (faults and stops are immediate)
    float dec = faults_ ? 6.0f : 2.4f;
    cmdV_ = slewTo(cmdV_, v, 0.9f, dec, dt);
    if (mode != Mode::FOLLOW && mode != Mode::MANUAL && mode != Mode::NAV) cmdV_ = slewTo(cmdV_, 0, 0.9f, 3.0f, dt);

    // ---- speed estimate (measured if available, else first-order model of the command)
    if (c_.hasSpeedSense) vEst_ = in.vMeas;
    else vEst_ += clampv(dt / 0.5f, 0.0f, 1.0f) * (cmdV_ - vEst_);

    // ---- brake: hill descent + park hold
    float brakeTgt = 0;
    bool stopped = cmdV_ < 0.03f && vEst_ < 0.30f;
    if (c_.hasBrake) {
      if (c_.hasSpeedSense && down && mode != Mode::FREE) {
        float over = vEst_ - (cmdV_ + 0.20f);
        if (over > 0) { brakeTgt = clampv(c_.brakeGain * over, 0.0f, c_.brakeMax); o.flags |= FL_DESCENT; }
      }
      if (mode != Mode::FREE && stopped && fabsf(in.pitchDeg) > c_.holdDeg) { brakeTgt = 1.0f; o.flags |= FL_HOLD; }
      if (faults_ && (faults_ & (F_TIP | F_IMU))) brakeTgt = stopped ? 1.0f : c_.brakeMax;
    }
    brake_ = slewTo(brake_, brakeTgt, 4.0f, 8.0f, dt);

    // ---- mix to wheels (forward only, so no pivot turns)
    float dv = omega * c_.trackWidthM * 0.5f;
    o.vL = clampv(cmdV_ - dv, 0.0f, 3.0f);
    o.vR = clampv(cmdV_ + dv, 0.0f, 3.0f);
    if (cmdV_ < 0.02f) o.vL = o.vR = 0;
    o.brake = brake_; o.vEst = vEst_;
    yawBias_.update(dt, in.yawRate, cmdV_ < 0.01f && vEst_ < 0.03f && mode != Mode::MANUAL);
    yawDeg_ += (in.yawRate - yawBias_.bias()) * dt * RAD2DEG; o.yawDeg = yawDeg_;
    o.navX = nav_.x(); o.navY = nav_.y(); o.navHeadDeg = nav_.psi() * RAD2DEG; o.navSeg = nav_.segment(); o.navState = (uint8_t)nav_.state();
    if (mode == Mode::NAV && !nav_.running()) o.mode = Mode::PARK;                // the route ended during this very step
    o.bearingDeg = in.bearing * RAD2DEG; o.seesPerson = in.bearingOk;
    o.slopePct = tanf(in.pitchDeg * DEG2RAD) * 100.0f;
    return o;
  }
  uint16_t faults() const { return faults_; }
 private:
  SupCfg c_; FollowController fc_; NavController nav_; YawBias yawBias_;
  float yawDeg_ = 0;
  uint16_t faults_ = 0; float tipT_ = 0, cmdV_ = 0, vEst_ = 0, brake_ = 0, omegaM_ = 0;
};

// ------------------------------------------------------------------------------------------- pause / green hold
// The latching switch is YOUR pause. The phone's green guard is an automatic pause. If you press the switch while the
// guard is holding, that means "go anyway": the hold is dropped, the position you just switched to becomes the new
// "run" position (so the next press pauses again), and the phone is told (FL_OVERRIDE) until it sends hold:0.
class HoldLogic {
 public:
  void begin(bool switchPos) { run_ = last_ = switchPos; remote_ = override_ = false; }
  void onConnect() { remote_ = override_ = false; }                 // a new link always starts clean
  void onHold(bool on) {
    if (!on) { remote_ = false; override_ = false; }
    else if (!override_) remote_ = true;                             // ignore hold:1 until the phone has seen the override
  }
  void onSwitch(bool pos) {                                          // call with the DEBOUNCED switch position
    if (pos == last_) return;
    last_ = pos;
    if (remote_) { remote_ = false; override_ = true; run_ = pos; }
  }
  bool autoHold() const { return remote_; }
  bool paused() const { return last_ != run_; }
  bool overridden() const { return override_; }
 private:
  bool run_ = false, last_ = false, remote_ = false, override_ = false;
};

// ---------------------------------------------------------------------------------------------- odometer
class Odometer {
 public:
  void add(float metres) { if (metres > 0) { trip_ += metres; total_ += metres; } }
  float tripMiles() const { return trip_ * M2MILE; }
  float totalMiles() const { return total_ * M2MILE; }
  float totalMetres() const { return total_; }
  void load(float totalM, float tripM) { total_ = totalM; trip_ = tripM; }
  void newTrip() { trip_ = 0; }
 private:
  float trip_ = 0, total_ = 0;
};

}  // namespace cart
