// Handle Caddie CART controller.  Board: ESP32 Dev Module (classic ESP32), arduino-esp32 core 3.x.
// Libraries: U8g2 (Library Manager).  BLE uses the library built into the core.
// Tools > Partition Scheme > "Huge APP (3MB No OTA/1MB SPIFFS)"  (the BLE stack does not fit the default partition).
//
// READ CART_DESIGN.md FIRST.  Test every part with BringUp/BringUp.ino before running this.
// FIRST DRIVE: wheels OFF THE GROUND, e-stop within reach.
//
// What it does: BLE link to the Handle Caddie app (name HandleCaddie_Cart); follows the UWB fob (2 base stations on the
// cart, 1 tag on you); manual joystick from the app; tip-over / low-battery / e-stop / signal-loss stops; hill-descent
// speed limit; ultrasonic obstacle slow/stop; pause switch; "green ahead" hold from the app; OLED status.
//
// SAFETY MODEL (all decisions are in cart_logic.h, tested on a PC):
//   * Boots and every new AUTHENTICATED phone connection start in PARK (no motion).  FOLLOW/MANUAL must be asked for each time.
//   * A phone must prove it holds the cart's key (cart_auth.h) before any command is obeyed or telemetry sent.  Pairing needs someone
//     at the cart: no key yet = pairing opens by itself; otherwise flip the pause switch 6 times quickly.  A PIN shows on the OLED.
//   * Any fault forces PARK and the request is forgotten - after a fault clears you must ask again.
//   * Manual joystick needs a frame every 500 ms.  Losing the phone drops MANUAL to PARK.  FOLLOW needs no phone.
//   * The loop is watched by the ESP32 hardware watchdog (0.6 s).  A reset floats the pins; the 10 k pull-down on each speed
//     pin then commands zero speed (see CART_DESIGN.md section 5).  The physical e-stop cuts motor power on its own.
#include <Arduino.h>
#include <Wire.h>
#include <Preferences.h>
#include <U8g2lib.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <BLESecurity.h>
#if defined(CONFIG_BLUEDROID_ENABLED)
#include <esp_gap_ble_api.h>
#endif
#include <esp_task_wdt.h>
#include <esp_random.h>
#include "cart_logic.h"
#include "cart_proto.h"
#include "cart_auth.h"

#define FW_VERSION "0.3"

// ================================================================================================ pins
#define PIN_SDA        21
#define PIN_SCL        22
#define PIN_SPEED_L    25
#define PIN_SPEED_R    26
#define PIN_BRAKE_L    32
#define PIN_BRAKE_R    33
#define PIN_HALL_L     34
#define PIN_HALL_R     35
#define PIN_VBAT       36
#define PIN_ESTOP      39
#define PIN_US_TRIG    18
#define PIN_US_ECHO_L  19
#define PIN_US_ECHO_R  23
#define PIN_UWB_A_RX   16
#define PIN_UWB_A_TX   17
#define PIN_UWB_B_RX   4
#define PIN_UWB_B_TX   14
#define PIN_SWITCH     27      // latching pause switch contact -> GND when pushed in (internal pull-up)
#define PIN_LED_GREEN  13      // -> transistor/MOSFET -> the switch's green LED (it is rated 12-24 V: NOT directly from the pin)
#define PIN_LED_RED    15      // -> transistor/MOSFET -> the switch's red LED

// ================================================================================================ settings you may need to change
#define UWB_A_IS_LEFT       1        // 1: kit A is on the cart's LEFT side, kit B on the right
#define UWB_BAUD            115200   // set the real value after the BU03 bench test
#define UWB_NO_UNIT_SCALE   1.0f     // metres per unit when a UWB line has no unit (0.01 if the kits print centimetres)
#define BASELINE_M          0.80f    // MEASURED distance between the two base stations
#define SPEED_PWM_HZ        20000
#define SPEED_PWM_BITS      10
#define SPEED_FULLSCALE_V   3.3f     // 3.3 = ESP32 pin straight into the RC filter; 5.0 = with the 74AHCT125 buffer
#define BOARD_MIN_V         0.1f
#define BOARD_FULLSCALE_V   5.0f
#define MIN_RUN_V           0.0f     // raise if your boards ignore tiny voltages (dead band); measure it
#define SPEED_AT_FULL_MS    2.4f     // CALIBRATE: cart speed (m/s) with the speed input at BOARD_FULLSCALE_V.  Guess until you measure.
#define SPEED_TRIM_L        1.00f    // fix a cart that veers: raise the slower side's trim a little
#define SPEED_TRIM_R        1.00f
#define HAS_BRAKE           0        // 1 only if the board brake inputs are wired
#define BRAKE_ACTIVE_HIGH   1
#define HAS_HALL            0        // 1 only if hall outputs are wired (through dividers)
#define WHEEL_DIAM_M        0.25f
#define HALL_PULSES_PER_REV 45.0f    // pulses per wheel turn on the hall pin: check with BringUp command 'h'
#define CART_BLE_ENCRYPT    1        // 1 = Bluetooth LE Secure Connections (encrypted link, passkey = the PIN). 0 = off (the older app-level check only).
#define HAS_ESTOP_SENSE     1        // 0 if pin 39 is not wired (then a software e-stop fault is impossible - only the physical one works)
#define ESTOP_PRESSED_LEVEL 0        // pin level when the e-stop is pressed (the divider reads the motor supply: pressed = 0 V)
#define VBAT_RATIO          7.67f
#define VBAT_CAL            1.000f   // from BringUp 'vcal'
#define PACK_CELLS          5        // Dewalt 20 V pack = 5S
#define PACK_WH             200.0f   // two 5 Ah packs in parallel = 200 Wh; edit for yours
#define WH_PER_MILE         35.0f    // guess for range-left; measure and edit
#define OLED_SH1106         0
#define IMU_ADDR            0x68

#if OLED_SH1106
U8G2_SH1106_128X64_NONAME_F_HW_I2C oled(U8G2_R0, U8X8_PIN_NONE);
#else
U8G2_SSD1306_128X64_NONAME_F_HW_I2C oled(U8G2_R0, U8X8_PIN_NONE);
#endif

#define NUS_SERVICE "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
#define NUS_RX      "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"   // phone -> cart
#define NUS_TX      "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"   // cart -> phone (notify)

// ================================================================================================ state
using namespace cart;
static Supervisor sup;
static TwoAnchorTracker trk(BASELINE_M);
static Attitude att;
static BatteryGauge batt(PACK_CELLS);
static Odometer odo;
static HoldLogic hold;
static Preferences prefs;
static Auth auth(esp_random);
static PairGesture pairGesture;

static float gyroBias[3] = {0, 0, 0};
static float pitchOff = 0, rollOff = 0;
static float cfgFd = 2.5f, cfgVm = 1.6f, cfgDc = 1.2f; static bool cfgHh = true;
static Mode reqMode = Mode::PARK;
static bool clearReq = false;
static uint32_t lastJoyMs = 0; static float joyX = 0, joyY = 0;
static SupOut out;

static bool imuOk = false; static uint32_t lastImuOkMs = 0; static int frozenCount = 0; static float lastAcc[3] = {0, 0, 0};
static float usL = -1, usR = -1; static uint32_t usOkMsL = 0, usOkMsR = 0, usTrigMs = 0;
static volatile uint32_t echoRise[2], echoWidth[2]; static volatile bool echoDone[2];
static volatile uint32_t hallCount[2];

static HardwareSerial* uwbPort[2] = {&Serial2, &Serial1};     // [0] = kit A, [1] = kit B
static LineBuffer uwbBuf[2];
static uint32_t uwbOk[2] = {0, 0}, uwbBad[2] = {0, 0}, uwbRate[2] = {0, 0}, uwbWinMs = 0, uwbWinCnt[2] = {0, 0};
static bool uwbDebug = false;

static bool oledOk = false; static int oledRow = 8; static uint32_t oledDrawMs = 0;
static bool swPos = false, swRaw = false; static uint32_t swChangeMs = 0;
static uint32_t lastTelMs = 0, lastBattMs = 0, lastSaveMs = 0; static float savedTotal = 0;
static float vbat = 0;

// BLE
static BLEServer* bleServer = nullptr; static BLECharacteristic* bleTx = nullptr;
static volatile bool bleUp = false, bleJustConnected = false, bleJustDropped = false, bleSecureEvt = false, bleFreshCand = false, bleSecureNow = false;
static volatile uint8_t bleAuthFails = 0; static volatile uint8_t blePeer[6] = {0}; static volatile bool bleHavePeer = false;
static uint32_t bleConnAtMs = 0; static char blePinSet[8] = ""; static volatile uint32_t bleConnMs = 0;
static volatile uint8_t rxBuf[1024]; static volatile uint16_t rxHead = 0, rxTail = 0;     // BLE task writes head, loop() reads tail
static LineBuffer bleLine;
static bool sendCfgNow = false;

// ================================================================================================ outputs
static void speedOut(int side, float v) {
  int pin = side ? PIN_SPEED_R : PIN_SPEED_L;
  v *= side ? SPEED_TRIM_R : SPEED_TRIM_L;
  uint32_t duty = 0;
  if (v >= 0.02f) {
    float f = clampv(v / SPEED_AT_FULL_MS, 0.0f, 1.0f);
    float volts = clampv(MIN_RUN_V + f * (BOARD_FULLSCALE_V - MIN_RUN_V), BOARD_MIN_V, BOARD_FULLSCALE_V);
    duty = (uint32_t)(clampv(volts / SPEED_FULLSCALE_V, 0.0f, 1.0f) * ((1 << SPEED_PWM_BITS) - 1));
  }
  ledcWrite(pin, duty);
}
static void brakeOut(float b) {
#if HAS_BRAKE
  bool on = b > 0.5f;
  digitalWrite(PIN_BRAKE_L, on == (bool)BRAKE_ACTIVE_HIGH); digitalWrite(PIN_BRAKE_R, on == (bool)BRAKE_ACTIVE_HIGH);
#endif
}
static void allStop() { ledcWrite(PIN_SPEED_L, 0); ledcWrite(PIN_SPEED_R, 0); }

// ================================================================================================ sensors
void IRAM_ATTR isrEchoL() { if (digitalRead(PIN_US_ECHO_L)) echoRise[0] = micros(); else { echoWidth[0] = micros() - echoRise[0]; echoDone[0] = true; } }
void IRAM_ATTR isrEchoR() { if (digitalRead(PIN_US_ECHO_R)) echoRise[1] = micros(); else { echoWidth[1] = micros() - echoRise[1]; echoDone[1] = true; } }
void IRAM_ATTR isrHallL() { hallCount[0]++; }
void IRAM_ATTR isrHallR() { hallCount[1]++; }

static void ultrasonicService(uint32_t now) {
  // collect results of the last ping
  for (int i = 0; i < 2; i++) {
    if (echoDone[i]) {
      echoDone[i] = false;
      float w = (float)echoWidth[i];
      if (w > 120 && w < 30000) { float d = w * 0.0001715f; if (i) { usR = d; usOkMsR = now; } else { usL = d; usOkMsL = now; } }
    }
  }
  if (now - usOkMsL > 250) usL = -1;
  if (now - usOkMsR > 250) usR = -1;
  if (now - usTrigMs >= 60) {                    // next ping (both sensors share the trigger line)
    usTrigMs = now; echoDone[0] = echoDone[1] = false;
    digitalWrite(PIN_US_TRIG, HIGH); delayMicroseconds(12); digitalWrite(PIN_US_TRIG, LOW);
  }
}

static bool imuRead(float* a, float* g) {
  Wire.beginTransmission(IMU_ADDR); Wire.write(0x3B);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)IMU_ADDR, 14) != 14) return false;
  int16_t v[7]; for (int i = 0; i < 7; i++) { uint8_t h = Wire.read(), l = Wire.read(); v[i] = (int16_t)((h << 8) | l); }
  // GY-521 flat, X arrow toward the FRONT of the cart: X forward, Y left, Z up.  Change signs here if yours differs.
  a[0] = v[0] / 16384.0f; a[1] = v[1] / 16384.0f; a[2] = v[2] / 16384.0f;
  g[0] = v[4] / 131.0f * DEG2RAD; g[1] = v[5] / 131.0f * DEG2RAD; g[2] = v[6] / 131.0f * DEG2RAD;
  return true;
}
static void imuStep(uint32_t now, float dt) {
  float a[3], g[3];
  if (imuRead(a, g)) {
    bool frozen = (a[0] == lastAcc[0] && a[1] == lastAcc[1] && a[2] == lastAcc[2]);      // a live sensor always has a little noise
    frozenCount = frozen ? frozenCount + 1 : 0;
    lastAcc[0] = a[0]; lastAcc[1] = a[1]; lastAcc[2] = a[2];
    if (frozenCount < 50) { lastImuOkMs = now; att.update(dt, a[0], a[1], a[2], g[0] - gyroBias[0], g[1] - gyroBias[1], g[2] - gyroBias[2]); }
  }
  imuOk = (now - lastImuOkMs) < 150;
}
static bool imuStart() {
  Wire.beginTransmission(IMU_ADDR); Wire.write(0x6B); Wire.write(0x00);
  if (Wire.endTransmission() != 0) return false;
  delay(100);
  double s[3] = {0, 0, 0}; int n = 0; float a[3], g[3];
  for (int i = 0; i < 150; i++) { if (imuRead(a, g)) { s[0] += g[0]; s[1] += g[1]; s[2] += g[2]; n++; } delay(10); }
  if (n < 80) return false;
  for (int i = 0; i < 3; i++) gyroBias[i] = (float)(s[i] / n);
  lastImuOkMs = millis();
  return true;
}

static bool estopPressed() {
#if HAS_ESTOP_SENSE
  static int cnt = 0;
  bool p = digitalRead(PIN_ESTOP) == ESTOP_PRESSED_LEVEL;
  cnt = p ? min(cnt + 1, 5) : 0;
  return cnt >= 3;                                  // 3 loops (60 ms) in a row
#else
  return false;
#endif
}

static void batteryStep(uint32_t now, float dt) {
  if (now - lastBattMs < 100) return;
  lastBattMs = now;
  uint32_t mv = 0; for (int i = 0; i < 8; i++) mv += analogReadMilliVolts(PIN_VBAT);
  vbat = (mv / 8.0f) / 1000.0f * VBAT_RATIO * VBAT_CAL;
  batt.update(0.1f, vbat, out.vEst > 0.2f);
}

static void hallStep(uint32_t now, float* vMeas) {
#if HAS_HALL
  static uint32_t last = 0, prev[2] = {0, 0};
  if (now - last >= 200) {
    float dts = (now - last) * 0.001f; last = now;
    uint32_t c0 = hallCount[0], c1 = hallCount[1];
    float vl = (c0 - prev[0]) / HALL_PULSES_PER_REV * 3.14159265f * WHEEL_DIAM_M / dts;
    float vr = (c1 - prev[1]) / HALL_PULSES_PER_REV * 3.14159265f * WHEEL_DIAM_M / dts;
    prev[0] = c0; prev[1] = c1; *vMeas = 0.5f * (vl + vr);
  }
#else
  (void)now; (void)vMeas;
#endif
}

// ================================================================================================ UWB
static void uwbService(uint32_t now) {
  for (int k = 0; k < 2; k++) {
    int guard = 0;
    while (uwbPort[k]->available() && guard++ < 200) {
      char c = (char)uwbPort[k]->read();
      if (!uwbBuf[k].push(c)) continue;
      float d; bool ok = parseUwbLine(uwbBuf[k].line(), &d, UWB_NO_UNIT_SCALE);
      if (uwbDebug) Serial.printf("[UWB %c] %s  ->  %s %.3f m\n", k ? 'B' : 'A', uwbBuf[k].line(), ok ? "OK" : "IGNORED", ok ? d : 0.0f);
      if (!ok) { uwbBad[k]++; continue; }
      uwbOk[k]++; uwbWinCnt[k]++;
      bool left = (k == 0) == (bool)UWB_A_IS_LEFT;
      float t = now * 0.001f;
      if (left) trk.pushLeft(t, d); else trk.pushRight(t, d);
    }
  }
  if (now - uwbWinMs >= 1000) { uwbWinMs = now; for (int k = 0; k < 2; k++) { uwbRate[k] = uwbWinCnt[k]; uwbWinCnt[k] = 0; } }
}

// ================================================================================================ BLE
class ServerCb : public BLEServerCallbacks {
  // Same callback form the display firmware uses (it compiles on this core). The negotiated MTU is not reported
  // through it, so bleSend() assumes the small default for the first 2 s after connecting, then the 247 we asked for.
  void onConnect(BLEServer*) override { bleConnMs = millis(); bleUp = true; bleJustConnected = true; }
  void onDisconnect(BLEServer*) override { bleUp = false; bleJustDropped = true; }
};
#if CART_BLE_ENCRYPT
// What the Bluetooth stack tells us about the link's protection. These run on the Bluetooth task, so they only set flags;
// bleService() (the main loop) acts on them.
class SecCb : public BLESecurityCallbacks {
  uint32_t onPassKeyRequest() override { return BLESecurity::getPassKey(); }
  void onPassKeyNotify(uint32_t) override { bleFreshCand = true; }       // only happens while a NEW phone pairs with the passkey
  bool onSecurityRequest() override { return true; }
  bool onConfirmPIN(uint32_t) override { return true; }
#if defined(CONFIG_BLUEDROID_ENABLED)
  void onAuthenticationComplete(esp_ble_auth_cmpl_t d) override {
    if (d.success) { memcpy((void*)blePeer, d.bd_addr, 6); bleHavePeer = true; bleSecureNow = true; bleSecureEvt = true; }
    else if (bleAuthFails < 250) bleAuthFails++;
  }
#endif
#if defined(CONFIG_NIMBLE_ENABLED)
  void onAuthenticationComplete(ble_gap_conn_desc* d) override {
    if (d && d->sec_state.encrypted) { bleSecureNow = true; bleSecureEvt = true; } else if (bleAuthFails < 250) bleAuthFails++;
  }
#endif
};
// One phone at a time: forget every other phone's Bluetooth bond (Bluedroid, i.e. the classic ESP32 this cart uses).
static void bleForgetBonds(bool keepCurrent) {
#if defined(CONFIG_BLUEDROID_ENABLED)
  int n = esp_ble_get_bond_device_num(); if (n <= 0) return;
  esp_ble_bond_dev_t* list = (esp_ble_bond_dev_t*)malloc(sizeof(esp_ble_bond_dev_t) * n); if (!list) return;
  int m = n; if (esp_ble_get_bond_device_list(&m, list) == ESP_OK)
    for (int i = 0; i < m; i++) if (!(keepCurrent && bleHavePeer && !memcmp(list[i].bd_addr, (const void*)blePeer, 6))) esp_ble_remove_bond_device(list[i].bd_addr);
  free(list);
#endif
}
// The passkey a NEW phone must type. While the pairing window is open it is the PIN on the screen; otherwise it is a random number
// nobody knows (so an unpaired phone cannot pair at all, and a bonded phone reconnects with the key it already holds).
static void bleSyncPasskey(bool open, const char* pin) {
  char want[8]; if (open) snprintf(want, sizeof(want), "%s", pin); else want[0] = 0;
  if (!strcmp(want, blePinSet) && !(want[0] == 0 && bleJustConnected)) return;
  strcpy(blePinSet, want);
  uint32_t v = open ? (uint32_t)atol(pin) : (esp_random() % 900000u) + 100000u;
  BLESecurity::setPassKey(true, v);
}
#endif
class RxCb : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) override {
    String v = c->getValue();
    for (size_t i = 0; i < v.length(); i++) {
      uint16_t nh = (rxHead + 1) % sizeof(rxBuf);
      if (nh == rxTail) return;                        // full: drop (the phone repeats what matters)
      rxBuf[rxHead] = (uint8_t)v[i]; rxHead = nh;
    }
  }
};
static void bleSend(const char* s, int n) {
  if (!bleUp || !bleTx || n <= 0) return;
  int mtu = (millis() - bleConnMs > 2000) ? 247 : 23;
  int chunk = clampv(mtu - 3, 20, 200);
  for (int i = 0; i < n; i += chunk) {
    bleTx->setValue((uint8_t*)(s + i), min(chunk, n - i));
    bleTx->notify();
    if (n > chunk) delay(8);
  }
}
static void bleStart() {
  BLEDevice::init("HandleCaddie_Cart");
  BLEDevice::setMTU(247);
#if CART_BLE_ENCRYPT
  BLESecurity* sec = new BLESecurity();
  sec->setCapability(ESP_IO_CAP_OUT);                       // we can show a passkey, nothing more: the phone types it
  sec->setAuthenticationMode(true, true, true);             // bonding + man-in-the-middle protection + LE Secure Connections
  sec->setPassKey(true, (esp_random() % 900000u) + 100000u);
  BLEDevice::setSecurityCallbacks(new SecCb());
#endif
  bleServer = BLEDevice::createServer();
  bleServer->setCallbacks(new ServerCb());
  BLEService* svc = bleServer->createService(NUS_SERVICE);
  #if CART_BLE_ENCRYPT
  bleTx = svc->createCharacteristic(NUS_TX, BLECharacteristic::PROPERTY_NOTIFY | BLECharacteristic::PROPERTY_READ_AUTHEN);
  bleTx->setAccessPermissions(ESP_GATT_PERM_READ_ENC_MITM);
#else
  bleTx = svc->createCharacteristic(NUS_TX, BLECharacteristic::PROPERTY_NOTIFY);
#endif
  bleTx->addDescriptor(new BLE2902());
  BLECharacteristic* rx = svc->createCharacteristic(NUS_RX, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR
#if CART_BLE_ENCRYPT
    | BLECharacteristic::PROPERTY_WRITE_AUTHEN
#endif
  );
#if CART_BLE_ENCRYPT
  rx->setAccessPermissions(ESP_GATT_PERM_WRITE_ENC_MITM);
  rx->setCallbacks(new RxCb());
#else
  rx->setCallbacks(new RxCb());
#endif
  svc->start();
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(NUS_SERVICE); adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

// ================================================================================================ settings
static void applySettings() {
  sup.follow().cfg().targetM = cfgFd;
  sup.follow().cfg().vMax = cfgVm;
  sup.cfg().descentVMax = cfgDc;
  sup.cfg().holdDeg = cfgHh ? 3.0f : 90.0f;
  sup.cfg().hasBrake = HAS_BRAKE; sup.cfg().hasSpeedSense = HAS_HALL;     // routes around hazards need HAS_HALL 1 (measured wheel speed)
}
static void saveSettings() { prefs.putFloat("fd", cfgFd); prefs.putFloat("vm", cfgVm); prefs.putFloat("dc", cfgDc); prefs.putBool("hh", cfgHh); }
static void sendCfg() { char b[140]; int n = formatCfg(b, sizeof(b), cfgFd, cfgVm, cfgDc, cfgHh, FW_VERSION, HAS_HALL != 0); bleSend(b, n); }
static void sendTel(uint32_t now) {
  TelData t;
  t.yawDeg = out.yawDeg; t.navOk = sup.navOk(); t.navShow = (out.navState != 0); t.navX = out.navX; t.navY = out.navY; t.navHeadDeg = out.navHeadDeg; t.navSeg = out.navSeg; t.navState = out.navState;
  t.mode = out.mode; t.volts = vbat; t.soc = batt.percent();
  t.pitch = att.pitchDeg() - pitchOff; t.roll = att.rollDeg() - rollOff; t.speed = out.vEst;
  t.range = trk.rangeOk() ? trk.range() : -1.0f; t.bearingOk = trk.bearingOk(); t.bearingDeg = out.bearingDeg;
  t.ml = (int)clampv(out.vL / VM_MAX * 100.0f, 0.0f, 100.0f); t.mr = (int)clampv(out.vR / VM_MAX * 100.0f, 0.0f, 100.0f);
  t.bk = (int)(out.brake * 100.0f);
  float o = -1; if (usL > 0) o = usL; if (usR > 0 && (o < 0 || usR < o)) o = usR;
  t.obs = o; t.tripM = odo.tripMiles() / M2MILE; t.totM = odo.totalMetres();
  t.faults = out.faults; t.flags = out.flags;
  char b[340]; int n = formatTel(b, sizeof(b), t); bleSend(b, n); lastTelMs = now;
}

static void handleMsg(const Msg& m, uint32_t now) {
  switch (m.kind) {
    case MsgKind::HELLO: sendCfgNow = true; lastTelMs = 0; break;
    case MsgKind::MODE:
      if (m.mode == Mode::NAV) {                                       // drive the route the phone staged: only when everything it relies on is in order
        if (!out.faults && sup.navOk() && sup.nav().ready() && sup.nav().begin()) { reqMode = Mode::NAV; }
        else { const char* r = "{\"k\":\"nav\",\"ok\":0}\n"; bleSend(r, strlen(r)); }
      } else if (m.mode == Mode::PARK || !out.faults) reqMode = m.mode;      // faults refuse driving modes (supervisor too)
      break;
    case MsgKind::NAVP: if (m.navI == 0) { sup.nav().clearFinished(); sup.nav().stageClear(); } sup.nav().stagePoint(m.navI, m.navX, m.navY); break;
    case MsgKind::NAVGO: { bool ok = sup.navOk() && sup.nav().commit(m.navN, m.navV); sup.nav().heartbeat();
      char r[48]; int n = snprintf(r, sizeof(r), "{\"k\":\"nav\",\"ok\":%d}\n", ok ? 1 : 0); bleSend(r, n); break; }
    case MsgKind::NAVHB: sup.nav().heartbeat(); break;
    case MsgKind::JOY: joyX = m.joyX; joyY = m.joyY; lastJoyMs = now; break;
    case MsgKind::SET:
      if (m.hasFd) cfgFd = m.fd;
      if (m.hasVm) cfgVm = m.vm;
      if (m.hasDc) cfgDc = m.dc;
      if (m.hasHh) cfgHh = m.hh;
      applySettings(); saveSettings(); sendCfgNow = true; break;
    case MsgKind::HOLD: hold.onHold(m.hold); break;
    case MsgKind::CMD:
      if (m.cmd == CmdKind::STOP) reqMode = Mode::PARK;
      else if (m.cmd == CmdKind::CLEAR) clearReq = true;
      else if (m.cmd == CmdKind::LEVEL) {
        float p = att.pitchDeg(), r = att.rollDeg();
        if (reqMode == Mode::PARK && fabsf(p) < 10 && fabsf(r) < 10 && out.vEst < 0.05f) { pitchOff = p; rollOff = r; prefs.putFloat("po", p); prefs.putFloat("ro", r); }
      }
      else if (m.cmd == CmdKind::TRIP0) odo.newTrip();
      break;
    default: break;
  }
}
// A phone proved it holds the key (or just paired): from here on it may drive. Starts clean, in PARK, like any new connection.
static void onPhoneAuthed() {
  reqMode = Mode::PARK; hold.onConnect(); lastJoyMs = 0; joyX = joyY = 0; sendCfgNow = true; lastTelMs = 0;
}
static void saveKeyChange() {
  uint8_t k[Auth::KEY_LEN]; bool erase = false;
  if (!auth.takeKeyChange(k, &erase)) return;
  if (erase) prefs.remove("akey"); else prefs.putBytes("akey", k, Auth::KEY_LEN);
}
static void bleService(uint32_t now) {
#if CART_BLE_ENCRYPT
  static bool lastOpen = false;
  bool open = auth.pairingOpen(now);
  bleSyncPasskey(open, auth.pin());
  if (open && !lastOpen) bleAuthFails = 0;                                    // a fresh window starts with a clean count of wrong passkeys
  lastOpen = open;
  if (bleAuthFails >= 5 && open) { auth.closePairing(); bleAuthFails = 0; Serial.println("Too many wrong passkeys: pairing closed."); }
#endif
  if (bleJustConnected) {
    bleJustConnected = false; bleConnAtMs = now; bleSecureNow = false; bleFreshCand = false; bleSecureEvt = false;
    auth.requireSecureLink(CART_BLE_ENCRYPT != 0); auth.setLink(false, false);
    char c[200]; int n = auth.onConnect(now, c, sizeof(c));
#if !CART_BLE_ENCRYPT
    bleSend(c, n);                                                   // the app also asks with "hello", in case this went out before it was listening
#else
    (void)n;                                                         // with protection on, the challenge goes out once the link is encrypted
#endif
  }
#if CART_BLE_ENCRYPT
  if (bleSecureEvt) {
    bleSecureEvt = false;
    bool fresh = bleFreshCand && auth.pairingOpen(now); bleFreshCand = false;
    auth.setLink(true, fresh);
    char c[200]; int n = auth.onConnect(now, c, sizeof(c)); bleSend(c, n);
  }
  if (bleUp && !bleSecureNow && bleConnAtMs && now - bleConnAtMs > 30000) {        // a phone that never secures the link is cut off
    bleConnAtMs = 0; if (bleServer) bleServer->disconnect(bleServer->getConnId());
  }
#endif
  if (bleJustDropped) {
    bleJustDropped = false; bleSecureNow = false; bleHavePeer = false; bleConnAtMs = 0;
    auth.onDisconnect();
    if (reqMode == Mode::MANUAL || reqMode == Mode::NAV) reqMode = Mode::PARK;     // FOLLOW keeps going: it runs on the fob. A route needs the phone watching.
    joyX = joyY = 0; lastJoyMs = 0;
    BLEDevice::startAdvertising();
  }
  int guard = 0;
  while (rxTail != rxHead && guard++ < 512) {
    char c = (char)rxBuf[rxTail]; rxTail = (rxTail + 1) % sizeof(rxBuf);
    if (!bleLine.push(c)) continue;
    char reply[300];
    Auth::Result r = auth.handle(bleLine.line(), now, reply, sizeof(reply));
    if (reply[0]) bleSend(reply, strlen(reply));
    if (r.ev != Auth::Event::NONE) {
      onPhoneAuthed(); saveKeyChange();
#if CART_BLE_ENCRYPT
      if (r.ev == Auth::Event::PAIRED) bleForgetBonds(true);       // the phone just paired replaces every other phone
#endif
    }
    if (r.consumed || !auth.authed()) continue;                    // not authenticated: nothing else is obeyed
    Msg m; if (parseMsg(bleLine.line(), m)) handleMsg(m, now);
  }
  if (sendCfgNow && bleUp && auth.authed()) { sendCfgNow = false; sendCfg(); }
}

// ================================================================================================ switch + LEDs
static void switchService(uint32_t now) {
  bool raw = digitalRead(PIN_SWITCH) == LOW;
  if (raw != swRaw) { swRaw = raw; swChangeMs = now; }
  if (swRaw != swPos && now - swChangeMs >= 40) {
    swPos = swRaw; hold.onSwitch(swPos);
    // six quick flips, only while parked and still: open the pairing window (a PIN shows on the OLED)
    if (pairGesture.onEdge(now) && reqMode == Mode::PARK && out.vEst < 0.1f) { auth.openPairing(now); Serial.printf("Pairing open for 2 minutes. PIN %s\n", auth.pin()); }
  }
}
static void ledService(uint32_t now) {
  bool g = false, r = false;
  if (out.faults) r = (now / 125) % 2;                                      // fast red blink: fault
  else if (out.flags & FL_PAUSED) r = true;                                 // steady red: paused by you
  else if (out.flags & FL_AUTOHOLD) { bool b = (now / 400) % 2; g = b; r = b; }       // blinking amber: waiting for the green
  else if (out.mode == Mode::PARK) g = (now % 2000) < 150;                  // brief green flash every 2 s: parked
  else g = true;                                                            // steady green: following / manual
  digitalWrite(PIN_LED_GREEN, g); digitalWrite(PIN_LED_RED, r);
}

// ================================================================================================ OLED
static void drawOled(uint32_t now) {
  char a[28], b[28], c[28], d[28];
  oled.clearBuffer();
  bool page2 = (now / 3500) % 2;
  const char* alert = nullptr; const char* sub = "";
  if (out.faults & F_ESTOP) { alert = "E-STOP"; sub = "release to continue"; }
  else if (out.faults & F_TIP) { alert = "TIPPED"; sub = "set upright, then Clear"; }
  else if (out.faults & F_IMU) { alert = "TILT SENSOR"; sub = "check GY-521 wiring"; }
  else if (out.faults & F_LOWBATT) { alert = "LOW BATTERY"; sub = "charge soon"; }
  else if (out.flags & FL_PAUSED) { alert = "PAUSED"; sub = "push switch to resume"; }
  else if (out.flags & FL_AUTOHOLD) { alert = "GREEN AHEAD"; sub = "waiting - switch = go"; }
  else if (out.mode == Mode::FOLLOW && (out.flags & FL_UWB_LOST)) { alert = "SIGNAL LOST"; sub = "fob not heard"; }
  else if (out.flags & FL_TOO_FAR) { alert = "TOO FAR"; sub = "come closer"; }
  else if (out.flags & FL_OBSTACLE) { alert = "OBSTACLE"; sub = "blocked ahead"; }
  else if (out.flags & FL_HOLD) { alert = "HILL HOLD"; sub = "brake on slope"; }
  if (alert) {
    oled.setFont(u8g2_font_10x20_tr); oled.drawStr((128 - oled.getStrWidth(alert)) / 2, 28, alert);
    oled.setFont(u8g2_font_6x12_tr); oled.drawStr((128 - oled.getStrWidth(sub)) / 2, 50, sub);
  } else if (auth.pairingOpen(now)) {
    oled.setFont(u8g2_font_6x12_tr); oled.drawStr((128 - oled.getStrWidth("PAIR WITH THE APP")) / 2, 12, "PAIR WITH THE APP");
    oled.setFont(u8g2_font_10x20_tr); oled.drawStr((128 - oled.getStrWidth(auth.pin())) / 2, 40, auth.pin());
    snprintf(a, sizeof(a), "type this PIN  %us", (unsigned)auth.pairingLeftS(now));
    oled.setFont(u8g2_font_6x12_tr); oled.drawStr((128 - oled.getStrWidth(a)) / 2, 60, a);
  } else if (!page2) {
    float miles = batt.percent() / 100.0f * PACK_WH / WH_PER_MILE;
    snprintf(a, sizeof(a), "BAT %3.0f%%   %4.1f V", batt.percent(), vbat);
    snprintf(b, sizeof(b), "%-6s %4.1f mph", out.mode == Mode::FOLLOW ? "FOLLOW" : out.mode == Mode::MANUAL ? "MANUAL" : "PARK", out.vEst * MPS2MPH);
    snprintf(c, sizeof(c), "~%.1f mi left", miles);
    snprintf(d, sizeof(d), "SLOPE %+.0f%%  %s", out.slopePct, bleUp ? "APP" : "no app");
    oled.setFont(u8g2_font_6x12_tr);
    oled.drawStr(0, 12, a); oled.drawStr(0, 28, b); oled.drawStr(0, 44, c); oled.drawStr(0, 60, d);
  } else {
    float o = -1; if (usL > 0) o = usL; if (usR > 0 && (o < 0 || usR < o)) o = usR;
    if (trk.rangeOk()) snprintf(a, sizeof(a), "FOB %.1f m  %+.0f deg", trk.range(), out.bearingDeg); else snprintf(a, sizeof(a), "FOB  --");
    snprintf(b, sizeof(b), "LINK L%u R%u /s", (unsigned)uwbRate[UWB_A_IS_LEFT ? 0 : 1], (unsigned)uwbRate[UWB_A_IS_LEFT ? 1 : 0]);
    if (o > 0) snprintf(c, sizeof(c), "OBSTACLE %.1f m", o); else snprintf(c, sizeof(c), "OBSTACLE clear");
    snprintf(d, sizeof(d), "TRIP %.1f  ALL %.0f mi", odo.tripMiles(), odo.totalMiles());
    oled.setFont(u8g2_font_6x12_tr);
    oled.drawStr(0, 12, a); oled.drawStr(0, 28, b); oled.drawStr(0, 44, c); oled.drawStr(0, 60, d);
  }
  oledRow = 0;                                           // start sending: one tile row per control loop (3 ms each, never a 25 ms stall)
}
static void oledService(uint32_t now) {
  if (!oledOk) return;
  if (oledRow < 8) { oled.updateDisplayArea(0, oledRow, 16, 1); oledRow++; }
  else if (now - oledDrawMs >= 250) { oledDrawMs = now; drawOled(now); }
}

// ================================================================================================ serial console (debug only)
static void console(const String& line) {
  if (line == "uwb") { uwbDebug = !uwbDebug; Serial.printf("UWB line echo %s\n", uwbDebug ? "ON (shows each raw line and what was parsed)" : "off"); }
  else if (line == "st") {
    Serial.printf("mode %d faults %u flags %u | bat %.2f V %.0f%% | pitch %.1f roll %.1f | range %.2f m ok=%d brg %.0f | us L %.2f R %.2f\n",
                  (int)out.mode, out.faults, out.flags, vbat, batt.percent(), att.pitchDeg() - pitchOff, att.rollDeg() - rollOff,
                  trk.range(), trk.rangeOk(), out.bearingDeg, usL, usR);
    Serial.printf("UWB lines parsed A %lu (ignored %lu)  B %lu (ignored %lu)  rate A %lu/s B %lu/s\n",
                  (unsigned long)uwbOk[0], (unsigned long)uwbBad[0], (unsigned long)uwbOk[1], (unsigned long)uwbBad[1], (unsigned long)uwbRate[0], (unsigned long)uwbRate[1]);
  }
  else if (line == "pair") { auth.openPairing(millis()); Serial.printf("Pairing open for 2 minutes. PIN %s (also on the OLED)\n", auth.pin()); }
  else if (line == "unpair") { auth.forget(millis()); saveKeyChange();
#if CART_BLE_ENCRYPT
    bleForgetBonds(false);
#endif
    Serial.printf("Key forgotten: no phone is paired now. Pairing is open for 5 minutes, PIN %s\n", auth.pin()); }
  else Serial.println("commands: uwb (toggle raw UWB line echo), st (status), pair (open pairing), unpair (forget the paired phone)");
}

// ================================================================================================ Arduino
void setup() {
  // outputs first, and OFF
  pinMode(PIN_BRAKE_L, OUTPUT); pinMode(PIN_BRAKE_R, OUTPUT);
  digitalWrite(PIN_BRAKE_L, !BRAKE_ACTIVE_HIGH); digitalWrite(PIN_BRAKE_R, !BRAKE_ACTIVE_HIGH);
  ledcAttach(PIN_SPEED_L, SPEED_PWM_HZ, SPEED_PWM_BITS); ledcAttach(PIN_SPEED_R, SPEED_PWM_HZ, SPEED_PWM_BITS);
  allStop();
  pinMode(PIN_LED_GREEN, OUTPUT); pinMode(PIN_LED_RED, OUTPUT); digitalWrite(PIN_LED_GREEN, LOW); digitalWrite(PIN_LED_RED, LOW);
  pinMode(PIN_SWITCH, INPUT_PULLUP);
  pinMode(PIN_US_TRIG, OUTPUT); digitalWrite(PIN_US_TRIG, LOW);
  pinMode(PIN_US_ECHO_L, INPUT); pinMode(PIN_US_ECHO_R, INPUT);
  attachInterrupt(PIN_US_ECHO_L, isrEchoL, CHANGE); attachInterrupt(PIN_US_ECHO_R, isrEchoR, CHANGE);
  pinMode(PIN_HALL_L, INPUT); pinMode(PIN_HALL_R, INPUT);
  attachInterrupt(PIN_HALL_L, isrHallL, RISING); attachInterrupt(PIN_HALL_R, isrHallR, RISING);
  pinMode(PIN_ESTOP, INPUT);
  analogSetPinAttenuation(PIN_VBAT, ADC_11db);

  Serial.begin(115200);
  Serial.printf("\nHandle Caddie CART firmware %s\n", FW_VERSION);
  Serial2.begin(UWB_BAUD, SERIAL_8N1, PIN_UWB_A_RX, PIN_UWB_A_TX);
  Serial1.begin(UWB_BAUD, SERIAL_8N1, PIN_UWB_B_RX, PIN_UWB_B_TX);

  Wire.begin(PIN_SDA, PIN_SCL); Wire.setClock(400000); Wire.setTimeOut(20);
  Wire.beginTransmission(0x3C); oledOk = (Wire.endTransmission() == 0);
  if (oledOk) { oled.begin(); oled.clearBuffer(); oled.setFont(u8g2_font_6x12_tr); oled.drawStr(0, 12, "HANDLE CADDIE CART"); oled.drawStr(0, 28, "keep the cart STILL"); oled.drawStr(0, 44, "calibrating tilt..."); oled.sendBuffer(); }

  prefs.begin("cart", false);
  cfgFd = prefs.getFloat("fd", 2.5f); cfgVm = prefs.getFloat("vm", 1.6f); cfgDc = prefs.getFloat("dc", 1.2f); cfgHh = prefs.getBool("hh", true);
  cfgFd = clampv(cfgFd, FD_MIN, FD_MAX); cfgVm = clampv(cfgVm, VM_MIN, VM_MAX); cfgDc = clampv(cfgDc, DC_MIN, DC_MAX);
  pitchOff = prefs.getFloat("po", 0); rollOff = prefs.getFloat("ro", 0);
  savedTotal = prefs.getFloat("tot", 0); odo.load(savedTotal, 0);
  applySettings();
  {   // the paired phone's key (none at first boot: pairing then opens by itself)
    uint8_t k[Auth::KEY_LEN]; bool have = prefs.getBytesLength("akey") == Auth::KEY_LEN && prefs.getBytes("akey", k, Auth::KEY_LEN) == Auth::KEY_LEN;
    auth.begin(have ? k : nullptr, millis());
    if (!have) Serial.printf("No phone paired yet. Pairing is open for 5 minutes, PIN %s (also on the OLED)\n", auth.pin());
  }

  bool ok = imuStart();
  if (!ok) Serial.println("IMU NOT FOUND at 0x68 - the cart will stay in PARK with a tilt-sensor fault.");
  swRaw = swPos = (digitalRead(PIN_SWITCH) == LOW); hold.begin(swPos);
  bleStart();

  // hardware watchdog: if the loop ever hangs the chip resets, which floats the speed pins (pull-downs -> zero speed)
  esp_task_wdt_config_t w; w.timeout_ms = 600; w.idle_core_mask = 0; w.trigger_panic = true;
  if (esp_task_wdt_init(&w) != ESP_OK) esp_task_wdt_reconfigure(&w);
  esp_task_wdt_add(NULL);
  Serial.println("Ready. Console: 'uwb' echoes raw UWB lines, 'st' prints status, 'pair' opens pairing, 'unpair' forgets the phone.");
}

void loop() {
  esp_task_wdt_reset();
  static uint32_t lastCtlUs = 0; static String cbuf;
  uint32_t nowUs = micros(), now = millis();

  // background work every pass
  uwbService(now); bleService(now); ultrasonicService(now); switchService(now);
  while (Serial.available()) { char ch = Serial.read(); if (ch == '\n' || ch == '\r') { cbuf.trim(); if (cbuf.length()) console(cbuf); cbuf = ""; } else if (cbuf.length() < 40) cbuf += ch; }

  if (nowUs - lastCtlUs < 20000) { delay(1); return; }                 // control loop: 50 Hz
  float dt = clampv((nowUs - lastCtlUs) * 1e-6f, 0.005f, 0.1f);
  lastCtlUs = nowUs;
  float t = now * 0.001f;

  imuStep(now, dt);
  batteryStep(now, dt);
  static float vMeas = 0; hallStep(now, &vMeas);

  trk.predict(dt, att.yawRate());
  trk.update(t);

  SupIn in; in.dt = dt; in.req = reqMode;
  in.rangeValid = trk.rangeOk(); in.rangeAgeS = trk.ageS(t); in.range = trk.range(); in.rangeRate = trk.rate();
  in.bearing = trk.bearing(); in.bearingOk = trk.bearingOk(); in.vMeas = vMeas;
  in.pitchDeg = att.pitchDeg() - pitchOff; in.rollDeg = att.rollDeg() - rollOff; in.yawRate = att.yawRate();
  in.imuOk = imuOk; in.batteryLow = batt.low(); in.estopPressed = estopPressed();
  in.obsL = usL; in.obsR = usR;
  in.clearFaults = clearReq; clearReq = false;
  in.joyX = joyX; in.joyY = joyY; in.joyAgeS = lastJoyMs ? (now - lastJoyMs) * 0.001f : 99.0f;
  in.autoHold = hold.autoHold(); in.paused = hold.paused(); in.overridden = hold.overridden();
  out = sup.update(in);

  if (out.faults) reqMode = Mode::PARK;                                // after any fault the driving mode must be asked for again
  if (reqMode == Mode::NAV && !sup.nav().running()) reqMode = Mode::PARK;   // the route ended (arrived, switch, or a safety stop): stay put until asked again

  speedOut(0, out.vL); speedOut(1, out.vR); brakeOut(out.brake);
  odo.add(out.vEst * dt);

  ledService(now);
  oledService(now);
  if (bleUp && auth.authed() && now - lastTelMs >= 200) sendTel(now);

  if (now - lastSaveMs > 60000) {                                      // save the odometer at most once a minute, and only if it moved
    lastSaveMs = now;
    if (odo.totalMetres() - savedTotal > 20.0f) { savedTotal = odo.totalMetres(); prefs.putFloat("tot", savedTotal); }
  }
}
