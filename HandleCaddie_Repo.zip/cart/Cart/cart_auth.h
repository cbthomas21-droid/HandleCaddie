// cart_auth.h - who may drive the cart. Pure C++ (no Arduino calls) so it is unit-tested on a PC (tests/test_auth.cpp).
//
// THREAT THIS ANSWERS: another phone (or a stray app) within Bluetooth range connecting to the cart and driving it.
// HOW: the phone and cart share a secret key. The cart sends a fresh random challenge on every connection; the phone answers
// with HMAC-SHA256(key, challenge). Until it does, the cart ignores every command and sends no telemetry.
// PAIRING: the key is created by pairing. Pairing is only possible while the cart's "pairing window" is open, which needs
// someone standing at the cart: it opens on its own while the cart has no key at all, or after flipping the pause switch 6 times
// quickly (PairGesture), or from the serial console. While open, the OLED shows a random 6-digit PIN that the phone must send.
//
// WHAT IT DOES NOT DO: the Bluetooth link itself is not encrypted, so someone who records the radio traffic DURING the
// few seconds of pairing could learn the key. Pairing in a car park, not in a crowd, closes that in practice. Real link
// encryption (BLE Secure Connections) is the next layer; see CART_DESIGN.md.
#pragma once
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "cart_proto.h"

namespace cart {

// ------------------------------------------------------------------------------------------------ SHA-256 / HMAC
struct Sha256 {
  uint32_t h[8]; uint8_t buf[64]; uint64_t bits; size_t n;
  static uint32_t rotr(uint32_t x, int s) { return (x >> s) | (x << (32 - s)); }
  void init() {
    static const uint32_t iv[8] = {0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
    memcpy(h, iv, sizeof(h)); bits = 0; n = 0;
  }
  void block(const uint8_t* p) {
    static const uint32_t K[64] = {
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
      0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
      0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};
    uint32_t w[64];
    for (int i = 0; i < 16; i++) w[i] = ((uint32_t)p[4 * i] << 24) | ((uint32_t)p[4 * i + 1] << 16) | ((uint32_t)p[4 * i + 2] << 8) | p[4 * i + 3];
    for (int i = 16; i < 64; i++) {
      uint32_t s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
      uint32_t s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
      w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
    for (int i = 0; i < 64; i++) {
      uint32_t S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25), ch = (e & f) ^ (~e & g), t1 = hh + S1 + ch + K[i] + w[i];
      uint32_t S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = S0 + mj;
      hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
  }
  void update(const uint8_t* d, size_t len) {
    bits += (uint64_t)len * 8;
    while (len) {
      size_t k = 64 - n; if (k > len) k = len;
      memcpy(buf + n, d, k); n += k; d += k; len -= k;
      if (n == 64) { block(buf); n = 0; }
    }
  }
  void final(uint8_t out[32]) {
    uint64_t total = bits;
    uint8_t pad = 0x80; update(&pad, 1);
    uint8_t zero = 0; while (n != 56) update(&zero, 1);
    uint8_t lenb[8]; for (int i = 0; i < 8; i++) lenb[i] = (uint8_t)(total >> (56 - 8 * i));
    update(lenb, 8);
    for (int i = 0; i < 8; i++) { out[4 * i] = (uint8_t)(h[i] >> 24); out[4 * i + 1] = (uint8_t)(h[i] >> 16); out[4 * i + 2] = (uint8_t)(h[i] >> 8); out[4 * i + 3] = (uint8_t)h[i]; }
  }
};

inline void sha256(const uint8_t* d, size_t n, uint8_t out[32]) { Sha256 s; s.init(); s.update(d, n); s.final(out); }

inline void hmacSha256(const uint8_t* key, size_t klen, const uint8_t* msg, size_t mlen, uint8_t out[32]) {
  uint8_t k[64]; memset(k, 0, sizeof(k));
  if (klen > 64) sha256(key, klen, k); else memcpy(k, key, klen);
  uint8_t ip[64], op[64];
  for (int i = 0; i < 64; i++) { ip[i] = k[i] ^ 0x36; op[i] = k[i] ^ 0x5c; }
  uint8_t inner[32];
  Sha256 s; s.init(); s.update(ip, 64); s.update(msg, mlen); s.final(inner);
  s.init(); s.update(op, 64); s.update(inner, 32); s.final(out);
}

inline void toHex(const uint8_t* b, size_t n, char* out) {
  static const char* d = "0123456789abcdef";
  for (size_t i = 0; i < n; i++) { out[2 * i] = d[b[i] >> 4]; out[2 * i + 1] = d[b[i] & 15]; }
  out[2 * n] = 0;
}
inline bool fromHex(const char* s, uint8_t* out, size_t n) {
  for (size_t i = 0; i < n; i++) {
    int v[2];
    for (int j = 0; j < 2; j++) {
      char c = s[2 * i + j];
      v[j] = (c >= '0' && c <= '9') ? c - '0' : (c >= 'a' && c <= 'f') ? c - 'a' + 10 : (c >= 'A' && c <= 'F') ? c - 'A' + 10 : -1;
      if (v[j] < 0) return false;
    }
    out[i] = (uint8_t)(v[0] * 16 + v[1]);
  }
  return true;
}
// compares n chars without stopping at the first difference (so the time taken says nothing about how much matched)
inline bool ctEqual(const char* a, const char* b, size_t n) {
  uint8_t d = 0; for (size_t i = 0; i < n; i++) d |= (uint8_t)(a[i] ^ b[i]); return d == 0;
}

// ------------------------------------------------------------------------------------------------ pairing gesture
// Six flips of the pause switch within five seconds opens the pairing window. The caller only feeds it while the cart is parked.
class PairGesture {
 public:
  static const int EDGES = 6; static const uint32_t WITHIN_MS = 5000;
  bool onEdge(uint32_t now) {
    for (int i = 0; i < EDGES - 1; i++) t_[i] = t_[i + 1];
    t_[EDGES - 1] = now;
    if (count_ < EDGES) count_++;
    if (count_ == EDGES && now - t_[0] <= WITHIN_MS) { count_ = 0; return true; }
    return false;
  }
  void reset() { count_ = 0; }
 private:
  uint32_t t_[EDGES] = {0}; int count_ = 0;
};

// ------------------------------------------------------------------------------------------------ the guard at the door
class Auth {
 public:
  typedef uint32_t (*RandFn)();
  static const int KEY_LEN = 16, NONCE_HEX = 16, TAG_HEX = 32, PIN_LEN = 6;
  static const uint32_t PAIR_WINDOW_MS = 120000, FIRST_WINDOW_MS = 300000, LOCKOUT_MS = 60000;
  static const int MAX_PAIR_TRIES = 5, MAX_AUTH_TRIES = 5;
  enum class Event : uint8_t { NONE, AUTHED, PAIRED };
  struct Result { bool consumed = false; Event ev = Event::NONE; };

  explicit Auth(RandFn r) : rnd_(r) {}

  /** Call once at boot with the stored key (or nullptr when there is none). With no key the pairing window opens by itself. */
  void begin(const uint8_t* key, uint32_t now) {
    hasKey_ = key != nullptr; if (key) memcpy(key_, key, KEY_LEN);
    authed_ = false; nonceOk_ = false; failures_ = 0; lockUntil_ = 0; open_ = false; keyDirty_ = false;
    if (!hasKey_) openPairing(now, FIRST_WINDOW_MS);
  }
  bool hasKey() const { return hasKey_; }

  void openPairing(uint32_t now, uint32_t windowMs = PAIR_WINDOW_MS) {
    open_ = true; openUntil_ = now + windowMs; pairTries_ = 0;
    uint32_t v = rnd_() % 1000000u; snprintf(pin_, sizeof(pin_), "%06u", (unsigned)v);
  }
  void closePairing() { open_ = false; pin_[0] = 0; }
  bool pairingOpen(uint32_t now) const { return open_ && (int32_t)(openUntil_ - now) > 0; }
  const char* pin() const { return pin_; }
  uint32_t pairingLeftS(uint32_t now) const { return pairingOpen(now) ? (openUntil_ - now + 999) / 1000 : 0; }

  /** Serial-console recovery: forget the key. The cart is then unpaired and (as at first boot) opens the pairing window. */
  void forget(uint32_t now) { hasKey_ = false; memset(key_, 0, KEY_LEN); authed_ = false; keyErase_ = true; openPairing(now, FIRST_WINDOW_MS); }

  bool authed() const { return authed_; }

  /**
   * The Bluetooth link's own protection (LE Secure Connections). When [requireSecure] is on, nothing the phone sends is looked at
   * until the link is encrypted. [fresh] = the phone was just paired with the passkey (the PIN) in this very connection, which proves
   * it knows the PIN, so the app may finish pairing without typing the PIN a second time.
   */
  void requireSecureLink(bool r) { requireSecure_ = r; }
  void setLink(bool secure, bool fresh) { secure_ = secure; fresh_ = secure && fresh; }
  bool linkSecure() const { return secure_; }

  /** A phone connected: start unauthenticated, and write the challenge line into [out]. Returns its length. */
  int onConnect(uint32_t now, char* out, size_t cap) { authed_ = false; newNonce(); return chal(now, out, cap); }
  void onDisconnect() { authed_ = false; nonceOk_ = false; secure_ = false; fresh_ = false; }

  /** True once after a new key was made (store it) or after forget() (erase it). */
  bool takeKeyChange(uint8_t outKey[KEY_LEN], bool* erase) {
    if (!keyDirty_ && !keyErase_) return false;
    *erase = keyErase_; if (keyDirty_) memcpy(outKey, key_, KEY_LEN);
    keyDirty_ = keyErase_ = false; return true;
  }

  /**
   * Feed one received line. [reply] gets any lines to send back (cleared first). If the result is not [consumed] the line is
   * not about authentication and the caller may act on it ONLY when authed().
   */
  Result handle(const char* line, uint32_t now, char* reply, size_t cap) {
    Result r; if (cap) reply[0] = 0;
    char k[12];
    if (!line || !getStr(line, "k", k, sizeof(k))) return r;
    if (requireSecure_ && !secure_) { r.consumed = true; return r; }       // an unprotected link: say nothing, obey nothing
    if (!strcmp(k, "hello") && !authed_) { if (!nonceOk_) newNonce(); chal(now, reply, cap); r.consumed = true; return r; }
    if (!strcmp(k, "auth")) { r.consumed = true; doAuth(line, now, reply, cap, r); return r; }
    if (!strcmp(k, "pair")) { r.consumed = true; doPair(line, now, reply, cap, r); return r; }
    return r;
  }

  // exposed for the tests / for computing the phone's answer on the same code
  static void tagFor(const uint8_t key[KEY_LEN], const char* nonce, char outHex[TAG_HEX + 1]) {
    uint8_t mac[32]; hmacSha256(key, KEY_LEN, (const uint8_t*)nonce, strlen(nonce), mac);
    toHex(mac, TAG_HEX / 2, outHex);
  }
  const char* nonce() const { return nonce_; }

 private:
  RandFn rnd_;
  uint8_t key_[KEY_LEN] = {0}; bool hasKey_ = false, keyDirty_ = false, keyErase_ = false;
  bool authed_ = false, requireSecure_ = false, secure_ = false, fresh_ = false;
  char nonce_[NONCE_HEX + 1] = {0}; bool nonceOk_ = false;
  int failures_ = 0; uint32_t lockUntil_ = 0;
  bool open_ = false; uint32_t openUntil_ = 0; int pairTries_ = 0; char pin_[PIN_LEN + 2] = {0};

  void newNonce() {
    uint8_t b[8]; for (int i = 0; i < 2; i++) { uint32_t v = rnd_(); for (int j = 0; j < 4; j++) b[4 * i + j] = (uint8_t)(v >> (8 * j)); }
    toHex(b, 8, nonce_); nonceOk_ = true;
  }
  int chal(uint32_t now, char* out, size_t cap) {
    return snprintf(out, cap, "{\"k\":\"chal\",\"n\":\"%s\",\"paired\":%d,\"pairing\":%d,\"sec\":%d,\"fresh\":%d}\n", nonce_, hasKey_ ? 1 : 0, pairingOpen(now) ? 1 : 0, secure_ ? 1 : 0, (fresh_ && pairingOpen(now)) ? 1 : 0);
  }
  static size_t len(const char* s) { return strlen(s); }

  void doAuth(const char* line, uint32_t now, char* reply, size_t cap, Result& r) {
    if (authed_) { snprintf(reply, cap, "{\"k\":\"auth\",\"ok\":1}\n"); return; }
    if ((int32_t)(lockUntil_ - now) > 0) { snprintf(reply, cap, "{\"k\":\"auth\",\"ok\":0,\"wait\":%u}\n", (unsigned)((lockUntil_ - now + 999) / 1000)); return; }
    if (!hasKey_) { snprintf(reply, cap, "{\"k\":\"auth\",\"ok\":0,\"np\":1}\n"); return; }
    char h[TAG_HEX + 4]; bool good = false;
    if (nonceOk_ && getStr(line, "h", h, sizeof(h)) && strlen(h) == TAG_HEX) {
      char want[TAG_HEX + 1]; tagFor(key_, nonce_, want);
      good = ctEqual(h, want, TAG_HEX);
    }
    nonceOk_ = false;                                   // a challenge is good for ONE answer: a recorded reply is useless
    if (good) { authed_ = true; failures_ = 0; r.ev = Event::AUTHED; snprintf(reply, cap, "{\"k\":\"auth\",\"ok\":1}\n"); return; }
    failures_++;
    int left = MAX_AUTH_TRIES - failures_;
    if (left <= 0) { lockUntil_ = now + LOCKOUT_MS; failures_ = 0; snprintf(reply, cap, "{\"k\":\"auth\",\"ok\":0,\"wait\":%u}\n", (unsigned)(LOCKOUT_MS / 1000)); return; }
    int n = snprintf(reply, cap, "{\"k\":\"auth\",\"ok\":0,\"left\":%d}\n", left);
    newNonce();
    if (n > 0 && (size_t)n < cap) chal(now, reply + n, cap - n);
  }

  void doPair(const char* line, uint32_t now, char* reply, size_t cap, Result& r) {
    if (!pairingOpen(now)) { snprintf(reply, cap, "{\"k\":\"paired\",\"ok\":0,\"closed\":1}\n"); return; }
    char p[16]; bool good = false;
    if (getStr(line, "pin", p, sizeof(p))) { if (strlen(p) == PIN_LEN) good = ctEqual(p, pin_, PIN_LEN); }
    else if (secure_ && fresh_) good = true;           // no PIN sent, but this encrypted link was made with the PIN a moment ago
    if (!good) {
      pairTries_++;
      int left = MAX_PAIR_TRIES - pairTries_;
      if (left <= 0) { closePairing(); snprintf(reply, cap, "{\"k\":\"paired\",\"ok\":0,\"closed\":1}\n"); }
      else snprintf(reply, cap, "{\"k\":\"paired\",\"ok\":0,\"left\":%d}\n", left);
      return;
    }
    for (int i = 0; i < 4; i++) { uint32_t v = rnd_(); for (int j = 0; j < 4; j++) key_[4 * i + j] = (uint8_t)(v >> (8 * j)); }
    hasKey_ = true; keyDirty_ = true; authed_ = true; closePairing(); r.ev = Event::PAIRED;
    char hex[KEY_LEN * 2 + 1]; toHex(key_, KEY_LEN, hex);
    snprintf(reply, cap, "{\"k\":\"paired\",\"ok\":1,\"key\":\"%s\"}\n", hex);
  }
};

}  // namespace cart
