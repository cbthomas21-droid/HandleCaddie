// cart_proto.h - phone link messages and UWB line parsing. Pure C++ (no Arduino calls) so it is unit-tested on a PC.
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "cart_logic.h"

namespace cart {

// ---------------------------------------------------------------------------------- tiny flat-JSON reader
// Messages are flat objects like {"k":"set","fd":2.5}. These helpers find a key and read its value; no allocation.
inline const char* findKey(const char* s, const char* key) {
  char pat[16]; int n = snprintf(pat, sizeof(pat), "\"%s\"", key);
  if (n <= 0 || n >= (int)sizeof(pat)) return nullptr;
  const char* p = strstr(s, pat);
  if (!p) return nullptr;
  p += n;
  while (*p == ' ') p++;
  if (*p != ':') return nullptr;
  p++;
  while (*p == ' ') p++;
  return p;
}
inline bool getNum(const char* s, const char* key, float* out) {
  const char* p = findKey(s, key); if (!p) return false;
  char* end; float v = strtof(p, &end);
  if (end == p || !isfinite(v)) return false;
  *out = v; return true;
}
inline bool getStr(const char* s, const char* key, char* out, size_t cap) {
  const char* p = findKey(s, key); if (!p || *p != '"') return false;
  p++; size_t i = 0;
  while (*p && *p != '"' && i + 1 < cap) out[i++] = *p++;
  if (*p != '"') return false;
  out[i] = 0; return true;
}

// ------------------------------------------------------------------------------------------ phone -> cart
enum class MsgKind : uint8_t { NONE, HELLO, MODE, JOY, SET, HOLD, CMD, NAVP, NAVGO, NAVHB };
enum class CmdKind : uint8_t { NONE, STOP, CLEAR, LEVEL, TRIP0 };
struct Msg {
  MsgKind kind = MsgKind::NONE;
  Mode mode = Mode::PARK;
  float joyX = 0, joyY = 0;
  bool hasFd = false, hasVm = false, hasDc = false, hasHh = false;
  float fd = 0, vm = 0, dc = 0; bool hh = true;
  bool hold = false;
  CmdKind cmd = CmdKind::NONE;
  int navI = 0, navN = 0; float navX = 0, navY = 0, navV = 0;     // route point i at (x, y); commit n points at speed v
};

// Limits (same as the app). Out-of-range values are CLAMPED, never rejected, and the cart echoes what it really applied.
static const float FD_MIN = 1.5f, FD_MAX = 6.0f, VM_MIN = 0.5f, VM_MAX = 1.6f, DC_MIN = 0.6f, DC_MAX = 1.6f;

inline bool parseMsg(const char* line, Msg& m) {
  m = Msg();
  if (!line || line[0] != '{') return false;
  char k[12];
  if (!getStr(line, "k", k, sizeof(k))) return false;
  if (!strcmp(k, "hello")) { m.kind = MsgKind::HELLO; return true; }
  if (!strcmp(k, "mode")) {
    char v[12]; if (!getStr(line, "m", v, sizeof(v))) return false;
    if (!strcmp(v, "park")) m.mode = Mode::PARK;
    else if (!strcmp(v, "follow")) m.mode = Mode::FOLLOW;
    else if (!strcmp(v, "manual")) m.mode = Mode::MANUAL;
    else if (!strcmp(v, "nav")) m.mode = Mode::NAV;
    else return false;                                   // unknown mode: ignore (never guess a driving mode)
    m.kind = MsgKind::MODE; return true;
  }
  if (!strcmp(k, "navp")) {                                // route point: {"k":"navp","i":2,"x":14.5,"y":-3.0}
    float i, x, y; if (!getNum(line, "i", &i) || !getNum(line, "x", &x) || !getNum(line, "y", &y)) return false;
    if (i < 0 || i >= NavController::MAXW) return false;
    m.navI = (int)i; m.navX = x; m.navY = y; m.kind = MsgKind::NAVP; return true;
  }
  if (!strcmp(k, "navgo")) {                               // make the staged points the route: {"k":"navgo","n":6,"v":1.0}
    float n, v; if (!getNum(line, "n", &n) || !getNum(line, "v", &v)) return false;
    if (n < 2 || n > NavController::MAXW) return false;
    m.navN = (int)n; m.navV = v; m.kind = MsgKind::NAVGO; return true;
  }
  if (!strcmp(k, "navhb")) { m.kind = MsgKind::NAVHB; return true; }     // the phone is still watching: keep driving
  if (!strcmp(k, "joy")) {
    float x, y; if (!getNum(line, "x", &x) || !getNum(line, "y", &y)) return false;
    m.joyX = clampv(x, -1.0f, 1.0f); m.joyY = clampv(y, 0.0f, 1.0f); m.kind = MsgKind::JOY; return true;
  }
  if (!strcmp(k, "set")) {
    float v;
    if (getNum(line, "fd", &v)) { m.fd = clampv(v, FD_MIN, FD_MAX); m.hasFd = true; }
    if (getNum(line, "vm", &v)) { m.vm = clampv(v, VM_MIN, VM_MAX); m.hasVm = true; }
    if (getNum(line, "dc", &v)) { m.dc = clampv(v, DC_MIN, DC_MAX); m.hasDc = true; }
    if (getNum(line, "hh", &v)) { m.hh = v >= 0.5f; m.hasHh = true; }
    m.kind = MsgKind::SET; return m.hasFd || m.hasVm || m.hasDc || m.hasHh;
  }
  if (!strcmp(k, "hold")) { float v; if (!getNum(line, "on", &v)) return false; m.hold = v >= 0.5f; m.kind = MsgKind::HOLD; return true; }
  if (!strcmp(k, "cmd")) {
    char c[12]; if (!getStr(line, "c", c, sizeof(c))) return false;
    if (!strcmp(c, "stop")) m.cmd = CmdKind::STOP;
    else if (!strcmp(c, "clear")) m.cmd = CmdKind::CLEAR;
    else if (!strcmp(c, "level")) m.cmd = CmdKind::LEVEL;
    else if (!strcmp(c, "trip0")) m.cmd = CmdKind::TRIP0;
    else return false;
    m.kind = MsgKind::CMD; return true;
  }
  return false;
}

// Collects bytes from the link into lines. Over-long lines are dropped whole (never half-parsed).
class LineBuffer {
 public:
  // returns true when a complete line is ready in line()
  bool push(char c) {
    if (c == '\r') return false;
    if (c == '\n') { bool ok = !over_ && n_ > 0; buf_[n_] = 0; if (!ok) { n_ = 0; over_ = false; return false; } n_ = 0; return true; }
    if (n_ + 1 >= sizeof(buf_)) { over_ = true; return false; }
    buf_[n_++] = c; return false;
  }
  const char* line() const { return buf_; }
 private:
  char buf_[256]; size_t n_ = 0; bool over_ = false;
};

// ------------------------------------------------------------------------------------------ cart -> phone
inline const char* modeName(Mode m) {
  switch (m) { case Mode::FOLLOW: return "follow"; case Mode::MANUAL: return "manual"; case Mode::NAV: return "nav"; default: return "park"; }   // FREE is never shown: park
}
struct TelData {
  Mode mode; float volts, soc, pitch, roll, speed, range, bearingDeg; bool bearingOk;
  int ml, mr, bk; float obs, tripM, totM; unsigned faults, flags;
  float yawDeg = 0; bool navOk = false; bool navShow = false; float navX = 0, navY = 0, navHeadDeg = 0; int navSeg = 0, navState = 0;   // route progress, sent while a route exists
};
inline int formatTel(char* b, size_t n, const TelData& t) {
  char brg[16]; if (t.bearingOk) snprintf(brg, sizeof(brg), "%.0f", t.bearingDeg); else snprintf(brg, sizeof(brg), "null");
  int len = snprintf(b, n,
    "{\"k\":\"tel\",\"m\":\"%s\",\"v\":%.1f,\"soc\":%d,\"pit\":%.1f,\"rol\":%.1f,\"spd\":%.2f,\"rng\":%.2f,\"brg\":%s,"
    "\"ml\":%d,\"mr\":%d,\"bk\":%d,\"obs\":%.2f,\"trip\":%.1f,\"tot\":%.0f,\"ft\":%u,\"fg\":%u,\"nr\":%d,\"yw\":%.1f",
    modeName(t.mode), t.volts, (int)(t.soc + 0.5f), t.pitch, t.roll, t.speed, t.range, brg,
    t.ml, t.mr, t.bk, t.obs, t.tripM, t.totM, t.faults, t.flags, t.navOk ? 1 : 0, t.yawDeg);
  if (len > 0 && (size_t)len < n && t.navShow)
    len += snprintf(b + len, n - len, ",\"nx\":%.1f,\"ny\":%.1f,\"nh\":%.0f,\"ni\":%d,\"ns\":%d", t.navX, t.navY, t.navHeadDeg, t.navSeg, t.navState);
  if (len > 0 && (size_t)len + 3 < n) { b[len++] = '}'; b[len++] = '\n'; b[len] = 0; }
  return len;
}
inline int formatCfg(char* b, size_t n, float fd, float vm, float dc, bool hh, const char* fw, bool navOk = false) {
  return snprintf(b, n, "{\"k\":\"cfg\",\"fd\":%.2f,\"vm\":%.2f,\"dc\":%.2f,\"hh\":%d,\"nav\":%d,\"fw\":\"%s\"}\n", fd, vm, dc, hh ? 1 : 0, navOk ? 1 : 0, fw);
}

// ------------------------------------------------------------------------------------------------- UWB lines
// The BU03 output format is NOT documented where I could read it, so this is a tolerant guess: find a key such as
// "dist", "distance", "range" or "dis" and read the number after it; a unit right after the number (mm / cm / m)
// overrides noScale (the factor to metres used when there is no unit). A line without such a key is ignored, so a wrong
// guess means "no reading" (the cart will not drive), never a wrong reading.
// When you have real BU03 lines, fix THIS function; tests/test_proto.cpp has a place to add them.
inline bool parseUwbLine(const char* line, float* metres, float noScale = 1.0f) {
  static const char* keys[] = {"distance", "dist", "range", "dis"};
  const char* best = nullptr;
  for (const char* k : keys) {
    size_t kl = strlen(k);
    for (const char* p = line; *p; p++) {
      size_t i = 0; while (i < kl && p[i] && tolower((unsigned char)p[i]) == k[i]) i++;
      if (i == kl) { if (!best || p < best) best = p + kl; break; }
    }
    if (best) break;                                        // longest key first: "distance" beats "dist" beats "dis"
  }
  if (!best) return false;
  const char* p = best;
  while (*p && !(isdigit((unsigned char)*p) || *p == '.' || *p == '-')) {
    if (p - best > 6) return false;                         // number must follow soon after the key (":", "=", " ", ...)
    p++;
  }
  char* end; float v = strtof(p, &end);
  if (end == p || !isfinite(v)) return false;
  float scale = noScale;
  const char* u = end; while (*u == ' ') u++;
  if (tolower((unsigned char)u[0]) == 'm' && tolower((unsigned char)u[1]) == 'm') scale = 0.001f;
  else if (tolower((unsigned char)u[0]) == 'c' && tolower((unsigned char)u[1]) == 'm') scale = 0.01f;
  else if (tolower((unsigned char)u[0]) == 'm') scale = 1.0f;
  float m = v * scale;
  if (!(m > 0.05f && m < 60.0f)) return false;              // RangeFilter would refuse these anyway; keep garbage out of the counters
  *metres = m; return true;
}

}  // namespace cart
