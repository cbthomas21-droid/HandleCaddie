# Handle Caddie

- `android/`  phone app + Wear OS watch app (Kotlin / Compose). Docs: README.md, BENCH_TEST.md, CART_PROTOCOL.md, WEAR_SETUP.md
- `cart/`     motorised cart firmware (ESP32), host tests and simulation
- `display/`  ESP32-S3 dashboard firmware

Every push is built by GitHub (Actions tab > "Build and test"). A green run gives you installable apps under "Artifacts" (HandleCaddie-apks);
a red run gives you the compile errors in the run summary and a build log to send on.
The display firmware needs the board's own graphics library, so GitHub only runs its logic test, not a full compile.
